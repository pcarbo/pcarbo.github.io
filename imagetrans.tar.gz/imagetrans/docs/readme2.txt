Some extra notes:
- The code for Normalized Cuts was not included in this package. You may 
  have to contact the original authors to get it.
- Before using the data, there is one important thing you need to do: 
  change the absolute directories in the "specs" files in each data set 
  you plan to use. Almost certainly you will not place the data in the 
  same absolute directory as I did.

Peter Carbonetto
April 24, 2003
