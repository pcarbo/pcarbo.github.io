package dispatch;

// ELIDE imports
import ca.ubc.cs.elide.*;
import ca.ubc.cs.elide.nodes.*;

// Java 1.2.2 imports
import java.util.Vector;
import java.util.Stack;
import java.util.LinkedList;
import java.util.StringTokenizer;
import java.lang.reflect.Modifier;

// DispatchedParameter
// ---------------------------------------------------------------------------------------
// Parameter in dispatched method.
class DispatchedParameter {

	// Fields.
	private ParameterNode param;
	private ClassNode     classType;
	
	// Constructors.
	
	public DispatchedParameter (ParameterNode param) {
		this.param     = param;
		this.classType = null;
	}
	
	public DispatchedParameter (ParameterNode param, ClassNode classType) {
		this.param     = param;
		this.classType = classType;
	}
	
	// Accessors.
	public ParameterNode getParameter () { return param; }
	public ClassNode getClassType () { return classType; }
	public boolean isPolymorphic() { 
		if (classType == null) 
			return false;
		else
			return true;
	}
	
	// Methods.

	public DispatchedParameter copy () {
		return new DispatchedParameter (this.param, this.classType);
	}
	
	// Two parameters are equal if their types are the same.
	public boolean equals (DispatchedParameter dp) {
		return dp.getParameter().getType().equals (param.getType());
	}
	
	public void setClassType (ClassNode classType) { 
		this.classType = classType;
	}
	
	public void print () {
		if (param == null)
			System.out.print ("receiver");
		else
			System.out.print (param.getName());
		if (classType != null)
			System.out.print ("*");			
	}

	public void printPrototype () {
		if (param == null)
			System.out.print (classType.getName());
		else
			System.out.print (param.getType());
		if (classType != null)
			System.out.print ("*");			
	}
}

// MethodEntry
// ---------------------------------------------------------------------------------------
// Superclass for method entry definitions.
class MethodEntry { 
	public void print() { }
}

// NoDispatchedMethodDefined
// ---------------------------------------------------------------------------------------
// Signifies that a dispatched method is not defined. 
class NoDispatchedMethodDefined extends MethodEntry { 

	public void print() { 
		System.out.print("No method");
	}
}

// AmbiguousDispatchDefinition
// ---------------------------------------------------------------------------------------
// Signifies that a dispatched method is ambigious. 
class AmbiguousDispatchDefinition extends MethodEntry {

	public void print() { 
		System.out.print("Ambigious");
	}
}

// DispatchedMethod
// ---------------------------------------------------------------------------------------
// Method for dispatching.
class DispatchedMethod extends MethodEntry {

	// Fields.
	MethodNode            method;
	DispatchedParameter[] params;
	DispatchedParameter[] dspParams;

	// Constructor.
	public DispatchedMethod (MethodNode method, boolean[] isDispatched) {
		this.method = method;
		
		// Get the method's parameters.
		ParameterNode[] prms = method.getParameters();
		
		// Get the method's declaring class.
		ClassNode cls = method.getDeclaringClass();
		
		// Find out how many parameters are dispatched.
		int n = 1; // Don't forget the type of the declaring class.
		for (int i = 0; i < isDispatched.length; i++)
			if (isDispatched[i])
				n++;
		
		// Create the DispatchedParameter objects.
		params    = new DispatchedParameter[prms.length + 1];
		dspParams = new DispatchedParameter[n];
		
		// Add the declaring class type.
		dspParams[0] = params[0] = new DispatchedParameter (null, cls);
		
		// Add the rest of the parameters.
		int j = 1;
		for (int i = 0; i < prms.length; i++) {
			ParameterNode prm = prms[i];
		
			if (isDispatched[i]) {
				// Get the associated ClassNode.
				ClassNode clsNd = ClassNode.forName (prm.getType(), prm);
				
				// Create the dispatched parameter.
				if (clsNd == null) {
					System.out.println ("Invalid class for parameter " + prm);
					params[i+1] = null;
				}
				else
					params[i+1] = dspParams[j++] = new DispatchedParameter (prm, clsNd);
			}
			else
				params[i+1] = new DispatchedParameter (prm);
		}
	}
	
	// Accessors.

	public MethodNode getMethod () { return method; }
	public DispatchedParameter[] getParameters () { return params; }
	public DispatchedParameter[] getDispatchedParams () { return dspParams; }

	public ClassNode[] getDispatchedTypes () {
		ClassNode[] result = new ClassNode [dspParams.length];
		
		for (int i = 0; i < result.length; i++)
			result[i] = dspParams[i].getClassType();
			
		return result;
	}
	
	public boolean[] whichAreDispatched () {
		boolean[] result = new boolean[params.length - 1];
		
		for (int i = 0; i < result.length; i++) {
			if (params[i+1].getClassType() == null)
				result[i] = false;
			else
				result[i] = true;
		}
		
		return result;
	}
	
	// Methods.

	public DispatchedMethod copy () {
		return new DispatchedMethod (this.method, this.whichAreDispatched());
	}		

	// Two dispatched methods are equal if:
	//   1. The method names are equal.
	//   2. The return types are equal.
	//   3. There are the same number of parameters.
	//   3. The non-polymorphic parameters have the same types.
	public boolean equals (DispatchedMethod dm) {
		return equals (dm.getMethod());
	}
	
	public boolean equals (MethodNode m) {
		
		// Check the method names.
		if (!m.getName().equals (this.method.getName()))
			return false;
		
		// Check the return types.
		if (!m.getReturnType().equals (this.method.getReturnType()))
			return false;
			
		// Check the number of parameters.
		ParameterNode[] params1 = this.method.getParameters();
		ParameterNode[] params2 = m.getParameters();
		if (params2.length != params1.length)
			return false;
			
		// Check the non-polymorphic parameter types.
		for (int i = 0; i < params1.length; i++)
			if (!params[i].isPolymorphic() &&
					!params1[i].equals (params2[i]))
				return false;
		
		// If all those tests did not fail, then they must be equal.
		return true;
	}
	
	public void print () {
	
		// Print the name of the method.
		System.out.print (method.getName() + " (");

		// Print the parameters.
		for (int i = 0; i < params.length; i++) {
			params[i].print();
			System.out.print (" ");
		}
		
		System.out.print (")");
	}
	
	public void printPrototype () {
	
		// Print the name of the method.
		System.out.print (method.getName() + " (");

		// Print the parameters.
		for (int i = 0; i < params.length; i++) {
			params[i].printPrototype();
			System.out.print (" ");
		}
		
		System.out.println(")");
	}
}

// HierClassNode
// ---------------------------------------------------------------------------------------
// Describes a node in the class hierarchy.
class HierClassNode {

	// Fields.
	private ClassNode     cls;      // The class represented by this node.
 	private HierClassNode parent;   // The parent class of the node.
	private Vector        children; // The children of the class node.

 	// Constructors.
 	 	
 	// Use this one to create the root node.
 	public HierClassNode (ClassNode cls) {
 		initialize (cls);
 	}
 	
 	// Use this one to create a non-root node.
 	public HierClassNode (ClassNode cls, HierClassNode parent) {
 	  initialize (cls);
 	  setParent (parent);
 	}

 	// Accessors. 	

	// Return the classNode object.
 	public ClassNode getClassNode ()   { return cls; }

	// Return the parent of this node in the hierarchy.
 	public HierClassNode getParent ()  { return parent; }

 	// Return the children of this node as an array of HierClassNode objects.
 	public HierClassNode[] getChildren() {
 		// Create the new empty array of HierClassNode objects.
		HierClassNode[] result = new HierClassNode[children.size()];
		
		// Fill in the array.
		for (int i = 0; i < result.length; i++)
			result[i] = (HierClassNode) children.elementAt(i);
			
		return result;
	}
	
	// Methods.
	
	// Add a child to the list of children.
	public void addChild (HierClassNode child) { children.addElement (child); }

	public void setParent (HierClassNode prn) { parent = prn; }		
	
	// Print out this object.
	public void print () {
		System.out.print (cls.getName());
	}
	
	// Private methods.
	private void initialize (ClassNode cls) {
 		this.cls      = cls;
 		this.parent   = null;
 		this.children = new Vector();
	}
}

// HierPolyClassNode
// ---------------------------------------------------------------------------------------
// Describes a node in the poly class-type hierarchy.
class HierPolyClassNode {

	// Fields.
	public    int             marker;
	protected HierClassNode[] nodes;
	protected boolean         isRoot;
	protected Vector          parents;
  protected Vector          children;
	
	// Constructors.
	
	public HierPolyClassNode (HierClassNode[] clsNodes) {
		initialize (clsNodes);
	}
	
	public HierPolyClassNode (ClassNode[] clses) {
		// Add the classes to the node.
		nodes = new HierClassNode[clses.length];
		for (int i = 0; i < nodes.length; i++)
			nodes[i] = new HierClassNode (clses[i]);
			
		initialize (nodes);
	}
	
	// Accessors.
	
	// Return the dimension of the poly-type.
	public int dim() { return nodes.length; }
	
	// Return the set of HierClassNodes.
	public HierClassNode[] getHierClasses() { return nodes; }
	
	// Return the set of class types represented by this node.
	public ClassNode[] getClassNodes() {
		ClassNode[] result = new ClassNode[nodes.length];
		
		for (int i = 0; i < result.length; i++)
			result[i] = nodes[i].getClassNode();
			
		return result;
	}
	
	// Get a list of the parent nodes.
	public HierPolyClassNode[] getParents() {
		HierPolyClassNode[] result = new HierPolyClassNode[parents.size()];

		for (int i = 0; i < result.length; i++)
			result[i] = (HierPolyClassNode) parents.elementAt(i);
			
		return result;
	}
		
	// Get a list of the children nodes.
	public HierPolyClassNode[] getChildren() {
		HierPolyClassNode[] result = new HierPolyClassNode[children.size()];

		for (int i = 0; i < result.length; i++)
			result[i] = (HierPolyClassNode) children.elementAt(i);
			
		return result;
	}
	
	// Methods.	

	public void addParent (HierPolyClassNode parent) { 
		isRoot = false;
		parents.addElement (parent); 
	}

	// Add a child to the list of children.
	public void addChild (HierPolyClassNode child) { 
		children.addElement (child); 
	}
	
	public void print () {

		System.out.println();
		System.out.print ("Polytype " + marker + " ( ");
	
		// Print poly class-type.
		for (int i = 0; i < nodes.length; i++) {
			nodes[i].print();
			System.out.print (" ");
		}
		System.out.println(")");
		
		// Print parents.
		System.out.print ("  Parents: ");
		HierPolyClassNode[] parents = getParents();
		for (int i = 0; i < parents.length; i++)
			System.out.print ("(" + parents[i].marker + ") ");
		System.out.println();
		
		// Print children.
		System.out.print ("  Children: ");
		HierPolyClassNode[] children = getChildren();
		for (int i = 0; i < children.length; i++)
			System.out.print ("(" + children[i].marker + ") ");
		System.out.println();
	}

	// Private methods.
	private void initialize (HierClassNode[] clsNodes) {
		isRoot   = true;
		marker   = 0;
		parents  = new Vector();
		children = new Vector();
		nodes    = clsNodes;
	}	
}

// HierMethodPolyClassNode
// ---------------------------------------------------------------------------------------
// Describes a node in the poly class-type hierarchy with a MethodNode object.
class HierMethodPolyClassNode extends HierPolyClassNode {

	// Fields.
	private DispatchedMethod method;
	
	// Constructors.

	public HierMethodPolyClassNode (HierClassNode[] clsNodes) { 
		super (clsNodes); 
		this.method = null;
	}
	
	public HierMethodPolyClassNode (HierClassNode[] clsNodes, DispatchedMethod method) { 
		super (clsNodes); 
		this.method = method;
	}
	
	public HierMethodPolyClassNode (ClassNode[] clses) { 
		super (clses); 
		this.method = null;
	}
	
	public HierMethodPolyClassNode (ClassNode[] clses, DispatchedMethod method) { 
		super (clses); 
		this.method = method;
	}
	
	// Accessors.
	public DispatchedMethod getMethod () { return method; }
	
	// Methods.
	
	// Return "true" if we are overriding a previously-defined method. 
	// We are warning the user about ambiguities.
	public boolean setMethod (DispatchedMethod method) {
		if (this.method == null) {
			this.method = method;
			return false;
		}
		else {
			System.out.println ("Ambiguity caused by methods " + this.method.getMethod().getName() + 
			  " and " + method.getMethod().getName() + 
			  ". The former overrides the latter, but may be inconsistent with desired results.");
			return true;
		}
	}
	
	// Go up the tree, finding the closest method.
	public MethodEntry findClosestMethod () {
	
		// If we found a method, just return that.
		if (method != null)
			return method;
		// Otherwise, we have to check the parents to see if they
		// have a method.
		else {
			MethodEntry foundMtd = new NoDispatchedMethodDefined();
			for (int i = 0; i < parents.size(); i++) {
				HierMethodPolyClassNode prn = (HierMethodPolyClassNode) parents.elementAt(i);
				MethodEntry newFoundMtd = prn.findClosestMethod();
				
				if (newFoundMtd instanceof AmbiguousDispatchDefinition)
					return newFoundMtd;
				else if ((newFoundMtd instanceof DispatchedMethod) && 
								 (foundMtd instanceof DispatchedMethod) &&
								 (foundMtd != newFoundMtd))
					return new AmbiguousDispatchDefinition();
				else
					foundMtd = newFoundMtd;
			}
			
			return foundMtd;
		}
	}
	
	public void print () {
		super.print();
		if (method != null) {
			System.out.print ("Method: ");
			method.print();
			System.out.println();
		}
	}
}
	
// ClassHierarchy
// ---------------------------------------------------------------------------------------
// Describes the hierarchy of class nodes.
class ClassHierarchy {

	// Fields.
	private HierClassNode root;	  // The root of the hierarchy.
	private Vector        nodes;  // All the nodes in the hierarchy.

	// Constructors.

  public ClassHierarchy (HierClassNode clsNode) { initialize (clsNode); }
	
	public ClassHierarchy (ClassNode cls) {
		root = new HierClassNode (cls);
		initialize (root);
  }
  
	// Accessors.
	public HierClassNode getRoot() { return root; }
	public HierClassNode elementAt (int i) {
		return (HierClassNode) nodes.elementAt(i);
	}
	
	// Methods.

	// Get the node in the hierarchy that corresponds to that class.
	// If it can't be found, returns null.
	public HierClassNode findClass (ClassNode cls) {
	
		for (int i = 0; i < nodes.size(); i++) {
			HierClassNode node = (HierClassNode) nodes.elementAt(i);
			if (cls == node.getClassNode())
				return node;
		}
				
		return null;
	}

	// Returns HierClassNode object if the class was added to the hierarchy 
	// or if the class already exists. Returns null if it's not a strict 
	// subclass of the root.
	public HierClassNode addClass (ClassNode cls) {
		return addClass (new HierClassNode (cls));
	}

	// Returns HierClassNode object if the class was added to the hierarchy 
	// or if the class already exists. Returns null if it's not a strict 
	// subclass of the root.
	public HierClassNode addClass (HierClassNode clsNode) {
	
		// Check to see if the class already exists in the hierarchy.
		// If so, we just return "true" and we're done.
		HierClassNode foundNode = findClass (clsNode.getClassNode());
		if (foundNode != null)
			return foundNode;

		// We need to find the parent of the class
		// in the class hierarchy and add it.
		ClassNode parent = grabParent (clsNode.getClassNode());
		
		// If it does not have a parent, return null.
		if (parent == null)
			return null;
		
		// If the parent was added successfully, then we can add the 
		// child.
		HierClassNode newPrn = addClass (parent);
		if (newPrn == null)
			return null;
			
		putClassInHierarchy (clsNode, newPrn);
		return clsNode;
	}

	// Returns "true" if c1 is a superclass of c2. Otherwise, 
	// returns "false".
	public boolean isSuperclass (ClassNode c1, ClassNode c2) {
		return isSuperclass (findClass (c1), findClass (c2));
	}
		
	// Returns "true" if c1 is a subclass of c2. Otherwise, 
	// returns "false".
	public boolean isSubclass (ClassNode c1, ClassNode c2) {
		return isSubclass (findClass (c1), findClass (c2));
	}

	// Returns "true" if c1 is a superclass of c2. Otherwise, 
	// returns "false".
	public boolean isSuperclass (HierClassNode n1, HierClassNode n2) {

		if (n1 == n2) 
			return true;
		else {
		
			// Look at all the children.
			HierClassNode[] children = n1.getChildren();
			for (int i = 0; i < children.length; i++)
				if (isSuperclass (children[i], n2))
					return true;
		}
		
		// We didn't find a child that is the same as "c2", so it's not
		// a superclass.
		return false;
	}

	// Returns "true" if c1 is a subclass of c2. Otherwise, 
	// returns "false".
	public boolean isSubclass (HierClassNode n1, HierClassNode n2) {
		return isSuperclass (n2, n1);
	}
		
	// Return an array of classes in breadth-first search order
	// from the root. It will return an array where item i+1 is always
	// a (non-strict) subclass of item i.
	public ClassNode[] listClassesBFS () {
		
		// Create the empty array of class nodes.
		ClassNode[] result = new ClassNode[nodes.size()];
		
		// Create a queue and put the root on it.
		LinkedList clsQueue = new LinkedList();
		clsQueue.addLast (root);
				
		// Repeat until there are no more nodes to look at.
		// We always put the children of a node at the end of the 
		// queue so we make sure to look at the classes that are
		// higher up in the hierarchy first.
		int n = 0;
		while (clsQueue.size() > 0) {
		
			// Get the first item in the queue and add it to our array.
			HierClassNode curCls = (HierClassNode) clsQueue.removeFirst();
			result[n++] = curCls.getClassNode();
			
			// Now add it's children to the end of the queue.
			HierClassNode[] children = curCls.getChildren();
			for (int i = 0; i < children.length; i++)
				clsQueue.addLast (children[i]);
		}
		
		return result;
	}
	
	// Print out the list of classes in depth-first search order.
	public void printClassesDFS () {
		printClassesDFS_Helper (root, "");
	}
	
	// Private methods.
	
  private void initialize (HierClassNode clsNode) {
  	root  = clsNode;
  	nodes = new Vector();
  	nodes.addElement (root);
  }
    
	public static ClassNode grabParent (ClassNode cls) {
		String prnStr = cls.getSuperclass();
		return ClassNode.forName(prnStr, cls);
	}
		
	private void printClassesDFS_Helper (HierClassNode curNode, String indent) {
	
		// Print out the current node.
		System.out.println(indent + curNode.getClassNode().getName());
		
		// Print out the children of the current node.
		HierClassNode[] children = curNode.getChildren();
		for (int i = 0; i < children.length; i++)
			printClassesDFS_Helper (children[i], indent.concat ("   "));
	}
	
	// Adds a child to the node "prn".
	private void putClassInHierarchy (HierClassNode cls, HierClassNode prn) {	
		nodes.addElement (cls);
		prn.addChild (cls);
		cls.setParent (prn);
	}	
}

// PolyClassHierarchy
// ---------------------------------------------------------------------------------------
// Describes the hierarchy of poly class-type nodes.
class PolyClassHierarchy {

	// Fields.
	protected HierPolyClassNode root;
	protected ClassHierarchy[]  clsHrchies;
	protected Vector            nodes;
	
	// Constructors.
	public PolyClassHierarchy (HierPolyClassNode clsesNode) { 
		initialize (clsesNode); 
	}	
	
	// Accessors.
	public int dim() { return root.dim(); }
	public ClassHierarchy[] getClassHierarchies () { return clsHrchies; }
	public HierPolyClassNode getRoot () { return root; }
	public HierPolyClassNode[] getNodes () { 
		HierPolyClassNode[] result = new HierPolyClassNode[nodes.size()];
		for (int i = 0; i < result.length; i++)
			result[i] = (HierPolyClassNode) nodes.elementAt(i);
		return result; 
	}
	public int getNumberOfNodes () { return nodes.size(); }
	public HierPolyClassNode elementAt (int i) {
		return (HierPolyClassNode) nodes.elementAt(i);
	}
	
	// Methods.

	// Get the node in the hierarchy that corresponds to that poly 
	// class-type. If it can't be found, returns null.
	public HierPolyClassNode findPolyClass (ClassNode[] clses) {
	
		for (int i = 0; i < nodes.size(); i++) {
			ClassNode[] clses2 = ((HierPolyClassNode) nodes.elementAt(i)).getClassNodes();
			
			// Check all the classes in the poly class-type node and return
			// true if they all match.
			boolean good = true;
			for (int j = 0; j < dim(); j++)
			  if (clses[j] != clses2[j]) {
			  	good = false;
			  	break;
			  }
			  
			if (good)
				return (HierPolyClassNode) nodes.elementAt(i);
		}
	
		return null;
	}
	
	// Get the node in the hierarchy that corresponds to that poly 
	// class-type. If it can't be found, returns null.
	public HierPolyClassNode findPolyClass (HierClassNode[] clses) {
	
		for (int i = 0; i < nodes.size(); i++) {
			HierClassNode[] clses2 = ((HierPolyClassNode) nodes.elementAt(i)).getHierClasses();
			
			// Check all the classes in the poly class-type node and return
			// true if they all match.
			boolean good = true;
			for (int j = 0; j < dim(); j++)
			  if (clses[j] != clses2[j]) {
			  	good = false;
			  	break;
			  }
			  
			if (good)
				return (HierPolyClassNode) nodes.elementAt(i);
		}
	
		return null;
	}	
	
	// Return true if object was added to the hierarchy or if it
	// already exists. Return false if it couldn't be added.
	private boolean spawnClass (HierClassNode clsNode, int whichParam) {
	
		// First see if the type already exists in the 
		// hierarchy. If so, just return "true"!
		ClassHierarchy clsHrchy = clsHrchies[whichParam];
		if (clsHrchy.findClass (clsNode.getClassNode()) != null)
			return true;
			
		// Otherwise, we have to do several things. The first thing
		// we need to do is add the parent to the hierarchy.
		ClassNode parent = clsHrchy.grabParent (clsNode.getClassNode());
		if (parent == null)
			return false;
		if (!spawnClass (new HierClassNode (parent), whichParam))
			return false;
			
		// Since the parent was successfully added to the hierarchy,
		// we can now add the current class to the hierarchy.
		// First we add it to the single-type hierarchy.
		clsHrchy.addClass (clsNode);
		
		// Next, we spawn it to the poly-type hierarchy.
		for (int i = 0; i < nodes.size(); i++) {
			HierPolyClassNode curNode = (HierPolyClassNode) nodes.elementAt(i);
			if (curNode.getClassNodes()[whichParam] == parent) {
			
				// Create the classes list for the new poly-type node.
				HierClassNode[]    clsList = curNode.getHierClasses();
				HierClassNode[] newClsList = new HierClassNode [clsList.length];
				for (int j = 0; j < newClsList.length; j++)
					newClsList[j] = clsList[j];
				newClsList[whichParam] = clsNode;
				
				// See if the poly-type already exists.
				HierPolyClassNode newNode = findPolyClass (newClsList);
				if (newNode == null) {
					// Create the new poly-type.
					newNode = new HierPolyClassNode (newClsList);
					int marker = nodes.size();
					nodes.addElement (newNode);
					newNode.marker = marker;
				}
							
				// Add the poly-type to the hierarchy.
				curNode.addChild (newNode);
				newNode.addParent (curNode);
			}
		}
		
		return true;
	}
	
	// Returns HierPolyClassNode object if the polyclass was added to the hierarchy 
	// or if the polyclass already exists. Returns null if it's not a strict 
	// subclass of the root.
	public HierPolyClassNode addPolyClass (HierPolyClassNode clsesNode) {

		// Check to see if we have the right number of parameters.
		if (clsesNode.dim() != dim())
			return null;
	
		// Check to see if the class already exists in the hierarchy.
		// If so, we just return "true" and we're done.
		HierPolyClassNode foundNode = findPolyClass (clsesNode.getClassNodes());
		if (foundNode != null)
			return foundNode;

		// Spawn the single-type nodes in the poly-type hierarchy
		// and add them to the single-type hierarchies.
		HierClassNode[] nodes = clsesNode.getHierClasses();
		for (int i = 0; i < nodes.length; i++) {
			if (!spawnClass (nodes[i], i))
				return null;
		}
		
		// Find the poly-class in the poly-hierarchy and return it.
		HierPolyClassNode result = findPolyClass (clsesNode.getClassNodes());
		return result;
	}

	// Returns "true" if c1 is a superclass of c2. Otherwise, 
	// returns "false".
	public boolean isSuperclass (ClassNode[] c1, ClassNode[] c2) {
		return isSuperclass (findPolyClass (c1), findPolyClass (c2));
	}
		
	// Returns "true" if c1 is a subclass of c2. Otherwise, 
	// returns "false".
	public boolean isSubclass (ClassNode[] c1, ClassNode[] c2) {
		return isSubclass (findPolyClass (c1), findPolyClass (c2));
	}

	// Returns "true" if c1 is a superclass of c2. Otherwise, 
	// returns "false".
	public boolean isSuperclass (HierPolyClassNode n1, HierPolyClassNode n2) {
		if (n1 == n2)
			return true;
		else {
		
			// Look at all the children.
			HierPolyClassNode[] children = n1.getChildren();
			for (int i = 0; i < children.length; i++)
				if (isSuperclass (children[i], n2))
					return true;
		}
		
		// We didn't find a child that is the same as "c2", so it's not
		// a superclass.
		return false;
	}

	// Returns "true" if c1 is a subclass of c2. Otherwise, 
	// returns "false".
	public boolean isSubclass (HierPolyClassNode n1, HierPolyClassNode n2) {
		return isSuperclass (n2, n1);
	}

	// Return the list of classes for each hierarchy.
	public ClassNode[][] listClassesBFS () {
	
		ClassNode[][] result = new ClassNode[clsHrchies.length][];
		for (int i = 0; i < clsHrchies.length; i++)
			result[i] = clsHrchies[i].listClassesBFS();
			
		return result;
	}

	// Print out the list of classes in breadth-first search order.
	public void printClassesBFS () {

		System.out.println ();
		System.out.println ("Uni-type hierarchies: ");
		
		for (int i = 0; i < clsHrchies.length; i++) {
			System.out.println();
			clsHrchies[i].printClassesDFS();
		}
		
		System.out.println ();
		System.out.println ("Poly-type hierarchy: ");

		// We need to keep track of which classes we've printed 
		// so we don't print them twice.
		boolean[] printed = new boolean[nodes.size()];
		for (int i = 0; i < printed.length; i++)
			printed[i] = false;

		// Create a queue and put the root on it.
		LinkedList clsQueue = new LinkedList();
		clsQueue.addLast (root);
				
		// Repeat until there are no more nodes to look at.
		// We always put the children of a node at the end of the 
		// queue so we make sure to look at the classes that are
		// higher up in the hierarchy first.
		int n = 0;
		while (clsQueue.size() > 0) {
		
			// Get the first item in the queue and add it to our array.
			HierPolyClassNode curCls = (HierPolyClassNode) clsQueue.removeFirst();
			if (!printed[curCls.marker]) {
				curCls.print();
			
				// Now add it's children to the end of the queue.
				HierPolyClassNode[] children = curCls.getChildren();
				for (int i = 0; i < children.length; i++)
					clsQueue.addLast (children[i]);

				printed[curCls.marker] = true;
			}
		}
		
	}
	
	// Private methods.

	private void initialize (HierPolyClassNode clsesNode) {
		root       = clsesNode;
		nodes      = new Vector();
		clsHrchies = new ClassHierarchy[root.dim()];

		nodes.addElement (root);

		// Create the class hierarchies.
		HierClassNode[] hierClses = clsesNode.getHierClasses();
		for (int i = 0; i < clsHrchies.length; i++)
			clsHrchies[i] = new ClassHierarchy (hierClses[i]);
	}
		
	// Adds a child to the node "prn". Returns the object of type
	// HierPolyClassNode that is added to the hierarchy.
	protected void putPolyClassInHierarchy (HierPolyClassNode cls, HierPolyClassNode[] prns) {		

		// Create the new HierPolyClassNode object.
		int marker = nodes.size();
		nodes.addElement (cls);
		cls.marker = marker;
		
		// Update the children and parent pointers.
		for (int i = 0; i < prns.length; i++)
			if (prns[i] != null) {
				prns[i].addChild (cls);
				cls.addParent (prns[i]);
			}
	}

	protected static ClassNode[] grabParent (ClassNode[] clses, int whichParent) {
	
		// Grab the parent for the chosen class-type.
		String prnStr = clses[whichParent].getSuperclass();
		ClassNode parent = ClassNode.forName(prnStr, clses[whichParent]);
		
		if (parent == null)
			return null;
		
		// Build the new set of classes;
		ClassNode[] result = new ClassNode[clses.length];
		for (int i = 0; i < result.length; i++)
			result[i] = clses[i];
		result[whichParent] = parent;
		
		return result;
	}
}

// MethodPolyClassHrchy
// ---------------------------------------------------------------------------------------
// Describes the hierarchy of poly class-type nodes with the addition of methods.
class MethodPolyClassHrchy extends PolyClassHierarchy {

	// Fields.
	protected Vector             methods;
	protected DispatchedMethod   prototype;
	
	// Constructors.
	public MethodPolyClassHrchy (DispatchedMethod method) {
		super (new HierMethodPolyClassNode (method.getDispatchedTypes()));
		prototype	= method;
		methods   = new Vector();
	}
	
	// Accessors.
	public DispatchedMethod getPrototype () { return prototype; }
	
	public DispatchedMethod[] getMethods () {
		DispatchedMethod[] result = new DispatchedMethod[methods.size()];
		
		for (int i = 0; i < result.length; i++)
			result[i] = (DispatchedMethod) methods.elementAt(i);
			
		return result;
	}
	
	// Methods.
	
	// Return true if object was added to the hierarchy or if it
	// already exists. Return false if it couldn't be added.
	private boolean spawnClass (HierClassNode clsNode, int whichParam) {
	
		// First see if the type already exists in the 
		// hierarchy. If so, just return "true"!
		ClassHierarchy clsHrchy = clsHrchies[whichParam];
		if (clsHrchy.findClass (clsNode.getClassNode()) != null)
			return true;
			
		// Otherwise, we have to do several things. The first thing
		// we need to do is add the parent to the hierarchy.
		ClassNode parent = clsHrchy.grabParent (clsNode.getClassNode());
		if (parent == null)
			return false;
		if (!spawnClass (new HierClassNode (parent), whichParam))
			return false;
			
		// Since the parent was successfully added to the hierarchy,
		// we can now add the current class to the hierarchy.
		// First we add it to the single-type hierarchy.
		clsHrchy.addClass (clsNode);
		
		// Next, we spawn it to the poly-type hierarchy.
		for (int i = 0; i < nodes.size(); i++) {
			HierMethodPolyClassNode curNode = (HierMethodPolyClassNode) nodes.elementAt(i);
			if (curNode.getClassNodes()[whichParam] == parent) {
			
				// Create the classes list for the new poly-type node.
				HierClassNode[]    clsList = curNode.getHierClasses();
				HierClassNode[] newClsList = new HierClassNode [clsList.length];
				for (int j = 0; j < newClsList.length; j++)
					newClsList[j] = clsList[j];
				newClsList[whichParam] = clsNode;
				
				// See if the poly-type already exists.
				HierMethodPolyClassNode newNode = (HierMethodPolyClassNode) findPolyClass (newClsList);
				if (newNode == null) {
					// Create the new poly-type.
					newNode = new HierMethodPolyClassNode (newClsList);

					// We need to find the parents of the class
					// in the class hierarchy and add them. At most,
					// there will be as many parents as the number of 
					// classes in the list. If none of the classes have 
					// parents then return null.
					ClassNode[][] parents = new ClassNode[dim()][];
					ClassNode[] clses     = newNode.getClassNodes();
					for (int j = 0; j < parents.length; j++) {
						parents[j] = PolyClassHierarchy.grabParent (clses, j);
					}
							
					// Create the parent classes (if they are not already created).
					// As soon as one parent is added successfully, we can add the 
					// child.
					HierMethodPolyClassNode[] prnNodes = new HierMethodPolyClassNode[parents.length];
					for (int j = 0; j < prnNodes.length; j++) {
						if (parents[j] != null)
							prnNodes[j] = (HierMethodPolyClassNode) findPolyClass (parents[j]);						
						else
							prnNodes[j] = null;
					}

					putPolyClassInHierarchy (newNode, prnNodes);
				}
			}
		}
		
		return true;
	}
	
	// Returns HierPolyClassNode object if the polyclass was added to the hierarchy 
	// or if the polyclass already exists. Returns null if it's not a strict 
	// subclass of the root.
	public HierMethodPolyClassNode addPolyClass (HierMethodPolyClassNode clsesNode) {

		// Check to see if we have the right number of parameters.
		if (clsesNode.dim() != dim())
			return null;
	
		// Check to see if the class already exists in the hierarchy.
		// If so, we just return "true" and we're done.
		HierMethodPolyClassNode foundNode = (HierMethodPolyClassNode)
			findPolyClass (clsesNode.getClassNodes());
		if (foundNode != null)
			return foundNode;

		// Spawn the single-type nodes in the poly-type hierarchy
		// and add them to the single-type hierarchies.
		HierClassNode[] nodes = clsesNode.getHierClasses();
		for (int i = 0; i < nodes.length; i++) {
			if (!spawnClass (nodes[i], i))
				return null;
		}
		
		// Find the poly-class in the poly-hierarchy and return it.
		HierMethodPolyClassNode result = (HierMethodPolyClassNode) 
			findPolyClass (clsesNode.getClassNodes());
		return result;
	}

	// Returns true if the method was added.
	public boolean addMethod (MethodNode method) {
		
		// Add the method.
		DispatchedMethod newDM = new DispatchedMethod (method, prototype.whichAreDispatched());
		
		// Add the class corresponding to the method.
		HierMethodPolyClassNode newNode = addPolyClass 
			(new HierMethodPolyClassNode (newDM.getDispatchedTypes()));

		if (newNode == null) {
			System.out.println ("Class polytype is not a poly-subclass of prototype method; " +
													"method cannot be included for dispatch.");
			return false;
		}
		else {
			boolean result = newNode.setMethod (newDM);
			if (!result) {
				methods.addElement (newDM);
				return true;
			}
			else
				return false;
		}	
	}		

	public void print () {
	
		// Print the method prototype.
		System.out.print ("Prototype method: ");
		prototype.printPrototype();
		System.out.println();
	
		// Print the classes.
		printClassesBFS();
	}
		
	// Private methods.
	
	protected void putPolyClassInHierarchy (HierMethodPolyClassNode cls, 
																					HierMethodPolyClassNode[] prns) {		

		// Create the new HierPolyClassNode object.
		int marker = nodes.size();
		nodes.addElement (cls);
		cls.marker = marker;
		
		// Update the children and parent pointers.
		for (int i = 0; i < prns.length; i++)
			if (prns[i] != null) {
				prns[i].addChild (cls);
				cls.addParent (prns[i]);
			}
	}
}

// DispatchTable
// ---------------------------------------------------------------------------------------
// Contains the dispatch table. 
class DispatchTable {
	private Vector  types;   // Vector of ClassNode objects.
	private Vector  table;   // Contains another DispatchTable.
	private MethodEntry m;   // Contains either the objects: DispatchedMethod, 
													 // NoDispatchedMethodDefined, AmbiguousDispatchDefinition or
													 // null. It is null if the en has not been updated yet.
	private int     level;   // The dispatch level. There are a number of levels equal
	             					   // to the number of parameters. Level 0 is the receiver
	             		 			   // The highest level is the method to dispatch on.
	private int     numLvls; // The number of parameters to dispatch on, including the receiver.
	private HierMethodPolyClassNode hNode; // Associated polytype node in hierarchy.

	// Constructor.
	// The first dimension of the array is the class hierarchy. The second dimension
	// is the class types in that hierarchy.
  public DispatchTable (MethodPolyClassHrchy h) {
  
  	// Initialize the table.
  	initialize (h.getClassHierarchies().length, 0);
  
  	// To add all the types, simply add the polytypes.
  	for (int i = 0; i < h.getNumberOfNodes(); i++) {
  		HierMethodPolyClassNode hNode = (HierMethodPolyClassNode) h.elementAt(i);
  		addPolyType (hNode);
  	}	
  }

  public DispatchTable (int numLevels, int curLevel)
  {	initialize (numLevels, curLevel); }

	// Accessors.

	public DispatchTable getTableFor (ClassNode type) {
	
		for (int i = 0; i < types.size(); i++)
			if (type == (ClassNode) types.elementAt(i))
				return (DispatchTable) table.elementAt(i);
	
		return null;
	}
	
	// Return null if the method cannot be found for whatever reason.
	public MethodEntry getMethodFor (ClassNode[] paramTypes) {
		if (paramTypes.length != numLvls)
			return null;

		if (paramTypes.length == level)
			return m;
		else {
			DispatchTable dt = getTableFor (paramTypes[level]);
			if (dt == null)
				return null;
			else
				return dt.getMethodFor (paramTypes);
		}
	}
	
	// Methods.
	
	// Copy the object.	
	public DispatchTable copy () {
		DispatchTable result = new DispatchTable (numLvls, level);
		
		if (numLvls == level) {		
			// We're at the last level so there's not much to do.
		}
		else {
			for (int i = 0; i < table.size(); i++)
				result.addTableEntry ((ClassNode) types.elementAt(i), 
															((DispatchTable) table.elementAt(i)).copy());
		}
		
		return result;
	}															

	// Check to see if the type has already been entered in the dispatch table.
	// Returns the DispatchTable if such is the case. Otherwise, returns null.
	private DispatchTable typeExists (ClassNode type) {
		
		for (int i = 0; i < types.size(); i++)
			if (types.elementAt(i) == type)
				return (DispatchTable) table.elementAt(i);
				
		return null;
	}

	// Adds a type and an associated dispatch table.
	public DispatchTable addType (ClassNode type) {
		DispatchTable newTable = typeExists (type);
		
		// Check to see if the type already exists. 
		// If so, we won't add it again.
		if (newTable != null)
			return newTable;
			
		// Otherwise, we have to add the type.
		if (table.size() == 0)
			newTable = new DispatchTable (numLvls, level + 1);			
		else
			newTable = ((DispatchTable) table.elementAt(0)).copy();
		addTableEntry (type, newTable);
		
		return newTable;
	}	

	public void addPolyType (HierMethodPolyClassNode hNode) {
	
		if (level == numLvls)
			this.hNode = hNode;
		else {
			// Get the type at the current level.
			ClassNode type = hNode.getHierClasses()[level].getClassNode();
			
			// Add the type to the dispatch table.
			DispatchTable newTable = addType (type);
			newTable.addPolyType (hNode);
		}
	}
	
	public void addTableEntry (ClassNode type, DispatchTable tableEntry) {
		types.addElement (type);
		table.addElement (tableEntry);
	}

	public void bringUptodate () {
	
		if (level == numLvls) {
			// Check to see if we need to update the method.
			if (m == null) {
				if (hNode == null)
					m = new NoDispatchedMethodDefined();
				else
					m = hNode.findClosestMethod();
			}
		}
		else {
		
			// Bring up-to-date all the table entries.
			for (int i = 0; i < table.size(); i++)
				((DispatchTable) table.elementAt(i)).bringUptodate();
		}
	}
	
	public void print () {
		System.out.println();
		System.out.println("Dispatch table:");
		this.print (new String());
	}

	public void print (String typeStr) {
	
		if (level == numLvls) {
		
			// Print types.
			System.out.print (typeStr);
			
			// Print method.
			if (m == null)
				System.out.println (" -");
			else {
				System.out.print(" ");
				m.print();
				System.out.println();
			}
		}
		else {
		
			// Branch and add the type to the typeStr variable.
			for (int i = 0; i < types.size(); i++) {
				String newTypeStr = typeStr;
				if (level > 0)
					newTypeStr = newTypeStr.concat (", ");
				newTypeStr = newTypeStr.concat (((ClassNode) types.elementAt(i)).getName());
				((DispatchTable) table.elementAt(i)).print (newTypeStr);
			}
		}
	}
				
	public String buildIfStatement (ClassNode dclClass, String[] prmNames, boolean hasReturn) {
	
		// If we've reached the last level, just return the method definition.
		if (level == numLvls) {
		
			// Return the method call.
			if ((m == null) || (m instanceof NoDispatchedMethodDefined))
				return " throw new UnsupportedOperationException (\"No method defined.\"); \n";
			else if (m instanceof AmbiguousDispatchDefinition)
				return " throw new UnsupportedOperationException (\"Ambiguous method definition.\"); \n";
			else {
				DispatchedMethod        dm = (DispatchedMethod) m;
				DispatchedParameter[] prms = dm.getParameters();
				
				// Build string.
				String result = new String();
				if (hasReturn)
					result = result.concat(" return ");
				
				// Add method name.
				result = result.concat (dm.getMethod().getName());
				result = result.concat (" (");
				for (int i = 0; i < prmNames.length; i++) {
					
					// Add type coersion.
					if (prms[i + 1].isPolymorphic())
						result = result.concat ("(" + prms[i + 1].getParameter().getType() + ") ");
					
					// Add parameter name.
					result = result.concat (prmNames[i]);
					if (i < (prmNames.length - 1))
						result = result.concat (", ");
				}
				
				// Add semi-colon.
				result = result.concat ("); \n");
				return result;
			}
		}
		// We are at the first level so dispatch on the appropriate receiver type.
		else if (level == 0)
			return getTableFor(dclClass).buildIfStatement (dclClass, prmNames, hasReturn);
		// We are not at the last level yet.
		else {
			String result = "";
			for (int i = types.size() - 1; i >= 0; i--) {
				if (i == types.size() - 1)
					result = result.concat (" if ");
				else
					result = result.concat (" else if ");
					
				result = result.concat ("(" + prmNames[level - 1] + " instanceof " + 
																((ClassNode) types.elementAt(i)).getName().substring(1) + ") { \n");
				result = result.concat
					(((DispatchTable) table.elementAt(i)).buildIfStatement (dclClass, prmNames, hasReturn));
				result = result.concat ("} \n");
			}
			
			// Last else statement.
			result = result.concat 
				(" else throw new UnsupportedOperationException (\"No method defined.\"); \n");
			return result;
		}
	}
			
  // Private methods.
  private void initialize (int numLevels, int curLevel) {
  	numLvls  = numLevels;
  	level    = curLevel;
    m        = null;
    hNode    = null;
    types    = new Vector();
  	table    = new Vector();
  }
}

// DispatchTableGenerator
// ---------------------------------------------------------------------------------------
// Contains the polytype hierarchy and builds the dispatch table and if statements for the 
// dispatching.
class DispatchTableGenerator extends MethodPolyClassHrchy {

	// Fields.
	protected DispatchTable table;
	protected MethodNode    prototypeMethod;
	
	// Constructor.
	public DispatchTableGenerator (MethodNode prototype, boolean[] whichToDispatch) {
	
		// Call the constructor for the super class.
		super (new DispatchedMethod (prototype, whichToDispatch));
		
		prototypeMethod = prototype;
		
		// Create the dispatch table.
		table = new DispatchTable (this);
	}
	
	// Methods.
	
	public void addMethods (MethodNode[] methods) {
		
		// Add the methods to the super class.
		for (int i = 0; i < methods.length; i++)
			if (methods[i] != prototypeMethod)
				super.addMethod (methods[i]);
		
		// Add the parameter types to the dispatch table.
		HierPolyClassNode[] hNodes = getNodes();
		for (int i = 0; i < hNodes.length; i++)
			table.addPolyType ((HierMethodPolyClassNode) hNodes[i]);
	}
	
	public void bringUptodate () {
		table.bringUptodate();
	}

	public void print () {
		super.print();
		table.print();
	}
	
	public String buildIfStatement (ClassNode dclClass) { 
	
		// Get the main dispatch method's parameter names.
		DispatchedParameter[] dspParams = prototype.getParameters();
		String[] prmNames = new String[dspParams.length - 1];
		for (int i = 0; i < prmNames.length; i++)
			prmNames[i] = dspParams[i + 1].getParameter().getName();
	
		// Find out whether there's a return type.
		boolean hasReturn;
		if (prototype.getMethod().getReturnType().equals("void"))
			hasReturn = false;
		else
			hasReturn = true;
	
		return table.buildIfStatement (dclClass, prmNames, hasReturn); 
	}
}

// ProcessedMethod
// ---------------------------------------------------------------------------------------
// A dispatched method that has been processed by the Dispatched transform class.
class ProcessedMethod {

	// Fields.
	DispatchedMethod method;
	ClassNode        cls;
	
	// Constructor.
	public ProcessedMethod (ClassNode cls, DispatchedMethod method) {
		this.cls    = cls;
		this.method = method;
	}
	
	// Methods.
	public boolean hasBeenProcessed (ClassNode cls, DispatchedMethod method) {
		if ((cls == this.cls) && (method.equals (this.method)))
			return true;
		else
			return false;
	}
}

// Dispatched
// ---------------------------------------------------------------------------------------
// Performs the "dispatched" transform.
public class Dispatched extends Transform {								

	// This field keeps track of all the methods in the classes
	// we've processed.
	static Vector processedMethods = new Vector();

	// Returns true if the name of the method is not declared in the class
	// and its superclasses.
	private static boolean methodNameIsUnique (String name, ClassNode dclClass) {
	
		ClassNode curCls = dclClass;
		
		while (curCls != null) {
			MethodNode[] dclMethods = curCls.getDeclaredMethods();

			for (int i = 0; i < dclMethods.length; i++)
				if (name.equals(dclMethods[i].getName()))
					return false;
					
			String curClsStr = curCls.getSuperclass();
			curCls = ClassNode.forName (curClsStr, curCls);
		}

		return true;
	}

	// Creates a new name for the method if it conflicts with any of 
	// the other method names in the class.
	private static String createUniqueMethodName (String name, ClassNode dclClass) {
		String newName = new String(name);
		int          n = 1;

		while (!methodNameIsUnique(newName, dclClass)) {
			n++;
			newName = new String(name + Integer.toString(n));
		}

		return newName;
	}

	private static boolean[] whichAreDispatched (MethodNode method, String dispatchParameters) {
	
		// Get the list of parameters for the method.
		ParameterNode[] params = method.getParameters();
		boolean[] result       = new boolean[params.length];
		
		// If the string is empty, then we assume that all the parameters are
		// polymorphic.
		if (dispatchParameters.length() == 0) {
			for (int i = 0; i < result.length; i++)
				result[i] = true;
		}
		else {
		
			// Initially set all the parameters to NOT polymorphic.
			for (int i = 0; i < result.length; i++)
				result[i] = false;
			
			// Parse the "dispatchParameters" string.
			String dpStr = dispatchParameters.substring (1, dispatchParameters.length() - 1);
			StringTokenizer st = new StringTokenizer (dpStr, ",");
			
			while (st.hasMoreTokens()) {
				String prmName = st.nextToken();
				
				// Now that we've got the name, find out if it corresponds to
				// a parameter in the method. If it does, then add it to the
				// list of dispatch parameters.
				boolean foundParam = false;
				for (int i = 0; i < params.length; i++)
			  	if (params[i].getName().equals(prmName)) {
						foundParam = true;
						result[i] = true;
						break;
					}
				
				// If we haven't found a corresponding parameter, then warn the user.
				if (!foundParam)
					System.out.println ("Warning: Parameter " + prmName + " specified in the dispatched " +
						"keyword does not correspond to a parameter in the method, so it is ignored.");
			}
		}
		
		return result;
	}

	satisfies<DispatchMechanismCreated>
	public void dispatchTransform (MethodNode method) {
		dispatchTransform (method, "");
	}
	
	satisfies<DispatchMechanismCreated>
	public void dispatchTransform (MethodNode method, String dispatchParameters) {

		// Get the declaring class.
		ClassNode dclClass = method.getDeclaringClass();
		
		// Build the dispatched method.
		DispatchedMethod dspMtd = new DispatchedMethod (method, 
			whichAreDispatched (method, dispatchParameters));

		// Check to see if we've already processed this method in this
		// class. If so, then we report an error and stop right there.
		boolean alreadyProcessed = false;
		for (int i = 0; i < processedMethods.size(); i++)
			if (((ProcessedMethod) processedMethods.elementAt(i)).hasBeenProcessed (dclClass, dspMtd))
				alreadyProcessed = true;
	
		if (alreadyProcessed) {
			System.out.print ("Warning: The \"dispatched\" modifier has been used more than once " + 
				"for method ");
			dspMtd.print();
			System.out.println (" in class " + dclClass.getName().substring(1) + ". The redundant " + 
				"instance is ignored because it may cause ambiguities in the behaviour of the method. " +
				"(Note that the dispatched behaviour is inherited in the class hierarchy.)");
		}
		else {
		
			// The "dispatched" keyword has not been processed so we can process this class
			// and it's subclasses!
			
			// First we create the DispatchTableGenerator object.
			DispatchTableGenerator dspTable = new DispatchTableGenerator (method, 
				whichAreDispatched (method, dispatchParameters));			
			
			// Next, we create the dispatch mechanism for this class and it's subclasses.
			
			// Create a queue and put the declared class in it.
			LinkedList clsQueue = new LinkedList();
			clsQueue.addLast (dclClass);
			
			// Get all the classes in the package.
			ClassNode[] allClasses = dclClass.getPackage().getClasses();
			
				
			// Repeat until there are no more nodes to look at.
			// We always put the children of a node at the end of the 
			// queue so we make sure to look at the classes that are
			// higher up in the hierarchy first.
			while (clsQueue.size() > 0) {

				// First create the dispatch mechanism for the next class in the queue.
				// We also find out if the method is abstract or not.
				ClassNode curCls = (ClassNode) clsQueue.removeFirst();

				boolean isAbstract;
				
				if (curCls.isInterface() || (Modifier.isAbstract (method.getModifiers()) && 
						(curCls == dclClass)))
					isAbstract = true;
				else
					isAbstract = false;

				alreadyProcessed = false;

				if (!alreadyProcessed) {

					createDispatchMechanism (curCls, dspTable, isAbstract);
					processedMethods.addElement (new ProcessedMethod (curCls, dspMtd));
					
					// Next, get the children of this class and put the children on the queue.
					for (int i = 0; i < allClasses.length; i++) {
						if (ClassNode.forName (allClasses[i].getSuperclass(), curCls) == curCls) {
							clsQueue.addLast (allClasses[i]);
						}
					}
				}
			}
			
			if (!dclClass.isInterface() && !Modifier.isAbstract (method.getModifiers())) {
				dclClass.remove (method);
				dclClass.extend ( %{ #{Modifier.toString(method.getModifiers())}# #{method.getReturnType()}# #{method.getName()}# (#{getParametersString (method.getParameters())}#) {
					#{dspTable.buildIfStatement(dclClass)}#
				} 
				}% );
			}
		}
	}

	private static String getParametersString (ParameterNode[] params) {
		String result = new String();
	
		for (int i = 0; i < params.length; i++) {
			ParameterNode param = params[i];
			
			result = result.concat (param.getType() + " " + param.getName());
			if (i < params.length - 1)
				result = result.concat (", ");
		}
		
		return result;
	}
	
	private static void createDispatchMechanism (ClassNode cls, DispatchTableGenerator dspTable,
											  											 boolean isAbstract) {

		DispatchedMethod prototype = dspTable.getPrototype();

		// First check to see if the method is abstract or if the class
		// is an interface. If it's not, then we add the methods from the class to the 
		// dispatch table and spawn the dispatch table to it's subclasses.
		// Otherwise, we just spawn the dispatch table to it's subclasses.
		if (!isAbstract) {

			// The class is not an interface nor is the method abstract. 
			
			// Get all the methods that fit the prototype criteria.
			MethodNode[] methods       = cls.getMethods(); 
			DispatchedMethod[] oldMtds = dspTable.getMethods();
			Vector     goodMtdsV       = new Vector();
			
			for (int i = 0; i < methods.length; i++) {
				MethodNode method = methods[i];	
				
				// Check to see if the method has already been used.
				if (prototype.equals (method) && method.getDeclaringClass() == cls) {
					boolean okay = true;
										
					// So the method matches the prototype. But we still have to 
					// check the modifiers and make sure they are okay.
					int mdfrs = method.getModifiers();
					
					// Check to see if the method is abstract.
					if (Modifier.isAbstract (mdfrs)) {
						System.out.println ("Warning: Method " + method.getName() + " in class " +
							cls.getName().substring(1) + " is not allowed to be abstract. It will " +
							"not be used for multiple dispatch.");
						okay = false;
					}
					
					if (Modifier.isStatic (mdfrs) != 
						 	Modifier.isStatic (prototype.getMethod().getModifiers())) {
						System.out.println ("Warning: Method " + method.getName() + " in class " + 
						cls.getName().substring(1) + " is either static when the prototype is not " + 
						"static or not static when the prototype is static. Since this will result " +
						"in a compile error, this method is not considered for multiple dispatch.");
						okay = false;
					}

					if (okay)
						goodMtdsV.addElement (method);
				}
			}
					
			MethodNode[] goodMtds = new MethodNode [goodMtdsV.size()];
			for (int i = 0; i < goodMtds.length; i++)
				goodMtds[i] = (MethodNode) goodMtdsV.elementAt(i);
		
			if (goodMtds.length > 0) {
			
				dspTable.addMethods (goodMtds);
	
				// Update the dispatch table.
				dspTable.bringUptodate();
				
				// Modify the declared methods.
				// First, change the names of the methods declared in the class
				// and make them private.
				for (int i = 0; i < goodMtds.length; i++) {
					MethodNode goodMtd = goodMtds[i];
					if (goodMtd != prototype.getMethod()) {
						goodMtd.setName (createUniqueMethodName (goodMtd.getName(), cls));
						goodMtd.makeProtected();
					}
				}
				
				// Next, set the body for the prototype. This may require 
				// creating a new method if we're in a subclass.

				// Get info from prototype.
				MethodNode mtd = prototype.getMethod();
				boolean b = Modifier.isAbstract(mtd.getModifiers());
				mtd.setAbstract(false);
				int mdfrs = mtd.getModifiers();
				mtd.setAbstract(b);

				if (cls != prototype.getMethod().getDeclaringClass()) {
					cls.extend ( %{ #{Modifier.toString(mdfrs)}# #{mtd.getReturnType()}# #{mtd.getName()}# (#{getParametersString (mtd.getParameters())}#) {
						#{dspTable.buildIfStatement(cls)}#
					} 
					}% );
				}
	
				// Print out the results.
				System.out.println();
				System.out.println ("-------------------------------------------------------------------");
				System.out.print ("CREATING DISPATCH FOR METHOD ");
				prototype.print();
				System.out.println (" IN CLASS " + cls.getName().substring(1));
				
				System.out.println();
				dspTable.print();
			
				System.out.println();
				System.out.println (dspTable.buildIfStatement(cls));
			
				// Create the dispatch mechanism in the class.
			}
			else {
				System.out.println();
				System.out.print ("No methods for dispatched method ");
				prototype.print();
				System.out.println ("In class " + cls.getName().substring(1));
			}
		}
	}
}
