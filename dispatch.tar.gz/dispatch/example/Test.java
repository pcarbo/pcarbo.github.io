class P { }
class Q extends P { }
class R extends P { }

abstract class Z {
	public dispatched<"p"> void m (P p, int i);	
}

class A extends Z {
  public void m (Q q, int i) { System.out.println ("m(A,Q)"); }
}

class B extends A {
	public void m (P p, int i); { System.out.println ("m(B,P)"); }
	public void m (R r, int i); { System.out.println ("m(B,R)"); }
}

class C extends A {
	public void m (R r, int i); { System.out.println ("m(C,R)"); }
}

public class Test {

	public static void main (String[] args) {
	
		A a = new A();
		A b = new B();
		A c = new C();
				
		P p = new P();
		P q = new Q();
		P r = new R();
		
		a.m(q, 0);
		b.m(p, 0);
		b.m(q, 0);
		b.m(r, 0);
		c.m(r, 0);
		c.m(q, 0);
		c.m(p, 0);
	}
}