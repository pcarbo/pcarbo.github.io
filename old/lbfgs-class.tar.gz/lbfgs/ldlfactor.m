function x = ldlfactor (A)
  [x.L x.D x.P x.S] = ldl(A);
  