classdef LBfgs
  properties
  
    % Scalars
    n      % The number of optimization variables.
    m      % The number of correction pairs stored so far.
    mmax   % The maximum number of correction pairs.
    sigma  % Scaling factor for the "initial" Hessian approximation.

    % The correction pairs.
    S   % n x m matrix that stores the iterate differences.
    Y   % n x m matrix that stores the gradient differences.

    % A few intermediate values.
    SS  % m x m matrix containing the matrix product S'*S.
    D   % The diagonal of an m x m matrix in which the ith diagonal 
        % entry is the dot product of the ith correction pair.
    L   % m x m matrix L containing the matrix product S'*Y.
  end

  methods
  
    % Initialize the limited-memory quasi-Newton approximation to the
    % Hessian, where n is the number of optimization variables and m is
    % the maximum number of correction pairs.
    function x = LBfgs (n, m)
  
      % Initialize the scalars.
      x.n     = n;
      x.m     = 0;
      x.mmax  = m;
      x.sigma = 1;
      
      % Storage for the correction pairs.
      x.S = zeros(n,0);
      x.Y = zeros(n,0);
      
      % Storage for a few intermediate values.
      x.SS = [];
      x.D  = [];
      x.L  = [];
    end

    % This function removes the first correction pair in storage, which
    % effectively means that it removes the first column of S and Y.
    function x = removepair (x)
      x.m = x.m - 1;

      % Remove the first column from S and Y.
      x.S = x.S(:,2:end);
      x.Y = x.Y(:,2:end);
      
      % Remove the first column and row from D, SS and L.
      x.D  = x.D(2:end);
      x.SS = x.SS(2:end,2:end);
      x.L  = x.L(2:end,2:end);
    end

    % Update the limited-memory Hessian approximation with a new correction
    % pair (s,y).
    function x = update (x, s, y)
	
      % Compute the dot products.
      sy = s'*y;
      ss = s'*s;
      
      % If the dot products are too small, do not perform the update.
      if ss < eps | sy < eps
        return
      end
      
      % Update sigma.
      x.sigma = sy / ss;
      
      % Store the new correction pair (s,y). There are two possible
      % situations: we haven't yet used up the maximum allowable storage, or
      % we have used up all the storage, in which case we have to remove one
      % of the correction pairs in order to store the new one. Note that a
      % new correction pair is always placed at the end of the matrix.
      if x.m == x.mmax
	x = removepair(x);
      end
      
      % Update D.
      x.D = [ x.D sy ];

      % Update SS = S'*S.
      sS   = s'*(x.S);
      x.SS = [ x.SS  sS'
	        sS   ss ];
      
      % Update L = S'*Y.
      x.L = [   x.L   zeros(x.m,1) 
	      s'*x.Y       0       ];
      
      % Update the collection of correction pairs (s,y).
      x.S = [ x.S s ];
      x.Y = [ x.Y y ];
      x.m = x.m + 1;
    end

    % Call this function if you would like to multiply the Hessian
    % approximation B times a vector v in an efficient manner. The result of
    % calling this function is p = B * v. The explanation for how to compute
    % the matrix-vector product efficiently is given on pages 142-3 of Byrd,
    % Nocedal and Schnabel (1994).
    function p = mtimes (x, v)

      % In the special case when m = 0, we just need to multiply the
      % vector v times a scalar.
      if x.m == 0
	p = x.sigma * v;
      else
        U = [ x.Y x.sigma*x.S ];
	p = x.sigma*v - U*product(x,U'*v);
      end
    end
    
    % Call this function if you want to compute the solution x to 
    % 
    %     (W + B) p = -b,
    % 
    % where W is a sparse, nv x nv symmetric matrix, and B is the n x n
    % limited-memory, low-rank update to the Hessian, with nv being greater
    % than or equal to n. When the size of the matrix W is greater than B,
    % then we only add B to the top-left portion of W.
    function p = solve (x, b, W)
      m = x.m;
      if m == 0
	
	% In the special case when no correction pairs have been added to
        % the limited-memory approximation of the Hessian, then there is
        % very little that needs to be done.
        % FIX THIS.
        p = W \ (-b);
      else

	% Compute the vector U.
        U = [ x.Y x.sigma*x.S ];
	U = [ U; zeros(length(b) - x.n,2*m) ];
	
	% Apply the Sherman-Morrison-Woodbury formula to compute the final
	% solution. Here, we are effectively computing the inverse of W
	% plus a low-rank update U*V'. Most of the expense is contained in
        % the fifth step here, because it involves factorizing a dense 2m x
        % 2m matrix, and because it involves multiplying an n x 2m matrix
        % times an 2m x 2m matrix for a total cost of O(nm^2).
        % FIX THIS.
        factor = ldlfactor(W);
        p      = ldlsolve(factor,-b);
	p      = product(x,U'*p);
        CU     = ldlsolve(factor,U);
	p      = (eye(2*m) - product(x,U'*CU)) \ p;
        p      = ldlsolve(factor,U*p - b);
      end
    end

    % The limited-memory approximation to the Hessian can be written in
    % the form
    %
    %      B = sigma*I - U*inv(M)*U'
    %
    % Rather than form the inverse of M directly, it is possible to
    % efficiently factorize M using the Cholesky factorization, and then
    % implicitly compute the product inv(M) * U'. That is effectively what
    % this function does: it computes this product an efficient manner. For
    % more information, see Algorithm 3.2 on pages 142-3 of Byrd, Nocedal
    % and Schnabel (1994). This function should only be called when at
    % least one correection pair has been stored.
    function P = product (x, U)
      
      % Compute the subblocks of the factors of M.
      O  = zeros(x.m);
      D  = diag(sqrt(x.D));
      LD = x.L * diag(1./sqrt(x.D));
      
      % Compute the Cholesky factor; see equation (2.26) on p. 136 of
      % Byrd, Nocedal and Schnabel (1994).
      J = chol(x.sigma*x.SS + x.L*diag(sparse(1./x.D))*x.L','lower');

      % Perform a forward substitution and then a backward substitution
      % to obtain the desired product.
      P = [ -D LD'; O J' ] \ ([ D O; -LD J ] \ U);
    end
  end
end

