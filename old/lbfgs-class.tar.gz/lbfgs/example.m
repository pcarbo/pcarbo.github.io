clear

% Optimization parameters.
tolerance = 1e-3;  % Stopping criterion.
maxiter   = 100;   % The maximum number of iterations.
ncp       = 8;     % Number of correction pairs.

% CREATE DATA SET.
% Generate the input vectors from the standard normal, and generate the
% binary responses from the regression with some additional noise, and then
% transform the results using the logistic function. The variable "beta" is
% the set of true regression coefficients of length m.
lambda  = 1;                              % Level of L1 regularization.
n       = 100;                            % Number of training examples.
epsilon = 1;                              % Std. dev. in noise of outputs.
beta    = [ 0 0 2 -4 0 0 -1 3 ]';         % True regression coefficients.
sigma   = [ 4 1 1  1 1 1  1 2 ]';       % Standard deviation of coord's.
m       = length(beta);                   % Number of dimensions/features.
A       = repmat(sigma',n,1).*randn(n,m); % The n x m matrix of examples.
noise   = epsilon*randn(n,1);             % Noise in outputs.
y       = A*beta + noise;                 % The binary outputs.

% COMPUTE SOLUTION WITH BATCH INTERIOR-POINT METHOD.
% Compute the L1-regularized maximum likelihood estimator.
w = lassoip(A,y,lambda,tolerance,maxiter,ncp);
f = norm(y - A*w)^2/2 + lambda*norm(w,1);
fprintf('The value of the loss function at the solution: %0.3f \n',f);
fprintf('Regression coefficients (compare with beta): \n');
disp(w);
