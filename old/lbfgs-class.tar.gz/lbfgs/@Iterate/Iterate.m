classdef Iterate
  properties

    % Scalars.
    m   % The number of regression variables.
    nv  % The number of primal-dual optimization variables.
    
    % Vectors.
    w   % The m x 1 vector of regression coefficients.
    u   % The m x 1 vector of auxiliary variables.
    zL  % The m x 1 vector of lower bound multipliers.
    zU  % The m x 1 vector of upper bound multipliers.
  end

  methods
  
    % The class constructor. There are two ways to create an Iterate
    % object. The first way is to specify the number of regression
    % coefficients. The second way is to specify values for all the
    % optimization variables.
    function x = Iterate (varargin)
      if nargin == 1
	m  = varargin{1};

	% Initialize the primal-dual variables.
        x.w  = zeros(m,1);
	x.u  = ones(m,1);
	x.zL = ones(m,1);
	x.zU = ones(m,1);
      
      elseif nargin == 4
	[w u zL zU] = deal(varargin{:});
	m           = length(w);

        % Set the primal-dual variables.
	x.w  = w;
	x.u  = u;
	x.zL = zL;
	x.zU = zU;
      end

      % Set the number of optimization variables.
      x.m  = m;
      x.nv = 4*m;
    end
    
    % Access the full set of Lagrange multipliers.
    function a = z (x)
      a = [ x.zL; x.zU ];
    end

    % Take a step of length alpha along direction px.
    function x = takestep (x, alpha, p)
      
      % Take the step.
      x.w  = x.w  + alpha * p.w;
      x.u  = x.u  + alpha * p.u;
      x.zL = x.zL + alpha * p.zL;
      x.zU = x.zU + alpha * p.zU;      
    end
  end
end  
