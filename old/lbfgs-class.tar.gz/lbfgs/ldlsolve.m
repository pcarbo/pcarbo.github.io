function y = ldlsolve (x, b)
  y = x.S * x.P * (x.L' \ (x.D \ (x.L \ (x.P' * x.S * b))));
