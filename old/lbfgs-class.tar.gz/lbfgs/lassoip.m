function w = lassoip (A, y, lambda, tolerance, maxiter, ncp)
  
  % Some algorithm parameters.
  eps      = 1e-8;   % A number close to zero.
  alphamax = 0.995;  % Maximum step size.
  sigmamax = 0.9;    % The maximum centering parameter.
  etamax   = 0.25;   % The maximum forcing number.
  mumin    = 1e-9;   % Minimum barrier parameter.
  pcexp    = 2;      % Exponent in predictor-corrector centering param.
  
  % Initialize the primal variables (x,u) and the dual variables (zl,zu).
  m = size(A,2);   % The number of regression coefficients.
  x = Iterate(m);  % The initial iterate.
  
  % Initialize the quasi-Newton approximation.
  B = LBfgs(m,ncp);
  
  fprintf('  i f(x)       lg(mu) sigma   ||rx||  ||rc||  alpha   #ls  rel err\n');
  
  % Repeat while the convergence criterion has not been satisfied, and
  % we haven't reached the maximum number of iterations.
  alpha = 0;
  ls    = 0;
  for iter = 1:maxiter

    % (1.) Compute the objective, constraints, and other quantities.
    f       = objective(A,y,x,lambda);
    g       = gradient(A,y,x.w);
    [cL cU] = constraints(x);
    [rx rc] = residual(x,cL,cU,g,lambda);
    r0      = [rx; rc]; 
    gap     = -sum(rc);
    eta     = min(etamax,norm(r0)/x.nv);
    erel    = gap/(f - gap);

    % (2.) Update the quasi-Newton approximation to the Hessian, and
    % store the current point (w) and the gradient at the current point.
    if iter > 1
      B = update(B,x.w - wprev,g - gprev);
    end  
    wprev = x.w;
    gprev = g;
        
    % (3.) Set the centering parameter.
    % Compute the affine search direction.
    p = searchdir(x,cL,cU,lambda,g,B,0,eps);
    
    % Execute backtracking line search to find the largest feasible
    % step along the affine (mu = 0) search direction.
    alphaaff       = alphamax * feasiblestep(x,p);
    [alphaaff ans] = linesearch(A,y,lambda,x,p,g,0,eta,alphaaff,eps);
    
    % Calculate Mehrotra's choice of centering parameter based on the
    % ratio of the affine reduction in the duality gap and the current
    % value of the duality gap.
    gapaff = dualitygap(takestep(x,alphaaff,p));
    sigma  = (gapaff/gap)^pcexp;
    
    % (4.) Update the barrier parameter.
    sigma = min(sigmamax,sigma);
    mu    = max(mumin,sigma*gap/(2*m));
    
    % (5.) Print the status of the algorithm.
    fprintf('%3d %+0.3e  %+5.2f %0.1e %0.1e %0.1e %0.1e %3d  ',...
            iter,f,log10(mu),sigma,norm(rx),norm(rc),alpha,ls);
    if f > gap
      fprintf('%0.1e\n',erel);
    else
      fprintf('  ---  \n');
    end
    
    % (6.) Check the stopping criterion.
    if f > gap & max(norm(rx)/x.nv,erel) < tolerance 
      break
    end
    
    % (7.) Compute the Newton search direction based on a first-order Taylor
    % expansion of the perturbed Karush-Kuhn-Tucker conditions.
    p = searchdir(x,cL,cU,lambda,g,B,mu,eps);
    
    % (8.) Execute backtracking line search to find the largest feasible
    % step along the Newton search direction.
    alpha      = alphamax * feasiblestep(x,p);
    [alpha ls] = linesearch(A,y,lambda,x,p,g,mu,eta,alpha,eps);
      
    % (9.) Move to the new point.
    x = takestep(x,alpha,p);
  end

  % Output the regression coefficients.
  fprintf('\n');
  w = x.w;
  
% ------------------------------------------------------------------
% Return an n x n sparse matrix of zeros.
function A = spzeros (n)
  A = sparse([],[],[],n,n);

% ------------------------------------------------------------------
% Compute the response of the objective function at (x,u).
function f = objective (A, y, x, lambda)
  f = norm(y - A*x.w)^2/2 + lambda*sum(x.u);
  
% ------------------------------------------------------------------
% Compute the gradient of the objective function with respect to the
% regression coefficients w.
function g = gradient (A, y, w)
  g = -A'*(y - A*w);

% ------------------------------------------------------------------
% Compute the responses of the vector-valued inequality constraint
% function at (x,u).
function [cL, cU] = constraints (x)
  cL = [ -x.w - x.u ];
  cU = [  x.w - x.u ];

% ------------------------------------------------------------------
% Compute the gap between the primal and dual objectives at the 
% given point.
function gap = dualitygap (x)
  [cL cU] = constraints(x);
  gap     = -(cL'*x.zL + cU'*x.zU);

% ------------------------------------------------------------------
% Compute the residual of the unperturbed Karush-Kuhn-Tucker system.
function [rx, rc] = residual (x, cL, cU, g, lambda)
  rx = [ g      - x.zL + x.zU    % Dual residual of x.
	 lambda - x.zL - x.zU ]; % Dual residual of u.
  rc = [ cL.*x.zL                % Complementarity of lower bounds.
	 cU.*x.zU ];             % Complementarity of upper bounds.

% ------------------------------------------------------------------
% Compute the response of the merit function at the given point.
function psi = merit (f, x, cL, cU, mu, eps)  
  psi = f - cL'*x.zL - mu*sum(log(cL.^2.*x.zL + eps)) ...
	  - cU'*x.zU - mu*sum(log(cU.^2.*x.zU + eps));

% ------------------------------------------------------------------
% Compute the directional derivative of the merit function.
function dpsi = gradmerit (x, p, cL, cU, lambda, g, mu, eps)
  dpsi = p.w'*(g + x.zL - x.zU + 2*mu./(cL-eps) - 2*mu./(cU-eps)) + ...
	 p.u'*(lambda + x.zL + x.zU + 2*mu./(cL-eps) + 2*mu./(cU-eps)) - ...
	 p.zL'*(cL + mu./(x.zL+eps)) - p.zU'*(cU + mu./(x.zU+eps));
  
% ------------------------------------------------------------------
% Compute the primal-dual Newton search direction by solving the 
% augmented system.
function p = searchdir (x, cL, cU, lambda, g, B, mu, eps)
  m = x.m;  % The number of regression coefficients.
  
  % First, compute the gradient of the logarithmic barrier function.
  gb = [ g      + mu./(cL-eps) - mu./(cU-eps)
	 lambda + mu./(cL-eps) + mu./(cU-eps) ];
  
  % Next, compute the search direction for (x,u).
  SL = x.zL./(cL-eps);
  SU = x.zU./(cU-eps);
  D  = diag(sparse(SL + SU));
  W  = [ B.sigma*speye(m) - D   spzeros(m)
         diag(sparse(SU - SL))     -D      ];
  pwu = solve(B,gb,W);
  pw  = pwu(1:m);
  pu  = pwu(m+1:end);
  
  % Finally, compute the search direction for (zL,zU).
  pzL = -x.zL - mu./(cL-eps) + SL.*(pw + pu);
  pzU = -x.zU - mu./(cU-eps) + SU.*(pu - pw);
  
  % Output the primal-dual search direction.
  p = Iterate(pw,pu,pzL,pzU);
  
% ------------------------------------------------------------------
% Find the step length along the Newton search direction that keeps the
% iterate within the feasible region.
function alpha = feasiblestep (x, p)
  t  = [ x.z; x.w + x.u; x.u - x.w ];
  pt = [ p.z; p.w + p.u; p.u - p.w ];
  is = find(pt < 0);
  if length(is)
    alpha = min(1,min(t(is) ./ -pt(is)));
  else
    alpha = 1;
  end

% ------------------------------------------------------------------
% Execute backtracking line search to find the step length along the given
% search direction that sufficiently decreases the merit function. It is
% assumed that the initial step length "alpha" provided as input maintains
% feasibility of the iterate.
function [alpha, ls] = linesearch (A, y, lambda, x, p, g, mu, eta, alpha, eps)
  
  % Some line search parameters.
  alphamin = 1e-6;  % Minimum step size.
  beta     = 0.75;  % Granularity of backtracking search.
  tau      = 0.01;  % Amount of decrease we will accept in line search.
  
  % Compute the response of the merit function and the directional
  % gradient at the current point and search direction.
  f       = objective(A,y,x,lambda);
  [cL cU] = constraints(x);
  psi     = merit(f,x,cL,cU,mu,eps);
  dpsi    = gradmerit(x,p,cL,cU,lambda,g,mu,eps);

  % Execute backtracking line search to select a candidate that reduces
  % the merit function.
  ls = 0;
  while true

    % Compute the candidate point.
    xnew = takestep(x,alpha,p);
    ls   = ls + 1;
    
    % Compute the response of the merit function at the candidate point.
    f       = objective(A,y,xnew,lambda);
    [cL cU] = constraints(xnew);
    psinew  = merit(f,xnew,cL,cU,mu,eps);
    
    % Stop backtracking search if we've found a candidate point that
    % sufficiently decreases the norm of the residual.
    if psinew < psi + tau*eta*alpha*dpsi
      break
    end
      
    % The candidate point does not meet our criteria, so decrease the step
    % size for 0 < beta < 1.
    alpha = alpha * beta;
    if alpha < alphamin
      error('Step size too small');
    end
  end
  