% Sample script for creating a data set from a single set of images.
datadir     = '/cs/beta/People/Nando/corel/imagetrans/data/images/token1';
datadir2    = '/cs/beta/People/Nando/corel/imagetrans/data/images/token2';
resultdir   = '/cs/beta/People/Nando/corel/imagetrans/data/sets/new/token';
datalabels  = {'training' 'test'};
proportions = [7 4];
seed        = 2067;

cd createdatasets
create_datasets({datadir datadir2}, resultdir, datalabels, proportions, 1, seed);