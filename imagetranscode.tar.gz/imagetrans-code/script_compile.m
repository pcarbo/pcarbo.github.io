datadir = '/cs/beta/People/Nando/corel/imagetrans/data/sets/new/corelB/p32';
model   = 'corelB/dPL1MRF';
trial   = 0;

cd resultsbrowser
stats = compile_stats(datadir,model);

show_stats_latex(stats,trial);

