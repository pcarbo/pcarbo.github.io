
%    Copyright (c) 2003 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function varargout = trans_rules (varargin)
  
  % Invoke callback function
  % ------------------------
  try
    if nargout,
      [varargout{1:nargout}] = feval(varargin{:}); 
    else,
      feval(varargin{:});
    end;
  
  catch
    disp(lasterr);
  end;
  
% --------------------------------------------------------------------
% CALLBACK FUNCTIONS
% --------------------------------------------------------------------  
% Initialization function for GUI.
function init (data_dir, model_name, varargin)
  
  % Function constants.
  defaultTrial   = 0;
  generalPath    = '../general';
  resultsSubdir  = 'results';
  trialPrefix    = 'trial';
  
  % Add the proper paths in order to access the "general" functions. 
  oldPath = path;
  dirs    = genpath(generalPath);
  path(dirs, oldPath);
  clear generalPath dirs oldPath

  % Launch GUI
  % ----------
  fig = openfig(mfilename, 'new');
  
  % Generate a structure of handles to pass to callbacks, and store it. 
  handles = guihandles(fig);
  
  % Get the parameters from "varargin".
  defargs = { defaultTrial };
  [trial] = manage_vargs(varargin, defargs);  
  clear defargs varargin
  
  try
    % Load the data set
    % -----------------
    data = load_data(data_dir);
    if ~length(data),
      error('Unable to load data sets.');
    end;

    % Get the feature names.
    featureNames  = data{1}.featureNames;
    featureCounts = data{1}.featureCounts;
    handles.features = cell(sum(featureCounts),1);
    ft = 0;
    for f = 1:length(featureNames),
      for fc = 1:featureCounts(f),
	ft = ft + 1;
	handles.features{ft} = featureNames{f};
      end;
    end;
    clear data featureNames featureCounts f ft fc
    
    % Load the list of words
    % ----------------------
    model_dir     = [data_dir '/' resultsSubdir '/' model_name];
    handles.words = importdata([model_dir '/words']);
    
    % Load the model specs
    % --------------------
    modelSpecs        = load_model_params(model_dir, [], 'specs');
    featureSel        = modelSpecs.featureSel;
    handles.features  = handles.features(featureSel);
    handles.modelName = modelSpecs.name;
    clear modelSpecs 
    
    % Load the model parameters
    % -------------------------
    % If "trial" is 0, then we load the model information for all the
    % trials. Otherwise, we do it for only a specific trial.
    if trial == 0,
    
      % Get the number of trials.
      files     = get_file_list(model_dir, '', -1, trialPrefix);
      numTrials = length(files);
      clear files
      
      % Get the blobs mean and standard deviation.
      trial_dir = [model_dir sprintf('/%s1', trialPrefix)];
      x = importdata([trial_dir '/blobs']);
      x = x(:,featureSel);
      handles.blobs.mean = x(1,:);
      handles.blobs.std  = x(2,:);
      clear x

      % Allocate memory for mu and sigma.
      numFeatures = length(handles.features);
      numWords    = length(handles.words);
      mu  = zeros(numFeatures, numWords, numTrials);
      sig = zeros(numFeatures, numFeatures, numWords, numTrials);
      
      % Get mu and sigma for each trial.
      for i = 1:numTrials,
	trial_dir    = [model_dir sprintf('/%s%i', trialPrefix, i)];
	mu(:,:,i)    = importdata([trial_dir '/mu']);
	sig(:,:,:,i) = reshape(importdata([trial_dir '/sigma']), ...
			       [numFeatures numFeatures numWords]);
      end;
      
      handles.model.mu  = sum(mu,3) / numTrials;
      handles.model.sig = sum(sig,4) / numTrials;
      clear numFeatures numWords mu sig
      
    else,
      trial_dir = [model_dir sprintf('/%s%i', trialPrefix, trial)];

      % Get the blobs mean and standard deviation.
      x = importdata([trial_dir '/blobs']);
      x = x(:,featureSel);
      handles.blobs.mean = x(1,:);
      handles.blobs.std  = x(2,:);
      clear x
      
      % Get mu and sigma.
      numFeatures       = length(handles.features);
      numWords          = length(handles.words);
      handles.model.mu  = importdata([trial_dir '/mu']);
      handles.model.sig = reshape(importdata([trial_dir '/sigma']), ...
				  [numFeatures numFeatures numWords]);
	  
      clear numFeatures numWords
    end;
    
  catch
    disp(lasterr);
    close;
    return;
  end;

  % Set up interface
  % ----------------
  % Modify the vocabulary control.
  set(handles.vocab, 'FontName', 'helvetica');
  set(handles.vocab, 'Value', []);  
  
  % Set up some interface variables.
  handles.dim = 1;
  
  % The original positions for GUI controls.
  handles.origpos.fig          = get(fig, 'Position');
  handles.origpos.modellabel   = get(handles.model_label, 'Position');
  handles.origpos.rulesimg     = get(handles.rulesimg, 'Position');

  handles.origpos.frame1       = get(handles.frame1, 'Position');
  handles.origpos.backdim      = get(handles.backdim_btn, 'Position');
  handles.origpos.forwarddim   = get(handles.forwarddim_btn, 'Position');
  handles.origpos.dimlabel     = get(handles.dim_label, 'Position');

  handles.origpos.vocablabel   = get(handles.vocab_label, 'Position');
  handles.origpos.vocab        = get(handles.vocab, 'Position');
  
  % Update display
  % --------------
  set(handles.vocab, 'String', handles.words);
  set(handles.model_label, 'String', handles.modelName);
  updateDisplay(handles);
  
  % Store the changes.
  guidata(fig, handles);

% --------------------------------------------------------------------
% Callback routine for vocabulary list control.
function varargout = vocab_Callback(h, eventdata, handles, varargin)
  updateDisplayImage(handles);

% --------------------------------------------------------------------
% Callback routine for the back button.
function varargout = backdim_Callback(h, eventdata, handles, varargin)

  if handles.dim > 1,
    handles.dim = handles.dim - 1;
    updateDisplayImage(handles);
    updateDisplayDim(handles);
  end;
  
  % Store the changes.
  guidata(h, handles);

% --------------------------------------------------------------------
% Callback routine for the forward button.
function varargout = forwarddim_Callback(h, eventdata, handles, varargin)

  if handles.dim < length(handles.features),
    handles.dim = handles.dim + 1;
    updateDisplayImage(handles);
    updateDisplayDim(handles);
  end;

  % Store the changes.
  guidata(h, handles);

% --------------------------------------------------------------------
% Callback routine for the figure.
function varargout = trans_rules_ButtonDownFcn(h, eventdata, handles, varargin)
  
% --------------------------------------------------------------------
% Callback routine for the file menu.
function varargout = FileMenu_Callback(h, eventdata, handles, varargin)

% --------------------------------------------------------------------
% Callback when the window is resized.
function varargout = ResizeFcn(H, eventdata, handles, varargin)
  
  if ~length(handles),
    return;
  end;
  
  % Get the new location of the figure.
  fig    = gcbo;
  figpos = get(fig,'Position');
  
  % Make sure the new dimensions of the figure are allowed. We cannot
  % make the window smaller than the original dimensions.
  figpos(3:4) = max(figpos(3:4), handles.origpos.fig(3:4));
  
  % Set the position of the Vocabulary control.
  x = figpos(3) - handles.origpos.fig(3) + handles.origpos.vocab(1);
  y = handles.origpos.vocab(2);  
  set(handles.vocab, 'Position', [x y handles.origpos.vocab(3:4)]);
  
  % Set the position of the Vocabulary label.
  x = figpos(3) - handles.origpos.fig(3) + handles.origpos.vocablabel(1);
  y = handles.origpos.vocablabel(2);  
  set(handles.vocab_label, 'Position', [x y handles.origpos.vocablabel(3:4)]); 
  
  % Set the position of the "rules" image.
  rw = figpos(3) / handles.origpos.fig(3);
  rh = figpos(4) / handles.origpos.fig(4);
  w  = handles.origpos.rulesimg(3) * rw;
  h  = handles.origpos.rulesimg(4) * rh;
  x  = handles.origpos.rulesimg(1) * rw;
  y  = handles.origpos.rulesimg(2) * rh;
  set(handles.rulesimg, 'Position', [x y w h]);
  
  % Set the position of the model label.
  w2 = handles.origpos.modellabel(3) * rw;
  h2 = handles.origpos.modellabel(4);
  x  = handles.origpos.modellabel(1) * rw;
  y  = handles.origpos.modellabel(2) * rh;  
  set(handles.model_label, 'Position', [x y w2 h2]);  
  
  % Set the position of the frame and its contents.
  x = handles.origpos.rulesimg(1) * rw + (w2 - handles.origpos.frame1(3)) / 2;
  y = handles.origpos.rulesimg(2) * rh - handles.origpos.frame1(4) - 1.2;
  set(handles.frame1, 'Position', [x y handles.origpos.frame1(3:4)]);
  
  x2 = handles.origpos.backdim(1) - handles.origpos.frame1(1) + x;
  y2 = handles.origpos.backdim(2) - handles.origpos.frame1(2) + y;
  set(handles.backdim_btn, 'Position', [x2 y2 handles.origpos.backdim(3:4)]);
  
  x2 = handles.origpos.forwarddim(1) - handles.origpos.frame1(1) + x;
  y2 = handles.origpos.forwarddim(2) - handles.origpos.frame1(2) + y;
  set(handles.forwarddim_btn, 'Position', ...
		    [x2 y2 handles.origpos.forwarddim(3:4)]);
  
  x2 = handles.origpos.dimlabel(1) - handles.origpos.frame1(1) + x;
  y2 = handles.origpos.dimlabel(2) - handles.origpos.frame1(2) + y;
  set(handles.dim_label, 'Position', [x2 y2 handles.origpos.dimlabel(3:4)]);
  
  % Store the changes.
  guidata(H, handles);

% --------------------------------------------------------------------
% DISPLAY FUNCTIONS
% --------------------------------------------------------------------
% Update the display of the entire interface.
function updateDisplay (handles)
  figure(handles.trans_rules_figure);
  updateDisplayDim(handles);
  
  updateDisplayImage(handles);
  
  % Update the vocabulary display.
  updateDisplayVocab(handles);
  
% --------------------------------------------------------------------
% Update the display of the dimension.
function updateDisplayDim (handles)
  s = sprintf('%i - %s', handles.dim, handles.features{handles.dim});
  set(handles.dim_label, 'String', s);

% --------------------------------------------------------------------
% Update the display of the current image.
function updateDisplayImage (handles)

  % Function constants.
  numSigmas = 4;
  numInts   = 100;
  colours = 'brkgy';
  
  % Find out what words are selected.
  selWords = get(handles.vocab, 'Value');  
  numWords = length(selWords);
  
  axes(handles.rulesimg);
  cla;
  % set(handles.rulesimg, 'YTick', [], 'XTick', [], 'XTickLabel', [], ...
  %		    'YTickLabel', [], 'Box', 'off');
  
  if ~numWords,
    return;
  end;

  % Find mu and sigma.
  mu  = zeros(numWords, 1);
  sig = zeros(numWords, 1);
  for i = 1:numWords,
    w      = selWords(i);
    mu(i)  = handles.model.mu(handles.dim, w);
	     % + handles.blobs.mean(handles.dim);
    sig(i) = handles.model.sig(handles.dim, handles.dim, w);
	     % * handles.blobs.std(handles.dim);
  end;
  
  % Find out the bounds of the graph and produce X.
  lBnd = min(mu - sig*numSigmas);
  uBnd = max(mu + sig*numSigmas);
  n = (uBnd - lBnd) / numInts;
  X = [lBnd:n:uBnd]';
  N = length(X);
  
  % Repeat for each word selected.
  hold on;
  for i = 1:numWords,
    Y = gaussian(X, mu(i), sig(i)^2);
    c = colours(mod(i-1,length(colours))+1);
    plot(X,Y,c);
  end;
  hold off;
  
  % Show the legend.
  wrds = cell(numWords,1);
  for i = 1:numWords,
    wrds{i} = handles.words{selWords(i)};
  end;
  legend(wrds{:}, 1);
  
% --------------------------------------------------------------------
% Update the display for the vocabulary.
function updateDisplayVocab (handles)
  set(handles.vocab, 'String', handles.words);
% X is an N x 1 vector. Outputs an N x 1 vector.

% --------------------------------------------------------------------
function y = gaussian (x, mu, sigma)
  n = length(x);
  y = exp(-0.5*(x - repmat(mu,[n 1])).^2/sigma) / sqrt(2*pi*sigma);
  