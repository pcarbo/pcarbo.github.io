% MODEL1DISCRETE_TRANS
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function t = model1MRFdiscrete_trans (B, M, A, model)
  
  try
  
  N           = length(M);
  maxM        = max(M);
  F           = size(model.clusterCenters,1);
  numclusters = size(model.clusterCenters,2);
  numwords    = size(model.t, 2);
  blobImages  = B;

  % Convert the matrix of blobs to a discrete matrix of clusters. In
  % other words, we need to find the membership for each blob.
  B = zeros(N,maxM);
  
  % Repeat for each document.
  for n = 1:N,
    % Repeat for each blob in the document.
    for b = 1:M(n),
      % Find the cluster that best matches the blob.
      [ans c] = min(sum((repmat(blobImages(:,b,n),[1 numclusters]) - ...
			 model.clusterCenters).^2,1));
      B(n,b) = c;
    end;
  end;
  clear blobImages

  % Set up the adjacency matrices.
  for n = 1:N,
    A{n} = A{n} > 0;
  end;
  
  % Now that we've clustered the blobs, let's build the "t" matrix.
  t = zeros(numwords,maxM,N);
  for n = 1:N,

    fprintf('  Translating document %i.\n', n);
    
    % Get the number of blobs.
    Mn = M(n);
    
    % Check for the limiting conditions. When there is one blob, we don't
    % need to perform loopy belief propagation. 
    if Mn == 1,
      
      % There is only one blob, so set the alignment probabilities to
      % the translation probabilities.
      x        = model.t(B(n,1),:)';
      t(:,1,n) = x / sum(x);
      clear x
    else,
      
      % Initialise the adjacencies for the document.
      An = zeros(2*Mn,2*Mn);
      
      % Get the set of adjacencies from the document MRF.
      An(1:Mn,1:Mn) = A{n};
       
      % Set the adjacencies for the translation cliques.
      An(1:Mn,Mn+[1:Mn]) = eye(Mn);
      An(Mn+[1:Mn],1:Mn) = eye(Mn);
      
      % Set up the set of clique probabilities P.
      P = cell(2*Mn,2*Mn);

      % For each alignment clique, put the spatial context potential
      % into P. 
      [us vs] = find(triu(A{n}));
      for i = 1:length(us),
	u = us(i);
	v = vs(i);
	P{u,v} = model.psi;
	P{v,u} = model.psi';
      end;
      clear us vs i u v Puv
      
      % For each translation clique, put the translation potential
      % into P.
      for u = 1:Mn,
	Puv       = model.t(B(n,u),:);
	Puv       = Puv / sum(Puv);
	P{u+Mn,u} = Puv;
	P{u,u+Mn} = Puv';
      end;
      clear u Puv
      
      % Run loopy belief propagation. If it does not converge, report
      % an error. 
      [x ans f] = loopybp([numwords*ones(Mn,1); ones(Mn,1)], ...
			  An, P, model.BPtol, (2*Mn)^4, 0);
      if ~f,
	error(fprintf(['Loopy belief propagation for translation ' ...
      		       'failed to converge on document %i \n'], n));
      end;
	  
      % Copy the resulting probabilities into the translation table.
      for b = 1:Mn,
	t(:,b,n) = x{b};
      end;
      clear x	
    end;    
  end;

  catch
    peter = 1;
  end;