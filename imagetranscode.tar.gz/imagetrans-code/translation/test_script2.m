% This goes along with the "token" training set with a threshold not
% exceeding 0.01.
B = [2 3 1 0 0 0 0 0; 
     2 3 1 0 0 0 0 0; 
     1 2 4 0 0 0 0 0;
     4 4 2 5 0 0 0 0;
     5 4 4 4 4 2 2 1;
     3 6 3 2 1 0 0 0;
     3 6 0 0 0 0 0 0 ];
