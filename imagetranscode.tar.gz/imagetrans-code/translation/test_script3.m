% Here we load the blob-word information and use that to create the blob 
% tokens. This is to make sure that the discrete translation model is
% working. 

datadir='/cs/beta/People/Nando/corel/imagetrans/data/sets/new/corelB/ncuts';
data = load_data(datadir);
data = data{1};
clear datadir

global blobsKept
for n = 1:N,
  u = 0;
  for b = 1:M(n),
    if blobsKept(n,b),
      u = u + 1;
      if data.blobWordCounts(n,b),
	B(n,u) = data.blobWords(1,b,n);
      else,
	B(n,u) = data.numWords + 1;
      end;
    end;
  end;
end;
clear n b data u