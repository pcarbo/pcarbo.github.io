for d = 1:length(data),

  testdata = data{d};
  for w = 1:testdata.numWords,
    
    fprintf('%s\n', testdata.words{w});
    
    numPoss        = 0;
    numPossPredNeg = 0;
    numNegs        = 0;
    numNegsPredPos = 0;
    
    % Repeat for each document.
    for s = 1:testdata.numImages,
      
      % Repeat for each blob in the doc.
      for b  = 1:testdata.imageBlobCounts(s),
	
	ispos = length(find(testdata.blobWords(:,b,s) ~= w & ...
			    testdata.blobWords(:,b,s) > 0));
	isneg = length(find(testdata.blobWords(:,b,s) == w));

	if ispos & ~isneg,
	  numNegs = numNegs + 1;
	  [ans i] = max(t{d}(:,b,s));
	  numNegsPredPos = numNegsPredPos + (i == w);
	elseif ~ispos & isneg,
	  numPoss = numPoss + 1;
	  [ans i] = max(t{d}(:,b,s));
	  numPossPredNeg = numPossPredNeg + (i ~= w);
	end;
      end;
    end;

    if numNegs,
      fprintf('False positives: %i / %i \n', numNegsPredPos, numNegs);
    end
    
    if numPoss,
      fprintf('False negatives: %i / %i \n\n', numPossPredNeg, numPoss);
    end
    
  end;
end;
