% MODEL1DISCRETE_TRAIN    Train model 1 discrete ML.
%   The function call is [MODEL,VAL] = MODEL1DISCRETE_TRAIN(B,W,M,L,
%   NUMWORDS,KMITER,EMITER,EMTOLERANCE). The model-specific parameters
%   are: 
%     - KMITER       The maximum number of iterations to run K-Means.
%     - EMITER       The maximum number of iterations ro run EM.
%     - EMTOLERANCE  Stop the EM algorithm when the difference in error
%                    between two steps is less than EMTOLERANCE.
%
%   In MODEL we will return the following information: 
%     - clusterCenters  F x W matrix where F is the number of features
%                       and W is the number of clusters (i.e. the number
%                       of words), indicating the centres of the
%                       normalized clusters.
%     - t               W x W matrix where W is the number of
%                       words. Entry t(b,w) is the probability of
%                       generating blob b from word w.
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function [model, val] = model1MRFdiscrete_train ...
      (B, W, A, M, L, numwords, numclusters, KMrest, KMiter, ...
       EMiter, EMtol, UPStol, BPtol, psiPrior, tPrior, UPSiter, ...
       Tupdate)

  try 
    
  % Function constants.
  noise = 1e-15;
    
  % Get some important variables.
  imageBlobs  = B;
  N           = length(M);
  maxM        = max(M);
  maxL        = max(L);

  % Run k-means
  % -----------
  % Run k-means on blobs to find clusters centers and blob-cluster
  % membership. 
  proglog('a.) Running k-means.');
  sB = smash_blobs(imageBlobs, M);
  [clusterCenters blobsInClusters] = ...
      do_kmeans(sB', 0, KMiter, KMrest, numclusters);
  clusterCenters  = clusterCenters';
  blobsInClusters = blobsInClusters';

  % Create the new blob matrix. B is an N x B matrix, where B is the
  % maximum number of blobs in a document.
  B = reshape(unsmash_blobs(blobsInClusters, M),[maxM N])';
  clear sB blobsInClusters
  
  % TESTING...
  test_script3;

  % Set up adjacency matrices.
  for n = 1:N,
    A{n} = A{n} > 0;
  end;
  
  % Set up the feature responses count.
  fcnt = psiPrior + tPrior;
  for n = 1:N,
    fcnt = fcnt + M(n) + sum(sum(triu(A{n})));
  end;
  
  % Set up the UPS annealing schedule and the number of 
  if ~UPSiter,
    UPSiter = numwords*numclusters;
  end;
  
  tSched = Tupdate.^[(UPSiter-1):-1:0];
  
  % Initialize the translation probabilities
  % ----------------------------------------
  % t is an B x W matrix, where B = number of blob clusters
  %                             W = number of words tokens
  % The (i,j) entry represents the translation probability t(bi | wj).
  % Initially, the translation probabilities are set to random values.
  t = ones(numclusters,numwords) + tPrior;
  t = t ./ sum(sum(t));

  % Initialise the spatial potentials
  % ---------------------------------
  % psi is a uniform probability table p(wi,wj); it is a W x W matrix
  % where W is the number of of word tokens. Place an unprincipled prior
  % on psi.
  psi = ones(numwords, numwords) + psiPrior;
  psi = triu(ones(numwords,numwords)) .* psi + ...
	(triu(ones(numwords,numwords),1) .* psi)';
  psi = psi / sum(sum(psi));
  
  % Run EM
  % ------
  proglog('b.) Running EM.');
  likelihoods = [];
  oldpsi = psi;
  oldt   = t;
  for iter = 1:EMiter,
    
    % E step
    % ------
    % Do loopy belief propagation to find the alignment probablities
    % p(a_nu = i) and the alignment probabilities over the cliques,
    % p(a_nu = i, a_nv = j).
    [pxi pxic f] = inferaligns(L,M,W,B,A,t,psi,BPtol);
    if ~f,
      proglog('E step failed to converge.');
      psi = oldpsi;
      t   = oldt;
      break;
    end;
    
    % Save the old parameters.
    oldpsi = psi;
    oldt   = t;
    
    % M step
    % ------
    % Do iterative scaling to update the model parameters using the
    % alignment probabilities from the E Step.
    % Set the flag to "not converged".
    f = 0;
    
    % Repeat until we've reached convergence or the maximum number of
    % iterations.
    for s = 1:UPSiter,

      % Get the old predictions and error.
      if s > 1,
        oldFP = FP;
        oldGP = GP;
      end;
      
      % Run loopy belief propagation to find the distribution of the blob
      % and alignment variables. 
      [Pxic Pt fi] = infervars(L,M,W,A,t,psi,BPtol);
      if ~fi,
	proglog('Inference in M Step failed to converge.');
	psi = oldpsi;
	t   = oldt;
	f   = -1;
	break;
      end;
      
      % Get the old model parameters.
      oldpsi = psi;
      oldt   = t;

      % Now that we've computed the marginals of the alignments and blobs
      % given the potentials, find the sufficient statistics of the
      % features. 
      Fp = zeros(numwords, numwords) + psiPrior / (numwords * numwords);
      FP = zeros(numwords, numwords) + psiPrior / (numwords * numwords);
      Gp = zeros(numclusters, numwords) + tPrior / (numclusters * numwords);
      GP = zeros(numclusters, numwords) + tPrior / (numclusters * numwords);

      % Repeat for each document.
      for n = 1:N,

	% Get the number of blobs, number of words and the set of words in
	% the document.
	Mn = M(n);
	Ln = L(n);
	Wn = W(n,1:Ln);
	
	% Repeat for each blob in the document.
	for u = 1:Mn,
	  b = B(n,u);
	  GP(:,Wn) = GP(:,Wn) + Pt{u,n};
	  Gp(b,Wn) = Gp(b,Wn) + pxi{u,n}';
	end;
	clear u 
	
	% Repeat for each MRF clique in the document.
	[us vs] = find(triu(A{n}));
	for i = 1:length(us),
	  u  = us(i);
	  v  = vs(i);
	  FP(Wn,Wn) = FP(Wn,Wn) + Pxic{u,v,n};
	  Fp(Wn,Wn) = Fp(Wn,Wn) + pxic{u,v,n};
	end;
	clear u v i us vs
      end;
      clear n Mn Ln Wn
      
      % Make sure that the MRF clique potentials are symmetric.
      FP = FP + FP';
      Fp = Fp + Fp';
      
      % Update the model parameters.
      psi = psi + log(Fp ./ FP) / fcnt * tSched(s);
      t   = t + log(Gp ./ GP) / fcnt * tSched(s);
      
      % Find the difference between the old predictions nad the new
      % predictions. 
      if s > 1,
	e = max([max(abs(oldFP - FP)) max(abs(oldGP - GP))]);
	proglog('Iterative scaling - iteration %i, factor %g, error %g', ...
		s, tSched(s), e);
	
	% Check to see if the messages have converged.
	if e < UPStol,
	  f = 1;
	  break;
	end;
	
	% Check to see if we've reached infinite error (i.e. the message
	% passing has diverged). This condition will be true if we each Inf
	% or NaN.
	if ~(e < Inf),
	  break;
	end;
      else,
	proglog('Iterative scaling - iteration %i, factor %g', ...
		s, tSched(s));
      end;
      
      % if (s > 1),
      %   if (e > olde),
      %     psi = oldpsi;
      %     t   = oldt;
      %     break;
      %   end;
      % end;
    end;
    
    % Check to see if we have not converged.
    if f < 1,
      proglog('Iterative scaling did not converge');
    end;
    
    % Compute the incomplete log likelihood
    % -------------------------------------
    l = computelikelihood(L,M,B,W,A,t);
    likelihoods = [likelihoods l];
    proglog('   EM iteration %i - log likelihood = %f', iter, l);
    proglog('');    
    
    % Compute the error.
    if iter > 1,
      e = l - likelihoods(iter-1);
      if e < EMtol | f == -1,
	break;
      end;
    end; 
  end;
  
  % Return the model and value of the model.
  if EMiter,
    val = likelihoods(length(likelihoods));
  else,
    val = 0;
  end;
  
  model.t              = t;
  model.psi            = psi;
  model.clusterCenters = clusterCenters;
  model.BPtol          = BPtol;
  
  catch
    peter = 1;
  end;
  
% ------------------------------------------------------------------------
% Run loopy belief propagation to find the marginals on the translation
% and spatial context cliques.
function [xi, xic, f] = inferaligns (L, M, W, B, A, t, psi, tol)

  try
  % Get a few variables.
  N           = length(L);
  numclusters = size(t,1);
  maxM        = max(M);
  
  % Reserve storage for the distribution probabilities for running
  % iterative proportional fitting. 
  xi  = cell(maxM,N);
  xic = cell(maxM,maxM,N);

  % It will be useful to work with the exponential of the parameters.
  et   = exp(t);
  epsi = exp(psi);

  % Get the marginal probabilities of the variables.
  % Repeat for each document.
  for n = 1:N,

    % Get the number of blobs, number of words and the set of words.
    Mn = M(n);
    Ln = L(n);
    Wn = W(n,1:Ln);
	
    % Check for the limiting conditions. When there is one word,
    % setting the alignment probabilities is easy. When there is one
    % blob, we don't need to perform loopy belief propagation.
    if Ln == 1,
      
      % There is only one word, so set the alignment probabilities to 1.
      for u = 1:Mn,
	xi{u,n} = 1;
      end;

      [us vs] = find(triu(A{n}));
      for i = 1:length(us),
	u = us(i);
	v = vs(i);
	xic{u,v,n} = 1;
	xic{v,u,n} = 1;
      end;
      clear us vs u v i
      
    elseif Mn == 1,
      
      % There is only one blob, so set the alignment probabilities to
      % the translation probabilities.
      x       = et(B(n,1),Wn)';
      xi{1,n} = x / sum(x);
      clear x
    else,
	
      % Initialise the adjacencies for the document.
      An = zeros(2*Mn,2*Mn);
      
      % Get the set of adjacencies from the document MRF.
      An(1:Mn,1:Mn) = A{n};
       
      % Set the adjacencies for the translation cliques.
      An(1:Mn,Mn+[1:Mn]) = eye(Mn);
      An(Mn+[1:Mn],1:Mn) = eye(Mn);
      
      % Set up the set of clique probabilities P.
      P   = cell(2*Mn,2*Mn);
      Puv = epsi(Wn,Wn);
      Puv = Puv / sum(sum(Puv));
      
      % For each alignment clique, put the spatial context potential
      % into P. 
      [us vs] = find(triu(A{n}));
      for i = 1:length(us),
	u = us(i);
	v = vs(i);
	P{u,v} = Puv;
	P{v,u} = Puv';
      end;
      clear us vs i u v Puv
      
      % For each translation clique, put the translation potential
      % into P.
      for u = 1:Mn,
	Puv = et(B(n,u),Wn);
	Puv = Puv / sum(sum(Puv));
	P{u+Mn,u} = Puv;
	P{u,u+Mn} = Puv';
      end;
      clear u Puv
      
      % Run loopy belief propagation. If it does not converge, report
      % an error. 
      if 0,
      [x1 x2] = ...
	  exactbeliefswrapper([Ln*ones(Mn,1); ones(Mn,1)],An,P);
      else,
      [x1 x2 f] = loopybp([Ln*ones(Mn,1); ones(Mn,1)], ...
			  An, P, tol, (2*Mn)^2, 0);
      if ~f,
	break;
      end;
      end
	  
      % Copy the resulting probabilities.
      xi(1:Mn,n)       = x1(1:Mn); 
      xic(1:Mn,1:Mn,n) = x2(1:Mn,1:Mn);
      clear x1 x2 
    end;
  end;
  catch
    x = 1;
  end

% ------------------------------------------------------------------------
% Run loopy belief propagation to find the marginals on the translation
% and spatial context cliques.
function [Pxic, Pt, f] = infervars (L, M, W, A, t, psi, tol)

  try
    
  % Get a few variables.
  N           = length(L);
  numclusters = size(t,1);
  maxM        = max(M);
  
  % Reserve storage for the distribution probabilities for running
  % iterative proportional fitting. 
  Pxic = cell(maxM,maxM,N);
  Pt   = cell(maxM,N);

  % It will be useful to work with the exponential of the parameters.
  et   = exp(t);
  epsi = exp(psi);

  % Get the marginal probabilities of the variables.
  % Repeat for each document.
  for n = 1:N,

    % Get the number of blobs, number of words and the set of words.
    Mn = M(n);
    Ln = L(n);
    Wn = W(n,1:Ln);
	
    % Check for the limiting conditions. When there is one word,
    % setting the alignment probabilities is easy. When there is one
    % blob, we don't need to perform loopy belief propagation.
    if Ln == 1,
	  
      % There is only one word, so set the alignment probabilities to
      % 1 and set the blobs to the translation probability for that
      % single word.
      
      % For each alignment clique, put the spatial context potential
      % into P. 
      [us vs] = find(triu(A{n}));
      for i = 1:length(us),
	u = us(i);
	v = vs(i);
	Pxic{u,v,n} = 1;
	Pxic{v,u,n} = 1;
      end;
      clear us vs i u v
      
      % Repeat for each blob in the document.
      for u = 1:Mn,
	x       = et(:,W(n,1));
	Pt{u,n} = x / sum(x);
      end;
      clear u x
    elseif Mn == 1,
	  
      % There is only one blob, so set the alignment and and blob
      % probabilities to the marginals of the translation potential.  
      x       = sum(et(:,Wn));
      Pt{u,n} = x / sum(sum(x));
      clear x
    else,
	
      % Initialise the adjacencies for the document.
      An = zeros(2*Mn,2*Mn);
      
      % Get the set of adjacencies from the document MRF.
      An(1:Mn,1:Mn) = A{n} > 0;
       
      % Set the adjacencies for the translation cliques.
      An(1:Mn,Mn+[1:Mn]) = eye(Mn);
      An(Mn+[1:Mn],1:Mn) = eye(Mn);
      
      % Set up the set of clique probabilities P.
      P   = cell(2*Mn,2*Mn);
      Puv = epsi(Wn,Wn);
      Puv = Puv / sum(sum(Puv));
      
      % For each alignment clique, put the spatial context potential
      % into P. 
      [us vs] = find(triu(A{n}));
      for i = 1:length(us),
	u = us(i);
	v = vs(i);
	P{u,v} = Puv;
	P{v,u} = Puv';
      end;
      clear us vs i u v Puv
      
      % For each translation clique, put the translation potential
      % into P.
      Puv = et(:,Wn);
      Puv = Puv / sum(sum(Puv));
      for u = 1:Mn,
	P{u+Mn,u} = Puv;
	P{u,u+Mn} = Puv';
      end;
      clear u Puv
      
      % Run loopy belief propagation. If it does not converge, report
      % an error. 
      if 0,
      [ans x] = ...
	  exactbeliefswrapper([Ln*ones(Mn,1); numclusters*ones(Mn,1)], ...
			      An, P);
      else,
      [ans x f] = loopybp([Ln*ones(Mn,1); numclusters*ones(Mn,1)], ...
			  An, P, tol, (2*Mn)^2, 0);
      if ~f,
	break;
      end;
      end;
      
      % Copy the resulting probabilities.
      Pxic(1:Mn,1:Mn,n) = x(1:Mn,1:Mn);
      Pt(1:Mn,n)        = diag(x(Mn+[1:Mn],1:Mn));
      clear x
    end;
  end;
  catch
    x = 1;
  end
  
% ------------------------------------------------------------------------
% Use loopy belief propagation to ompute the incomplete log likelihood.
function l = computelikelihood (L, M, B, W, A, t)
  
  % Get a few variables.
  N           = length(L);
  numclusters = size(t,1);
  maxM        = max(M);
  
  % It will be useful to also work with the exponent of the translation
  % parameters. 
  et = exp(t);

  % Find the translation probabilities summed over the blobs.
  etw = sum(et,1);
  
  % Initialise the log likelihood.
  l = 0;
  
  % Repeat for each document.
  for n = 1:N,
    
    % Get the number of blobs, number of words and the set of words.
    Mn = M(n);
    Ln = L(n);
    Wn = W(n,1:Ln);    
    
    % l = l + sum(sum(triu(A{n}))) * sum(sum(psi(Wn,Wn)));
    
    % Repeat for each blob in the document.
    for u = 1:Mn,
      l = l + log(sum(et(B(n,u),Wn) / etw(Wn)));
    end;
  end;
  
% ------------------------------------------------------------------------
% Compute exact beliefs using potential format of LOOPYBP.
function [B, Bc] = exactbeliefswrapper (K, A, P)

  N = length(K);
  
  [is js] = find(triu(A));
  Nc = length(is);
  Pc = cell(Nc,1);
  C  = zeros(Nc,2);
  for u = 1:Nc,
    i      = is(u);
    j      = js(u);
    C(u,:) = [i j];
    Pc{u}  = P{i,j};
  end;
  
  [ans Bct] = exactbeliefs(K,Pc,C);
  
  Bc = cell(N,N);
  for u = 1:Nc,
    i       = C(u,1);
    j       = C(u,2);
    Bc{i,j} = Bct{u};
    Bc{j,i} = Bct{u}';
  end;
  
  B = pottomarg(C,Bct);