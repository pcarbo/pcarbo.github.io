% TRANSLATE    Translates a data set using a trained model.
%    T = TRANSLATE(DATA,MODELPARAMS,MODEL) returns a W x B x N matrix of
%    translation probabilities where W is the number of word tokens, B is
%    the maximum number of blobs in an image and N is the number of
%    images (or documents). MODELPARAMS is obtained from
%    /GENERAL/DATA/LOAD_MODEL_PARAMS. DATA is obtained from
%    /GENERAL/DATA/LOAD_DATA. 
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function t = translate (data, modelparams, model)
  
  % Do some general preprocessing on the data.
  if modelparams.threshOnTest,
    blobThresh = modelparams.blobAreaThresh;
  else,
    blobThresh = 'none';
  end;
  
  % Keep the old blob counts.
  M = data.imageBlobCounts;
  
  % Process the data.
  [data blobsKept] = process_data(data, model.blobs.mean, model.blobs.std, ...
				  blobThresh, 'all', modelparams.featureSel);
  
  % Run the model on the data.
  tm = feval(modelparams.func.trans, data.imageBlobs, ...
	     data.imageBlobCounts, data.adjacencies, model);

  % Initialise the new translation matrix.
  W = size(tm,1);
  t = zeros(W,max(data.imageBlobCounts),data.numImages);
  
  % Fill in the matrix with the model and uniform predictions.
  for i = 1:data.numImages,
    t(:,find(blobsKept(i,:)),i) = tm(:,1:data.imageBlobCounts(i),i);
    t(:,find(~blobsKept(i,1:M(i))),i) = 1 / W;
  end;