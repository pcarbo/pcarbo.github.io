% Input:
%   - DOCS is a N x 1 matrix describing the document membership for each
%     data point. N is the total number of data points.
%   - BALLS is a D x M matrix describing the ball membersehip for each
%     document. M is the maximum number of balls in a document.
%   - X is a F x N matrix of data points (balls).
%   - Y is a 2 x D matrix of labels.
%   - M is a D x 1 matrix of ball counts.
%   - L is a D x 1 matrix of label counts.
%   - KMREST is the number of restarts for K-means.
%   - KMITER is the number of iterations for K-means.
%   - K number of clusters. If K is a matrix, then this is the cluster
%     centres. 
%   - KF is the kernel function.
%   - R is the kernel size.
%   - S0 and S1 are the number of samples to generate.
%   - MU0 and NU0 are priors on "beta".
%   - NEGCONST is 1 only if we use the negative constraints. Otherwise,
%     set it to 0.
%
% Output:
% 

function model = semibinclass_train (docs, balls, X, Y, M, L, ...
				     KMrest, KMiter, K, kf, r, ...
				     S0, S1, mu0, nu0, negconst)
  
  % Set up some function parameters.
  F    = size(X,1); % Number of features.
  N    = size(X,2); % Number of data points.
  S    = S0 + S1;   % The total number of samples to generate. 
  D    = size(L,1); % D is the number of documents in the set.
  maxM = max(M);    % Maximum size for a bag of balls.
  
  % Find mu
  % -------
  % If K is a matrix, than this contains the cluster centres.
  if length(K) > 1,
    mu = K;
    K  = size(mu,2);
  else,
    
    % Find the cluster means using k-means. MU is an F x K matrix.
    [clusterCenters blobsInClusters] = ...
	do_kmeans(X', 0, KMiter, KMrest, K);
    mu = clusterCenters';
  end;
  clear clusterCenters blobsInClusters KMiter KMrest
  
  % Compute kernel matrix
  % ---------------------
  % X is now an (F x N) matrix. We also need to create the kernel
  % matrix, which we will denote by XK -- a N x K+1 matrix.
  XK = [ones(N,1) zeros(N,K)];
  for k = 1:K,
    XK(:,k+1) = feval(kf, X, repmat(mu(:,k),[1 N]), r)';
  end;
  clear k

  % We have to compute X'X a lot of times, so let's get that.
  XtX = XK'*XK;
  
  % Reserve storage for the matrices of samples
  % -------------------------------------------
  Beta = zeros(K+1,S1);
  ys   = zeros(N,S1);
  
  % Initialize delta
  % ----------------
  delta = nu0 / (mu0 + 1);
  
  % Initialize beta
  % ---------------
  beta = delta * randn(K+1,1);
  
  % Initialize z
  % ------------
  z = normrnd(XK*beta,1);
  
  logp = zeros(1,S);

  % Repeat for each sample.
  for s = 1:S,

    A  = inv(eye(K+1)/delta + XtX);
    ZX = z'*XK;

    % Sample alpha
    % ------------
    % alpha = sqrt(inv(gengamma(N/2, z'*z + ZX*A*ZX')));
    
    % Sample beta
    % -----------
    beta = mvnormrnd(A*ZX', A, 1)';    
    % beta = mvnormrnd(A*ZX'/alpha, A, 1)';
 
    % Sample delta
    % ------------
    XKb   = XK*beta;
    delta = inv(gengamma(0.5*(K+1+mu0), 0.5*(nu0+XKb'*XKb)));
    
    % Sample y
    % --------
    % Initialize y. Keep track of which y's have been labeled.
    y   = zeros(N,1);
    lbl = zeros(N,1);
    
    % Grab the labels when we have exactly one.
    f      = find(L(docs) == 1);
    y(f)   = Y(1,docs(f));
    lbl(f) = 1;

    % Get the probability that a data point is labeled with 1.
    p = norm_cdf(XKb, zeros(N,1), ones(N,1))';    
    % p   = 1 - norm_cdf(zeros(N,1), XKb, ones(N,1))';
    
    % Next, sample in the documents that have two labels but only one
    % ball. For these documents, we don't place any constraints on them. 
    f = find(L(docs) == 2 & M(docs) == 1);
    if length(f),
      y(f)   = randb(p(f)');
      lbl(f) = 1;
    end;
    
    % Sample the labels when the bags are two in size but have more than
    % one ball.
    f = find(L(docs) == 2 & M(docs) > 1);
    if length(f),
      fd  = find(L == 2 & M > 1);
      nfd = length(fd);
      P   = zeros(nfd, maxM);
    
      % Build the matrix of probabilities that a document will be selected
      % for the positive label.
      % Repeat for each document.
      i = 0;
      for d = 1:nfd,
	md        = M(fd(d));
	P(d,1:md) = p(f(i+[1:md]));
	i         = i + md;
      end;
      
      % Find the set of data points to set to a positive label.
      t      = randint(P) + balls(fd,1) - 1;
      y(t)   = 1;
      lbl(t) = 1;
    
      % Now that we have a single positive label for every document with
      % more than one label and more than one ball, the next step is to
      % fill in labels with negative examples. Note that we don't need to
      % set "y" on that selection to 0, since in a sense we have already
      % done so.
      if negconst,
	f0 = ~y(f)';
	P  = zeros(nfd, maxM);
      
	% Build the matrix of probabilities that a document will be
        % selected for a negative label.
	% Repeat for each document.
	i = 0;
	for d = 1:nfd,
	  md = M(fd(d));
	  P(d,1:md) = f0(i+[1:md]) .* (1 - p(f(i+[1:md])));
	  i = i + md;
	end;
    
	% Find the set of data points to set to a negative label.
	t      = randint(P) + balls(fd,1) - 1;
	lbl(t) = 1;
      end;
      
      % Sample the remaining labels in an unconstrained fashion. 
      % Essentially, we need to fill in the remaining labels that are still
      % negative that were selected by "f" above.
      f = find(~lbl);
      if length(f),
	y(f) = randb(p(f)');
      end; 
    end;
    
    % Sample z
    % --------
    f  = find(y == 0);
    nf = length(f);
    if nf,
      z(f) = normt_rnd(XKb(f), ones(nf,1), ...
		       repmat(-Inf,[nf 1]), zeros(nf,1));
    end;
    
    f  = find(y == 1);
    nf = length(f);
    if nf,
      z(f) = normt_rnd(XKb(f), ones(nf,1), ...
		       zeros(nf,1), repmat(Inf,[nf 1]));
    end;
    
    % Compute log posterior of sample
    % -------------------------------
    % Z       = norm_cdf(zeros(N,1), XK*beta, ones(N,1));
    % logp(s) = -(0.5*mu0 + 1)*log(delta) - 0.5*nu0/delta ...
    % 	      - 0.5*log(2*pi*delta) - 0.5*beta'*beta/delta  ...
    %	      + sum(log((y == 0).*Z + (y == 1).*(1 - Z)));

    % Store the samples.
    if s > S0,
      Beta(:,s-S0) = beta;
      % Beta(2:K+1,s-S0) = beta(2:K+1);
      ys(:,s-S0)   = y;
    end;    
  end;
  
  % Plot the log posterior over time.
  % figure;
  % plot(1:S, logp);

  % Return the result.
  model.beta = Beta;
  model.logp = logp;
  model.mu   = mu;
  model.r    = r;
  model.kf   = kf;
  
% ------------------------------------------------------------------------
% Generate an N x 1 matrix of random numbers distributed on the Bernoulli
% distribution with success rate P, where P is an N x 1 matrix of
% probabilities. 
function x = randb (p)
  n = size(p,1);
  U = rand(n,1);
  x = floor(p + U);

% ------------------------------------------------------------------------
% Return an N x 1 matrix of random integers, where the probability of
% generating the i for the n-th random variable is given by P(n,i). P is
% a N x M matrix, where the set of integers is defined by [1,M].
function x = randint (p)
  
  % Get some function parameters.
  N = size(p,1);
  M = size(p,2);
  
  % Normalize the probabilities.
  p = p ./ repmat(sum(p,2),[1 M]);
  
  % Set the lower and upper bounds.
  lb = zeros(N,M);
  for m = 2:M,
    lb(:,m) = lb(:,m-1) + p(:,m-1);
  end;
  ub = [lb(:,2:M) ones(N,1)];
  
  % Get the uniform random integers.
  U = rand(N,1);
  U = repmat(U .* (U < 1), [1 M]);
  
  % Figure out which class we're in.
  x = sum((lb <= U & U < ub) .* repmat(1:M, [N 1]), 2);
  