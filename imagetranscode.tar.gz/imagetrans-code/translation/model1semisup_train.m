% Function call:
%
% Input (other than the standard parameters):
%   - KMiter  Number of iterations for k-means.
%   - K       Number of clusters.
%   - S0      Number of samples to "burn in".
%   - S1      Number of samples to keep.
%   - T       Number of samples for prediction.
%   - mu0     Prior on delta.
%   - nu0     Prior on delta.
%   - kernel  Kernel to use. Options are 'gaussian'.
%   - r       The kernel width
% 
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function [model, val] = model1semisup_train ...
    (B, W, A, M, L, numwords, KMiter, K, S0, S1, T, mu0, nu0, kernel, r)

  % try
  
  % Function constants.
  infty = 1e99;
  
  % Set up some function parameters.
  D    = length(M);        % Number of documents/images.
  F    = size(B,1);        % The number of features.
  maxM = max(M);           % The maximum number of blobs in an image.
  maxL = max(L);           % The maximum number of words in an image.
  S    = S0 + S1;          % The total number of samples to generate. 
  C    = numwords;         % The number of classes. 
  X    = smash_blobs(B,M); % Data vector.
  N    = size(X,2);        % Number of data points.
  
  % Modify the word indices by subtracting all of them by -1.
  W = W - 1;
  
  % Find the document number corresponding to each data point i.
  J = zeros(N,1);
  i = 0;
  for d = 1:D,
    md = M(d);
    J(i+1:i+md) = d;
    i = i + md;
  end;
  clear i md d
  
  % Find the kernel function, kf
  kf = kernel;
  clear kernel
  
  % Find mu
  % --------
  % Find the cluster means using k-means. MU is an F x K matrix.
  proglog('a.) Running k-means to find cluster means.');
  [clusterCenters blobsInClusters] = ...
      do_kmeans(X', 0, KMiter, 1, K);
  mu = clusterCenters';
  % mu = [3.1527 1.9985 1.0409];
  clear clusterCenters blobsInClusters KMiter
  
  % Compute kernel matrix
  % ---------------------
  % X is now an (F x N) matrix. We also need to create the kernel
  % matrix, which we will denote by XK -- a N x K+1 matrix.
  proglog('b.) Computing kernel matrix.');
  XK = [ones(N,1) zeros(N,K)];
  for k = 1:K,
    XK(:,k+1) = feval(kf, X,repmat(mu(:,k),[1 N]), r)';
  end;
  clear k

  % We have to compute X'X a lot of times, so let's get that.
  XtX = XK'*XK;
  
  % Reserve storage for the matrices of samples
  % -------------------------------------------
  proglog('c.) Initializing MCMC samples.');
  Beta  = zeros(K+1,C-1,S1);
  alpha = zeros(C-1,1);
  
  % Initialize delta
  % ----------------
  % Grab the mode.
  delta = nu0 / (mu0 + 1) * ones(C-1,1);
  % This causes problems because we can start with really large deltas.
  %   delta = invgamm_rnd(C-1,1,mu0/2,nu0/2);
  
  % Initialize beta
  % ---------------
  % beta = zeros(K+1,C-1);
  beta = repmat(delta',[K+1 1]) .* randn(K+1,C-1);
  
  % Initialize z
  % ------------
  % Initialize the samples for the latent variables z.
  z = zeros(N,C);
  for c = 1:C-1,
    z(:,c+1) = randn(N,1) + XK * beta(:,c);
  end;
  clear c
  
  % Repeat for each sample.
  proglog('d.) Running Enhanced MCMC sampler.');
  for s = 1:S,
    
    % fprintf('Sample %i.\n', s);
    
    % Repeat for each class.
    for c = 1:C-1,
      
      zc  = z(:,c+1);
      Ac  = inv(eye(K+1)/delta(c) + XtX);
      ZXc = zc'*XK;
      
      % Sample alpha
      % ------------
      alpha(c) = sqrt(invgamm_rnd(1,1,N/2,zc'*zc + ZXc*Ac*ZXc'));
      
      if ~(abs(alpha(c)) < Inf),
	error('Problem with alpha');
      end;
      
      % Sample beta
      % -----------
      beta(:,c) = mvnormrnd(Ac*ZXc'/alpha(c),Ac,1)';
      
      if sum(~(abs(beta(:,c)) < Inf)),
	error('Problem with beta');
      end;
      
      % Sample delta
      % ------------
      delta(c) = invgamm_rnd(1,1,0.5*(K+1+mu0),nu0 + 0.5*beta(:,c)'*beta(:,c));
    
      if ~(abs(delta(c)) < Inf),
	error('Problem with delta');
      end;
      
      % Sample Z
      % --------
      % Generate uniform random variates.
      u = rand(N,1);
      u = 1 + floor(L(J) .* u .* (u < 1));
      
      % Get the labels.
      yu = diag(W(J,u));
      
      a = -infty*(yu ~= c) + max(z(:,[2:c c+2:C]),[],2).*(yu == c);
      b = infty*(yu == c) + diag(z(:,yu+1)).*(yu ~= c & yu ~= 0);
      z(:,c+1) = ...
	  normt_rnd(XK*beta(:,c), ones(N,1), a, b);
      zf        = find(z(:,c+1) == -Inf);
      z(zf,c+1) = a(zf) - 1e-3;
      zf        = find(z(:,c+1) == Inf);
      z(zf,c+1) = b(zf) + 1e-3;
    
      if sum(~(abs(z(:,c+1)) < Inf)),
	error('Problem with z');
      end;
    end;
    
    % Store the samples.
    if s > S0,
      Beta(:,:,s-S0) = beta;
    end;
  end;
  clear s zf c u a b zc Ac ZXc yu
  
  % Compute the log posterior p(theta | y)
  % ----------------------------------
  % Compute the log posterior given the samples we generated above. 
  
  % Return the result.
  val         = 1;
  model.beta  = Beta;
  model.mu    = mu;
  model.T     = T;
  model.kf    = kf;
  model.r     = r;
  
  % catch,
  %   disp(lasterr);
  % end;
  
