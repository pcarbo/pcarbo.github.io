% MODEL1DISCRETE_TRAIN    Train model 1 discrete ML.
%   The function call is [MODEL,VAL] = MODEL1DISCRETE_TRAIN(B,W,M,L,
%   NUMWORDS,KMITER,EMITER,EMTOLERANCE). The model-specific parameters
%   are: 
%     - KMITER       The maximum number of iterations to run K-Means.
%     - EMITER       The maximum number of iterations ro run EM.
%     - EMTOLERANCE  Stop the EM algorithm when the difference in error
%                    between two steps is less than EMTOLERANCE.
%
%   In MODEL we will return the following information: 
%     - clusterCenters  F x W matrix where F is the number of features
%                       and W is the number of clusters (i.e. the number
%                       of words), indicating the centres of the
%                       normalized clusters.
%     - t               W x W matrix where W is the number of
%                       words. Entry t(b,w) is the probability of
%                       generating blob b from word w.
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function [model, val] = model1MRFdiscrete_trainFO ...
      (B, W, A, M, L, numwords, numclusters, KMrest, KMiter, ...
       EMiter, EMtol, BPtol, psiPrior, tPrior)

  try 
    
  % Function constants.
  noise = 1e-15;
    
  % Get some important variables.
  imageBlobs  = B;
  N           = length(M);
  maxM        = max(M);
  maxL        = max(L);

  % Run k-means
  % -----------
  % Run k-means on blobs to find clusters centers and blob-cluster
  % membership. 
  proglog('a.) Running k-means.');
  sB = smash_blobs(imageBlobs, M);
  [clusterCenters blobsInClusters] = ...
      do_kmeans(sB', 0, KMiter, KMrest, numclusters);
  clusterCenters  = clusterCenters';
  blobsInClusters = blobsInClusters';

  % Create the new blob matrix. B is an N x B matrix, where B is the
  % maximum number of blobs in a document.
  B = reshape(unsmash_blobs(blobsInClusters, M),[maxM N])';
  clear sB blobsInClusters
  
  % Set up adjacency matrices.
  for n = 1:N,
    A{n} = A{n} > 0;
  end;
  clear n
  
  % Initialize the translation probabilities
  % ----------------------------------------
  % t is an B x W matrix, where B = number of blob clusters
  %                             W = number of words tokens
  % The (i,j) entry represents the translation probability t(bi | wj).
  % Initially, the translation probabilities are set to random values.
  t = ones(numclusters,numwords);
  t = t + tPrior;
  t = t / sum(sum(t));

  % Initialise the spatial potentials
  % ---------------------------------
  % psi is a uniform probability table p(wi,wj); it is a W x W matrix
  % where W is the number of of word tokens. Place an unprincipled prior
  % on psi.
  psi = ones(numwords, numwords);
  psi = psi + psiPrior;
  psi = triu(ones(numwords,numwords)) .* psi + ...
	(triu(ones(numwords,numwords),1) .* psi)';
  psi = psi / sum(sum(psi));
  
  % Run EM
  % ------
  proglog('b.) Running EM.');
  likelihoods = [];
  for iter = 1:EMiter,

    % E step
    % ------
    % Do loopy belief propagation to find the alignment probablities
    % p(a_nu = i) and the alignment probabilities over the cliques,
    % p(a_nu = i, a_nv = j).
    [pxi pxic f] = inferaligns(L,M,W,B,A,t,psi,BPtol);
    if ~f,
      proglog('E step failed to converge.');
      if s > 1,
	psi = oldpsi;
	t   = oldt;
      end;
      break;
    end;
    clear f
    
    % M step
    % ------
    % find the first-order update using the gradient and the alignment
    % probabilities from the E Step. First update t. 
    % Initialise the counts.
    Gcnt = zeros(numclusters, numwords);
    
    % Repeat for each document.
    for n = 1:N,
      
      % Get the set of words in the document.
      Wn = W(n,1:L(n));
      
      % Repeat for each blob in the document.
      for u = 1:M(n),
	b = B(n,u);
	Gcnt(b,Wn) = Gcnt(b,Wn) + pxi{u,n}';
      end;
    end;
    clear n Wn u b

    % Update t.
    x = sum(Gcnt);
    f = find(x);
    if length(f),
      t(:,f) = Gcnt(:,f) ./ repmat(x(f), [numclusters 1]);
    end;
    f = find(~x);
    if length(f),
      t(:,f) = 1 / numclusters;
    end;
    clear x f Gcnt
    
    % Normalise t and add the prior.
    t = t / sum(sum(t));
    t = t + tPrior;
    t = t / sum(sum(t));
    
    % Find the counts for updating psi.    
    psi = zeros(numwords,numwords);
    
    % Repeat for each document.
    for n = 1:N,
      
      % Get the words in the document.
      Ln = L(n);
      Wn = W(n,1:Ln);
      
      % Initialise the counts for the document.
      Fcnt = zeros(Ln,Ln);
      Fx   = zeros(Ln,1);

      % Repeat for each MRF clique in the document.
      [us vs] = find(A{n});
      for i = 1:length(us),
	u    = us(i);
	v    = vs(i);
	Fcnt = Fcnt + pxi{u,n} * pxi{v,n}';
	Fx   = Fx + pxi{u,n};
      end;
      
      % Update psi.
      for i = 1:Ln,
	for j = 1:Ln,
	  wi = W(n,i);
	  wj = W(n,i);
	  psi(wi,wj) = psi(wi,wj) + Fcnt(i,j) / (Fx(i) * Fx(j));
	end;
      end;
    end;
    clear n Wn us vs i j wi wj u v
    
    % Update psi.
    psi  = psi / sum(sum(psi));
    psi  = psi + psiPrior;
    psi  = psi / sum(sum(psi));
    
    % Compute the incomplete log likelihood
    % -------------------------------------
    l = computelikelihood(L,M,B,W,A,t);
    likelihoods = [likelihoods l];
    proglog('   EM iteration %i - log likelihood = %f', iter, l);
    proglog('');    
    
    % Compute the error.
    % if iter > 1,
    %  e = l - likelihoods(iter-1);
    %  if e < EMtol,
    %	break;
    %   end;
    % end; 
  end;
  
  % Return the model and value of the model.
  if EMiter,
    val = likelihoods(length(likelihoods));
  else,
    val = 0;
  end;
  
  model.t              = t;
  model.psi            = psi;
  model.clusterCenters = clusterCenters;
  model.BPtol          = BPtol;
  
  catch
    peter = 1;
  end;

% ------------------------------------------------------------------------
% Run loopy belief propagation to find the marginals on the translation
% and spatial context cliques.
function [xi, xic, f] = inferaligns (L, M, W, B, A, t, psi, tol)

  try
  % Get a few variables.
  N           = length(L);
  numclusters = size(t,1);
  maxM        = max(M);
  
  % Reserve storage for the distribution probabilities for running
  % iterative proportional fitting. 
  xi  = cell(maxM,N);
  xic = cell(maxM,maxM,N);

  % Get the marginal probabilities of the variables.
  % Repeat for each document.
  for n = 1:N,

    % Get the number of blobs, number of words and the set of words.
    Mn = M(n);
    Ln = L(n);
    Wn = W(n,1:Ln);
	
    % Check for the limiting conditions. When there is one word,
    % setting the alignment probabilities is easy. When there is one
    % blob, we don't need to perform loopy belief propagation.
    if Ln == 1,
      
      % There is only one word, so set the alignment probabilities to 1.
      for u = 1:Mn,
	xi{u,n} = 1;
      end;

      [us vs] = find(triu(A{n}));
      for i = 1:length(us),
	u = us(i);
	v = vs(i);
	xic{u,v,n} = 1;
	xic{v,u,n} = 1;
      end;
      clear us vs u v i
      
    elseif Mn == 1,
      
      % There is only one blob, so set the alignment probabilities to
      % the translation probabilities.
      x       = t(B(n,1),Wn)';
      xi{1,n} = x / sum(x);
      clear x
    else,
	
      % Initialise the adjacencies for the document.
      An = zeros(2*Mn,2*Mn);
      
      % Get the set of adjacencies from the document MRF.
      An(1:Mn,1:Mn) = A{n};
       
      % Set the adjacencies for the translation cliques.
      An(1:Mn,Mn+[1:Mn]) = eye(Mn);
      An(Mn+[1:Mn],1:Mn) = eye(Mn);
      
      % Set up the set of clique probabilities P.
      P   = cell(2*Mn,2*Mn);
      Puv = psi(Wn,Wn);
      Puv = Puv / sum(sum(Puv));
      
      % For each alignment clique, put the spatial context potential
      % into P. 
      [us vs] = find(triu(A{n}));
      for i = 1:length(us),
	u = us(i);
	v = vs(i);
	P{u,v} = Puv;
	P{v,u} = Puv';
      end;
      clear us vs i u v Puv
      
      % For each translation clique, put the translation potential
      % into P.
      for u = 1:Mn,
	Puv = t(B(n,u),Wn);
	Puv = Puv / sum(sum(Puv));
	P{u+Mn,u} = Puv;
	P{u,u+Mn} = Puv';
      end;
      clear u Puv
      
      % Run loopy belief propagation. If it does not converge, report
      % an error. 
      [x1 x2 f] = loopybp([Ln*ones(Mn,1); ones(Mn,1)], ...
			  An, P, tol, (2*Mn)^2, 0);
      if ~f,
	break;
      end;
	  
      % Copy the resulting probabilities.
      xi(1:Mn,n)       = x1(1:Mn); 
      xic(1:Mn,1:Mn,n) = x2(1:Mn,1:Mn);
      clear x1 x2 
    end;
  end;
  
  catch
    x = 1;
  end

% ------------------------------------------------------------
function [pxi, pxic] = inferaligns2 (L, M, W, B, A, t, psi, tol)
  
  for n = 1:N,
    Mn = M(n);
    Ln = L(n);
    Wn = W(n,1:Ln);  
    
    % Run loopy belief propagation, grabbing the potentials only for
    % the words in the image's label.
    if Mn  1,	
      pot = psi(W(n,1:ls),W(s,1:ls));
      
      % Run loopy belief propagation.
      indicator(1:ms,1:ls,s) = bpmrf2(A{n},pot,tn,1,tol,Mn^4,0); 
    else,
      indicator(1,1:ls,s) = t;
    end;
  end;
  
% ------------------------------------------------------------------------
% Use loopy belief propagation to ompute the incomplete log likelihood.
function l = computelikelihood (L, M, B, W, A, t)
  
  % Get a few variables.
  N           = length(L);
  numclusters = size(t,1);
  maxM        = max(M);
  
  % Initialise the log likelihood.
  l = 0;
  
  % Repeat for each document.
  for n = 1:N,
    
    % Get the number of blobs, number of words and the set of words.
    Mn = M(n);
    Ln = L(n);
    Wn = W(n,1:Ln);    
    
    % Repeat for each blob in the document.
    for u = 1:Mn,
      l = l + log(sum(t(B(n,u),Wn) / sum(t(:,Wn))));
    end;
  end;
