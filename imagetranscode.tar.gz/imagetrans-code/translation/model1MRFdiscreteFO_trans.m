% MODEL1MRFGAUSSMAP_TRANS
%
%    Copyright (c) 2003 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function t = model1MRFdiscreteFO_trans (B, M, A, model)

  try
  
  % Function constants.
  BPiter = 10;
  
  % Get some variables.
  N           = length(M);
  maxM        = max(M);
  numclusters = size(model.t,1);
  numwords    = size(model.t,2);  
  blobImages  = B;
  
  % Convert the matrix of blobs to a discrete matrix of clusters. In
  % other words, we need to find the membership for each blob.
  B = zeros(N,maxM);
  
  % Repeat for each document.
  for n = 1:N,
    % Repeat for each blob in the document.
    for b = 1:M(n),
      % Find the cluster that best matches the blob.
      [ans c] = min(sum((repmat(blobImages(:,b,n),[1 numclusters]) - ...
			 model.clusterCenters).^2,1));
      B(n,b) = c;
    end;
  end;
  clear blobImages
  
  % Now that we've clustered the blobs, let's build the "t" matrix.
  t = zeros(numwords,maxM,N);
  
  % Repeat for each sentence.
  for n = 1:N,
    Mn = M(n);
    Bn = B(n,1:Mn);
      
    % Run loopy belief propagation, grabbing the potentials only for
    % the words in the image's label. 
    if Mn > 1,
      
      % Run loopy belief propagation.
      t(:,1:Mn,n) = bpmrf2(A{n} > 0, model.psi, model.t(Bn,:), model.sp, ...
			   model.BPtol, BPiter*Mn, 0)';
    else,
      t(:,1,n) = model.t(Bn,:)';
    end;
    
    % Normalize again, over all the words.
    z  = sum(t(:,:,n),1);
    f  = find(z);
    fn = find(~z);
    if length(f),
      t(:,f,n) = t(:,f,n) ./ repmat(z(f), [numwords 1]);
    end;
    if length(fn),
      t(:,fn,n) = 1 / numwords;
    end;
  end;  
  
  catch
    peter = 1;
  end;