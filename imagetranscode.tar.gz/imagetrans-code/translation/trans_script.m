data = load_data(datadir);
modelparams.threshOnTest = 0;
modelparams.func.trans = 'model1MRFdiscrete_trans';
modelparams.featureSel = [8:13];

resultdir = [datadir '/results/dML1MRFd/trial1'];
x = importdata([resultdir '/blobs']);
model.blobs.mean = x(1,:)';
model.blobs.std  = x(2,:)';
model.psi = importdata([resultdir '/psi']);
model.t   = importdata([resultdir '/t']);
model.clusterCenters = importdata([resultdir '/clusters']);
model.BPtol = 1e-5;

t = translate(data{1}, modelparams, model);

write_translation(resultdir, data{1}, t);