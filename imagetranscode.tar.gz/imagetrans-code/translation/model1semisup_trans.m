function t = model1semisup_trans (B, M, A, model)
  
  D    = length(M);
  maxM = max(M);
  C    = size(model.beta, 2) + 1;
  S    = size(model.beta, 3);
  T    = model.T;
  K    = size(model.mu, 2);
  kf   = model.kf;
  
  % Allocate memory for the "t" matrix.
  t = zeros(C,maxM,D);

  % Repeat for each document and then for each blob in the document. 
  for d = 1:D,
    for b = 1:M(d),
      
      % Get the data point.
      x = B(:,b,d);
      
      % Compute kernel matrix. XK is a 1 x K+1 matrix.
      XK = [1 feval(kf, repmat(x,[1 K]), model.mu, model.r)];
      
      % What we're going to do now is generate a set of T samples z_N+1 ~
      % p(z_N+1 | x_N+1,x,y). To do that for each sample, we pick a
      % beta_c at random from our set of samples and then generate
      % z_N+1,c using the probability p(z_N+1,c | x_N+1, beta_c).

      % Get a set of uniform random variables. in order to sample from
      % the probability p(z_N+1,c | x_N+1, x, y).
      
      % U = rand(T,1);
      % U = 1 + floor(S * U .* (U < 1));
      
      % Generate the samples z_N+1,c.
      Z = zeros(C-1,T);
      for s = 1:T,
	fprintf('Sample %i\n', s);
	for c = 1:C-1,
	  for s2 = 1:S,
	    Z(c,s) = Z(c,s) + normrnd(XK(2:4)*model.beta(2:4,c,s2), 1);
	  end;
	  % Z(c,s) = sum(normrnd(XK*reshape(model.beta(:,c,:),[K+1 S]), 1))/S;
	end;
      end;
      Z = Z / s;
      
      % Now that we have the samples for z_N+1, this makes up an
      % approximate distribution for p(y_N+1 | x_N+1,x,y);
      [maxZ I] = max(Z);
      Y        = (maxZ > 0) .* I;
      
      % Convert the integral Y to translation probability table.
      t(:,b,d) = count(Y+1,C);
    end;
  end;
    
% -------------------------------------------------------------
function c = count (x,C)
  
  % Initialize c.
  N = length(x);
  c = zeros(C,1);
  
  for i = 1:N,
    c(x(i)) = c(x(i)) + 1;
  end;
  
  c = c / N;