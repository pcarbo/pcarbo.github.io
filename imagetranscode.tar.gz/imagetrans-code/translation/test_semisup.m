% User-defined parameters.
sigma = 0.1;
test = 1;

if test == 1,
words = {'sun';
	 'sky';
	 'grass'};
W = [1 0 0;
     1 0 0;
     1 0 0;
     2 0 0; 
     2 0 0;
     2 0 0;
     3 0 0;
     3 0 0;
     3 0 0;
     1 2 3 ];

train = 9;
B = W;
  
elseif test == 2,
words = {'sun';
	 'sky';
	 'grass'};
W = [1 2 0;
     3 2 0;
     1 2 3;
     1 2 3 ];

B = [1 2 0;
     3 2 0;
     1 2 3;
     1 2 3 ];

train = 3;
end;


dirs = genpath('../general');
path(dirs, path);

% Generate the word and blob lengths.
D = size(W,1);
L = zeros(D,1);
M = zeros(D,1);
for d = 1:D,
  L(d) = sum(W(d,:) > 0);
  M(d) = sum(W(d,:) > 0);
end;

% Generate the set of blobs.
B_ = [];
for d = 1:D,
  for b = 1:M(d),
    B_(1,b,d) = normrnd(B(d,b),sigma);
  end;
end;

B_

% Train the model.
S = 1000;
[model val] = model1semisup_train ...
    (B_(:,:,1:train), W(1:train,:), {}, M(1:train), L(1:train), ...
     length(words), 10, 3, S, S, 100, 0.1, 0.1, ...
     'gaussian', 1);  

% Test the model.
fprintf('Testing the model.\n');
t = model1semisup_trans (B_(:,:,train+1:D), M(train+1:D), {}, model);
