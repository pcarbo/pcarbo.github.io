% Input:
%   - X is a F x N matrix of data points (balls).
%   - MODEL is the model.
%   - T is the number of samples to generate.
%
% Output:
%   - t is a 2 x N matrix of class probabilities.

function t = semibinclass_test (X, model, T)
  
  % Set up some function parameters.
  S  = size(model.beta,2); % Number of training samples.
  K  = size(model.mu,2);   % Number of kernel functions.
  N  = size(X,2);          % Number of data points.  
  kf = model.kf;           % The kernel function.
  
  % Allocate memory for the final result.
  t = zeros(2,N);
  
  % Repeat for each data point.
  for i = 1:N,
      
    % Get the data point.
    x = X(:,i);
      
    % Compute kernel matrix. XK is a 1 x K+1 matrix.
    XK = [1 feval(kf, repmat(x,[1 K]), model.mu, model.r)];
  
    % Generate uniform random variables for the samples.
    % U = rand(T,1);
    % U = 1 + floor(S * U .* (U < 1));
    
    % Generate the samples and find the mean of them.
    t(2,i) = sum(norm_cdf(zeros(S,1),(XK*model.beta)',ones(S,1)) < 0.5) / S;
    % t(2,i) = sum(normrnd(XK*model.beta(:,U), 1) > 0.5) / T;
  end;
  
  % Return the result.
  t(1,:) = 1 - t(2,:);

    