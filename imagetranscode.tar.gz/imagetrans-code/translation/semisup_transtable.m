m = 1;
d = 2;

testData = data{d};
fprintf('Testing model %i on data set "%s" (word %s). \n', ...
	m, testData.setlabel, word);

% Do a bit of preprocessing on the data.
testData = process_data(testData, blobinfo.mean, blobinfo.std, ...
			'none', 'all', modelparams.featureSel);

[X ans L M docs ans y] = convert_data(testData, word);

N = length(y);

S0          = modelparams.S0;
S           = S0 + modelparams.S1;
modelt      = model{m};
modelt.beta = modelt.beta(:,S0+1:S);
modelt.logp = modelt.logp(S0+1:S);

% Get the translation matrix by computing T samples.
% t = semibinclass_test(X, modelt, modelparams.T);
t = semibinclass_test2(X, modelt);

% Find the index of the word. 
% The index of the word is contained in "w". 
for wi = 1:testData.numWords,
  if strcmp(testData.words{wi}, word),
    w = wi;
    break;
  end;
end;
clear wi

% Convert the translation table into a probability table.
tnew = zeros(length(testData.words), max(testData.imageBlobCounts), ...
	     testData.numImages);

i = 0;
for n = 1:testData.numImages,
  for b = 1:testData.imageBlobCounts(n),
    i = i + 1;
    [ans maxt] = max(t(:,i));
    if maxt == 2,
      tnew(w,b,n) = 1;
    else,
      tnew(:,b,n) = 1 / length(testData.words);
    end;
  end;
end;

write_translation([data_dir '/results/semisup/trial4'], testData, tnew);
