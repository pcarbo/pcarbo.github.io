function [pm, pr] = evaluate_semisup (data_dir, word, varargin) 
  
  % Function constants.
  generalPath = '../general';
  
  % Model parameters.
  modelparams.KMrest = 20;
  modelparams.KMiter = 24;
  modelparams.K      = 300;
  modelparams.kf     = 'gaussian';
  modelparams.r      = 2;
  modelparams.S0     = 10000;
  modelparams.S1     = 10000;
  modelparams.mu0    = 0.01;
  modelparams.nu0    = 0.01;
  modelparams.T      = 10000;
  %word = 'cheetah';
  negconst = 1;
  
  modelparams.blobAreaThresh = 0.01; 
  modelparams.maxNumBlobs    = 'all';
  modelparams.featureSel     = [8:13];
  
  % Default arguments.
  defaultTrainingSet = 1;
  
  % Add the proper paths in order to access the "general" functions. 
  oldPath = path;
  dirs    = genpath(generalPath);
  path(dirs, oldPath);
  clear generalPath dirs  
  
  % Set up function parameters
  % --------------------------
  defargs = { defaultTrainingSet };
  trainingSet = manage_vargs(varargin, defargs);
  clear defargs varargin defaultTrainingSet
  
  % Load data
  % ---------
  fprintf('Loading the data from %s. \n', data_dir);
  data      = load_data(data_dir);
  trainData = data{trainingSet};
  
  % Find mean and variance
  % ----------------------
  % First reshape the blobs data in a (F x N) matrix, where N is the
  % total number of blobs.
  blobs = smash_blobs(trainData.imageBlobs, trainData.imageBlobCounts);
  
  % Now that we have the blobs in a nice format, we can find the mean and
  % variance. 
  blobinfo.mean = mean(blobs')';
  blobinfo.std  = std(blobs')';
  clear blobs
  
  % Process the data
  % ----------------
  % Do some general preprocessing on the data.
  fprintf('Doing some preprocessing of the data. \n');
  trainData = process_data(trainData, blobinfo.mean, blobinfo.std, ...
		      modelparams.blobAreaThresh, ...
		      modelparams.maxNumBlobs, modelparams.featureSel);
  
  % Do some final data processing
  % -----------------------------
  fprintf('Doing some more preprocessing of data. \n');
  [X Y L M docs balls y] = convert_data(trainData, word);
  clear y
  
  % Train the model
  % ---------------
  % First find the clusters.
  fprintf('Finding the cluster means. \n');
  tic;
  % [mu ans] = do_kmeans(X', 0, modelparams.KMiter, ...
  %		         modelparams.KMrest, modelparams.K);
  % mu = mu';
  
  % Next train the model.
  fprintf('Training the model. \n');
  % model = binclass_train(X(:,find(y >= 0)), y(find(y >= 0)), ...
  %			 modelparams.KMiter, modelparams.K, 0, ...
  %			 modelparams.S0 + modelparams.S1, ...
  %			 modelparams.mu0, modelparams.nu0, modelparams.r);
  
  if 0,
  Np = length(find(y >= 0));
  model{1} = semibinclass_train([1:Np]', [1:Np]', ...
				X(:,find(y >= 0)), y(find(y >= 0))', ...
				ones(Np,1)', ones(Np,1)', ...
				modelparams.KMrest, modelparams.KMiter, ...
				modelparams.K, modelparams.kf, ...
				modelparams.r, 0, ...
				modelparams.S0 + modelparams.S1, ...
				modelparams.mu0, modelparams.nu0, negconst);
  end
  
  % Semi-supervised model.
  if 0,
  model{1} = semibinclass_train(docs, balls, X, Y, M, L, ...
				modelparams.KMrest, modelparams.KMiter, ...
				modelparams.K, modelparams.kf, ...
				modelparams.r, 0, ...
				modelparams.S0 + modelparams.S1, ...
				modelparams.mu0, modelparams.nu0, negconst);
  end
  
  if 1,
  % EM model.
  [modelt ans] = ...
      model1gaussML_train(unsmash_blobs(X,M), Y'+1, {}, ...
			  M, L, 2, modelparams.KMiter, ...
			  20, 0.01, 'no', 'no');
  model{3} = modelt;
  clear modelt
  end
  
  t = toc;
  fprintf('Training took %0.2f seconds. \n', t);
  clear docs balls X M trainData mu t y

  % Compute the (empirically) random model
  % --------------------------------------
  [ans randModel] = max(count_labels(Y,L));
  randModel = randModel - 1;
  clear Y L
  
  % Test the model on training and test sets
  % ----------------------------------------
  numDatasets = length(data);
  pm          = zeros(numDatasets,1);
  pr          = zeros(numDatasets,1);
  for d = 1:numDatasets,
    for m = 3 %0:1,
      testData = data{d};
      fprintf('Testing model %i on data set "%s" (word %s). \n', ...
	      m, testData.setlabel, word);
    
      % Do a bit of preprocessing on the data.
      testData = process_data(testData, blobinfo.mean, blobinfo.std, ...
			      'none', 'all', modelparams.featureSel);
  
      % Do some more processing of the data.
      [X ans L M docs ans y] = convert_data(testData, word);

      % Remove the data points with the ambiguous labels. We are only
      % concerned with those that have exact labels (i.e. 0 or 1).
      f    = find(y >= 0);
      y    = y(f);
      docs = docs(f);
      X    = X(:,f);
      N    = length(y);
    
      % Prune the set of samples.
      if m == 0,
	t = repmat([1;0]*(~randModel) + [0;1]*randModel, [1 N]);
      
      elseif m == 1 | m == 2,
	S0          = modelparams.S0;
	S           = S0 + modelparams.S1;
	modelt      = model{m};
	modelt.beta = modelt.beta(:,S0+1:S);
	modelt.logp = modelt.logp(S0+1:S);

	% Get the translation matrix by computing T samples.
	% t = semibinclass_test(X, modelt, modelparams.T);
	t = semibinclass_test2(X, modelt);
      elseif m == 3,
	% EM model.
	modelt = model{m};
	t = model1gaussML_trans(reshape(X,[size(X,1) 1 N]), ones(N,1), {}, ...
				modelt);
	t = reshape(t, [2 N]);
      end;
      
      eval_translation(y,t,L(docs),0.5);
      
      % fprintf('The precision of the model on the word "%s" on the \n', word);
      % fprintf('"%s" set is %0.4f \n', testData.setlabel, pm(d));
      % fprintf('The random bound is %0.4f \n', pr(d));
    end;
  end;
  clear testData t S modelt f y X N
  
  % Restore the old path.
  path(oldPath);
 
% -----------------------------------------------------------------
function [X, Y, L, M, docs, balls, y] = convert_data (data, word)
  
  % Find the index of the word. 
  % The index of the word is contained in "w". 
  for wi = 1:data.numWords,
    if strcmp(data.words{wi}, word),
      w = wi;
      break;
    end;
  end;
  clear wi
  
  X = smash_blobs(data.imageBlobs, data.imageBlobCounts);
  N = size(X,2);
  D = data.numImages;

  % Construct the set of labels.
  Y      = -ones(2,D);
  Y(1,:) = sum(data.imageWords == w,2)';
  Y(2,:) = -1 * (~Y(1,:) | data.imageWordCounts' == 1);

  % Construct the set of exact labels. We set the label to 1 when there
  % is only the positive label (w), we set the label to 0 when there is
  % at least one negative label and not the positive label, and set the
  % label to -1 if there is both the negative label and the positive
  % label or neither.
  yt = smash_blobs(data.blobWords, data.imageBlobCounts);
  y0 = sum(yt ~= w & yt > 0,1)' > 0;
  y1 = sum(yt == w,1)';
  y  = -(y0 == y1) + (y1 & ~y0);
  clear yt y0 y1
  
  % Construct the sizes for the bags of labels and the bags of balls.
  L = sum(Y >= 0,1)';
  M = data.imageBlobCounts;
  
  % We need to build the structures "docs" and "balls".
  docs  = zeros(N,1);
  balls = zeros(D, max(M));
  i = 0;
  for d = 1:D,
    balls(d,1:M(d))  = i + [1:M(d)];
    docs(i+[1:M(d)]) = d;
    i = i + M(d);
  end;
  clear i d  

% --------------------------------------------------------------------
% We assume there are two labels.
function counts = count_labels (Y, L)

  L = L';
  
  counts = zeros(1,2);
  for c = 0:1,
    counts(c+1) = sum((Y(1,:) == c) ./ L) + ...
	          sum((Y(2,:) == c & L == 2) ./ L);
  end;

% --------------------------------------------------------------------
 % t is a 2 x N matrix. y is an N x 1 matrix.
function [fp, tp] = eval_translation (y, t, L, thresh)

  N = length(y);

  % Evaluate the translation matrix for the model.
  I       = t(2,:) >= thresh;
  p       = sum(y' == I) / N;
  y0      = find(y == 0);
  y1      = find(y == 1);
  f0      = sum(y(y0)' ~= I(y0));
  f1      = sum(y(y1)' ~= I(y1));

  u       = find(L > 1);
  pu      = sum(y(u)' == I(u)) / length(u);
  yu0     = find(y == 0 & L > 1);
  yu1     = find(y == 1 & L > 1);
  fu0     = sum(y(yu0)' ~= I(yu0));
  fu1     = sum(y(yu1)' ~= I(yu1));  
  
  fprintf('\n');
  fprintf('- %i known labels \n', sum(L == 1));
  fprintf('- %i unknown labels \n', sum(L == 2));

  fprintf('ALL LABELS: %0.4f \n', p);
  fprintf('- false positives: %i / %i \n', f0, length(y0));
  fprintf('- false negatives: %i / %i \n', f1, length(y1));
	  
  fprintf('UNKNOWN LABELS: %0.4f \n', pu);
  fprintf('- false positives: %i / %i \n', fu0, length(yu0));
  fprintf('- false negatives: %i / %i \n\n', fu1, length(yu1));

  fp = f0;
  tp = 1 - f1;