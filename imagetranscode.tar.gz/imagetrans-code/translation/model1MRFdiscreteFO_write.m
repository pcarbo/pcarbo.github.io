% MODEL1GAUSSMAP_WRITE
%
%    Writes the following files to disk:
%      - sigma
%      - mu
%      - tau
%      - psi{1,...,n}
%      - misc
%
%    Copyright (c) 2003 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function model1MRFdiscreteFO_write (d, model)
  
  % Write out "sp" and "BPtol".
  write_matrix(d, 'misc', [model.sp model.BPtol]);

  % Write out the potentials psi.
  write_matrix(d, 'psi', model.psi);
  
  % Write out the translation matrix.
  write_matrix(d, 't', model.t);
