addpath /grads2/pcarbo/matlab/statbox/
addpath /grads2/pcarbo/matlab/mcmc/
addpath /grads2/pcarbo/matlab/econometrics/distrib/

% Script parameters.
datadir = '/cs/beta/People/Nando/corel/imagetrans/data/sets/new/corelB/ncuts';
word    = 'bear'
% r       = [0.1];
seed    = 6768;

% Train and test the model.
j = 0;
j = j + 1;
% fprintf('Evaluating using a kernel width of %0.2f \n', i);
rand('state', seed);
randn('state', seed);
[pmi pri] = evaluate_semisup(datadir,word);
% pm{j} = pmi;
% pr{j} = pri;
fprintf('\n');

