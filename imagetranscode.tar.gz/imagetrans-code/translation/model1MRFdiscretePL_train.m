% MODEL1MRFGAUSSMAP_TRAIN    Train model 1 MRF Gaussian MAP.
%   The function call is [MODEL,VAL] = MODEL1MRFGAUSSMAP_TRAIN(B,W,M,L,
%   NUMWORDS,KMITER,EMITER,EMTOL,ALPHA,A,B,PSIPRIOR,SP,RANDINIT). The
%   model-specific parameters are:
%     - KMITER       The maximum number of iterations to run
%                    K-Means. Only valid if RANDINIT is 'no' (see
%                    below). 
%     - EMITER       The maximum number of iterations ro run EM.
%     - EMTOL        Stop the EM algorithm when the difference in error
%                    between two steps is less than EMTOLERANCE.
%     - ALPHA        The degree of freedom parameter for the Inverse
%                    Wishart distribution on the covariance.
%     - A            The shape parameter on the Inverse Gamma
%                    distribution on tau.
%     - B            The scale parameter on the Inverse Gamma
%                    distribution for tau.
%     - PSIPRIOR     A Dirichlet prior on the inter-alignment
%                    potentials, psi. 0 means no prior.
%     - SP           If it is 'yes', use the sum-product algorithm
%                    (i.e. mean) for inference. Otherwise, use argmax.
%     - RANDINIT     Optional parameter. By default, the value of this
%                    parameter is 'no' which means that the cluster means
%                    are initialized using K-Means. If this parameter is
%                    'yes', they are initialized by sampling randomly
%                    from the prior distribution. If RANDINIT is set to
%                    'yes' then the parameter KMITER is irrelevant.
%      
%   In MODEL we will return the following information:
%     - mu   F x W matrix of Gaussian means, where F is the number of
%            features and W is the number of word tokens.
%     - sig  F x F x W matrix of Gaussian covariances.
%     - tau  F x 1 matrix of feature weights.
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function [model, val] = model1MRFdiscretePL_train ...
      (B, W, A, M, L, numwords, KMiter, EMiter, EMtol, numclusters, ...
       psiPrior, tPrior, sp, BPtol)

  try
  
  % Function constants.
  BPiter = 10;
  
  % Set up some miscellaneous parameters
  N    = length(M);
  maxM = max(M);
  maxL = max(L);
  sp   = strcmp('yes',sp);

  % Run k-means
  % -----------
  % Run k-means on blobs to find clusters centers and blob-cluster
  % membership. 
  imageBlobs = B;
  sB = smash_blobs(imageBlobs, M);
  [clusterCenters blobsInClusters] = ...
      do_kmeans(sB', 0, KMiter, 1, numclusters);
  clusterCenters  = clusterCenters';
  blobsInClusters = blobsInClusters';
  
  % Create the new blob matrix. B is an N x B matrix, where B is the
  % maximum number of blobs in a document.
  B = reshape(unsmash_blobs(blobsInClusters, M),[maxM N])';  
  clear sB blobsInClusters
  
  % Set up adjacency matrices.
  for n = 1:N,
    A{n} = A{n} > 0;
  end;
  clear n
  
  % Set up a matrix describing the neighbours for each node. At the same
  % time, let's find out the largest number of neighbours in the graph. 
  NB = zeros(N,maxM);
  for n = 1:N,
    NB(n,1:M(n)) = sum(A{n});
  end;
  maxNB = max(max(NB));

  % Create the matrix with the actual neighbour indices now.
  nb = zeros(maxM,maxNB,N);
  for n = 1:N,
    for b = 1:M(n),
      bs = find(A{n}(b,:));
      if length(bs),
	nb(b,1:NB(n,b),n) = bs;
      end;
    end;
  end;
  clear n b bs

  % Allocate memory for latent variables.
  xi = zeros(maxM,maxL,N);

  % Initialize psi.
  psi = rand(numwords, numwords);
  psi = psi / sum(sum(psi)) + psiPrior;  
  psi = psi / sum(sum(psi));

  % Initialise t.
  t = rand(numclusters, numwords);
  t = t / sum(sum(t)) + tPrior;
  t = t ./ repmat(sum(t), [numclusters 1]);
  
  % Run EM.
  proglog('Running EM.');
  for iter = 1:EMiter,
    
    % Save the old parameter values.
    oldpsi = psi;
    oldt   = t;
    
    % E step
    % ------
    % Compute p(a_si=j|b_sj,w_si).
    % Repeat for each sentence.
    for n = 1:N,
      Mn = M(n);
      Ln = L(n);
      Wn = W(n,1:Ln);
      Bn = B(n,1:Mn);
      
      % Run loopy belief propagation, grabbing the potentials only for
      % the words in the image's label.
      if Mn == 1,
	xi(1,1:Ln,n) = t(Bn,Wn);
      else,
	
	% Run loopy belief propagation.
	[xi(1:Mn,1:Ln,n) xic(1:Ln,1:Ln,1:Mn,1:Mn,n)] = ...
	    bpmrf2(A{n} > 0, psi(Wn,Wn), t(Bn,Wn), sp, BPtol, BPiter*Mn, 0);
      end;
      
      % Normalize again.
      z  = sum(xi(1:M(n),1:L(n),n),2);
      f  = find(z);
      fn = find(~z);
      if length(f),
	xi(f,1:Ln,n) = xi(f,1:Ln,n)./repmat(z(f),[1 Ln]);
      end;
      if length(fn),
	xi(fn,1:Ln,n) = 1 / Ln;
      end;
      clear z f fn
    
    end;
    clear n Mn Ln Wn Bn
    
    % M step
    % ------
    % Get the feature counts (the sufficient statistics) from the
    % marginals of the cliques from the E Step. For the purpose of
    % iterative scaling in the M Step, these will be considered the
    % "true" counts.
    [fcnt gcnt] = gettruecounts(numwords,numclusters,L,M,W,B,nb,NB,xi,xic);    
    
    % Estimate the counts given the current parameters.
    t = t / sum(sum(t));
    [Fcnt Gcnt] = estimatecounts(numwords,numclusters,M,L,W,nb,NB,psi, ...
				 t,xi,BPtol);
    Gcnt = sum(Gcnt,3);
      
    % Perform the iterative proportional fitting update on t.
    t = ipf(gcnt,Gcnt,t);
    t = t + tPrior;
    t = t / sum(sum(t));
    
    % Estimate the counts given the current parameters.
    [Fcnt Gcnt] = estimatecounts(numwords,numclusters,M,L,W,nb,NB,psi, ...
				 t,xi,BPtol);

    % Perform the iterative scaling update on psi.
    psi = iis(fcnt,Fcnt,psi);
    psi = psi + psiPrior;
    psi = psi / sum(sum(psi));
    
    % Perform the iterative scaling update on t.
    t = iis(gcnt,Gcnt,t);
    t = t + tPrior;
    
    % Normalise t.
    t = t ./ repmat(sum(t), [numclusters 1]);

    % Find the error between the two EM iterations.
    e = max(max(abs([(oldpsi - psi) (oldt - t)'])));
    proglog('   EM iteration %i - error %g', iter, e);
    
    if e < 1e-3,
      break;
    end;
  end; % Repeat EM.

  % Return the model.
  model.psi            = psi;
  model.t              = t;
  model.sp             = sp;
  model.BPtol          = BPtol;
  model.clusterCenters = clusterCenters;  
  
  % Return the value.
  val = 0;

  catch
    peter = 1;
  end;
  
% ---------------------------------------------------------------------
% Find the true counts.
function [fcnt, gcnt] = gettruecounts ...
      (numwords, numclusters, L, M, W, B, nb, NB, xi, xic)

  try
  
  % Get some variables.
  N = length(L);
    
  % Initialise the "true" counts.
  fcnt = zeros(numwords,numwords);
  gcnt = zeros(numclusters,numwords);
  
  % Repeat for each document.
  for n = 1:N,
    
    % Get the words in the document.
    Mn = M(n);
    Ln = L(n);
    Wn = W(n,1:Ln);
    
    % Repeat for each blob in the document.
    for u = 1:Mn,
      
      % Get the blob associated with index i.
      b = B(n,u);
      
      % Count the translation probability.
      gcnt(b,Wn) = gcnt(b,Wn) + xi(u,1:Ln,n);
      
      % Repeat for each neighbour of the blob.
      naybrs = nb(u,1:NB(n,u),n);
      for v = naybrs,
	fcnt(Wn,Wn) = fcnt(Wn,Wn) + xic(1:Ln,1:Ln,u,v,n);
      end;
    end;
  end;

  % Make sure the spatial context feature counts are symmetric.
  fcnt = fcnt + fcnt';    

  catch
    peter = 1;
  end;
  
% ------------------------------------------------------------------------
% Estimate the counts given the current parameters.
function [Fcnt, Gcnt] = estimatecounts ...
      (numwords, numclusters, M, L, W, nb, NB, psi, t, xi, BPtol)

  try
  
  % Get a few variables.
  N           = length(L);
  numwords    = size(psi,1);
  numclusters = size(t,1);
  maxNB       = max(max(NB));
  
  % Initialise the estimated counts.
  Fcnt = zeros(numwords,numwords,maxNB+1); 
  Gcnt = zeros(numclusters,numwords,maxNB+1);
      
  % Run iterative scaling / iterative proportional fitting over each
  % "neighbourhood" of the pseudo-likelihood.
  % Repeat for each document.
  for n = 1:N,
	
    % Get the number of blobs, number of words and the set of words.
    Mn = M(n);
    Ln = L(n);
    Wn = W(n,1:Ln);
    
    % Check for the limiting condition when there is only one
    % blob. In that case, we only need to update the translation
    % potential. 
    if Mn == 1,
      x            = t(:,Wn);
      Gcnt(:,Wn,1) = Gcnt(:,Wn,1) + x / sum(sum(x));
    else,
      
      % Repeat for each blob in the document.
      for u = 1:Mn,
	
	% What we need to do is find the estimated probabilities of
	% the cliques in the neighbourhood of b.
	% Get the number of neighbours and the neighbours
	% themselves. 
	Nc     = NB(n,u);
	naybrs = nb(u,1:Nc,n);
	
	% Create the set of potentials. We need a clique for each of
	% the neighbours and an extra one for the link going to the
	% observed node (blob).
	P  = cell(Nc+1,1);
	Pv = psi(Wn,Wn);
	for v = 1:Nc,
	  P{v} = Pv;
	end;
	P{Nc+1} = t(:,Wn)';
	clear Pv v
	
	% Build the set of clamped potentials.
	p = cell(Nc+2,1);
	for v = 1:Nc,
	  p{v+1} = xi(naybrs(v),1:Ln,n)';
	end;
	clear v
	
	% Run tree belief propagation on the set of potentials.
	K      = [Ln*ones(Nc+1,1); numclusters];
	Cc     = [ones(Nc+1,1) [2:Nc+2]'];
	Ac     = [0 ones(1,Nc); ones(Nc,1) zeros(Nc,Nc)];
	[S Ps] = sepsfromcliques(Cc,Ac,K);
	[Pc ans ft] = treeups(K,Cc,Ac,P,S,Ps,p,BPtol*BPtol,Nc*Nc,0);
	clear P p K Cc Ac S Ps ft
	
	% Now that we've computed the marginals of the alignments and
	% blobs given the potentials, find the sufficient statistics
	% of the features. First, get the count for the translation
	% features. 
	Gcnt(:,Wn,Nc+1) = Gcnt(:,Wn,Nc+1) + Pc{Nc+1}';
	
	% Next, count the spatial context features.
	% Repeat for each blob in the neighbourhood.
	for v = 1:Nc,
	  Fcnt(Wn,Wn,Nc+1) = Fcnt(Wn,Wn,Nc+1) + Pc{v};
	end;
	clear v 
      end;
    end;
  end;
  clear n Mn Ln Wn
  
  % Make sure the spatial context feature counts are symmetric.
  for i = 1:maxNB+1,
    Fcnt(:,:,i) = Fcnt(:,:,i) + Fcnt(:,:,i)';
  end;

  catch
    peter = 1;
  end;
  
% --------------------------------------------------------------
% Perform iterative proportional fitting on parameter phi.
% "p" is the empirical count, "P" is the estimated count and "phi" is the
% paramter to update.
function phi = ipf (p, P, phi)
  
  Ni = size(phi,1);
  Nj = size(phi,2);
  
  for i = 1:Ni,
    for j = 1:Nj,
      if P(i,j),
	phi(i,j) = phi(i,j) * (p(i,j) / P(i,j));
      else,
	phi(i,j) = p(i,j);
      end;
    end;
  end;

  % Normalise the parameter.
  phi = phi / sum(sum(phi));

% --------------------------------------------------------------
% Perform the improved iterative scaling update on the paramter phi.
function phi = iis (p, P, phi)

  Ni = size(phi,1);
  Nj = size(phi,2);  
  C  = size(P,3);
  
  for i = 1:Ni,
    for j = 1:Nj,
      if sum(P(i,j,:)) & p(i,j),
	r = roots([-fliplr(reshape(P(i,j,:), [1 C])) p(i,j)]);
	r = r(find(r >= 0 & ~imag(r)));
	if length(r) ~= 1,
	  error('There is not exactly one root!');
	end;
	phi(i,j) = phi(i,j) * r;
      else,
	phi(i,j) = p(i,j);
      end;
    end;
  end;      

  % Normalise the updated parameters.
  phi = phi / sum(sum(phi));
