function model = semibin_train (X, Y, KMrestarts, KMiter, kf, K, S0, S1, ...
				mu0, nu0, r)
  
  % Function constants.
  kf = 'gaussian';
  
  % Set up some function parameters.
  F = size(X,1);   % Number of features.
  N = size(X,2);   % Number of data points.
  S = S0 + S1;     % The total number of samples to generate. 
  M = sum(Y > 0)'; % M is N x 1 matrix of bag sizes where N is the number
                   % of data points.
		   
  % Find mu
  % --------
  % Find the cluster means using k-means. MU is an F x K matrix.
  [clusterCenters blobsInClusters] = ...
      do_kmeans(X', 0, KMiter, KMrestarts, K);
  mu = clusterCenters';
  clear clusterCenters blobsInClusters KMiter
  
  % Compute kernel matrix
  % ---------------------
  % X is now an (F x N) matrix. We also need to create the kernel
  % matrix, which we will denote by XK -- a N x K+1 matrix.
  XK = [ones(N,1) zeros(N,K)];
  for k = 1:K,
    XK(:,k+1) = feval(kf, X, repmat(mu(:,k),[1 N]), r)';
  end;
  clear k

  % We have to compute X'X a lot of times, so let's get that.
  XtX = XK'*XK;
  
  % Reserve storage for the matrices of samples
  % -------------------------------------------
  Beta = zeros(K+1,S1);
  
  % Initialize delta
  % ----------------
  delta = nu0 / (mu0 + 1);
  % Sometimes we get really bad deltas when we do this:
  % delta = inv(gengamma(mu0/2, nu0/2));
  
  % Initialize beta
  % ---------------
  beta = delta * randn(K+1,1);
  
  % Initialize z
  % ------------
  z = normrnd(XK*beta,1);

  % Reserve storage for the log posteriors.
  logp = zeros(1,S);

  % Repeat for each sample.
  for s = 1:S,

    A  = inv(eye(K+1)/delta + XtX);
    ZX = z'*XK;

    % Sample alpha
    % ------------
    alpha = sqrt(inv(gengamma(N/2, z'*z + ZX*A*ZX')));
    
    % Sample beta
    % -----------
    beta = mvnormrnd(A*ZX'/alpha, A, 1)';
 
    % Sample delta
    % ------------
    delta = inv(gengamma(0.5*(K+1+mu0), nu0 + 0.5*beta'*beta));
    
    XKb = XK*beta;
    
    % Sample y
    % --------
    
    % Grab the labels when we have exactly one.
    y    = zeros(N,1);
    f    = find(M == 1);
    y(f) = Y(1,f);
    
    % We we have more than one label, sample it.
    f    = find(M == 2);
    nf   = length(f);
    if nf,
      U    = rand(nf,1);
      y(f) = floor(U + norm_cdf(zeros(nf,1), XKb(f), ones(nf,1)));
    end;
    
    % Sample z
    % --------
    f  = find(y == 0);
    nf = length(f);
    if nf,
    z(f) = normt_rnd(XKb(f), ones(nf,1), ...
		     repmat(-Inf,[nf 1]), zeros(nf,1));
    end;
    
    f  = find(y == 1);
    nf = length(f);
    if nf,
      z(f) = normt_rnd(XKb(f), ones(nf,1), ...
		       zeros(nf,1), repmat(Inf,[nf 1]));
    end;
    
    % Compute log posterior of sample
    % -------------------------------
    Z       = norm_cdf(zeros(N,1), XK*beta, ones(N,1));
    logp(s) = -(0.5*mu0 + 1)*log(delta) - 0.5*nu0/delta ...
	      - 0.5*log(2*pi*delta) - 0.5*beta'*beta/delta  ...
	      + sum(log((y == 0).*Z + (y == 1).*(1 - Z)));

    % Store the samples.
    if s > S0,
      Beta(:,s-S0) = beta;
    end;    
  end;
  
  % Return the result.
  model.beta = Beta;
  model.mu   = mu;
  model.r    = r;
  model.logp = logp;
