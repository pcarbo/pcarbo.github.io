% MODEL1DISCRETE_TRAIN    Train model 1 discrete ML.
%   The function call is [MODEL,VAL] = MODEL1DISCRETE_TRAIN(B,W,M,L,
%   NUMWORDS,KMITER,EMITER,EMTOLERANCE). The model-specific parameters
%   are: 
%     - KMITER       The maximum number of iterations to run K-Means.
%     - EMITER       The maximum number of iterations ro run EM.
%     - EMTOLERANCE  Stop the EM algorithm when the difference in error
%                    between two steps is less than EMTOLERANCE.
%
%   In MODEL we will return the following information: 
%     - clusterCenters  F x W matrix where F is the number of features
%                       and W is the number of clusters (i.e. the number
%                       of words), indicating the centres of the
%                       normalized clusters.
%     - t               W x W matrix where W is the number of
%                       words. Entry t(b,w) is the probability of
%                       generating blob b from word w.
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function [model, val] = model1MRFdiscrete_trainPL3 ...
      (B, W, A, M, L, numwords, numclusters, KMrest, KMiter, ...
       EMiter, EMtol, UPStol, BPtol, psiPrior, tPrior)

  try 
    
  % Function constants.
  noise = 1e-15;
    
  % Get some important variables.
  imageBlobs  = B;
  N           = length(M);
  maxM        = max(M);
  maxL        = max(L);

  % Run k-means
  % -----------
  % Run k-means on blobs to find clusters centers and blob-cluster
  % membership. 
  proglog('a.) Running k-means.');
  sB = smash_blobs(imageBlobs, M);
  [clusterCenters blobsInClusters] = ...
      do_kmeans(sB', 0, KMiter, KMrest, numclusters);
  clusterCenters  = clusterCenters';
  blobsInClusters = blobsInClusters';

  % Create the new blob matrix. B is an N x B matrix, where B is the
  % maximum number of blobs in a document.
  B = reshape(unsmash_blobs(blobsInClusters, M),[maxM N])';
  clear sB blobsInClusters
  
  % Set up adjacency matrices.
  for n = 1:N,
    A{n} = A{n} > 0;
  end;
  clear n
  
  % Set up a matrix describing the neighbours for each node. At the same
  % time, let's find out the largest number of neighbours in the graph. 
  NB = zeros(N,maxM);
  for n = 1:N,
    NB(n,1:M(n)) = sum(A{n});
  end;
  maxNB = max(max(NB));

  % Create the matrix with the actual neighbour indices now.
  nb = zeros(maxM,maxNB,N);
  for n = 1:N,
    for b = 1:M(n),
      bs = find(A{n}(b,:));
      if length(bs),
	nb(b,1:NB(n,b),n) = bs;
      end;
    end;
  end;
  clear n b bs
  
  % Set up the iterative scaling schedule.
  UPSiter = (numwords*numclusters)^2;
  
  % Initialize the translation probabilities
  % ----------------------------------------
  % t is an B x W matrix, where B = number of blob clusters
  %                             W = number of words tokens
  % The (i,j) entry represents the translation probability t(bi | wj).
  % Initially, the translation probabilities are set to random values.
  t = ones(numclusters,numwords);
  t = t + tPrior;
  t = t ./ sum(sum(t));

  % Initialise the spatial potentials
  % ---------------------------------
  % psi is a uniform probability table p(wi,wj); it is a W x W matrix
  % where W is the number of of word tokens. Place an unprincipled prior
  % on psi.
  psi = ones(numwords, numwords);
  psi = psi + psiPrior;
  psi = triu(ones(numwords,numwords)) .* psi + ...
	(triu(ones(numwords,numwords),1) .* psi)';
  psi = psi / sum(sum(psi));
  
  % Run EM
  % ------
  proglog('b.) Running EM.');
  likelihoods = [];
  for iter = 1:EMiter,

    % E step
    % ------
    % Do loopy belief propagation to find the alignment probablities
    % p(a_nu = i) and the alignment probabilities over the cliques,
    % p(a_nu = i, a_nv = j).
    [pxi pxic f] = inferaligns(L,M,W,B,A,t,psi,BPtol);
    if ~f,
      proglog('E step failed to converge.');
      if s > 1,
	psi = oldpsi;
	t   = oldt;
      end;
      break;
    end;
    clear f
    
    oldpsi = psi;
    oldt   = t;
    
    % M step
    % ------
    % Do iterative scaling to update the model parameters using the
    % alignment probabilities from the E Step.
    % Set the flag to "not converged".
    f = 0;
    
    % Get the feature counts (the sufficient statistics) from the
    % marginals of the cliques from the E Step. For the purpose of
    % iterative scaling in the M Step, these will be considered the
    % "true" counts.
    % Initialise the "true" counts.
    fcnt = zeros(numwords,numwords);
    gcnt = zeros(numclusters,numwords);

    % Repeat for each document.
    for n = 1:N,
      
      % Get the words in the document.
      Wn = W(n,1:L(n));
      
      % Repeat for each blob in the document.
      for u = 1:M(n),
	
	% Get the blob associated with index i.
	b = B(n,u);
	
	% Count the translation probability.
	gcnt(b,Wn) = gcnt(b,Wn) + pxi{u,n}';
	
	% Repeat for each neighbour of the blob.
	for v = nb(u,1:NB(n,u),n),
	  fcnt(Wn,Wn) = fcnt(Wn,Wn) + pxic{u,v,n};
	end;
      end;
    end;
    clear n u v b Wn
    
    % Make sure the spatial context feature counts are symmetric.
    fcnt = fcnt + fcnt';
    
    % Repeat until we've reached convergence or the maximum number of
    % iterations.
    for s = 1:UPSiter,

      % Get the old parameters.
      oldpsi = psi;
      oldt   = t;
      
      % Get the old error.
      if s > 1,
	olde = e;
      end;
      
      % Initialise the estimated counts.
      Fcnt = zeros(numwords,numwords,maxNB+1); 
      Gcnt = zeros(numclusters,numwords,maxNB+1);
      
      % Run iterative scaling / iterative proportional fitting over each
      % "neighbourhood" of the pseudo-likelihood.
      % Repeat for each document.
      for n = 1:N,
	
	% Get the number of blobs, number of words and the set of words.
	Mn = M(n);
	Ln = L(n);
	Wn = W(n,1:Ln);
	
	% Check for the limiting condition when there is only one
        % blob. In that case, we only need to update the translation
        % potential. 
	if Mn == 1,
	  x            = t(:,Wn);
	  Gcnt(:,Wn,1) = Gcnt(:,Wn,1) + x / sum(sum(x));
	else,
	  
	  % Repeat for each blob in the document.
	  for u = 1:Mn,
	    
	    % What we need to do is find the estimated probabilities of
            % the cliques in the neighbourhood of b.
	    % Get the number of neighbours and the neighbours
            % themselves. 
	    Nc       = NB(n,u);
	    neighbrs = nb(u,1:Nc,n);
	    
	    % Create the set of potentials. We need a clique for each of
            % the neighbours and an extra one for the link going to the
            % observed node (blob).
	    P  = cell(Nc+1,1);
	    Pv = psi(Wn,Wn);
	    Pv = Pv / sum(sum(Pv));
	    for v = 1:Nc,
	      P{v} = Pv;
	    end;
	    Pv      = t(:,Wn)';
	    P{Nc+1} = Pv / sum(sum(Pv));
	    clear Pv v
	    
	    % Build the set of clamped potentials.
	    p = cell(Nc+2,1);
	    for v = 1:Nc,
	      p{v+1} = pxi{neighbrs(v),n};
	    end;
	    clear v
		  
	    % Run tree belief propagation on the set of potentials.
	    K      = [Ln*ones(Nc+1,1); numclusters];
	    Cc     = [ones(Nc+1,1) [2:Nc+2]'];
	    Ac     = [0 ones(1,Nc); ones(Nc,1) zeros(Nc,Nc)];
	    [S Ps] = sepsfromcliques(Cc,Ac,K);
	    [Pc ans ft] = treeups(K,Cc,Ac,P,S,Ps,p,BPtol*BPtol,Nc*Nc,0);
	    clear P p K Cc Ac S Ps ft
	    
	    % Now that we've computed the marginals of the alignments and
            % blobs given the potentials, find the sufficient statistics
            % of the features. First, get the count for the translation
            % features. 
	    Gcnt(:,Wn,Nc+1) = Gcnt(:,Wn,Nc+1) + Pc{Nc+1}';
	    
	    % Next, count the spatial context features.
	    % Repeat for each blob in the neighbourhood.
	    for v = 1:Nc,
	      Fcnt(Wn,Wn,Nc+1) = Fcnt(Wn,Wn,Nc+1) + Pc{v};
	    end;
	    clear v 
	  end;
	end;
      end;
      clear n Mn Ln Wn
            
      % Make sure the spatial context feature counts are symmetric.
      for i = 1:maxNB+1,
	Fcnt(:,:,i) = Fcnt(:,:,i) + Fcnt(:,:,i)';
      end;
      clear i
      
      % Perform the iterative scaling update on psi.
      for i = 1:numwords,
	for j = i:numwords,
	  if sum(Fcnt(i,j,:)) & fcnt(i,j),
	    r = roots([-fliplr(reshape(Fcnt(i,j,:), [1 maxNB+1])) fcnt(i,j)]);
	    r = r(find(r >= 0 & ~imag(r)));
	    if length(r) ~= 1,
	      error('There is not exactly one root!');
	    end;
	    psi(i,j) = psi(i,j) * r;
	  else,
	    psi(i,j) = fcnt(i,j);
	  end;
	  psi(j,i) = psi(i,j);
	end;
      end;     
      psi = psi / sum(sum(psi));
      clear i j r
      
      % Perform the iterative scaling update on t.
      for i = 1:numclusters,
	for j = 1:numwords,
	  if sum(Gcnt(i,j,:)) & gcnt(i,j),
	    r = roots([-fliplr(reshape(Gcnt(i,j,:), [1 maxNB+1])) gcnt(i,j)]);
	    r = r(find(r >= 0 & ~imag(r)));
	    if length(r) ~= 1,
	      error('There is not exactly one root!');
	    end;
	    t(i,j) = t(i,j) * r;
	  else,
	    t(i,j) = gcnt(i,j);
	  end;
	end;
      end;
      t = t / sum(sum(t));
      clear i j r
      
      e = max(max(abs([(oldpsi - psi) (oldt - t)'])));
      proglog('Iterative scaling - iteration %i, error %g', s, e);
      
      if s > 1 & e > olde,
	psi = oldpsi;
	t   = oldt;
	break;
      end;
      
      % Check to see if the messages have converged.
      if e < UPStol,
	f = 1;
	break;
      end;
	
      % Check to see if we've reached infinite error (i.e. the message
      % passing has diverged). This condition will be true if we each Inf
      % or NaN.
      if ~(e < Inf),
	break;
      end;
    end;
    
    % Now that we've finished the iterative scaling (M Step), add the
    % priors to the psi and t model parameters.
    psi = psi + psiPrior;
    psi = psi / sum(sum(psi));
    t   = t + tPrior;
    t   = t / sum(sum(t));
    
    % Check to see if we have not converged.
    if ~f,
      proglog('Iterative scaling did not converge');
    end;
    
    % Compute the incomplete log likelihood
    % -------------------------------------
    l = computelikelihood(L,M,B,W,A,t);
    likelihoods = [likelihoods l];
    proglog('   EM iteration %i - log likelihood = %f', iter, l);
    proglog('');    
    
    % Compute the error.
    if 0,
    if iter > 1,
      e = l - likelihoods(iter-1);
      if e < EMtol,
	break;
      end;
    end; 
    end
  end;
  
  % Return the model and value of the model.
  if EMiter,
    val = likelihoods(length(likelihoods));
  else,
    val = 0;
  end;
  
  model.t              = t;
  model.psi            = psi;
  model.clusterCenters = clusterCenters;
  model.BPtol          = BPtol;
  
  catch
    peter = 1;
  end;
  
% ------------------------------------------------------------------------
% Run loopy belief propagation to find the marginals on the translation
% and spatial context cliques.
function [xi, xic, f] = inferaligns (L, M, W, B, A, t, psi, tol)

  try
  % Get a few variables.
  N           = length(L);
  numclusters = size(t,1);
  maxM        = max(M);
  
  % Reserve storage for the distribution probabilities for running
  % iterative proportional fitting. 
  xi  = cell(maxM,N);
  xic = cell(maxM,maxM,N);

  % Get the marginal probabilities of the variables.
  % Repeat for each document.
  for n = 1:N,

    % Get the number of blobs, number of words and the set of words.
    Mn = M(n);
    Ln = L(n);
    Wn = W(n,1:Ln);
	
    % Check for the limiting conditions. When there is one word,
    % setting the alignment probabilities is easy. When there is one
    % blob, we don't need to perform loopy belief propagation.
    if Ln == 1,
      
      % There is only one word, so set the alignment probabilities to 1.
      for u = 1:Mn,
	xi{u,n} = 1;
      end;

      [us vs] = find(triu(A{n}));
      for i = 1:length(us),
	u = us(i);
	v = vs(i);
	xic{u,v,n} = 1;
	xic{v,u,n} = 1;
      end;
      clear us vs u v i
      
    elseif Mn == 1,
      
      % There is only one blob, so set the alignment probabilities to
      % the translation probabilities.
      x       = t(B(n,1),Wn)';
      xi{1,n} = x / sum(x);
      clear x
    else,
	
      % Initialise the adjacencies for the document.
      An = zeros(2*Mn,2*Mn);
      
      % Get the set of adjacencies from the document MRF.
      An(1:Mn,1:Mn) = A{n};
       
      % Set the adjacencies for the translation cliques.
      An(1:Mn,Mn+[1:Mn]) = eye(Mn);
      An(Mn+[1:Mn],1:Mn) = eye(Mn);
      
      % Set up the set of clique probabilities P.
      P   = cell(2*Mn,2*Mn);
      Puv = psi(Wn,Wn);
      Puv = Puv / sum(sum(Puv));
      
      % For each alignment clique, put the spatial context potential
      % into P. 
      [us vs] = find(triu(A{n}));
      for i = 1:length(us),
	u = us(i);
	v = vs(i);
	P{u,v} = Puv;
	P{v,u} = Puv';
      end;
      clear us vs i u v Puv
      
      % For each translation clique, put the translation potential
      % into P.
      for u = 1:Mn,
	Puv = t(B(n,u),Wn);
	Puv = Puv / sum(sum(Puv));
	P{u+Mn,u} = Puv;
	P{u,u+Mn} = Puv';
      end;
      clear u Puv
      
      % Run loopy belief propagation. If it does not converge, report
      % an error. 
      [x1 x2 f] = loopybp([Ln*ones(Mn,1); ones(Mn,1)], ...
			  An, P, tol, (2*Mn)^2, 0);
      if ~f,
	break;
      end;
	  
      % Copy the resulting probabilities.
      xi(1:Mn,n)       = x1(1:Mn); 
      xic(1:Mn,1:Mn,n) = x2(1:Mn,1:Mn);
      clear x1 x2 
    end;
  end;
  
  catch
    x = 1;
  end
  
% ------------------------------------------------------------------------
% Use loopy belief propagation to ompute the incomplete log likelihood.
function l = computelikelihood (L, M, B, W, A, t)
  
  % Get a few variables.
  N           = length(L);
  numclusters = size(t,1);
  maxM        = max(M);
  
  % Initialise the log likelihood.
  l = 0;
  
  % Repeat for each document.
  for n = 1:N,
    
    % Get the number of blobs, number of words and the set of words.
    Mn = M(n);
    Ln = L(n);
    Wn = W(n,1:Ln);    
    
    % Repeat for each blob in the document.
    for u = 1:Mn,
      l = l + log(sum(t(B(n,u),Wn) / sum(t(:,Wn))));
    end;
  end;
