% Try a whole bunch of different thresholds.
fp = [];
tp = [];
Np = sum(y);
Nn = sum(~y);
for thresh = 0:0.01:1,
  [fpt tpt] = eval_translation(y,t,L(docs),thresh);
  tpt = tpt + Np - 1;
  fp = [fp fpt];
  tp = [tp tpt];
end;

hold on;
plot(fp/Nn,tp/Np,'g.');
if 0,
xlabel('% false positives');
ylabel('% true positives');
title(sprintf('ROC for "%s"', word));
axis([0 1 0 1]);
line([0 1],[0 1]);
end; 