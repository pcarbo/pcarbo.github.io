% KERNEL FUNCTIONS
% ------------------------------------------------------------------------
% XI and XJ are F x N matrices, where F is the number of features and N
% is the number of data points, and R is a scalar. The return value Y is
% a 1 x N matrix.
function y = gaussian (xi, xj, r)
  d = size(xi,1);
  u = xi - xj;
  y = exp(-0.5*dot(u,u,1)/(r^2));
