Training:
--------

airplane
False positives: 27 / 1640 
False negatives: 78 / 101 

astronaut
False positives: 9 / 1756 
False negatives: 2 / 2 

bear
False positives: 43 / 1717 
False negatives: 24 / 30 

bill
False positives: 18 / 1616 
False negatives: 96 / 136 

bird
False positives: 40 / 1728 
False negatives: 8 / 26 

building
False positives: 18 / 1738 
False negatives: 19 / 19 

cheetah
False positives: 22 / 1735 
False negatives: 3 / 10 

cloud
False positives: 72 / 1678 
False negatives: 31 / 50 

coin
False positives: 46 / 1730 
False negatives: 10 / 23 

coral
False positives: 21 / 1730 
False negatives: 11 / 24 

crab
False positives: 1 / 1752 
False negatives: 2 / 2 

dolphin
False positives: 48 / 1742 
False negatives: 7 / 11 

earth
False positives: 1 / 1752 
False negatives: 2 / 6 

fish
False positives: 23 / 1747 
False negatives: 3 / 6 

flag
False positives: 9 / 1743 
False negatives: 5 / 14 

fox
False positives: 28 / 1731 
False negatives: 9 / 22 

goat
False positives: 3 / 1756 
False negatives: 0 / 2 

grass
False positives: 23 / 1515 
False negatives: 142 / 175 

mountain
False positives: 21 / 1740 
False negatives: 9 / 12 

person
False positives: 3 / 1755 
False negatives: 0 / 3 

polarbear
False positives: 74 / 1731 
False negatives: 23 / 23 

rabbit
False positives: 6 / 1756 
False negatives: 0 / 2 

road
False positives: 65 / 1720 
False negatives: 20 / 31 

rock
False positives: 30 / 1713 
False negatives: 30 / 34 

sand
False positives: 30 / 1709 
False negatives: 25 / 44 

shuttle
False positives: 21 / 1738 
False negatives: 14 / 20 

sky
False positives: 28 / 1562 
False negatives: 119 / 144 

snow
False positives: 75 / 1631 
False negatives: 93 / 118 

space
False positives: 13 / 1750 
False negatives: 3 / 8 

tiger
False positives: 42 / 1718 
False negatives: 17 / 18 

tracks
False positives: 41 / 1729 
False negatives: 23 / 24 

train
False positives: 39 / 1686 
False negatives: 58 / 67 

trees
False positives: 34 / 1589 
False negatives: 80 / 136 

trunk
False positives: 31 / 1754 
False negatives: 1 / 3 

water
False positives: 79 / 1537 
False negatives: 114 / 186 

whale
False positives: 16 / 1749 
False negatives: 3 / 9 

wolf
False positives: 32 / 1742 
False negatives: 14 / 14 

zebra
False positives: 42 / 1735 
False negatives: 1 / 10 

Test
----
airplane
False positives: 27 / 790 
False negatives: 35 / 39 

astronaut
False positives: 3 / 836 
False negatives: 2 / 2 

atm
False positives: 31 / 829 
False negatives: 9 / 9 

bear
False positives: 31 / 824 
False negatives: 11 / 11 

beluga
False positives: 39 / 832 
False negatives: 5 / 6 

bill
False positives: 1 / 802 
False negatives: 36 / 36 

bird
False positives: 8 / 833 
False negatives: 4 / 4 

building
False positives: 63 / 833 
False negatives: 3 / 3 

cheetah
False positives: 17 / 825 
False negatives: 9 / 9 

cloud
False positives: 20 / 810 
False negatives: 21 / 21 

coin
False positives: 0 / 833 
False negatives: 4 / 4 

crab
False positives: 24 / 834 
False negatives: 4 / 4 

dolphin
False positives: 0 / 835 
False negatives: 1 / 1 

earth
False positives: 4 / 836 
False negatives: 2 / 2 

flag
False positives: 5 / 820 
False negatives: 5 / 17 

flowers
False positives: 34 / 837 
fox
False positives: 0 / 823 
False negatives: 11 / 11 

grass
False positives: 20 / 736 
False negatives: 56 / 75 

hand
False positives: 15 / 837 
False negatives: 1 / 1 

map
False positives: 0 / 834 
False negatives: 4 / 4 

mountain
False positives: 45 / 836 
False negatives: 2 / 2 

person
False positives: 0 / 829 
False negatives: 8 / 8 

polarbear
False positives: 35 / 825 
False negatives: 10 / 10 

road
False positives: 24 / 831 
False negatives: 6 / 6 

rock
False positives: 24 / 795 
False negatives: 34 / 37 

sand
False positives: 4 / 810 
False negatives: 18 / 19 

shuttle
False positives: 38 / 830 
False negatives: 8 / 8 

sky
False positives: 55 / 750 
False negatives: 66 / 67 

snow
False positives: 9 / 731 
False negatives: 99 / 99 

space
False positives: 29 / 831 
False negatives: 7 / 7 

tiger
False positives: 13 / 793 
False negatives: 29 / 30 

tracks
False positives: 23 / 825 
False negatives: 5 / 11 

train
False positives: 30 / 820 
False negatives: 15 / 15 

trees
False positives: 8 / 774 
False negatives: 42 / 42 

trunk
False positives: 65 / 831 
False negatives: 5 / 5 

water
False positives: 2 / 743 
False negatives: 64 / 65 

whale
False positives: 15 / 831 
False negatives: 7 / 7 

wolf
False positives: 14 / 788 
False negatives: 32 / 40 

zebra
False positives: 0 / 827 
False negatives: 4 / 4 