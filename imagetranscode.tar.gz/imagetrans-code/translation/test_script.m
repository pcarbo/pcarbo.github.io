N = 3;
W = [ 1 2 0;
      1 2 3;
      2 3 0 ];
B = [ 1 2 0 0 0;
      1 2 3 2 0;
      2 2 2 3 3 ];
L = sum(W > 0,2);
M = sum(B > 0,2);

N    = length(M);
maxM = max(M);
maxL = max(L);
numwords = 3;
numclusters = 3;

A = cell(N,1);
for n = 1:N,
  A{n} = zeros(M(n),M(n));
end;

A{1}(1,2) = 1;

A{2}(1,4) = 1;
A{2}(2,3) = 1;
A{2}(2,4) = 1;
A{2}(3,4) = 1;

A{3}(1,2) = 1;
A{3}(1,3) = 1;
A{3}(2,3) = 1;
A{3}(2,4) = 1;
A{3}(2,5) = 1;
A{3}(3,5) = 1;
A{3}(4,5) = 1;

for n = 1:N,
  A{n} = A{n} | A{n}';
end;