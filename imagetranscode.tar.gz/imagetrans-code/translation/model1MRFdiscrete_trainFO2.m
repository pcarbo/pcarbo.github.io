% MODEL1MRFGAUSSMAP_TRAIN    Train model 1 MRF Gaussian MAP.
%   The function call is [MODEL,VAL] = MODEL1MRFGAUSSMAP_TRAIN(B,W,M,L,
%   NUMWORDS,KMITER,EMITER,EMTOL,ALPHA,A,B,PSIPRIOR,SP,RANDINIT). The
%   model-specific parameters are:
%     - KMITER       The maximum number of iterations to run
%                    K-Means. Only valid if RANDINIT is 'no' (see
%                    below). 
%     - EMITER       The maximum number of iterations ro run EM.
%     - EMTOL        Stop the EM algorithm when the difference in error
%                    between two steps is less than EMTOLERANCE.
%     - ALPHA        The degree of freedom parameter for the Inverse
%                    Wishart distribution on the covariance.
%     - A            The shape parameter on the Inverse Gamma
%                    distribution on tau.
%     - B            The scale parameter on the Inverse Gamma
%                    distribution for tau.
%     - PSIPRIOR     A Dirichlet prior on the inter-alignment
%                    potentials, psi. 0 means no prior.
%     - SP           If it is 'yes', use the sum-product algorithm
%                    (i.e. mean) for inference. Otherwise, use argmax.
%     - RANDINIT     Optional parameter. By default, the value of this
%                    parameter is 'no' which means that the cluster means
%                    are initialized using K-Means. If this parameter is
%                    'yes', they are initialized by sampling randomly
%                    from the prior distribution. If RANDINIT is set to
%                    'yes' then the parameter KMITER is irrelevant.
%      
%   In MODEL we will return the following information:
%     - mu   F x W matrix of Gaussian means, where F is the number of
%            features and W is the number of word tokens.
%     - sig  F x F x W matrix of Gaussian covariances.
%     - tau  F x 1 matrix of feature weights.
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function [model, val] = model1MRFdiscreteFO_train ...
    (B, W, A, M, L, numwords, KMiter, EMiter, EMtol, ...
     psiPrior, tPrior, sp, BPtol)

  % Function constants.
  BPiter = 10;
  
  % Set up some miscellaneous parameters
  F    = size(B,1);
  N    = length(M);
  maxM = max(M);
  maxL = max(L);
  sp   = strcmp('yes',sp);

  % Run k-means
  % -----------
  % Run k-means on blobs to find clusters centers and blob-cluster
  % membership. 
  imageBlobs = B;
  sB = smash_blobs(imageBlobs, M);
  [clusterCenters blobsInClusters] = ...
      do_kmeans(sB', 0, KMiter, 1, numclusters);
  clusterCenters  = clusterCenters';
  blobsInClusters = blobsInClusters';
  
  % Create the new blob matrix. B is an N x B matrix, where B is the
  % maximum number of blobs in a document.
  B = reshape(unsmash_blobs(blobsInClusters, M),[maxM N])';  
  clear sB blobsInClusters
  
  % Make a list of all the edges for each document.
  % C{n} = set of pairs for the "next to" relation
  C = cell(N,1);
  for n = 1:N,
    [C1 C2] = find(A{n});
    if length(C1),
      C{n}(:,1) = C1;
      C{n}(:,2) = C2;
    else,
      C{n} = [];
    end;
  end;
  clear C1 C2 n

  % Allocate memory for latent variables.
  xi = zeros(maxM,maxL,N);

  % Initialize psi.
  psi = rand(numwords, numwords);
  psi = psi / sum(sum(psi)) + psiPrior;  
  psi = psi / sum(sum(psi));

  % Initialise t.
  t = rand(numclusters, numwords);
  t = t / sum(sum(t)) + tPrior;
  t = t / repmat(sum(t), [numclusters 1]);
  
  % Run EM.
  proglog('Running EM.');
  for iter = 1:EMiter,
    
    % E step
    % ------
    % Compute p(a_si=j|b_sj,w_si).
    % Repeat for each sentence.
    for n = 1:N,
      Mn = M(n);
      Ln = L(n);
      Wn = W(n,1:Ln);
      Bn = B(n,1:Mn);
      
      % Run loopy belief propagation, grabbing the potentials only for
      % the words in the image's label.
      if Mn == 1,
	xi(1,1:Ln,n) = t(Bn,Wn);
      else,
	
	% Run loopy belief propagation.
	xi(1:Mn,1:Ln,n) = bpmrf2(A{n} > 0, psi(Wn,Wn), t(Bn,Wn), sp, ...
				 BPtol, BPiter*Mn, 0); 
      end;
      
      % Normalize again.
      z  = sum(xi(1:M(n),1:L(n),n),2);
      f  = find(z);
      fn = find(~z);
      if length(f),
	xi(f,1:Ln,n) = xi(f,1:Ln,n)./repmat(z(f),[1 Ln]);
      end;
      if length(fn),
	xi(fn,1:Ln,n) = 1 / Ln;
      end;
      clear z f fn
    
    end;
    clear n Mn Ln Wn Bn
    
    % M step
    % ------
    % Update t.
    % Repeat for each document.
    for n = 1:N,
      Ln = L(n);
      Mn = M(n);
      Wn = W(n,1:Ln);
      Bn = B(n,1:Mn);
      
      t(Bn,Wn) = t(Bn,Wn) + 
      
      % Repeat for each blob in the document.
      for u = 1:Mn,
	b = B(n,u);
	t(b,Wn) = t(b,Wn) + xi(1:Mn,1:Ln);
      end;
    end;
    clear n Ln Mn Wn u b
    
    % Normalize t.
    z  = sum(t);
    f  = find(z);
    fn = find(~z);
    if length(f),
      t(:,f) = t(:,f) / repmat(z(f), [numclusters 1]);
    end;
    if length(fn),
      t(:,nf) = 1 / numclusters;
    end;
    
    % Update psi.
    psi = zeros(numwords, numwords);
    for n = 1:N,
      Mn = M(n);
      Ln = L(n);      
      
      if Mn > 1,
	x = zeros(numwords, numwords);
	  
	% Repeat for each pair of words in the image.
	for u = 1:Ln,
	  for v = 1:Ln,
	    wu = W(n,u);
	    wv = W(n,v);
	      
	    % Repeat for each clique pair.
	    for i = 1:size(C{n},1),
	      x(wu,wv) = x(wu,wv) + ...
		  indicator(C{n}(i,1),u,n) * ...
		  indicator(C{n}(i,2),v,n);
	    end;
	    
	    if x(wu,wv) > 0,
	      x(wu,wv) = x(wu,wv) / ...
		  (sum(indicator(C{n}(:,1),u,n)) * ...
		   sum(indicator(C{n}(:,2),v,n)));
	    end;
	  end;
	end;
	  
	psi = psi + x;
      end;
    end;      

    % Normalize psi and add the prior.
    psi = psi / sum(sum(psi)) + psiPrior;
    psi = psi / sum(sum(psi));
    
    proglog('   EM iteration %i', iter);
  end; % Repeat EM.

  % Return the model.
  model.psi    = psi;
  model.t      = t;
  model.sp     = sp;
  model.BPtol  = BPtol;
  
  % Return the value.
  val = 0;