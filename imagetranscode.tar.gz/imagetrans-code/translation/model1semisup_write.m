function model1semisup_write (d, model)  
  write_matrix(d, 'beta', model.beta);
  write_matrix(d, 'mu', model.mu);
  write_matrix(d, 'misc', [model.T model.r]);
  
  % Write the kernel function to disk.
  filename = [d '/kf'];
  outfile = fopen(filename, 'w');
  if outfile == -1,
    error(sprintf('Unable to read file %s', filename));
  end;
  
  fprintf(kf);
  
  % Close the file.
  fclose(outfile);