c = [0 1 0 0;
     1 0 1 0;
     0 1 0 1;
     0 0 1 0];

psi  = zeros(2,2,4,4);
psiA = rand(2,2);
psiA = psiA + psiA';
psiB = rand(2,2);
psiB = psiB + psiB';
psiC = rand(2,2);
psiC = psiC + psiC';
psi(:,:,1,2) = psiA;
psi(:,:,2,1) = psiA';
psi(:,:,2,3) = psiB;
psi(:,:,3,2) = psiB';
psi(:,:,3,4) = psiC;
psi(:,:,4,3) = psiC';

t = rand(4,2);

[p pc] = bpmrf2(c, psiA, t, 1, 1e-5, 100, 1);

for i = 1:2,
  for j = 1:2,
    for k = 1:2,
      for l = 1:2,
	P(i,j,k,l) = t(1,i) * t(2,j) * t(3,k) * t(4,l) * ...
	    psiA(i,j) * psiA(j,k) * psiA(k,l);
      end
    end
  end
end

P = P / sum(sum(sum(sum(P))));

