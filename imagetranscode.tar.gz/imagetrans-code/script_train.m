datadir='/cs/beta/People/Nando/corel/imagetrans/data/sets/new/corelB/p32';
modeldir  = '/cs/beta/People/Nando/corel/imagetrans/data/models/thesis';
model     = 'corelC/dPL1MRF';
numtrials = 9;

cd translation
evaluate_model(datadir, modeldir, model, numtrials);
cd ..
