for i = 1:3,
  t = rand(2,2);
  psi{i} = t / sum(sum(t));
end;
clear t

for i = 1:2,
  for j = 1:2,
    for k = 1:2,
      for l = 1:2,
	p(i,j,k,l) = psi{1}(i,j) * psi{2}(j,k) * psi{3}(j,l);
      end;
    end;
  end;
end;

%p = p / sum(sum(sum(sum(p))));

% Find p(x1, x2 | x3, x4).

p34 = sum(sum(p,2),1);

pc = p ./ repmat(p34, [2 2 1 1]);
