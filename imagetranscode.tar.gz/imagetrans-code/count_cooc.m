C = data.numWords;
N = data.numImages;
L = data.imageWordCounts;
W = data.imageWords;

x = zeros(C,C);
c = zeros(C,1);
for n = 1:N,
  for i = 1:L(n),
    for j = i:L(n),
      wi = W(n,i);
      wj = W(n,j);
      x(wi,wj) = x(wi,wj) + 1;
      x(wj,wi) = x(wj,wi) + 1;
      c(wi) = c(wi) + 1;
      c(wj) = c(wj) + 1;
    end;
  end;
end;

