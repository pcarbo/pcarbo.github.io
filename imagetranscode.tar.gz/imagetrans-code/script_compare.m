datadir = '/cs/beta/People/Nando/corel/imagetrans/data/sets/new/corelC/ncuts';
models  = {'corelC/dPL1MRF'};
test    = 'prn';
pr      = 1;
boxplot = 1;
options = {[] boxplot};

cd resultsbrowser
err = compare_models(datadir, models, test, options, pr);
