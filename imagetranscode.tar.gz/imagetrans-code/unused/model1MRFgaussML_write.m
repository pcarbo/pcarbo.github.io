function model1MRFgaussML_write (d, model)
  
  % Write out "sp", "BPtol" and "BPiter".
  write_matrix(d, 'sp', [model.sp model.BPtol model.BPiter]);

  % Write out the potentials psi.
  write_matrix(d, 'psi', model.psi);
  
  % Write out the Gaussian cluster means.
  write_matrix(d, 'mu', model.mu);
    
  % Write out the Gaussian cluster covariances.
  write_matrix(d, 'sigma', model.sig);
  
  