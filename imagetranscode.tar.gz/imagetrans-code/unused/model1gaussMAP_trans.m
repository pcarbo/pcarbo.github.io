function t = model1gaussMAP_trans (B, M, A, model)
  
  N          = length(M);
  maxM       = max(M);
  F          = size(model.mu,1);
  numwords   = size(model.mu, 2);
  
  % Let's build the "t" matrix.
  sig = model.sig;
  mu  = model.mu;
  t = zeros(numwords,maxM,N);
  for s = 1:N,
    for b = 1:M(s),
      for w = 1:numwords,
	u = B(:,b,s) - mu(:,w);
	t(w,b,s) = exp((-0.5)*u'*inv(sig(:,:,w))*u) ... 
	    / (sqrt(det(sig(:,:,w))));
      end;
      
      % Normalize the translation probabilities.
      z = sum(t(:,b,s));
      if z,
	t(:,b,s) = t(:,b,s) / z;
      else,
	t(:,b,s) = 1 / numwords;
      end;
    end;
  end;
  