% DRAW_CIRCLE    Draw a circle.
%     C = DRAW_CIRCLE(R) creates a 2R x 2R matrix. Each entry is 1 it is
%     in the circle, otherwise 0. 
function c = draw_circle (r)
  
  c = zeros(r,r);
  
  % We will make the lower right-hand corner of the circle.
  for w = 0:r-1,
    for h = 0:r-1,
      if w*w + h*h <= r*r,
	c(h+1,w+1) = 1;
      else,
	break;
      end;
    end;
  end;
  
  % Join the halves together.
  c = [fliplr(flipud(c)) flipud(c);
       fliplr(c)         c         ];
