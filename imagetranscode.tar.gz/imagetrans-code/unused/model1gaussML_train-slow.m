% MODEL1GAUSSML_TRAIN    Train model 1 Gaussian ML.
%   The function call is MODEL = MODEL1GAUSSML_TRAIN(B,W,M,L,NUMWORDS,
%   NUMRESTARTS,KMITER,EMITER,EMTOLERANCE,DIAGCOV). The model-specific
%   parameters are:
%     - NUMRESTARTS  The number of times you would like to train the
%                    model, taking the best based on the log-likelihood.
%     - KMITER       The maximum number of iterations to run K-Means.
%     - EMITER       The maximum number of iterations ro run EM.
%     - EMTOLERANCE  Stop the EM algorithm when the difference in error
%                    between two steps is less than EMTOLERANCE.
%     - DIAGCOV      Either 'yes' or 'no' as to whether the covariances
%                    should be restricted to diagonal matrices.
%
%   In MODEL we will return the following information:
%     - mu   F x W matrix of Gaussian means, where F is the number of
%            features and W is the number of word tokens.
%     - sig  F x F x W matrix of Gaussian covariances.
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function model = model1gaussML_train ...
      (B, W, M, L, numwords, numRestarts, KMiter, EMiter, EMtolerance, ...
       diagCov)
  
  % Function constants.
  worstLikelihood = -1e99;
  
  imageBlobs  = B;
  F           = size(B,1);
  N           = length(M);
  maxM        = max(M);
  maxL        = max(L);
  noise       = 1e-10 * eye(F,F);

  % Repeat for each restart.
  bestModel.likelihood = worstLikelihood;

  for r = 1:numRestarts,

    proglog('Model 1 Gaussian ML training, restart %i.', r);
    
    % Run k-means
    % -----------
    % Run k-means on blobs to find clusters centers and blob-cluster
    % membership.
    proglog('a.) Running k-means.');
    sB = smash_blobs(imageBlobs, M);
    [clusterCenters blobsInClusters] = ...
        do_kmeans(sB', 0, KMiter, 1, numwords);
    clear sB blobsInClusters
    
    % Initialize mu and sigma.
    proglog('b.) Initializing model parameter values.');
    mu  = clusterCenters';
    sig = repmat(eye(F,F),[1 1 numwords]);
    clear clusterCenters
    
    % Run EM
    % ------
    proglog('c.) Running EM.');
    likelihoods = [];
    error = 1e99;
    iter = 0;
    while (iter < EMiter) & (EMtolerance <= error),
      
      iter = iter + 1;
      
      % E step
      % ------
      % Compute p(a_si=j|b_sj,w_si).
      % Repeat for each sentence.
      for s = 1:N,
	for i = 1:L(s),
	  w = W(s,i);
	  for j = 1:M(s),
	    u = B(:,j,s) - mu(:,w);
	    indicator(j,i,s) = exp((-0.5)*u'*inv(sig(:,:,w))*u) ...
		/ (sqrt(det(sig(:,:,w))));
	  end;
	end;
	
	% For each blob, normalize over all words in the sentence.
	for j = 1:M(s),
	  z = sum(indicator(j,1:L(s),s));
	  if z,
	    indicator(j,1:L(s),s) = indicator(j,1:L(s),s) / z;
	  else,
	    indicator(j,:,s) = 1 / L(s);
	  end;
	end;
      end;
      
      % M step
      % ------
      % Update mu and sigma.
      A1 = zeros(numwords, 1);
      A2 = zeros(F, numwords);
      A3 = zeros(F, F, numwords);
      
      % Repeat for each sentence.
      for s = 1:N,
	% Repeat for each word in the sentence.
	for i = 1:L(s),
	  w = W(s,i);
	  
	  % Repeat for each blob in the sentence.
	  for j = 1:M(s),
	    w   = W(s,i);
	    b   = B(:,j,s);
	    u   = b - mu(:,w);
	    ind = indicator(j,i,s);
	    
	    A1(w)     = A1(w) + ind;
	    A2(:,w)   = A2(:,w) + b*ind;
	    A3(:,:,w) = A3(:,:,w) + u*u'*ind;
	  end;
	end;
      end;
      
      % Check to see if we are restricting the covariance to be
      % diagonal. 
      if strcmp(diagCov,'yes'),
	% Diagonal covariances.
	for w = 1:numwords,
	  A1inv = inv(A1(w));
	  mu(:,w)    = A1inv * A2(:,w);
	  sig(:,:,w) = diag(diag(A1inv * A3(:,:,w) + noise));
	end;
      else,
	% Non-diagonal covariances.
	for w = 1:numwords,
	  A1inv = inv(A1(w));
	  mu(:,w)    = A1inv * A2(:,w);
	  sig(:,:,w) = A1inv * A3(:,:,w) + noise;
	end;	  
      end;
      
      % Compute the log-likelihood
      % --------------------------
      l = 0;
      for s = 1:N,
	for j = 1:M(s),
	  b = B(:,j,s);
	  x = 0;
	  for i = 1:L(s),
	    w = W(s,i);
	    u = b - mu(:,w);
	    x = x + 1 / sqrt(det(2*pi*sig(:,:,w))) * ...
		exp((-0.5)*u'*inv(sig(:,:,w))*u);
	  end;
	  l = l + log(x / L(s));
	end;
      end;
      
      proglog('   EM iteration %i - log likelihood = %f', iter, l);
      likelihoods = [likelihoods l];
      
      % Compute the error.
      if iter > 1,
	error = l - likelihoods(iter-1);
      end;
    end; % Repeat EM.
    
    % Check whether this model is better than the previous ones, based on
    % our computation of the loglikelihood.
    curLikelihood = likelihoods(length(likelihoods));
    if curLikelihood > bestModel.likelihood,
      bestR                    = r;
      bestModel.likelihood     = curLikelihood;
      bestModel.mu             = mu;
      bestModel.sig            = sig;
    end;

  end; % Repeat for each restart.
  
  proglog('Out of %i restarts, the best model is from restart %i', ...
	  numRestarts, bestR);
  proglog('with a log likelihood of %f.', bestModel.likelihood);
  
  % Return the model.
  model.mu  = bestModel.mu;
  model.sig = bestModel.sig;