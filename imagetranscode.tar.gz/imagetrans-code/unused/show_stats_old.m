function show_stats (stats, trial)

  % Function constants.
  generalPath = '../general';

  % Add the proper paths in order to access the "general" functions. 
  oldPath = path;
  dirs    = genpath(generalPath);
  path(dirs, oldPath);
  clear generalPath dirs  

  % Repeat for each data set.
  numDatasets = length(stats.sets);
  
  % Grab the precision for the trial.
  for d = 1:numDatasets,
    if trial,
      pr{d}  = stats.sets{d}.pr(:,trial);
      prt{d} = stats.sets{d}.prt(trial);
    else,
      pr{d}  = stats.sets{d}.prAll;
      prt{d} = stats.sets{d}.prtAll;
    end;
  end;
  
  for d = 1:numDatasets,
    
    % Show the word frequencies
    % -------------------------
    label = stats.sets{d}.label;
    msg   = ['Frequencies of words in "' label '" labels'];
    fprintf([msg '\n']);
    printLine(length(msg));
    
    % Find the word with the longest length.
    maxWordLen = max([length('WORD') length('TOTALS') ...
		      maxStrLength(stats.sets{d}.words)]);
    numWords   = length(stats.sets{d}.words);
    
    fprintf('%s  LABEL%%  ANNOT%%  PRECISION\n', ...
	    leftJustify('WORD', maxWordLen));
    fprintf('%s  LABEL%%  ANNOT%%  PRECISION\n', ...
	    leftJustify('WORD', maxWordLen));
    
    % Repeat for each word.
    for w = 1:numWords,
      wrd = stats.sets{d}.words{w};
      
      % Show the word name and the label frequency.
      fprintf('%s  %0.3f   %0.3f   %0.3f \n', ...
	      leftJustify(wrd, maxWordLen), ...
	      stats.sets{d}.labelWordFreq(w), ...
	      stats.sets{d}.annotWordFreq(w), ...
	      pr{d}(w));
    end;
    
    % Show the totals.
    fprintf('%s  %0.3f   %0.3f   %0.3f \n', ...
	    leftJustify('TOTALS', maxWordLen), 1, 1, ...
	    prt{d});
    
    fprintf('\n');
  end;
  
  % Show tau
  % --------
  try
    tau = stats.tau;
    msg = ['Tau for ' stats.model];
    fprintf([msg '\n']);
    printLine(length(msg));
    
    maxFeatLen  = max(length('FEATURE'), ...
		      maxStrLength(stats.featureNames));
    numFeatures = length(tau);
    
    fprintf('%s  TAU \n', leftJustify('FEATURE', maxFeatLen));
    
    for f = 1:numFeatures,
      fName = stats.featureNames{f};
      fprintf('%s  %0.3f \n', leftJustify(fName, maxFeatLen), ...
	      tau(f));
    end;
    
  catch
  end
  
  % Restore the old path.
  path(oldPath);
  
% ----------------------------------------------------------
function s = leftJustify (s, n)
  s = [s repmat(' ', [1 n - length(s)])];

% ----------------------------------------------------------
function printLine (n)
  fprintf([repmat('-', [1 n]) '\n']);

% ----------------------------------------------------------
function n = maxStrLength (strs)

  S = length(strs);
  ls = zeros(S, 1);
  for i = 1:S,
    ls(i) = length(strs{i});
  end;
  n = max(ls);

% ----------------------------------------------------------
% Returns -1 if s1 is before s2. 
% Returns  0 if s1 equals s2. 
% Returns  1 if s1 is after s2.
function strcmp2 (s1, s2)
  
  % Make the strings the same size.
  l1 = length(s1);
  l2 = length(s2);
  if l1 < l2,
    s1 = [s1 repmat(0,[1 l2 - l1])];
  elseif l2 < l1,
    s2 = [s2 repmat(0,[1 l1 - l2])];
  end;
  
  