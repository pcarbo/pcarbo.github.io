% MODEL1GAUSSNULLML_WRITE
%
%    Writes the following files to disk:
%      - mu
%      - sigma
%      - t0
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function model1gaussNullML_write (d, model)
  
  % Write out the cluster means and covariances.
  model1gaussML_write(d,model);
  
  % Write out t0.
  write_matrix(d, 't0', model.t0);
