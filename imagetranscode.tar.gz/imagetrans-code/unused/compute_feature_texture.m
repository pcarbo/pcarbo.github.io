function f = compute_feature_texture (img, nimg, labimg, segment)

  try
  lastwarn('');
    
  % Get the response matrix for the segment using the RGB image. 
  response = get_seg_textures(img, segment);
  [ans numThetas numScales] = size(response);
  
  % Find out which orientation gives the maximum average response. 
  [ans maxT] = max(sum(response(1,:,:),3));
  for theta = [maxT:numThetas 1:maxT-1],
    responseRI(:,theta,:) = response(:,theta,:); 
  end;
  
  % Return the response. 
  f = [ reshape(response,   [1 numScales*numThetas*2]) ...
        reshape(responseRI, [1 numScales*numThetas*2]) ];

  if length(lastwarn),
    error(lastwarn);
  end;
  
  catch
  end;
  