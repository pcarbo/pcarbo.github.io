function model = MISVM_train (B, W, M, L, numwords, numRestarts)
  
  