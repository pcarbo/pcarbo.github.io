% We're going to find the filters for 3 scales and 6 orientations. 
function [ffilters, masks, Z] = get_gabor_filters
  
  % Function constants.
  Ul         = 0.05;
  Uh         = 0.4;
  firstScale = 3;
  lastScale  = 4;
  firstTheta = 1;
  lastTheta  = 6;
  N          = 64;
  n          = 32;
  maskSize   = [16 8 6];
  
  % Initialize the set of gabor filters.
  numScales = lastScale - firstScale + 1;
  numThetas = lastTheta - firstTheta + 1;
  filters   = cell(numScales+1, numThetas, 2);
  
  for s = 1:numScales,
    for theta = 1:numThetas,
      % Compute the Gabor filter.
      [Gr,Gi] = gabor(N, [s+firstScale-1 theta+firstTheta-1], ...
		      [Ul Uh], [lastScale lastTheta], 1);
      filters{s,theta,1} = Gr;
      filters{s,theta,2} = Gi;
    end;
  end;
  
  % We're going to add a final filter since the scales given to us aren't
  % small enough.
  for theta = 1:numThetas,
    Gr = imresize(filters{numScales,theta,1}, [n n], 'bilinear');
    Gi = imresize(filters{numScales,theta,2}, [n n], 'bilinear');
    filters{numScales+1,theta,1} = Gr;
    filters{numScales+1,theta,2} = Gi;
  end;
  
  % Debugging:
  %for s = 1:numScales+1,
  %  for theta = 1:numThetas,
  %    subplot(numScales+1,numThetas,(s-1)*numThetas+theta);
  %    imagesc(filters{s,theta,1});
  %  end;
  %end;  
  %colormap(gray);
  
  % Now we've filled up ffilters and filters, but we now need to
  % calculate the masks for the filters. Also, we will crop the filters
  % using the computed mask.
  masks    = cell(numScales+1, numThetas);
  ffilters = cell(numScales+1, numThetas);
  Z        = zeros(numScales+1, numThetas);
  for s = 1:numScales+1,
    for theta = 1:numThetas,
      
      % Find the mask.      
      Gr    = filters{s,theta,1};
      Gi    = filters{s,theta,2};
      %mask  = abs(Gr) > maskThresh(s);
      %[h w] = find(mask);
      n      = size(Gr,1);
      %h     = h - n/2;
      %w     = w - n/2;
      %r     = ceil(sqrt(max(h.*h + w.*w)));
      r     = ceil(maskSize(s)/2);
      mask  = draw_circle(r);
      
      % Now that we have the mask, let's crop the two filters (real and
      % imaginary).
      n              = floor(n/2);
      r              = min(r,n);
      Gr             = Gr(n-r+1:n+r, n-r+1:n+r) .* mask;
      Gi             = Gi(n-r+1:n+r, n-r+1:n+r) .* mask;
      masks{s,theta} = mask;
      
      % Find the normalization constant, Z.
      maskSz     = sum(sum(mask));
      Z(s,theta) = sqrt(sum(sum(abs(Gr + i*Gi).^2))) / maskSz;
      
      % Finally, compute the filter in frequency space.
      ffilters{s,theta}      = fft2(Gr+i*Gi);
      ffilters{s,theta}(1,1) = 0;      
      filters{s,theta,1}     = Gr;
      filters{s,theta,2}     = Gi;
    end;
  end;
  
  % Debugging:
  %for s = 1:numScales+1,
  %  for theta = 1:numThetas,
  %    subplot(numScales+1,numThetas,(s-1)*numThetas+theta);
  %    imagesc(filters{s,theta,1});
  %    %imagesc(-0.05*(~masks{s,theta}) + ...
  %    %	      masks{s,theta}.*filters{s,theta,1});
  %  end;
  %end;  
  %colormap(gray);
  