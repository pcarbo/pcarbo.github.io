% MODEL1GAUSSMAPONLINE_TRAIN    Train model 1 Gaussian MAP.
%   The function call is MODEL = MODEL1GAUSSMAPONLINE_TRAIN(B,W,M,L,
%   NUMWORDS,NUMRESTARTS,KMITER,EMITER,LSA,LSB,ALPHA,A,B,RANDINIT). The 
%   model-specific parameters are:
%     - NUMRESTARTS  The number of times you would like to train the
%                    model, taking the best based on the log-likelihood.
%     - KMITER       The maximum number of iterations to run
%                    K-Means. Only valid if RANDINIT is 'no' (see  
%                    below). 
%     - EMITER       The maximum number of iterations ro run EM.
%     - LSA          The parameter "a" in the learning schedule.
%     - LSB          A vector of the parameters "b2" and "b3" in the
%                    learning schedule, where b2 corresponds to
%                    sufficient statistic 2 (means) and b3 corresponds to
%                    sufficient statistic 3 (covariances). If LSB is a
%                    scalar, then b2 and b3 are the same. To calculate
%                    bi, bi = LSB(i) * N, where N is the number of
%                    documents in the training set.
%     - ALPHA        The degree of freedom parameter for the Inverse
%                    Wishart distribution on the covariance.
%     - A            The shape parameter on the Inverse Gamma
%                    distribution on tau.
%     - B            The scale parameter on the Inverse Gamma
%                    distribution for tau.
%     - RANDINIT     Optional parameter. By default, the value of this
%                    parameter is 'no' which means that the cluster means
%                    are initialized using K-Means. If this parameter is
%                    'yes', they are initialized by sampling randomly
%                    from a N(O,I) distribution. If RANDINIT is 'yes'
%                    then the parameter KMITER is irrelevant.
%
%   In MODEL we will return the following information:
%     - mu   F x W matrix of Gaussian means, where F is the number of
%            features and W is the number of word tokens.
%     - sig  F x F x W matrix of Gaussian covariances.
%     - tau  F x 1 matrix of feature weights.
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function model = model1gaussMAPOnline_train ...
      (B, W, M, L, numwords, numRestarts, KMiter, EMiter, ...
       LSa, LSb, alpha, a, b, varargin)

  % Function constants.
  worstPosterior = -1e99;
  numReqdArgs    = 13;

  % Default arguments.
  defaultRandInit = 'no';

  % Check to make sure there's enough arguments to run the function.
  if nargin < numReqdArgs,
    error('Not enough input arguments for function. See help for details');
  end;

  % Set up function parameters
  % --------------------------
  defargs = { defaultRandInit };
  [ randInit ] = manage_vargs(varargin, defargs);
  clear defargs varargin numReqdArgs defaultRandInit

  F           = size(B,1);
  N           = length(M);
  maxM        = max(M);
  maxL        = max(L);

  % Check to make sure the value for "alpha" is valid.
  if alpha <= F + 1,
    error([ 'Alpha must be greater than F + 1, where F is the ' ...
            number of features.' ]);
  end;

  % Set up the learning schedule. We set the "b2" and "b3" to the 2nd and
  % 3rd entries of the array just to make it more readable to the
  % programmer.
  LSb = round(LSb * N);
  if length(LSb) < 2,
    LSb([3 2]) = LSb([1 1]);
  else,
    LSb(3) = LSb(2);
    LSb(2) = LSb(1);
  end;

  % Get the sample mean and variance.
  sB      = smash_blobs(B, M);
  muStar  = mean(sB')';
  sigStar = cov(sB')';
  clear sB

  % Calculate the normalising constants on the Inverse-Wishart
  % distribution for the sigma parameter and on the Inverse-Gamma
  % distribution for the tau parameter.
  zIW = -numwords*(log(2^(0.5*alpha*F) * pi^(0.25*F*(F-1)) * ...
                prod(gamma(0.5*(alpha+1-[1:F])))) ...
            + log(det(alpha*sigStar)^(0.5*alpha)));
  zIG = F*log(b^a / gamma(a));

  % Reserve storage for the indicators.
  indicator = zeros(maxM,maxL);    

  % Repeat for each restart.
  bestModel.posterior = worstPosterior;
  for r = 1:numRestarts,
  
    proglog('Model 1 Gaussian MAP training, restart %i.', r);
        
    % Initialize the parameters by randomly sampling from their prior
    % distributions. For the means, we have the option of initializing
    % them using k-means. Note that we assume the data is normalised.
    %   - tau is a F x 1 matrix.
    %   - mu is a F x 1 matrix.
    %   - sig is a F x F x C matrix.
    proglog('a.) Initializing model parameter values.');
    
    % Initialize tau.
    tau = invgamm_rnd(F,1,a,b);
    
    % Initialize mu.
    if randInit,
      % Randomly initialize the cluster means from prior distribution.
      proglog('b.) Randomly finding cluster means.');
      mu = diag(sqrt(tau)) * randn(F,numwords) + ...
	   repmat(muStar,[1 numwords]);
    else,
      % Run k-means on blobs to find clusters centers and blob-cluster
      % membership.
      proglog('b.) Running k-means.');
      sB = smash_blobs(B,M);
      [clusterCenters blobsInClusters] = ...
	  do_kmeans(sB', 0, KMiter, 1, numwords);
      mu = clusterCenters';
      clear sB blobsInClusters clusterCenters
    end;
    
    % Initialize sigma.
    for w = 1:numwords,
      sig(:,:,w) = invwishirnd(alpha * sigStar, alpha+1+F);
    end;
    
    % We're going to keep track of three sufficient statistics, and we'll 
    % call them SS1, SS2 and SS3. Here we create the storage for the
    % sufficient statistics and initialize them. Since we have two
    % different learing rates for SS2 and SS3, in actual fact we have to
    % keep track of two different versions of SS1.
    proglog('c. Initializing sufficient statistics.');
    SS1_2 = ones(1, numwords);
    SS1_3 = SS1_2;
    SS2   = mu;
    SS3   = sig;
        
    % Run EM
    % ------
    % At each iteration, we add a new document to be analysed.
    proglog('d.) Running EM.');
    for time = 1:(N*EMiter),
      
      % Get the document number we just added.
      s  = 1+mod(time-1,N);
      ls = L(s);
      ms = M(s);
      
      % E step
      % ------
      % Compute p(a_si=j|b_sj,w_si).
      for i = 1:ls,
	w = W(s,i);
	u = (B(:,1:ms,s) - repmat(mu(:,w),[1 ms]))';
	indicator(1:ms,i) = ...
	    exp((-0.5)*dot(u*inv(sig(:,:,w)),u,2)) ...
	    / (sqrt(det(sig(:,:,w))));
      end;
	
      % For each blob, normalize over all words in the sentence.
      z  = sum(indicator(1:ms,1:ls),2);
      f  = find(z);
      fn = find(~z);
      if length(f),
	indicator(f,1:ls)  = indicator(f,1:ls) ./ repmat(z(f),[1 ls]);
      end;
      indicator(fn,1:ls) = 1 / ls;
      
      % M step
      % ------
      % Update the learning schedule.
      eta2 = 1 / (LSa*time + LSb(2));
      eta3 = 1 / (LSa*time + LSb(3));
      
      % These are some intermediate variables used for calculating the
      % sufficient statistics.
      A1 = zeros(1, numwords);
      A2 = zeros(F, numwords);
      A3 = zeros(F, F, numwords);

      % Repeat for each word in the sentence.
      for i = 1:ls,
	w   = W(s,i);
	blb = B(:,1:ms,s);
	u   = blb - repmat(mu(:,w),[1 ms]);
	
	A1(w)     = A1(w) + sum(indicator(1:ms,i));
	A2(:,w)   = A2(:,w) + sum(repmat(indicator(1:ms,i)',[F 1]).*blb,2);
	A3(:,:,w) = A3(:,:,w) + (u.*repmat(indicator(1:ms,i)',[F 1]))*u';
      end;	
      
      % Now that we have A1, A2 and A3, it's a simple matter to calculate
      % the new sufficient statistics. We have to add noise to SS3
      % because of ill-conditioning.
      SS1_2 = SS1_2 + eta2*(A1 - SS1_2);
      SS1_3 = SS1_3 + eta3*(A1 - SS1_3);
      SS2   = SS2   + eta2*(A2 - SS2);
      SS3   = SS3   + eta3*(A3 - SS3);
      
      % Save the old tau for the mu update step.
      Tau = diag(tau);

      % Update tau, mu and sigma. Note that the order is important!
      % Update tau.
      tau = b/(a + 0.5*numwords + 1) + ...
	    sum((mu - repmat(muStar,[1 numwords])).^2,2) / ...
	    (2*a + numwords + 2);

      % Update mu and sigma.
      for w = 1:numwords,
	z          = inv(sig(:,:,w) + Tau*SS1_2(w));
        mu(:,w)    = Tau * z * SS2(:,w) + sig(:,:,w) * z * muStar;
        sig(:,:,w) = (SS3(:,:,w) + alpha*sigStar) / (SS1_3(w)+alpha+F+1);
      end;    

    end; % Repeat EM.

    % Compute the posterior.
    l = 0;
    for s = 1:N,
      ms = M(s);
      ls = L(s);
      z  = zeros(ls,ms);
      
      for i = 1:ls,
	w         = W(s,i);
	z1        = 1 / sqrt(det(2*pi*sig(:,:,w)));
	u         = (B(:,1:ms,s) - repmat(mu(:,w),[1 ms]))';
	z(i,1:ms) = z1 * exp((-0.5)*dot(u*inv(sig(:,:,w)),u,2))';
      end;
      
      l = l + sum(log(sum(z,1) / ls));
    end;
    
    % Compute the prior on mu.
    Tau = diag(tau);
    z1  = inv(Tau);
    for w = 1:numwords,
      u = mu(:,w) - muStar;
      l = l - 0.5*u'*z1*u;
    end;
    l = l - 0.5*numwords*log(det(2*pi*Tau));
    
    % Compute the prior on sigma.
    for w = 1:numwords,
      l = l - 0.5*(alpha+F+1)*log(det(sig(:,:,w))) + ...
	  - 0.5*trace(alpha*sigStar*inv(sig(:,:,w)));
    end;
    l = l + zIW;
    
    % Compute the prior on tau.
    l = l + zIG - (a+1)*sum(log(tau)) - b*sum(tau.^(-1));
    
    % Check whether this model is better than the previous ones, based on
    % our computation of the log-posterior.
    if l > bestModel.posterior,
      bestR               = r;
      bestModel.posterior = l;
      bestModel.sig       = sig;
      bestModel.mu        = mu;
      bestModel.tau       = tau;
    end;
    
  end; % Repeat for each restart.
    
  proglog('Out of %i restarts, the best model is from restart %i', ...
	  numRestarts, bestR);
  proglog('with a log posterior of %f.', bestModel.posterior);
  
  % Return the model.
  model = bestModel;