function c = count_nonzero (x)
  c = sum(x > 0);
  