function modelCo_write (d, model)
  
  write_matrix(d, 'cooc', model.cooc);
  write_matrix(d, 'sp', model.sp);
  model1gaussMAP_write(d,model);