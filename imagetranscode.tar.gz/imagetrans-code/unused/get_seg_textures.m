% Function call:
%   response = get_seg_textures (img, segment)
%
% Inputs:
%   - img
%   - segment
%
% Outputs:
%   - response  2 x T x S matrix where S is the number of Gabor filter scales
%               and T is the number of Gabor filter orientations.

function response = get_seg_textures (img, segment)

  try
  
  % First get the gabor features and their masks.
  [ffilters masks Z] = get_gabor_filters;
    
  % Next we average the image to make it grayscale.
  img   = sum(img,3) / size(img,3);
  [h w] = size(segment);
  
  % Initialize the response.
  numScales = size(masks,1);
  numThetas = size(masks,2);
  response  = zeros(2, numThetas, numScales);
  
  % Repeat for each scale and each orientation.
  for s = 1:numScales,
    for theta = 1:numThetas,
      
      % To compute the responses, what we do first is find out locations
      % are valid locations for computing the texture. If no location is
      % valid, the best we can do is set it to the middle of the
      % segment. We all the matrix of locations "L".
      mask    = masks{s,theta};
      maskSz  = sum(sum(mask));
      ffilter = ffilters{s,theta};
      [mh mw] = size(mask);
      
      % "z" is the location in the filter where we do the computation.
      zh  = floor(mh/2);
      zw  = floor(mw/2);
      zh2 = mh - zh;
      zw2 = mw - zw;
      
      % Crop the segment and image and call the new versions "seg" and
      % "im", respectively.
      [lh lw] = find(segment(zh:h-zh2, zw:w-zw2));
      lh      = lh + zh - 1;
      lw      = lw + zw - 1;
      
      % Repeat for each location (h,w) in the image. Each location is a
      % potential candidate, and it is where the middle location of the
      % filter will be placed. We're going to put the successful
      % candidates in a vector called "locs".
      locs = [];
      for i = 1:length(lh),
	if maskSz == sum(sum(mask & segment(lh(i)-zh+1:lh(i)+zh2, ...
					    lw(i)-zw+1:lw(i)+zw2))),
	  locs = [locs; [lh(i) lw(i)]];
	end;
      end;
      
      % Now that we have all the goood locations for computing the
      % response... do so! But, if the "locs" matrix is empty then we
      % can only guess at the filter response by taking it over an
      % averaged pixel.
      numLocs = size(locs,1);
      if numLocs,
	R = zeros(mh, mw, numLocs);
	for i = 1:numLocs,
	  R(:,:,i) = abs(ifft2(fft2(img(locs(i,1)-zh+1:locs(i,1)+zh2, ...
					locs(i,2)-zw+1:locs(i,2)+zw2) ...
				    .* ffilter)));
	  % Normalize by the filter energy.
	  R(:,:,i) = R(:,:,i) / sqrt(sum(reshape((R(:,:,i).^2), [1 mh*mw])));
	end;
      
	% Normalize all the responses by the mask energy.
	R = R ./ repmat(Z(s,theta), [mh mw numLocs]);
	
	% Put the total response together.
	R  = reshape(R, [1 mh*mw*numLocs]);
	mu = sum(R) / (maskSz * numLocs);
	response(1,theta,s) = mu;
	response(2,theta,s) = sum((R - mu).^2) / (maskSz * numLocs);
      else,
	
	% We don't have any locations for which we can compute the filter
        % of scale "s" and orientation "theta". In effect, the response
        % will be 0.
	response(1:2,theta,s) = 0;
      end;
    end;
  end;
  
  catch
    disp(lasterr);
  end;