function plot_gabor (n)
  
  % Function constants.
  Ul         = 0.05;
  Uh         = 0.4;
  numScales  = 4;
  numThetas  = 6;
  N          = 64;
  maskThresh = 1e-3;
  
  % Create the two figures.
  f1 = figure;
  f2 = figure;
  
  p  = 0;
  for s = 1:numScales,
    for theta = 1:numThetas,
      p = p + 1;
      [Gr,Gi] = gabor(N, [s theta], [Ul Uh], [numScales numThetas], 1);
      
      % Resize the filter.
      Gr = imresize(Gr,[n n],'bilinear');
      
      % Find the mask.
      mask  = abs(Gr) > maskThresh;
      [h w] = find(mask);
      h     = h - n/2;
      w     = w - n/2;
      r     = ceil(sqrt(max(h.*h + w.*w)));
      disp(r);
      mask  = draw_circle(r);
      m     = floor(N/2);
      r     = min(r,m);
      Gr    = Gr(m-r+1:m+r, m-r+1:m+r);
      
      figure(f1);
      subplot(numScales,numThetas,p);
      imagesc(Gr);
      colormap(gray);
      
      figure(f2);
      subplot(numScales,numThetas,p);
      imagesc(mask);      
      colormap(gray);
    end;
  end;
