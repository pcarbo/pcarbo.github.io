function f = compute_feature_texrotinv_norm (img, nimg, labimg, segment)
  
  % Get the response matrix for the segment using the RGB image. 
  response = get_seg_textures(nimg, segment);
  [numScales numThetas] = size(response);
  
  % Find out which orientation gives the maximum average response. 
  [ans maxT] = max(sum(response,1));
  response = [response(:,maxT:numThetas) response(:,1:maxT-1)];
  
  % Return the response. 
  f = reshape(response', [1 numScales*numThetas]);