% MODEL1GAUSSNULLML_TRANS
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function t = model1gaussNullML_trans (B, M, A, model)
  
  % Build the "t" matrix.
  t = model1gaussML_trans(B,M,A,model);
