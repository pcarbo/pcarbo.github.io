function model = model1MRFgaussML_train ...
    (B, W, A, M, L, numwords, numRestarts, KMiter, EMiter, EMtol, ...
     psiPrior, sp, varargin)

  % Function constants.
  worstLikelihood = -1e99;
  numReqdArgs     = 12;

  % Default arguments.
  defaultFaulty   = 1;
  defaultDiagCov  = 'no';  
  defaultRandInit = 'no';
  defaultBPtol    = 1e-3;
  defaultBPiter   = 5;

  % Check to make sure there's enough arguments to run the function.
  if nargin < numReqdArgs,
    error('Not enough input arguments for function. See help for details');
  end;
  
  % Set up function parameters
  % --------------------------
  defargs    = { defaultFaulty;
		 defaultDiagCov; 
		 defaultRandInit;
		 defaultBPtol; 
		 defaultBPiter };
  [ faulty ...
    diagCov ...
    randInit ...
    BPtol ...
    BPiter ] = manage_vargs(varargin, defargs);
  clear defargs varargin numReqdArgs defaultDiagCov defaultRandInit
  clear defaultFaulty defaultBPtol defaultBPiter
  
  % Set up some miscellaneous parameters
  F      = size(B,1);
  N      = length(M);
  maxM   = max(M);
  maxL   = max(L);
  noise  = 1e-10 * eye(F,F);
  sp     = strcmp('yes',sp);
  
  % Make a list of all the pairs (i.e. edges) for each document.
  for s = 1:N,
    [C1 C2] = find(A{s});
    if length(C1),
      C{s}(:,1) = C1;
      C{s}(:,2) = C2;
    else,
      C{s} = [];
    end;
  end;
  clear C1 C2
  
  % Find the word co-occurence counts
  % ---------------------------------
  % Initialize the co-occurences table. Note that we never build up the
  % the counts along the diagonal. 
  cooc = zeros(numwords, numwords);
  for s = 1:N,
    [i j] = find(triu(ones(L(s)),1));
    for w = 1:length(i),
      cooc(W(s,i(w)),W(s,j(w))) = cooc(W(s,i(w)),W(s,j(w))) + 1;
      cooc(W(s,j(w)),W(s,i(w))) = cooc(W(s,j(w)),W(s,i(w))) + 1;
    end;
    for w = 1:L(s),
      cooc(W(s,w),W(s,w)) = cooc(W(s,w),W(s,w)) + 1;
    end;
  end;

  % Repeat for each restart.
  bestModel.likelihood = worstLikelihood;
  for r = 1:numRestarts,
    
    proglog('Model 1 MRF Gaussian ML training, restart %i.', r);
 
    % Occasionally we get some extreme results which we'll have to throw
    % away. That's no problem, we just try again! This only happens
    % because we sometimes get strange samples from the prior
    % distributions for our initial values for mu, sigma and tau. The
    % "faulty" parameter designates the maximum number of times to try
    % until we give up.
    success     = 0;
    faultyStart = 0;
    while ~success & faultyStart < faulty,
      faultyStart = faultyStart + 1;
      try
	% Run EM.
	[model likelihoods] = ...
	    em(B, W, A, C, M, L, cooc, numwords, F, maxM, maxL, N, ...
	       EMiter, EMtol, KMiter, BPiter, BPtol, sp, psiPrior, ...
	       noise, diagCov, randInit);
	success = 1;
      catch,
	str = 'Attempt no. %i failed.';
	if faultyStart < faulty,
	  str = [str ' Trying EM again.'];
      end;
	proglog(str, faultyStart);
	clear str;
      end;
    end;
 
    % Check whether this model is better than the previous ones, based on
    % our computation of the log-likelihood.
    curLikelihood = likelihoods(length(likelihoods));
    if curLikelihood > bestModel.likelihood;
      bestR                = r;
      bestModel            = model;
      bestModel.likelihood = curLikelihood;
    end;
    
  end; % Repeat for each restart.
  
  proglog('Out of %i restarts, the best model is from restart %i', ...
	  numRestarts, bestR);
  proglog('with a log likelihood of %f.', bestModel.likelihood);
  
  % Return the model.
  model = bestModel;
  
% ---------------------------------------------------------------------
function [model, likelihoods] = em ...
      (B, W, A, C, M, L, cooc, numwords, F, maxM, maxL, N, EMiter, ...
       EMtol, KMiter, BPiter, BPtol, sp, psiPrior, noise, diagCov, ...
       randInit)

  % Allocate memory for latent variables.
  indicator = zeros(maxM,maxL,N);

  if strcmp(randInit,'yes'),
    
    % Randomly initialize the cluster means from an N(O,I)
    % distribution. 
    proglog('a.) Randomly finding cluster means.');
    mu = randn(F,numwords);
  else,
    
    % Run k-means on blobs to find clusters centers and blob-cluster
    % membership.
    proglog('a.) Running k-means.');
    sB = smash_blobs(B, M);
    [clusterCenters blobsInClusters] = ...
	do_kmeans(sB', 0, KMiter, 1, numwords);
    mu = clusterCenters';
    clear sB blobsInClusters clusterCenters
  end;
  
  % Initialize sigma and psi.
  proglog('b.) Initializing model parameter values.');
  sig = repmat(eye(F,F),[1 1 numwords]);
  psi = rand(numwords, numwords);
  psi = psi / (mean(mean(psi)) * numwords) + psiPrior;  
  
  % Run EM.
  proglog('c.) Running EM.');
  likelihoods = [];
  for iter = 1:EMiter,

    % E step
    % ------
    % Compute p(a_si=j|b_sj,w_si).
    % Repeat for each sentence.
    for s = 1:N,
      ms = M(s);
      ls = L(s);
      
      % Build the MS x LS matrix "t", where MS is the number of blobs in
      % the image and LS is the number of words. Thus, each entry t(j,i)
      % is the probability of generating blob Bsj given that it is
      % aligned to the word Wsi.
      t = zeros(ms,ls);
      for i = 1:ls,
	w = W(s,i);
	u = (B(:,1:ms,s) - repmat(mu(:,w),[1 ms]))';
	t(:,i) = exp((-0.5)*dot(u*inv(sig(:,:,w)),u,2)) ...
		 / (sqrt(det(sig(:,:,w))));
      end;
      
      % For each blob, normalize over all words in the sentence.
      z  = sum(t,2);
      f  = find(z);
      fn = find(~z);
      if length(f),
	t(f,:) = t(f,:) ./ repmat(z(f),[1 ls]);
      end;
      t(fn,:) = 1 / ls;      
      
      % Run loopy belief propagation, grabbing the potentials only for
      % the words in the image's label.
      if ms > 1,
	indicator(1:ms,1:ls,s) = bpmrf2(A{s}, psi(W(s,1:ls),W(s,1:ls)), ...
					t, sp, BPtol, BPiter*ms, 0);
      else,
	indicator(1,1:ls,s) = t;
      end; 
      
      % Normalize again.
      z  = sum(indicator(1:ms,1:ls,s),2);
      f  = find(z);
      fn = find(~z);
      if length(f),
	indicator(f,1:ls,s) = ...
	    indicator(f,1:ls,s) ./ repmat(z(f),[1 ls]);
      end;
      indicator(fn,1:ls,s) = 1 / ls;
    end;

    % M step
    % ------
    % Update psi.
    psi = zeros(numwords, numwords);
    for s = 1:N,
      ms = M(s);
      ls = L(s);
      
      if ms > 1,
	x = zeros(numwords, numwords);
      
	% Repeat for each clique pair.
	for i = 1:size(C{s},1),
	  
	  % Repeat for each pair of words in the image.
	  for u = 1:ls,
	    for v = 1:ls,
	      x(W(s,u),W(s,v)) = x(W(s,u),W(s,v)) + ...
		  indicator(C{s}(i,1),u,s) * indicator(C{s}(i,2),v,s);
	    end;
	  end;
	end;
	
	% "Normalize" x.
	x = x / (mean(mean(x)) * numwords);
	psi = psi + x;
      end;
    end;
    
    % "Normalize" psi and add the prior.
    psi = psi / sum(M > 1);
    psi = psi + psiPrior;
    
    % Update mu and sigma.
    A1 = zeros(1,numwords);
    A2 = zeros(F,numwords);
    A3 = zeros(F,F,numwords);
    
    % Repeat for each sentence.
    for s = 1:N,
      ms = M(s);
      ls = L(s);
      
      % Repeat for each word in the sentence.
      for i = 1:ls,
	w   = W(s,i);
	blb = B(:,1:ms,s);
	u   = blb - repmat(mu(:,w),[1 ms]);
	
	A1(w)     = A1(w) + sum(indicator(1:ms,i,s));
	A2(:,w)   = A2(:,w) + ...
	    sum(repmat(indicator(1:ms,i,s)',[F 1]) .* blb,2);
	A3(:,:,w) = A3(:,:,w) + ...
	    (u.*repmat(indicator(1:ms,i,s)',[F 1]))*u';
      end;
    end;
    
    % Now that we have A1, A2 and A3, update the parameters mu and
    % sigma. 
    f = find(A1);
    mu(:,f) = A2(:,f) .* repmat(1 ./ A1(f), [F 1]);
    sig(:,:,f) = A3(:,:,f) ...
	.* repmat(reshape(1 ./ A1(f), [1 1 length(f)]), [F F 1]) ...
	+ repmat(noise, [1 1 length(f)]);

    % Check to see if we are restricting the covariance to be
    % diagonal. 
    if strcmp(diagCov,'yes'),
      for w = 1:numwords,
	sig(:,:,w) = diag(diag(sig(:,:,w)));
      end;
    end;    
    
    % Compute the log-likelihood
    % --------------------------
    l = 0;
    for s = 1:N,
      ms = M(s);
      ls = L(s);
      z  = zeros(ls,ms);
      
      for i = 1:ls,
	w         = W(s,i);
	z1        = 1 / sqrt(det(2*pi*sig(:,:,w)));
	u         = (B(:,1:ms,s) - repmat(mu(:,w),[1 ms]))';
	z(i,1:ms) = z1 * exp((-0.5)*dot(u*inv(sig(:,:,w)),u,2))';
      end;
      
      l = l + sum(log(sum(z,1) / ls));
    end;
    
    % TO CHANGE.
    for s = 1:N,
      ms = M(s);
      ls = L(s);
      
      for i = 1:size(C{s},1),
	x = 0;
	for u = 1:ls,
	  for v = 1:ls,
	    x = x + psi(W(s,u),W(s,v));
	  end;
	end;
	l = l + log(x);
      end;      
    end;
    
    proglog('   EM iteration %i - log likelihood = %f', iter, l);
    likelihoods = [likelihoods l];
    
    % Compute the error.
    % TO CHANGE
    if iter > 1,
       if abs(l - likelihoods(iter-1)) < EMtol,
         break;
       end;
     end;
    
  end; % Repeat EM.

  % Return the model.
  model.psi    = psi;
  model.sig    = sig;
  model.mu     = mu;  
  model.sp     = sp;
  model.BPtol  = BPtol;
  model.BPiter = BPiter;