N = 6; % Num. observed nodes.
W = 2; % Nu. latent states.
psi = softeye(W,0.8);

c = ...
[ 0 1 0 1 0 0; 
  1 0 1 0 1 0;
  0 1 0 0 0 1;
  1 0 0 0 1 0;
  0 1 0 1 0 1;
  0 0 1 0 1 0 ];

t = ...
[ 9.0  1.0;
  8.0  2.0;
  3.0  7.0;
  8.0  2.0;
  3.0  7.0;
  1.0  9.0 ];

% Sum product
newBel = bpmrf2(c, psi, t, 1, 1e-3, 5*N);

% Argmax
newBel = bpmrf2(c, psi, t, 0, 1e-3, 5*N);
