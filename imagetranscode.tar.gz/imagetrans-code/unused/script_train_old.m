clc;
clear;

% Script parameters.
datadir  = '/cs/beta/People/Nando/corel/imagetrans/data/sets/';
datadirs{1} = [datadir 'new/robomedia'];

modeldir = '/cs/beta/People/Nando/corel/imagetrans/data/models/exp';
models{1} = 'model7A';

numtrials = 1;
keepOld   = 'no';

% Add the proper paths in order to access the "general" functions. 
generalPath = 'general';
oldPath = path;
dirs    = genpath(generalPath);
path(dirs, oldPath);
clear generalPath dirs  
  
% Translate
cd translation
for d = 1:length(datadirs),
  
  for m = 1:length(models),
    % First check to see if the model results are already there. This is
    % simply done by checking to see if the directory exists. If it is
    % already there and the user has decided to keep the old results,
    % don't evaluate the model again for that data set. 
    [status ans] = system(sprintf('ls %s/results/%s',datadirs{d},models{m}));
    if status | strcmp(keepOld,'no'),
      evaluate_model(datadirs{d},modeldir,models{m},numtrials);
    end;
  end;
end;
cd ..