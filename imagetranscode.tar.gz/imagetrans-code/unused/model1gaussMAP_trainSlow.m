% MODEL1GAUSSMAP_TRAIN    Train model 1 Gaussian MAP.
%   The function call is MODEL = MODEL1DISCRETE_TRAIN(B,W,M,L,NUMWORDS, 
%   NUMRESTARTS,KMITER,EMITER,EMTOLERANCE). The model-specific parameters
%   are:
%     - NUMRESTARTS  The number of times you would like to train the
%                    model, taking the best based on the log-likelihood.
%     - KMITER       The maximum number of iterations to run K-Means.
%     - EMITER       The maximum number of iterations ro run EM.
%     - EMTOLERANCE  Stop the EM algorithm when the difference in error
%                    between two steps is less than EMTOLERANCE.
%
%   In MODEL we will return the following information: 
%     - clusterCenters  F x W matrix where F is the number of features
%                       and W is the number of clusters (i.e. the number
%                       of words), indicating the centres of the
%                       normalized clusters.
%     - t               W x W matrix where W is the number of
%                       words. Entry t(b,w) is the probability of
%                       generating blob b from word w.
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function model = model1gaussMAP_train ...
      (B, W, M, L, numwords, numRestarts, KMiter, EMiter, EMtolerance, ...
       alpha, a_prior, b_prior, varargin) 
  
  % Function constants.
  worstLikelihood = -1e99;
  
  F           = size(B,1);
  N           = length(M);
  maxM        = max(M);
  maxL        = max(L);
  
  % Allocate memory for indicators.
  indicator = zeros(maxM, maxL, N);

  % Repeat for each restart.
  bestModel.likelihood = worstLikelihood;
  
  for r = 1:numRestarts,
    
    proglog('Model 1 Gaussian MAP training, restart %i.', r);
    
    % Set up parameters.
    tau 
    
    % Run KM.
    % ------
    proglog('a.) Running KM.');
    sB = smash_blobs(B, M);
    [clusterCenters ans] = do_kmeans(sB',0,KMiter,1,numwords);
    
    % Set up parameters.
    tau    = ones(F,1);
    bigTau = diag(tau);
    
    muStar  = zeros(F,1);
    sigStar = eye(F,F);
    
    % Note that alpha has the following condition:
    % alpha > F + 1, where F is the number of features.
    sig = repmat(alpha * sigStar / (alpha - F - 1), [1 1 numwords]);
    mu  = clusterCenters';
    
    % Run EM.
    % ------
    proglog('b.) Running EM.');
    likelihoods = [];
    error = 1e99;
    iter = 0;
    while (iter < EMiter) & (EMtolerance <= error),
      
      iter = iter + 1;
      
      % E step
      % ------
      % Compute p(a_si=j|b_sj,w_si).
      % Repeat for each sentence.
      for s = 1:N,
	ls = L(s);
	ms = M(s);
	
        % Repeat for each word in the sentence.
        for i = 1:ls,
	  % Repeat for each blob in the sentence.
	  for j = 1:ms,
	    w = W(s,i);
	    u = B(:,j,s) - mu(:,w);
	    indicator(j,i,s) = exp((-0.5)*u'*inv(sig(:,:,w))*u) ... 
	      / (sqrt(det(sig(:,:,w))));
	  end;
        end;
      
        % For each blob, normalize over all words in the sentence.
        for j = 1:ms,
	  z = sum(indicator(j,1:ls,s));
	  if z ~= 0,
	    indicator(j,1:ls,s) = indicator(j,1:ls,s) / z;
	  else
	    indicator(j,1:ls,s) = 1 / ls;
	  end;
        end;
      end;
    
      % M step: calculate the new estimates for the parameters.
      % ------
      % Update the translation probabilities, t.
      A1 = zeros(numwords, 1);
      A2 = zeros(F, numwords);
      A3 = zeros(F, F, numwords);
      
      % Repeat for each sentence.
      for s = 1:N,
	ls = L(s);
	ms = M(s);
	
        % Repeat for each word in the sentence.
        for i = 1:ls,
	  % Repeat for each blob in the sentence.
	  for j = 1:ms,
	    w = W(s,i);
	    b = B(:,j,s);
	    u = B(:,j,s) - mu(:,w);
	    ind = indicator(j,i,s);
	    A1(w)     = A1(w) + ind;
	    A2(:,w)   = A2(:,w) + b*ind;
	    A3(:,:,w) = A3(:,:,w) + u*u'*ind;
	  end;
        end;
      end;
      
      bigTau = diag(tau);
      
      % Update tau, the hyperparameters.
      t_sum = zeros(F, 1);
      for i = 1:numwords,
        t_sum(:) = t_sum(:) + (mu(:,i) - muStar(:)).^2;
      end;
    
      tau = t_sum(:) / (2*a_prior + 2 + numwords) ...
	    + b_prior / (a_prior + 0.5*numwords + 1);

      for w = 1:numwords,
        mu(:,w) = bigTau*inv(A1(w)*bigTau + sig(:,:,w))*A2(:,w) + ...
		  sig(:,:,w)*inv(A1(w)*bigTau + sig(:,:,w))*muStar;
        sig(:,:,w) = (A3(:,:,w) + alpha*sigStar)  ...
	    / (A1(w)+alpha+F+1);
      end;    
      
      % Compute the log likelihood.
      % --------------------------
      l = 1.0;
      
      proglog('   EM iteration %i - log likelihood = %f', iter, l);
      likelihoods = [likelihoods l];
    
      % Compute the error.
      error = 1e99;
    end; % Repeat EM.
    
    % Check whether this model is better than the previous ones, based on
    % our computation of the loglikelihood.
    curLikelihood = likelihoods(length(likelihoods));
    if curLikelihood > bestModel.likelihood,
      bestR                    = r;
      bestModel.likelihood     = curLikelihood;
      bestModel.sig            = sig;
      bestModel.mu             = mu;
      bestModel.tau            = tau;
    end;
    
  end; % Repeat for each restart.
  
  proglog('Out of %i restarts, the best model is from restart %i', ...
	  numRestarts, bestR);
  proglog('with a log likelihood of %f.', bestModel.likelihood);
  
  % Return the model.
  model = bestModel;