% MODELCO_TRAIN    Train model and take account co-occurence counts for
%                  words. 
% 
%   In MODEL we will return the following information:
%     - mu   F x W matrix of Gaussian means, where F is the number of
%            features and W is the number of word tokens.
%     - sig  F x F x W matrix of Gaussian covariances.
%     - tau  F x 1 matrix of feature weights.
%
%    Copyright (c) 2002 University of British Columbia. All Rights
%    Reserved. Created by Peter Carbonetto, Department of Computer
%    Science.

function model = modelCo_train ...
      (B, W, M, L, numwords, priorCoCount, useModel, varargin)

  % Set up function parameters
  N = length(M);
  
  % Find the word co-occurence counts
  % ---------------------------------
  % Initialize the co-occurences table. Note that we never build up the
  % the counts along the diagonal. 
  cooc = (priorCoCount * N) * ones(numwords, numwords);
  for s = 1:N,
    [i j] = find(triu(ones(L(s)),1));
    for w = 1:length(i),
      cooc(W(s,i(w)),W(s,j(w))) = cooc(W(s,i(w)),W(s,j(w))) + 1;
      cooc(W(s,j(w)),W(s,i(w))) = cooc(W(s,j(w)),W(s,i(w))) + 1;
    end;
    for w = 1:L(s),
      cooc(W(s,w),W(s,w)) = cooc(W(s,w),W(s,w)) + 1;
    end;
  end;
    
  % Find the other model parameters
  % -------------------------------
  model = model1gaussMAP_train(B, W, M, L, numwords, varargin{:});
  
  % Return the model.
  model.cooc = cooc;