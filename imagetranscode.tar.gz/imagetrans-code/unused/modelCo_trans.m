function t = modelCo_trans (B, M, A, model)

  % Function constants.
  BPtol  = 1e-3;
  BPiter = 5;
  
  N        = length(M);
  maxM     = max(M);
  F        = size(model.mu,1);
  numwords = size(model.mu,2);  

  % First get the W x B x S translation probabilities from the MAP
  % model. Using this matrix "t", we build a new translation probability
  % matrix.
  tMAP = model1gaussMAP_trans(B,M,A,model);
  t    = zeros(size(tMAP));
  
  % Run generalized belief propagation for each image.
  for n = 1:N,

    x = bpmrf2(A{n}, model.cooc, tMAP(:,1:M(n),n)', model.sp, ...
	       BPtol, BPiter, 0); 
    t(:,1:M(n),n) = x';
  end;
  
  t = t;