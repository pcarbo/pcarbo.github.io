function l = get_posteriors (d, trials)
  
  path(genpath('.'), path);
  
  % Allocate memory for posteriors.
  N = length(trials);
  l = zeros(N,1);
  
  % Repeat for each trial.
  for i = 1:N,
    
    % Get the trial directory.
    trial_dir = sprintf('%s/trial%i', d, trials(i));
    fprintf('Getting posterior for trial %i.\n', trials(i));
    
    % Open the file.
    infile = openfile(trial_dir,'log','r');
    
    % Repeat for each line in the log file.
    s = [];
    while 1,
      t = s;
      s = fgetl(infile);
      if ~ischar(s) | ~length(s),
	strs = parse_string(t);
	s = strs{length(strs)};
	l(i) = str2num(s(1:length(s)-1));
	break;
      end;
    end;
    
    % Close the file.
    fclose(infile);
    
  end;

% ---------------------------------------------------------------------
function file = openfile (d, f, perm)

  filename = [d '/' f];
  file     = fopen(filename, perm);
  if file == -1,
    error(sprintf('Unable to open file %s for %s access', ...
		  filename, perm));
  end;
