#include "CoordBox.h"

// CLASS CoordBox methods
// ----------------------
CoordBox::CoordBox(const char* s1, const char* s2) {

	xy1 = Coord(s1);
	xy2 = Coord(s2);
	
	// Account for the fact that the second string is
	// simply a pair (width, height).
	xy2.x += xy1.x;
	xy2.y += xy1.y;

	if (xy1.good && xy2.good)
		good = true;
	else
		good = false;
};


bool CoordBox::ptInBox(Coord pt) {

	if (xy1.x <= pt.x && pt.x <= xy2.x &&
	    xy1.y <= pt.y && pt.y <= xy2.y)
		return true;
	else
		return false;
}
