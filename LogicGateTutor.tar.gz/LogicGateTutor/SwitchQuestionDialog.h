#include "fx.h"
#include "Session.h"

#define questionListWidth  80


// CLASS SwitchQuestionDialog
// --------------------------
// This is the dialog window where the user selects a new exercise.
class SwitchQuestionDialog : public FXDialogBox {
		FXDECLARE(SwitchQuestionDialog)

	public:
		// Constructor and destructor.
		SwitchQuestionDialog(FXApp* owner, QuestionIndex* qi, Session& ses);
		~SwitchQuestionDialog();

		long onCmdSelectListItem(FXObject* obj, FXSelector sel, void* ptr);

		// This static function takes care of everything.
		// It returns -1 if the user did not select a question. Otherwise, it
		// returns the index of the question selected.
		static int getUserInput(FXApp* owner, int curQIndex, QuestionIndex* qi, Session& ses);

		enum {
			ID_CANVAS=FXDialogBox::ID_LAST,
			ID_SELECTQ
		};

	protected:
	  FXVerticalFrame*   contents;
	  FXHorizontalFrame* buttons;
		FXList*            listOfQs;
		FXGIFIcon*         doc;
		FXText*            text1;

		SwitchQuestionDialog() { }
};