#include "fx.h"
#include "QuestionElements.h"
#include "QuestionState.h"


// CLASS Question
// --------------
// This stores all the information needed to run an exercise with the user.
class Question {

	public:
		Question(char* fileName, char* label, char* descrip, FXApp* owner);
		~Question();

		char* getFile()    { return file; }
		char* getLabel()   { return label; }
		char* getDescrip() { return descrip; }

		bool					 done();
		void           draw (FXDC& dc, FXint width, FXint height);
		bool           handleUserInput(Coord pt, int& inputNum, bool& inputGood);
		QuestionState* buildQuestionState();

		bool good;

	protected:

		FXApp*  app;
		char*   file;
		char*   label;
		char*   descrip;

		FXImage*  image;
		FXImage*  okImage;
		FXImage*  sq0Image;
		FXImage*  sq1Image;

		const unsigned char* picture;
		int      pictureWidth;
		int      pictureHeight;
		bool     offsetCalculated;
		int      pictureOffsetX;
		int      pictureOffsetY;

		LinkedList*  gates;
		LinkedList*  inputs;
		LinkedList*  wires;
		LinkedList*  userInputs;
};