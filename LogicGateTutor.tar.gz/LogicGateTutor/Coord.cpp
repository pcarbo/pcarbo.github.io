#include "Coord.h"
#include "Stoker.h"
#include <stdlib.h>

// CLASS Coord methods
// -------------------
Coord::Coord(const char* s) {
	int n;
	good = false;

	char** tokens = Stoker::tokenize(s, n, ',');
	
	if (n < 2) {
		delete [] tokens;
		return;
	}

	x = atoi(tokens[0]);
	y = atoi(tokens[1]);

	good = true;
	delete [] tokens;
}


