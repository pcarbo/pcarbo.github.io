#include "LogicTable.h"
#include "LogicCalculus.h"

#include <math.h>
#include <iostream>

using namespace std;


// CLASS LogicTable methods.
// ------------------------
LogicTable::LogicTable(int val) {

	dim  = 0;
	size = 1;
	vals = new int[1];
	vals[0] = val;
}


LogicTable::LogicTable() {

	dim  = 1;
	size = 2;
	vals = new int[2];
	vals[0] = 0;
	vals[1] = 1;
}


LogicTable::LogicTable(const LogicTable& t, int gateType) {

	dim  = t.dim;
	size = t.size;
	vals = new int[size];

	for (int i = 0; i < size; i++)
		vals[i] = LogicCalculus::unary(t.vals[i], gateType);
}


LogicTable::LogicTable(const LogicTable& t1, const LogicTable& t2, int gateType) {

	int i, j, k;

	dim  = t1.dim + t2.dim;
	size = t1.size * t2.size;
	vals = new int[size];

	k = 0;
	for (i = 0; i < t1.size; i++)
		for (j = 0; j < t2.size; j++) {
			vals[k] = LogicCalculus::binary(t1.vals[i], t2.vals[j], gateType);
			k++;
		}
}


bool LogicTable::areEqual(LogicTable t1, LogicTable t2) {

	// First check the dimensions.
	if (t1.size != t2.size)
		return false;

	for (int i = 0; i < t1.size; i++)
		if (t1.vals[i] != t2.vals[i])
			return false;

	return true;
}


void LogicTable::print() {

	for (int i = 0; i < size; i++)
		cout << vals[i] << endl;
	cout << endl;
}


LogicTable::~LogicTable() {
	//delete [] vals;
}