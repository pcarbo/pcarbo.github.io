#include "network2.h"

#define numKnowledgeStates  7
#define numAffectiveStates  2
#define totalNumUserStates  (numKnowledgeStates + numAffectiveStates)

#define andState            0
#define orState             1
#define xorState            2
#define notState            3
#define gatesState          4
#define genKnowledgeState   5
#define combiningAbilState  6
#define independenceState   7
#define moraleState         8

char* userStateNames[] = { "AND", 
													 "OR",
													 "XOR",
													 "NOT",
													 "Gates",
													 "GeneralKnowledge",
													 "CombiningAbility",
													 "Independence",
													 "Morale" };


// CLASS UserState
// ---------------
class UserState {

	public:
		UserState();

	protected:
		// The influence network.
		DSL_network bn;		
		
		// Knowledge and affective user state.
		int bnUserStates[totalNumUserStates];
};