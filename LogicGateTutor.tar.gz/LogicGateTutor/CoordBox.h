#include "Coord.h"

// CLASS CoordBox
// --------------
class CoordBox {
	public:
		CoordBox() { xy1 = Coord(); xy2 = Coord(); good = true; }
		CoordBox(double x1, double y1, double x2, double y2)
			{ xy1 = Coord(x1,y1); xy2 = Coord(x2,y2); good = true; }
		CoordBox(Coord pt1, Coord pt2) 
			{ xy1 = pt1; xy2 = pt2; good = true; }
		CoordBox(const char* s1, const char* s2);

		bool ptInBox(Coord pt);
		bool ptInBox(int x, int y) { return ptInBox(Coord(x,y)); }

		Coord xy1;
		Coord xy2;

		bool good;
};