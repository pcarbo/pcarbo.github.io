// Project includes.
#include "UserBeliefNet.h"
#include "ErrorBox.h"

// Standard includes.

using namespace std;

UserBeliefNet::UserBeliefNet(FXApp* owner) {

	good = false;

	app = owner;

	qs = NULL;

	// Before we do anything, let's initialize the 
	// probability tables.
	probTables = new ProbTables(probTablesFileName);
	if (!probTables->good)
		return;

	// Create the set of outcomes for the nodes.
	// It's either going to be "true" or "false".
	DSL_stringArray someNames;
	someNames.Add("True");
	someNames.Add("False");
	
	// Add the states.
	// Add "AND" node.
	andState = bn.AddNode(DSL_CPT, andStateName);
	bn.GetNode(andState)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "OR" node.
	orState = bn.AddNode(DSL_CPT, orStateName);
	bn.GetNode(orState)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "NOT" node.
	notState = bn.AddNode(DSL_CPT, notStateName);
	bn.GetNode(notState)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "XOR" node.
	xorState = bn.AddNode(DSL_CPT, xorStateName);
	bn.GetNode(xorState)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "Combining Ability" node.
	combAbilityState = bn.AddNode(DSL_CPT, combAbilityStateName);
	bn.GetNode(combAbilityState)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "Independence" node.
	independenceState = bn.AddNode(DSL_CPT, independenceStateName);
	bn.GetNode(independenceState)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "Morale" node.
	moraleState = bn.AddNode(DSL_CPT, moraleStateName);
	bn.GetNode(moraleState)->Definition()->SetNumberOfOutcomes(someNames);

	// Next we need to add the "temporary" states. They are temporary
	// in the sense that they're not crucial for keeping track of
	// the user's state. However, we need them at the start to assign
	// the priors to the initial user state.
	int gateTState;
	int gkTState;

	// Add the "Gates" node.
	gateTState = bn.AddNode(DSL_CPT, gateStateName);
	bn.GetNode(gateTState)->Definition()->SetNumberOfOutcomes(someNames);

	// Add the "General Knowledge" node.
	gkTState = bn.AddNode(DSL_CPT, gkStateName);
	bn.GetNode(gkTState)->Definition()->SetNumberOfOutcomes(someNames);

	// Now we need to add the arcs between the user states.
	// At this point, we don't need to add any arcs for the affective 
	// state. Note that the order of the arcs added is crucial for
	// compatibility with the probability tables.
						// Prior          // Posterior
	bn.AddArc(gkTState,         gateTState);
	bn.AddArc(gkTState,         combAbilityState);
	bn.AddArc(gateTState,       andState);
	bn.AddArc(gateTState,       orState);
	bn.AddArc(gateTState,       xorState);
	bn.AddArc(gateTState,       notState);

	// Next let's set the priors of the nodes we know about.
	// At this point, we only need the priors for "general knowledge",
	// "independence" and "morale".
	double          p;
	DSL_doubleArray theProbs;
	theProbs.SetSize(2);

	// Set prior for "general knowledge".
	p = probTables->at(gkPrior, priorCol);
	theProbs[0] = p;
	theProbs[1] = 1 - p;
	bn.GetNode(gkTState)->Definition()->SetDefinition(theProbs);

	// Set prior for "independence".
	p = probTables->at(independencePrior, priorCol);
	theProbs[0] = p;
	theProbs[1] = 1 - p;
	bn.GetNode(independenceState)->Definition()->SetDefinition(theProbs);

	// Set prior for "morale".
	p = probTables->at(moralePrior, priorCol);
	theProbs[0] = p;
	theProbs[1] = 1 - p;
	bn.GetNode(moraleState)->Definition()->SetDefinition(theProbs);

	// We still have to set up the conditional probability tables
	// for the belief network.
	DSL_sysCoordinates theCoords;

	// Set up the conditional probability tables for P(AND | Gates),
	// P(OR | Gates), P(XOR | Gates), P(NOT | Gates), P(Gates | G.K.) and
	// P(Combining Ability | G.K.).
	setConditionalTables(andState, andConditional, conditionalCol, 1);
	setConditionalTables(orState, orConditional, conditionalCol, 1);
	setConditionalTables(xorState, xorConditional, conditionalCol, 1);
	setConditionalTables(notState, notConditional, conditionalCol, 1);
	setConditionalTables(gateTState, gatesConditional, conditionalCol, 1);
	setConditionalTables(combAbilityState, combAbilityConditional, conditionalCol, 1);

	// Set the inference algorithm and update the beliefs.
	bn.SetDefaultBNAlgorithm(DSL_ALG_BN_LAURITZEN);
	bn.SetDefaultIDAlgorithm(DSL_ALG_ID_COOPERSOLVING);
	bn.UpdateBeliefs();

	// Now let's remove the non-essential states (i.e. the temporary
	// ones) but keep the posterior probabilities.
	bn.MarginalizeNode(gkTState,   gateTState);
	bn.MarginalizeNode(gkTState,   combAbilityState);
	bn.MarginalizeNode(gateTState, andState);
	bn.MarginalizeNode(gateTState, orState);
	bn.MarginalizeNode(gateTState, xorState);
	bn.MarginalizeNode(gateTState, notState);

	// Now that we've removed the arcs, let's remove the nodes.
	bn.DeleteNode(gkTState);
	bn.DeleteNode(gateTState);

	#ifdef DEBUG_USERSTATE
	// Print out the probabilities to make sure everything went okay.
	cout << "State 0:" << endl;
	printState(andState, andStateName);
	printState(orState, orStateName);
	printState(xorState, xorStateName);
	printState(notState, notStateName);
	printState(combAbilityState, combAbilityStateName);
	printState(independenceState, independenceStateName);
	printState(moraleState, moraleStateName);
	cout << endl;
	#endif

	// Initialize the two arrays used for decision making.
	for (int i = 0; i < numAgentActions; i++) {
		cbArray[i] = ' ';
		policyValues[i] = 0.5;
	}

	// If we get to here then everything is okay, so we set
	// the "good" flag to "true".
	t = 0;
	good = true;
}


void UserBeliefNet::draw (FXDC& dc, FXint width, FXint height) {

	// Set up the colours.
	int knowlColor       = 255;  // Shade of blue.
	int affectColor      = 255;  // Shade of green.
	int agentActionColor = 255;  // Shade of red.
	int y                = drawOuterMargin;

	// Draw the knowledge states.
	drawProbRectangle(dc, FXRGB(0,0,knowlColor), getProbOfBinaryNode(andState), y);
	drawProbRectangle(dc, FXRGB(0,0,knowlColor-12), getProbOfBinaryNode(orState), y);
	drawProbRectangle(dc, FXRGB(0,0,knowlColor-24), getProbOfBinaryNode(xorState), y);
	drawProbRectangle(dc, FXRGB(0,0,knowlColor-36), getProbOfBinaryNode(notState), y);
	drawProbRectangle(dc, FXRGB(0,0,knowlColor-122), getProbOfBinaryNode(combAbilityState), y);

	y += drawInnerMargin;

	// Draw the affective states.
	drawProbRectangle(dc, FXRGB(0,affectColor,0), getProbOfBinaryNode(independenceState), y);
	drawProbRectangle(dc, FXRGB(0,affectColor-122,0), getProbOfBinaryNode(moraleState), y);
	
	y += drawInnerMargin;

	for (int i = 0; i < numAgentActions; i++)
		if (cbArray[i] == '*')
			drawProbRectangle(dc, FXRGB(122,122,122), policyValues[i], y);
		else
			drawProbRectangle(dc, FXRGB(agentActionColor-i*16,0,0), policyValues[i], y);
}


void UserBeliefNet::drawProbRectangle (FXDC& dc, FXColor c, double p, int& y) {

	dc.setForeground(FXRGB(0,0,0));
	dc.drawRectangle(drawOuterMargin, y, probBarWidth, probBarHeight);
	dc.setForeground(c);
	dc.fillRectangle(drawOuterMargin+1, y+1, (probBarWidth-2)*p, probBarHeight-1);

	y += (probBarHeight + drawInnerMargin);
}


void UserBeliefNet::printState (int node, const char* s) {
	cout << "P(" << s << ") = " << getProbOfBinaryNode(node) << endl;
}


// This is where we do LOTS of stuff: we create the state nodes
// at time t+1, update the probabilities and then marginalize the 
// nodes. In other words: 1. Predict, 2. Roll up, 3. Estimate.
void UserBeliefNet::updateState(int inputNum, bool inputGood) {

	// The states at time t+1.
	int andStateF;
	int orStateF;
	int notStateF;
	int xorStateF;
	int combAbilityStateF;
	int independenceStateF;
	int moraleStateF;

	DSL_doubleArray theProbs;
	theProbs.SetSize(2);

	double p;

	// Create the set of outcomes for the nodes.
	// It's either going to be "true" or "false".
	DSL_stringArray someNames;
	someNames.Add("True");
	someNames.Add("False");


	// CREATE STATE T+1 NODES
	// ----------------------
	// First let's set up the nodes for the future state. 
	
	// Add the states.
	// Add "AND" node for time t+1.
	andStateF = bn.AddNode(DSL_CPT, andStateNameF);
	bn.GetNode(andStateF)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "OR" node for time t+1.
	orStateF = bn.AddNode(DSL_CPT, orStateNameF);
	bn.GetNode(orStateF)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "NOT" node for time t+1.
	notStateF = bn.AddNode(DSL_CPT, notStateNameF);
	bn.GetNode(notStateF)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "XOR" node for time t+1.
	xorStateF = bn.AddNode(DSL_CPT, xorStateNameF);
	bn.GetNode(xorStateF)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "Combining Ability" node for time t+1.
	combAbilityStateF = bn.AddNode(DSL_CPT, combAbilityStateNameF);
	bn.GetNode(combAbilityStateF)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "Independence" node for time t+1.
	independenceStateF = bn.AddNode(DSL_CPT, independenceStateNameF);
	bn.GetNode(independenceStateF)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "Morale" node for time t+1.
	moraleStateF = bn.AddNode(DSL_CPT, moraleStateNameF);
	bn.GetNode(moraleStateF)->Definition()->SetNumberOfOutcomes(someNames);


	// CREATE INPUT PERCEPTS
	// ---------------------
	// Construct the nodes "Success on input", "Failed on previous input"
	// and "Gave hint for input".
	int  successOnInput;
	int  failedOnPrevInput;
	int  gaveHintForInput;
	int  gaveAHintForInput;

	// "Success on input" node.
	successOnInput = bn.AddNode(DSL_CPT, successOnInputName);
	bn.GetNode(successOnInput)->Definition()->SetNumberOfOutcomes(someNames);

	// Set up the priors for the "success on input" node.
	p = inputGood ? 1.0 : 0.0;
	theProbs[0] = p;
	theProbs[1] = 1 - p;
	bn.GetNode(successOnInput)->Definition()->SetDefinition(theProbs);

	// "Failed on previous input" node.
	failedOnPrevInput = bn.AddNode(DSL_CPT, failedOnPrevInputName);
	bn.GetNode(failedOnPrevInput)->Definition()->SetNumberOfOutcomes(someNames);

	// Set up the priors on "failed on previous input" node.
	p = qs->getFailedOnInput(inputNum) ? 1.0 : 0.0;
	theProbs[0] = p;
	theProbs[1] = 1 - p;
	bn.GetNode(failedOnPrevInput)->Definition()->SetDefinition(theProbs);

	// "Gave hint for input" node.
	gaveHintForInput = bn.AddNode(DSL_CPT, gaveHintOnInputName);
	bn.GetNode(gaveHintForInput)->Definition()->SetNumberOfOutcomes(someNames);

	// Set up the priors for the "gave hint for input" node.
	p = qs->getHintForInput(inputNum) ? 1.0 : 0.0;
	theProbs[0] = p;
	theProbs[1] = 1 - p;
	bn.GetNode(gaveHintForInput)->Definition()->SetDefinition(theProbs);
	
	// CREATE GATE PERCEPTS
	// --------------------
	// Construct the nodes "Success on gate" and "Gave hint for gate".
	int   numGates;
	int   numUniqueGates;
	int*  inputGates;
	int   i;
	char  buf[1024];
	char  nodeName[1024];

	// Get the gates. We'll assume it only grabs the ones that the
	// user has not succeed on. Also, each gate should be of a different
	// type -- otherwise it doesn't make sense for our belief net.
	inputGates = qs->getGatesForInput(inputNum, numGates);
	delete inputGates;
	inputGates = qs->getUniqueGatesForInput(inputNum, numUniqueGates);

	// Allocate and create the arrays of nodes for the gates.
	int* successOnGates    = new int[numUniqueGates];
	int* gaveHintForGates  = new int[numUniqueGates];

	// Create the belief nodes. Also, at this point let's add priors.
	for (i = 0; i < numUniqueGates; i++) {
		
		// Add the nodes (there should be two nodes for
		// each gate).

		// Figure out what the name should be for our node
		// and add the "Success on gate" node.
		strcpy(buf, successOnGateName);
		strcat(buf, " %d");
		sprintf(nodeName, buf, inputGates[i]);

		// Create the node.
		successOnGates[i] = bn.AddNode(DSL_CPT, nodeName);
		bn.GetNode(successOnGates[i])->Definition()->SetNumberOfOutcomes(someNames);

		// Add the priors.
		p = inputGood ? 1.0 : 0.0;
		theProbs[0] = p;
		theProbs[1] = 1 - p;
		bn.GetNode(successOnGates[i])->Definition()->SetDefinition(theProbs);


		// Figure out what the name should be for our node
		// and add the "Gave hint for gate" node.
		strcpy(buf, gaveHintOnGateName);
		strcat(buf, " %d");
		sprintf(nodeName, buf, inputGates[i]);

		// Create the node.
		gaveHintForGates[i] = bn.AddNode(DSL_CPT, nodeName);
		bn.GetNode(gaveHintForGates[i])->Definition()->SetNumberOfOutcomes(someNames);
		
		// Add the priors.
		p = qs->getHintForGate(inputGates[i]) ? 1.0 : 0.0;
		theProbs[0] = p;
		theProbs[1] = 1 - p;
		bn.GetNode(gaveHintForGates[i])->Definition()->SetDefinition(theProbs);
	}

	// "Gave hint for input" node.
	gaveAHintForInput = bn.AddNode(DSL_CPT, gaveAHintOnInputName);
	bn.GetNode(gaveAHintForInput)->Definition()->SetNumberOfOutcomes(someNames);

	// Set up the priors for the "gave hint for input" node.
	p = 0.0;
	if (qs->getHintForInput(inputNum))
		p = 1.0;
	for (i = 0; i < numUniqueGates; i++)
		if (qs->getHintForGate(inputGates[i]))
			p = 1.0;
	theProbs[0] = p;
	theProbs[1] = 1 - p;
	bn.GetNode(gaveAHintForInput)->Definition()->SetDefinition(theProbs);

	// SET THE CONDITIONAL PROBABILITIES FOR THE AFFECTIVE STATES & C.A.
	// ----------------------------------------------------------------

	// Set up the arcs and the conditional probability table for
	// the "independence" state at time t+1.
	bn.AddArc(gaveAHintForInput, independenceStateF);
	bn.AddArc(independenceState, independenceStateF);
	bn.AddArc(failedOnPrevInput, independenceStateF);
	bn.AddArc(successOnInput,    independenceStateF);
	
	// P(Independence' | Independence, Failed on Previous Input, Success on Input)
	setConditionalTables(independenceStateF, independenceConditional, conditionalCol, 4);

	// Set up the arcs and the conditional probability table for
	// the "morale" state at time t+1.
	bn.AddArc(moraleState,       moraleStateF);
	bn.AddArc(failedOnPrevInput, moraleStateF);
	bn.AddArc(successOnInput,    moraleStateF);

	// P(Morale' | Morale, Failed on Previous Input, Success on Input)
	setConditionalTables(moraleStateF, moraleConditional, conditionalCol, 3);

	// Set up the arcs and the conditional probability table for the
	// "combining ability" state at time t+1.
	if (numGates > 1) {
		bn.AddArc(successOnInput, combAbilityStateF);
		bn.AddArc(gaveHintForInput, combAbilityStateF);
		bn.AddArc(combAbilityState, combAbilityStateF);

		// P(Combining Ability' | Success on Input, Gave hint for input 1, Combining Ability) 
		setConditionalTables(combAbilityStateF, combAbilityFromPrevCond, conditionalCol, 3);
	}
	else {
		bn.AddArc(combAbilityState, combAbilityStateF);

		// P(Combining Ability' | Combining Ability)
		setDirectConditionalTables(combAbilityStateF);
	}


	// SET THE CONDITIONAL PROBABILITIES FOR THE REST OF THE NODES
	// -----------------------------------------------------------
	// Let's add arcs between the states at time t and the states
	// at time t+1.

	// Find which gates we're dealing with.
	int*  theGateTypes = new int[5];
	for (i = 1; i < 5; i++)
		theGateTypes[i] = -1;
	for (i = 0; i < numUniqueGates; i++)
		theGateTypes[qs->getGateType(inputGates[i])] = i;

	// Set up the arcs and the conditional probability table
	// for the AND state.
	if (theGateTypes[gateTypeAND] == -1) {
		bn.AddArc(andState, andStateF);

		// P(AND' | AND)
		setDirectConditionalTables(andStateF);
	}
	else {
		bn.AddArc(successOnGates[theGateTypes[gateTypeAND]],   andStateF);
		bn.AddArc(gaveHintForGates[theGateTypes[gateTypeAND]], andStateF);
		bn.AddArc(andState,                                    andStateF);

		// P(AND' | Success on Gate, Gave Hint on Gate, AND);
		setConditionalTables(andStateF, gateConditional, conditionalCol, 3);
	}

	// Set up the arcs and the conditional probability table
	// for the OR state.
	if (theGateTypes[gateTypeOR] == -1) {
		bn.AddArc(orState, orStateF);

		// P(OR' | OR)
		setDirectConditionalTables(orStateF);
	}
	else {
		bn.AddArc(successOnGates[theGateTypes[gateTypeOR]],   orStateF);
		bn.AddArc(gaveHintForGates[theGateTypes[gateTypeOR]], orStateF);
		bn.AddArc(orState,                                    orStateF);

		// P(OR' | Success on Gate, Gave Hint on Gate, OR);
		setConditionalTables(orStateF, gateConditional, conditionalCol, 3);
	}

	// Set up the arcs and the conditional probability table
	// for the XOR state.
	if (theGateTypes[gateTypeXOR] == -1) {
		bn.AddArc(xorState, xorStateF);

		// P(XOR' | XOR)
		setDirectConditionalTables(xorStateF);
	}
	else {
		bn.AddArc(successOnGates[theGateTypes[gateTypeXOR]],   xorStateF);
		bn.AddArc(gaveHintForGates[theGateTypes[gateTypeXOR]], xorStateF);
		bn.AddArc(xorState,                                    xorStateF);

		// P(XOR' | Success on Gate, Gave Hint on Gate, XOR);
		setConditionalTables(xorStateF, gateConditional, conditionalCol, 3);
	}

	// Set up the arcs and the conditional probability table
	// for the NOT state.
	if (theGateTypes[gateTypeNOT] == -1) {
		bn.AddArc(notState, notStateF);

		// P(NOT' | NOT)
		setDirectConditionalTables(notStateF);
	}
	else {
		bn.AddArc(successOnGates[theGateTypes[gateTypeNOT]],   notStateF);
		bn.AddArc(gaveHintForGates[theGateTypes[gateTypeNOT]], notStateF);
		bn.AddArc(notState,                                    notStateF);

		// P(NOT' | Success on Gate, Gave Hint on Gate, NOT);
		setConditionalTables(notStateF, gateConditional, conditionalCol, 3);
	}


	// UPDATE NETWORK
	// --------------
	// We've set up all the nodes, arcs and conditional probability tables.
	// We're ready for action.
	bn.UpdateBeliefs();


	// ROLL UP
	// -------
	// This is where we remove the nodes from time t and all the 
	// percepts, too. Essentially, we're marginalizing the probability 
	// distributions.
	bn.MarginalizeNode(independenceState, independenceStateF);
	bn.MarginalizeNode(failedOnPrevInput, independenceStateF);
	bn.MarginalizeNode(successOnInput,    independenceStateF);
	bn.MarginalizeNode(moraleState,       moraleStateF);
	bn.MarginalizeNode(failedOnPrevInput, moraleStateF);
	bn.MarginalizeNode(successOnInput,    moraleStateF);

	if (numGates > 1) {
		bn.MarginalizeNode(successOnInput,    combAbilityStateF);
		bn.MarginalizeNode(gaveHintForInput,  combAbilityStateF);
		bn.MarginalizeNode(combAbilityState,  combAbilityStateF);
	}
	else
		bn.MarginalizeNode(combAbilityState,  combAbilityStateF);
	
	if (theGateTypes[gateTypeAND] == -1)
		bn.MarginalizeNode(andState, andStateF);
	else {
		bn.MarginalizeNode(successOnGates[theGateTypes[gateTypeAND]],   andStateF);
		bn.MarginalizeNode(gaveHintForGates[theGateTypes[gateTypeAND]], andStateF);
		bn.MarginalizeNode(andState,                                    andStateF);
	}

	if (theGateTypes[gateTypeOR] == -1)
		bn.MarginalizeNode(orState, orStateF);
	else {
		bn.MarginalizeNode(successOnGates[theGateTypes[gateTypeOR]],   orStateF);
		bn.MarginalizeNode(gaveHintForGates[theGateTypes[gateTypeOR]], orStateF);
		bn.MarginalizeNode(orState,                                    orStateF);
	}

	if (theGateTypes[gateTypeXOR] == -1)
		bn.MarginalizeNode(xorState, xorStateF);
	else {
		bn.MarginalizeNode(successOnGates[theGateTypes[gateTypeXOR]],   xorStateF);
		bn.MarginalizeNode(gaveHintForGates[theGateTypes[gateTypeXOR]], xorStateF);
		bn.MarginalizeNode(xorState,                                    xorStateF);
	}

	if (theGateTypes[gateTypeNOT] == -1)
		bn.MarginalizeNode(notState, notStateF);
	else {
		bn.MarginalizeNode(successOnGates[theGateTypes[gateTypeNOT]],   notStateF);
		bn.MarginalizeNode(gaveHintForGates[theGateTypes[gateTypeNOT]], notStateF);
		bn.MarginalizeNode(notState,                                    notStateF);
	}	


	// Now that we've marginalized the nodes, we still have to do two more
	// things: 
	// 1. Change the names of the nodes.
	// 2. Assign nodes at time t <-- nodes at time t+1.
	// 3. Update the time.
	
	// Change the names of the nodes.
	bn.GetNode(andStateF)->Info().Header().SetId(andStateName);
	bn.GetNode(orStateF)->Info().Header().SetId(orStateName);
	bn.GetNode(xorStateF)->Info().Header().SetId(xorStateName);
	bn.GetNode(notStateF)->Info().Header().SetId(notStateName);

	bn.GetNode(combAbilityStateF)->Info().Header().SetId(combAbilityStateName);
	bn.GetNode(independenceStateF)->Info().Header().SetId(independenceStateName);
	bn.GetNode(moraleStateF)->Info().Header().SetId(moraleStateName);

	// Assign the nodes at time t <-- nodes at time t+1.
	andState = andStateF;
	orState  = orStateF;
	xorState = xorStateF;
	notState = notStateF;

	combAbilityState  = combAbilityStateF;
	independenceState = independenceStateF;
	moraleState       = moraleStateF;

	// Update the time.
	t++;


	// UPDATE THE STATE OF THE QUESTION.
	// --------------------------------
	if (inputGood)
		qs->setInput(inputNum);
	else
		qs->setFailedOnInput(inputNum);


	// DEBUGGING STUFF.
	// ---------------
	#ifdef DEBUG_USERSTATE
	cout << "State " << t << ":" << endl;
	printState(andState, andStateName);
	printState(orState, orStateName);
	printState(xorState, xorStateName);
	printState(notState, notStateName);
	printState(combAbilityState, combAbilityStateName);
	printState(independenceState, independenceStateName);
	printState(moraleState, moraleStateName);
	cout << endl;
	#endif


	// Clean up.
	delete [] inputGates;
	delete [] successOnGates;
	delete [] gaveHintForGates;
}


// Note that we make changes to the current belief network, but
// these changes will all be reversed at the end so there's nothing
// to worry about.
void UserBeliefNet::doBestAction (int inputNum) {

	// The states at time t+1.
	int andStateF;
	int orStateF;
	int notStateF;
	int xorStateF;
	int combAbilityStateF;


	// CREATE AGENT ACTION NODE.
	// ------------------------
	// Create the node.
	int agentActionNode = bn.AddNode(DSL_LIST, agentActionName);

	// Set all the possible choices for the node.
	DSL_stringArray someNames2;
	someNames2.Add("No hint");
	someNames2.Add("Give hint about AND");
	someNames2.Add("Give hint about OR");
	someNames2.Add("Give hint about XOR");
	someNames2.Add("Give hint about NOT");
	someNames2.Add("Give hint on combining");
	bn.GetNode(agentActionNode)->Definition()->SetNumberOfOutcomes(someNames2);


	// CREATE STATE t+1 NODES
	// ----------------------
	// Let's set up the nodes for the future state. In this case,
	// we only need the nodes for AND, OR, XOR, NOT and Combining Ability
	// because the others do not change, no matter what the agent action
	// may be.

	DSL_doubleArray theProbs;
	theProbs.SetSize(2);

	double p;

	// Create the set of outcomes for the nodes.
	// It's either going to be "true" or "false".
	DSL_stringArray someNames;
	someNames.Add("True");
	someNames.Add("False");

	// Add the states.
	// Add "AND" node for time t+1.
	andStateF = bn.AddNode(DSL_CPT, andStateNameF);
	bn.GetNode(andStateF)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "OR" node for time t+1.
	orStateF = bn.AddNode(DSL_CPT, orStateNameF);
	bn.GetNode(orStateF)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "NOT" node for time t+1.
	notStateF = bn.AddNode(DSL_CPT, notStateNameF);
	bn.GetNode(notStateF)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "XOR" node for time t+1.
	xorStateF = bn.AddNode(DSL_CPT, xorStateNameF);
	bn.GetNode(xorStateF)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "Combining Ability" node for time t+1.
	combAbilityStateF = bn.AddNode(DSL_CPT, combAbilityStateNameF);
	bn.GetNode(combAbilityStateF)->Definition()->SetNumberOfOutcomes(someNames);


	// SET CONDITIONAL PROBABILITIES BETWEEN AGENT ACTION & NODES AT STATE t+1
	// -----------------------------------------------------------------------

	// P(AND' | AND, Agent Action)
	bn.AddArc(andState,        andStateF);
	bn.AddArc(agentActionNode, andStateF);
	setAgentActionCondTables(andStateF, andAgentActionConditional, conditionalCol, 2);

	// P(OR' | OR, Agent Action)
	bn.AddArc(orState,         orStateF);
	bn.AddArc(agentActionNode, orStateF);
	setAgentActionCondTables(orStateF, orAgentActionConditional, conditionalCol, 2);

	// P(XOR' | XOR, Agent Action)
	bn.AddArc(xorState,        xorStateF);
	bn.AddArc(agentActionNode, xorStateF);
	setAgentActionCondTables(xorStateF, xorAgentActionConditional, conditionalCol, 2);

	// P(NOT' | NOT, Agent Action)
	bn.AddArc(notState,        notStateF);
	bn.AddArc(agentActionNode, notStateF);
	setAgentActionCondTables(notStateF, notAgentActionConditional, conditionalCol, 2);

	// P(Combining Ability' | Combining Ability, Agent Action)
	bn.AddArc(combAbilityState, combAbilityStateF);
	bn.AddArc(agentActionNode,  combAbilityStateF);
	setAgentActionCondTables(combAbilityStateF, combAbilityAgentActionCond, conditionalCol, 2);


	// CREATE STATE t+2 NODES
	// ----------------------
	int andStateF2;
	int orStateF2;
	int notStateF2;
	int xorStateF2;
	int combAbilityStateF2;
	int independenceStateF2;
	int moraleStateF2;

	// Add the states.
	// Add "AND" node for time t+2.
	andStateF2 = bn.AddNode(DSL_CPT, andStateNameF2);
	bn.GetNode(andStateF2)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "OR" node for time t+2.
	orStateF2 = bn.AddNode(DSL_CPT, orStateNameF2);
	bn.GetNode(orStateF2)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "NOT" node for time t+2.
	notStateF2 = bn.AddNode(DSL_CPT, notStateNameF2);
	bn.GetNode(notStateF2)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "XOR" node for time t+2.
	xorStateF2 = bn.AddNode(DSL_CPT, xorStateNameF2);
	bn.GetNode(xorStateF2)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "Combining Ability" node for time t+2.
	combAbilityStateF2 = bn.AddNode(DSL_CPT, combAbilityStateNameF2);
	bn.GetNode(combAbilityStateF2)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "Independence" node for time t+2.
	independenceStateF2 = bn.AddNode(DSL_CPT, independenceStateNameF2);
	bn.GetNode(independenceStateF2)->Definition()->SetNumberOfOutcomes(someNames);

	// Add "Morale" node for time t+2.
	moraleStateF2 = bn.AddNode(DSL_CPT, moraleStateNameF2);
	bn.GetNode(moraleStateF2)->Definition()->SetNumberOfOutcomes(someNames);


	// CREATE INPUT PERCEPTS AT STATE t+2
	// ----------------------------------
	// Construct the nodes "Success on input", "Failed on previous input"
	// and "Gave hint for input" for state t+2.
	int  successOnInput;
	int  failedOnPrevInput;
	int  gaveHintForInput;
	int  gaveAHintForInput;
	int  successOnInputS;

	// "Success on input" node.
	successOnInput = bn.AddNode(DSL_CPT, successOnInputName);
	bn.GetNode(successOnInput)->Definition()->SetNumberOfOutcomes(someNames);

	// "Success on input" support node.
	successOnInputS = bn.AddNode(DSL_CPT, successOnInputSName);
	bn.GetNode(successOnInputS)->Definition()->SetNumberOfOutcomes(someNames);

	// "Failed on previous input" node.
	failedOnPrevInput = bn.AddNode(DSL_CPT, failedOnPrevInputName);
	bn.GetNode(failedOnPrevInput)->Definition()->SetNumberOfOutcomes(someNames);

	// Set up the priors on "failed on previous input" node.
	// It is assumed that the user failed on the previous input, otherwise
	// we wouldn't be giving advice!
	theProbs[0] = 1.0;
	theProbs[1] = 0.0;
	bn.GetNode(failedOnPrevInput)->Definition()->SetDefinition(theProbs);

	// "Gave hint for input" node.
	gaveHintForInput = bn.AddNode(DSL_CPT, gaveHintOnInputName);
	bn.GetNode(gaveHintForInput)->Definition()->SetNumberOfOutcomes(someNames);

	// Gave some kind of hint for input" node
	gaveAHintForInput = bn.AddNode(DSL_CPT, gaveAHintOnInputName);
	bn.GetNode(gaveAHintForInput)->Definition()->SetNumberOfOutcomes(someNames);


	// CREATE CONDITIONAL PROBABILITIES BETWEEN AGENT ACTION AND PERCEPTS AT STATE t+2
	// -------------------------------------------------------------------------------
	
	// P(Success on Input | independence, C.A.(t+1), AND(t+1), OR(t+1), XOR(t+1), NOT(t+1))
	bn.AddArc(combAbilityStateF, successOnInputS);
	bn.AddArc(andStateF,         successOnInputS);
	bn.AddArc(orStateF,          successOnInputS);
	bn.AddArc(xorStateF,         successOnInputS);
	bn.AddArc(notStateF,         successOnInputS);
	setUserActionCondTables(successOnInputS, userActionConditional, conditionalCol, inputNum);
	
	bn.AddArc(successOnInputS,   successOnInput);
	bn.AddArc(independenceState, successOnInput);
	setConditionalTables(successOnInput, indKnowlConditional, conditionalCol, 2);

	// P(Gave Hint on Input | Agent Action)
	if (qs->getHintForInput(inputNum)) {
		theProbs[0] = 1.0;
		theProbs[1] = 0.0;
		bn.GetNode(gaveHintForInput)->Definition()->SetDefinition(theProbs);
	}
	else {
		bn.AddArc(agentActionNode, gaveHintForInput);
		setAgentActionCondTables(gaveHintForInput, gaveHintOnInputConditional, conditionalCol, 1);
	}


	// CREATE GATE PERCEPTS AT STATE t+2
	// ---------------------------------
	// Construct the nodes "Success on gate" and "Gave hint for gate".
	// 
	// -> Also here we set the conditional probabilities from the 
	//    "agent action" node and the "Success on input" node to
	//    these nodes.
	int   numGates;
	int   numUniqueGates;
	int*  inputGates;
	int   i;
	char  buf[1024];
	char  nodeName[1024];

	// Get the gates. We'll assume it only grabs the ones that the
	// user has not succeed on. Also, each gate should be of a different
	// type -- otherwise it doesn't make sense for our belief net.
	inputGates = qs->getGatesForInput(inputNum, numGates);
	delete inputGates;
	inputGates = qs->getUniqueGatesForInput(inputNum, numUniqueGates);

	// Allocate and create the arrays of nodes for the gates.
	int* successOnGates    = new int[numUniqueGates];
	int* gaveHintForGates  = new int[numUniqueGates];

	// Create the belief nodes. Also, at this point let's add priors.
	for (i = 0; i < numUniqueGates; i++) {
		
		// Add the nodes (there should be two nodes for
		// each gate).

		// Figure out what the name should be for our node
		// and add the "Success on gate" node.
		strcpy(buf, successOnGateName);
		strcat(buf, " %d");
		sprintf(nodeName, buf, inputGates[i]);

		// Create the node.
		successOnGates[i] = bn.AddNode(DSL_CPT, nodeName);
		bn.GetNode(successOnGates[i])->Definition()->SetNumberOfOutcomes(someNames);

		// P(Success on Gate | Success on Input)
		bn.AddArc(successOnInput, successOnGates[i]);
		setDirectConditionalTables(successOnGates[i]);

		// Figure out what the name should be for our node
		// and add the "Gave hint for gate" node.
		strcpy(buf, gaveHintOnGateName);
		strcat(buf, " %d");
		sprintf(nodeName, buf, inputGates[i]);

		// Create the node.
		gaveHintForGates[i] = bn.AddNode(DSL_CPT, nodeName);
		bn.GetNode(gaveHintForGates[i])->Definition()->SetNumberOfOutcomes(someNames);

		// P(Gave Hint on Input | Agent Action)
		if (qs->getHintForGate(inputGates[i])) {
			theProbs[0] = 1.0;
			theProbs[1] = 0.0;
			bn.GetNode(gaveHintForGates[i])->Definition()->SetDefinition(theProbs);
		}
		else {
			bn.AddArc(agentActionNode, gaveHintForInput);

			int row;
			switch (qs->getGateType(inputGates[i])) {
				case gateTypeAND: row = gaveHintOnAndConditional; break;
				case gateTypeOR:  row = gaveHintOnOrConditional;  break;
				case gateTypeXOR: row = gaveHintOnXorConditional; break;
				case gateTypeNOT: row = gaveHintOnNotConditional;
			}
			setAgentActionCondTables(gaveHintForGates[i], row, conditionalCol, 1);
		}
	}

	bn.AddArc(gaveHintForInput, gaveAHintForInput);
	for (i = 0; i < numUniqueGates; i++)
		bn.AddArc(gaveHintForGates[i], gaveAHintForInput);

	DSL_sysCoordinates c3(*bn.GetNode(gaveAHintForInput)->Definition());
	for (i = 0; i < 2*powerOf2(numUniqueGates)-1; i++) {
		c3.UncheckedValue() = 1.0;
		c3.Next();
		c3.UncheckedValue() = 0.0;
		c3.Next();
	}
	c3.UncheckedValue() = 0.0;
	c3.Next();
	c3.UncheckedValue() = 1.0;


	// SET UP THE CONDITIONAL PROBABILITIES FOR THE STATE t+2 NODES
	// ------------------------------------------------------------

	// Set up the arcs and the conditional probability table for
	// the "independence" state at time t+2.
	bn.AddArc(gaveAHintForInput,  independenceStateF2);
	bn.AddArc(independenceState, independenceStateF2);
	bn.AddArc(failedOnPrevInput, independenceStateF2);
	bn.AddArc(successOnInput,    independenceStateF2);
	
	// P(Independence (t+2) | Independence, Failed on Previous Input, Success on Input)
	setConditionalTables(independenceStateF2, independenceConditional, conditionalCol, 4);

	// Set up the arcs and the conditional probability table for
	// the "morale" state at time t+2.
	bn.AddArc(moraleState,       moraleStateF2);
	bn.AddArc(failedOnPrevInput, moraleStateF2);
	bn.AddArc(successOnInput,    moraleStateF2);

	// P(Morale(t+2) | Morale, Failed on Previous Input, Success on Input)
	setConditionalTables(moraleStateF2, moraleConditional, conditionalCol, 3);

	// Set up the arcs and the conditional probability table for the
	// "combining ability" state at time t+2.
	if (numGates > 1) {
		bn.AddArc(successOnInput, combAbilityStateF2);
		bn.AddArc(gaveHintForInput, combAbilityStateF2);
		bn.AddArc(combAbilityState, combAbilityStateF2);

		// P(Combining Ability(t+2) | Success on Input, Gave hint for input 1, Combining Ability) 
		setConditionalTables(combAbilityStateF2, combAbilityFromPrevCond, conditionalCol, 3);
	}
	else {
		bn.AddArc(combAbilityState, combAbilityStateF2);

		// P(Combining Ability(t+2 | Combining Ability)
		setDirectConditionalTables(combAbilityStateF2);
	}


	// SET THE CONDITIONAL PROBABILITIES FOR THE REST OF THE NODES
	// -----------------------------------------------------------
	// Let's add arcs between the states at time t and the states
	// at time t+2.

	// Find which gates we're dealing with.
	int*  theGateTypes = new int[5];
	for (i = 1; i < 5; i++)
		theGateTypes[i] = -1;
	for (i = 0; i < numUniqueGates; i++)
		theGateTypes[qs->getGateType(inputGates[i])] = i;

	// Set up the arcs and the conditional probability table
	// for the AND state at time t+2.
	if (theGateTypes[gateTypeAND] == -1) {
		bn.AddArc(andState, andStateF2);

		// P(AND(t+2) | AND)
		setDirectConditionalTables(andStateF2);
	}
	else {
		bn.AddArc(successOnGates[theGateTypes[gateTypeAND]],   andStateF2);
		bn.AddArc(gaveHintForGates[theGateTypes[gateTypeAND]], andStateF2);
		bn.AddArc(andState,                                    andStateF2);

		// P(AND(t+2) | Success on Gate, Gave Hint on Gate, AND);
		setConditionalTables(andStateF2, gateConditional, conditionalCol, 3);
	}

	// Set up the arcs and the conditional probability table
	// for the OR state at time t+2.
	if (theGateTypes[gateTypeOR] == -1) {
		bn.AddArc(orState, orStateF2);

		// P(OR(t+2) | OR)
		setDirectConditionalTables(orStateF2);
	}
	else {
		bn.AddArc(successOnGates[theGateTypes[gateTypeOR]],   orStateF2);
		bn.AddArc(gaveHintForGates[theGateTypes[gateTypeOR]], orStateF2);
		bn.AddArc(orState,                                    orStateF2);

		// P(OR(t+2) | Success on Gate, Gave Hint on Gate, OR);
		setConditionalTables(orStateF2, gateConditional, conditionalCol, 3);
	}

	// Set up the arcs and the conditional probability table
	// for the XOR state at time t+2.
	if (theGateTypes[gateTypeXOR] == -1) {
		bn.AddArc(xorState, xorStateF2);

		// P(XOR(t+2) | XOR)
		setDirectConditionalTables(xorStateF2);
	}
	else {
		bn.AddArc(successOnGates[theGateTypes[gateTypeXOR]],   xorStateF2);
		bn.AddArc(gaveHintForGates[theGateTypes[gateTypeXOR]], xorStateF2);
		bn.AddArc(xorState,                                    xorStateF2);

		// P(XOR(t+2) | Success on Gate, Gave Hint on Gate, XOR);
		setConditionalTables(xorStateF2, gateConditional, conditionalCol, 3);
	}

	// Set up the arcs and the conditional probability table
	// for the NOT state at time t+2.
	if (theGateTypes[gateTypeNOT] == -1) {
		bn.AddArc(notState, notStateF2);

		// P(NOT(t+2) | NOT)
		setDirectConditionalTables(notStateF2);
	}
	else {
		bn.AddArc(successOnGates[theGateTypes[gateTypeNOT]],   notStateF2);
		bn.AddArc(gaveHintForGates[theGateTypes[gateTypeNOT]], notStateF2);
		bn.AddArc(notState,                                    notStateF2);

		// P(NOT(t+2) | Success on Gate, Gave Hint on Gate, NOT);
		setConditionalTables(notStateF2, gateConditional, conditionalCol, 3);
	}


	// CREATE THE UTILITY NODE (and supporing node).
	// --------------------------------------------
	int uSupportNode = bn.AddNode(DSL_CPT, "Utility Support Node");
	int utilityNode  = bn.AddNode(DSL_TABLE, utilityNodeName);

	// Let's add the arcs from the knowledge and affective nodes to the 
	// final utility node.
	//        Prior                Posterior
	bn.AddArc(andStateF2,          uSupportNode);
	bn.AddArc(orStateF2,           uSupportNode);
	bn.AddArc(xorStateF2,          uSupportNode);
	bn.AddArc(notStateF2,          uSupportNode);

	// P(Support | AND, OR, XOR, NOT)
	this->setConditionalTables(uSupportNode, supportUtilityConditional, conditionalCol, 4);

	bn.AddArc(combAbilityStateF2,  utilityNode);
	bn.AddArc(uSupportNode,        utilityNode);
	bn.AddArc(independenceStateF2, utilityNode);
	bn.AddArc(moraleStateF2,       utilityNode);

	// Utility | Combining Ability, Support, Independence, Morale
	setUtilityTables(utilityNode, utilityTable, utilityCol, 4);


	// UPDATE NETWORK
	// --------------
	// We've set up all the nodes, arcs and conditional probability tables.
	// We're ready for action.
	bn.UpdateBeliefs();


	// FIND THE UTILITIES FOR THE RESPECTIVE POLICIES.
	// Find the maximal decision of the hints we haven't already given.
	// Out "best policy" is going to be out of one of the 6 choices.
	DSL_intArray prns = bn.GetNode(utilityNode)->Value()->GetIndexingParents();
 	DSL_sysCoordinates coords(*bn.GetNode(utilityNode)->Value());	
	coords.GoFirst();

	int     bestPolicy = -1;
	double  valOfBestPolicy = -1;
	bool    chosenBefore;
	for (i = 0; i < numAgentActions; i++) {

		// Get the value of the policy i.
		p = policyValues[i] = coords.UncheckedValue();
		coords.Next();

		// Make sure we don't perform the same action twice
		// or perform an action that doesn't make sense.
		if (i >= 1 && i <= 4 && (qs->getHintForGate(theGateTypes[i]) || theGateTypes[i] == -1))
			chosenBefore = true;
		else if (i == 5 && (qs->getHintForInput(inputNum) || numGates < 2))
			chosenBefore = true;
		else
			chosenBefore = false;

		if (chosenBefore)
			cbArray[i] = '*';
		else
			cbArray[i] = ' ';

		if (p > valOfBestPolicy && !chosenBefore) {
			valOfBestPolicy = p;
			bestPolicy      = i;
		}
	}
	

	// DEBUGGING STUFF.
	// ---------------
	#ifdef DEBUG_USERSTATE
	cout << "Policies:" << endl;
	cout << "  " << cbArray[0] << "EU(No action) =     " << policyValues[0] << endl;
	cout << "  " << cbArray[1] << "EU(Hint for AND) =  " << policyValues[1] << endl;
	cout << "  " << cbArray[2] << "EU(Hint for OR) =   " << policyValues[2] << endl;
	cout << "  " << cbArray[3] << "EU(Hint for XOR) =  " << policyValues[3] << endl;
	cout << "  " << cbArray[4] << "EU(Hint for NOT) =  " << policyValues[4] << endl;
	cout << "  " << cbArray[5] << "EU(Hint for C.A.) = " << policyValues[5] << endl;
	cout << endl;
	#endif


	// CLEAN UP
	// --------
	// Essentially, we're going to delete all the nodes we've created so
	// we can return to the original state. We do two things:
	// 1. Remove all the created arcs.
	// 2. Remove all the created nodes.

	// 1. Remove all the created arcs.
	bn.RemoveArc(andState,          andStateF);
	bn.RemoveArc(agentActionNode,   andStateF);
	bn.RemoveArc(orState,           orStateF);
	bn.RemoveArc(agentActionNode,   orStateF);
	bn.RemoveArc(xorState,          xorStateF);
	bn.RemoveArc(agentActionNode,   xorStateF);
	bn.RemoveArc(notState,          notStateF);
	bn.RemoveArc(agentActionNode,   notStateF);
	bn.RemoveArc(combAbilityState,  combAbilityStateF);
	bn.RemoveArc(agentActionNode,   combAbilityStateF);
	bn.RemoveArc(combAbilityStateF, successOnInputS);
	bn.RemoveArc(andStateF,         successOnInputS);
	bn.RemoveArc(orStateF,          successOnInputS);
	bn.RemoveArc(xorStateF,         successOnInputS);
	bn.RemoveArc(notStateF,         successOnInputS);
	bn.RemoveArc(successOnInputS,   successOnInput);
	bn.RemoveArc(independenceState, successOnInput);
	bn.RemoveArc(agentActionNode,   gaveHintForInput);
	bn.RemoveArc(successOnInput,    successOnGates[i]);
	bn.RemoveArc(agentActionNode,   gaveHintForInput);
	bn.RemoveArc(gaveAHintForInput, independenceStateF2);
	bn.RemoveArc(independenceState, independenceStateF2);
	bn.RemoveArc(failedOnPrevInput, independenceStateF2);
	bn.RemoveArc(successOnInput,    independenceStateF2);
	bn.RemoveArc(moraleState,       moraleStateF2);
	bn.RemoveArc(failedOnPrevInput, moraleStateF2);
	bn.RemoveArc(successOnInput,    moraleStateF2);

	bn.RemoveArc(gaveHintForInput, gaveAHintForInput);
	for (i = 0; i < numUniqueGates; i++)
		bn.RemoveArc(gaveHintForGates[i], gaveAHintForInput);

	if (numGates > 1) {
		bn.RemoveArc(successOnInput,   combAbilityStateF2);
		bn.RemoveArc(gaveHintForInput, combAbilityStateF2);
		bn.RemoveArc(combAbilityState, combAbilityStateF2);
	}
	else
		bn.RemoveArc(combAbilityState, combAbilityStateF2);

	if (theGateTypes[gateTypeAND] == -1)
		bn.RemoveArc(andState, andStateF2);
	else {
		bn.RemoveArc(successOnGates[theGateTypes[gateTypeAND]],   andStateF2);
		bn.RemoveArc(gaveHintForGates[theGateTypes[gateTypeAND]], andStateF2);
		bn.RemoveArc(andState,                                    andStateF2);
	}

	if (theGateTypes[gateTypeOR] == -1)
		bn.RemoveArc(orState, orStateF2);
	else {
		bn.RemoveArc(successOnGates[theGateTypes[gateTypeOR]],   orStateF2);
		bn.RemoveArc(gaveHintForGates[theGateTypes[gateTypeOR]], orStateF2);
		bn.RemoveArc(orState,                                    orStateF2);
	}

	if (theGateTypes[gateTypeXOR] == -1)
		bn.RemoveArc(xorState, xorStateF2);
	else {
		bn.RemoveArc(successOnGates[theGateTypes[gateTypeXOR]],   xorStateF2);
		bn.RemoveArc(gaveHintForGates[theGateTypes[gateTypeXOR]], xorStateF2);
		bn.RemoveArc(xorState,                                    xorStateF2);
	}

	if (theGateTypes[gateTypeNOT] == -1)
		bn.RemoveArc(notState, notStateF);
	else {
		bn.RemoveArc(successOnGates[theGateTypes[gateTypeNOT]],   notStateF2);
		bn.RemoveArc(gaveHintForGates[theGateTypes[gateTypeNOT]], notStateF2);
		bn.RemoveArc(notState,                                    notStateF2);
	}

	bn.RemoveArc(andStateF2,          uSupportNode);
	bn.RemoveArc(orStateF2,           uSupportNode);
	bn.RemoveArc(xorStateF2,          uSupportNode);
	bn.RemoveArc(notStateF2,          uSupportNode);
	bn.RemoveArc(combAbilityStateF2,  utilityNode);
	bn.RemoveArc(uSupportNode,        utilityNode);
	bn.RemoveArc(independenceStateF2, utilityNode);
	bn.RemoveArc(moraleStateF2,       utilityNode);	

	// 2. Remove all the created nodes.
  bn.DeleteNode(agentActionNode);
	bn.DeleteNode(andStateF);
	bn.DeleteNode(orStateF);
	bn.DeleteNode(xorStateF);
	bn.DeleteNode(notStateF);
	bn.DeleteNode(combAbilityStateF);
	bn.DeleteNode(andStateF2);
	bn.DeleteNode(orStateF2);
	bn.DeleteNode(xorStateF2);
	bn.DeleteNode(notStateF2);
	bn.DeleteNode(combAbilityStateF2);
	bn.DeleteNode(independenceStateF2);
	bn.DeleteNode(moraleStateF2);
	bn.DeleteNode(successOnInput);
	bn.DeleteNode(successOnInputS);
	bn.DeleteNode(failedOnPrevInput);
	bn.DeleteNode(gaveHintForInput);
	bn.DeleteNode(gaveAHintForInput);

	for (i = 0; i < numUniqueGates; i++) {		
		bn.DeleteNode(successOnGates[i]);
		bn.DeleteNode(gaveHintForGates[i]);
	}

	bn.DeleteNode(uSupportNode);
	bn.DeleteNode(utilityNode);


	// PERFORM ACTION
	// --------------
	// So we've decided which action is the best.
	// Let's actually perform it!!!

	if (bestPolicy == 0)
		;
	else if (bestPolicy == 5) {
		ErrorBox::displayErrorMsg(app, "It looks like you're having difficulty combining the inputs from several gates. It will be easier if you calculate the output for a single combination values for the variables (i.e. the letters), then trace those values down the wires.");
		qs->setHintForInput(inputNum);
	}
	else if (bestPolicy == gateTypeAND) {
		ErrorBox::displayErrorMsg(app, "It looks like you are having trouble with AND gates. Remember that and AND Gate will result in a value of 1 only when both of the inputs are 1.");
		qs->setHintForGateType(bestPolicy);
	}
	else if (bestPolicy == gateTypeOR) {
		ErrorBox::displayErrorMsg(app, "Let me refresh your memory about OR gates; an OR gate will result in a value of 0 only when both of the inputs are 0.");
		qs->setHintForGateType(bestPolicy);
	}
	else if (bestPolicy == gateTypeXOR) {
		ErrorBox::displayErrorMsg(app, "A XOR gate is what we call 'exclusive or', because it has a value of 1 when one gate has a value of 0 and the other gate has a value of 1, but it is not 1 if both of the gates are 1.");
		qs->setHintForGateType(bestPolicy);
	}
	else if (bestPolicy == gateTypeNOT) {
		ErrorBox::displayErrorMsg(app, "Just in case you're having trouble determining the result of a NOT gate, remember that input value is reversed, so a 0 becomes a 1 and a 1 becomes a 0.");
		qs->setHintForGateType(bestPolicy);
	}
}


// Set the conditional probability tables for "node". The parameter "dim" is
// the number of binary variables we depend on. Note that this function will
// only work after all the arcs have been properly set between the nodes.
// Also, we assume that all the nodes have binary outcomes (i.e. either "true"
// or "false").
void UserBeliefNet::setConditionalTables(int node, int row, int col, int dim) {

	double  p;
	int     i, numCols;

	// Links a DSL_sysCoordinates objet to a DSL_nodeDefinition object.
	DSL_sysCoordinates theCoords(*bn.GetNode(node)->Definition());

	// Calculate the number of columns we have to fill in.
	numCols = powerOf2(dim);

	for (i = 0; i < numCols; i++) {
		p = probTables->at(row + i, col + dim);
		theCoords.UncheckedValue() = p;
		theCoords.Next();
		theCoords.UncheckedValue() = 1 - p;
		theCoords.Next();
	}
}


void UserBeliefNet::setUserActionCondTables(int node, int row, int col, int inputNum) {

	int* numGsPerType = qs->getNumGatesPerType(inputNum);
	int  ttlNumGates  = numGsPerType[1] + numGsPerType[2] + 
		                  numGsPerType[3] + numGsPerType[4];

	// Convert the numbers of gates into importances.
	int    i, j;
	double importances[5];
	double nImportances[5];

	// Set the importances for the combining ability.
	nImportances[0] = importances[0] = setCAImportance(ttlNumGates);

	// Set the importances for the gates.
	for (i = 1; i < 5; i++)
		nImportances[i] = importances[i] = setGateImportance(numGsPerType[i]);

	// Normalize the importances.
	double sum = 0.0;
	for (i = 0; i < 5; i++)
		sum += nImportances[i];
	for (i = 0; i < 5; i++)
		nImportances[i] /= sum;

	// In this case, the dimension is 1.
	double p = probTables->at(row, col + 1);
	double q = probTables->at(row + 1, col + 1);

	// Generate the probability table.
	double probTable[32][5]={ { p, p, p, p, p }, 
														{ p, p, p, p, q }, 
														{ p, p, p, q, p }, 
														{ p, p, p, q, q }, 
														{ p, p, q, p, p }, 
														{ p, p, q, p, q }, 
														{ p, p, q, q, p }, 
														{ p, p, q, q, q }, 
														{ p, q, p, p, p }, 
														{ p, q, p, p, q }, 
														{ p, q, p, q, p }, 
														{ p, q, p, q, q }, 
														{ p, q, q, p, p }, 
														{ p, q, q, p, q }, 
														{ p, q, q, q, p }, 
														{ p, q, q, q, q }, 
														{ q, p, p, p, p }, 
														{ q, p, p, p, q }, 
														{ q, p, p, q, p }, 
														{ q, p, p, q, q }, 
														{ q, p, q, p, p }, 
														{ q, p, q, p, q }, 
														{ q, p, q, q, p }, 
														{ q, p, q, q, q }, 
														{ q, q, p, p, p }, 
														{ q, q, p, p, q }, 
														{ q, q, p, q, p }, 
														{ q, q, p, q, q }, 
														{ q, q, q, p, p }, 
														{ q, q, q, p, q }, 
														{ q, q, q, q, p }, 
														{ q, q, q, q, q } };

	// Now repeat for all the rows of the probability table and 
	// generate 
	DSL_sysCoordinates theCoords(*bn.GetNode(node)->Definition());

	double x;
	for (i = 0; i < 32; i++) {

		p = 0.0;
		for (j = 0; j < 5; j++) {
			x = nImportances[j] * pow( probTable[i][j], importances[j]);
			p += x;
		}
		theCoords.UncheckedValue() = p;
		theCoords.Next();
		theCoords.UncheckedValue() = 1 - p;
		theCoords.Next();
	}
}


void UserBeliefNet::setUtilityTables(int node, int row, int col, int dim) {

	double  v;
	int     i, numCols;

	DSL_Dmatrix *theMatrix;
	bn.GetNode(node)->Definition()->GetDefinition(&theMatrix);

	// Calculate the number of columns we have to fill in.
	numCols = powerOf2(dim);

	for (i = 0; i < numCols; i++) {
		v = probTables->at(row + i, col + dim);
		theMatrix->Subscript(i) = v;
	}
}


void UserBeliefNet::setAgentActionCondTables(int node, int row, int col, int dim) {

	double  p;
	int     i, numCols;

	// Links a DSL_sysCoordinates objet to a DSL_nodeDefinition object.
	DSL_sysCoordinates theCoords(*bn.GetNode(node)->Definition());

	// Calculate the number of columns we have to fill in.
	numCols = numAgentActions * powerOf2(dim-1);

	for (i = 0; i < numCols; i++) {
		p = probTables->at(row + i, col + dim);
		theCoords.UncheckedValue() = p;
		theCoords.Next();
		theCoords.UncheckedValue() = 1 - p;
		theCoords.Next();
	}
}


// Set the conditional probability tables for the "node". In this case, the
// relationship between the node and it's single parent is trivial:
//    P(node = T | parent = T) = 1.0
//    P(node = F | parent = T) = 0.0
//    P(node = T | parent = F) = 0.0
//    P(node = F | parent = F) = 1.0
void UserBeliefNet::setDirectConditionalTables(int node) {
	
	// Links a DSL_sysCoordinates objet to a DSL_nodeDefinition object.
	DSL_sysCoordinates theCoords(*bn.GetNode(node)->Definition());

	theCoords.UncheckedValue() = 1.0;
	theCoords.Next();
	theCoords.UncheckedValue() = 0.0;
	theCoords.Next();
	theCoords.UncheckedValue() = 0.0;
	theCoords.Next();
	theCoords.UncheckedValue() = 1.0;
	theCoords.Next();
}
	

// Get the probability that the node is true.
double UserBeliefNet::getProbOfBinaryNode(int node) {
	double result;

	DSL_sysCoordinates theCoords(*bn.GetNode(node)->Value());
	theCoords[0] = 0;
	theCoords.GoToCurrentPosition();
	result = theCoords.UncheckedValue();

	return result;
}


// Computes 2 to the power of "p".
int UserBeliefNet::powerOf2(int p) {
	int result = 1;

	for (int i = 0; i < p; i++)
		result *= 2;

	return result;
}


void UserBeliefNet::setBinaryProb(int node, double p) {

	DSL_doubleArray theProbs;
	theProbs.SetSize(2);

	theProbs[0] = p;
	theProbs[1] = 1 - p;
	bn.GetNode(node)->Definition()->SetDefinition(theProbs);
}


void UserBeliefNet::readFromFile (ifstream f) {

	// Note that the user belief net is already initialized at this
	// point.
	double p;

	// The order of the session file is as follows:
	// 1. and state
	// 2. or state
	// 3. xor state
	// 4. not state
	// 5. combining ability state
	// 6. independence state
	// 7. morale state

	f >> p;
	setBinaryProb(andState, p);
	f >> p;
	setBinaryProb(orState, p);
	f >> p;
	setBinaryProb(xorState, p);
	f >> p;
	setBinaryProb(notState, p);
	f >> p;
	setBinaryProb(combAbilityState, p);
	f >> p;
	setBinaryProb(independenceState, p);
	f >> p;
	setBinaryProb(moraleState, p);
}


void UserBeliefNet::writeToFile (ofstream f) {

	double p;

	p = getProbOfBinaryNode(andState);
	f << p;
	p = getProbOfBinaryNode(orState);
	f << p;
	p = getProbOfBinaryNode(xorState);
	f << p;
	p = getProbOfBinaryNode(notState);
	f << p;
	p = getProbOfBinaryNode(combAbilityState);
	f << p;
	p = getProbOfBinaryNode(independenceState);
	f << p;
	p = getProbOfBinaryNode(moraleState);
	f << p;
}
