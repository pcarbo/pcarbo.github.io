// Project includes.
#include "UserBeliefNet.h"

// Standard includes.
#include <iostream>

using namespace std;

int main(int argc, char* argv[]) {

	// Set up the question state.
  // We have 2 inputs and 3 gates.
	QuestionState qs(2,3);
	qs.setGateType(0, gateTypeOR);
	qs.setGateType(1, gateTypeNOT);
	qs.setGateType(2, gateTypeXOR);
	qs.addInputToGate(0, 0);
	qs.addInputToGate(0, 1);
	qs.addInputToGate(1, 1);
	qs.addInputToGate(2, 1);

	UserBeliefNet b = UserBeliefNet();
	b.setQuestion(&qs);

	char response = 0;
	while (response != 'q') {

		cout << "Select an option: " << endl;
		cout << "1) Enter value for input 1" << endl;
		cout << "2) Enter value for input 2" << endl;
		cout << "Q) Quit" << endl;
		cin >> response;

		cout << endl;
		int x;
		switch (response) {

			case '1':
				cout << "Enter a value (1 is good, 0 is bad): ";
				cin >> x;

				if (x == 1)
					b.updateState(0,true);
				else {
					b.updateState(0,false);
					b.doBestAction(0);
				}
				break;

			case '2':
				cout << "Enter a value (1 is good, 0 is bad): ";
				cin >> x;

				if (x == 1)
					b.updateState(1,true);
				else {
					b.updateState(1,false);
					b.doBestAction(1);
				}
				break;

			case 'q':
				return 0;
		}
	}

	return 0;
}

