#ifndef QUESTIONSTATE_DEFINED

#define gateTypeNone    0
#define gateTypeAND     1
#define gateTypeOR      2
#define gateTypeXOR     3
#define gateTypeNOT     4

#define QUESTIONSTATE_DEFINED

// CLASS QuestionState
// -------------------
// In this class we keep track of all the information 
// pertaining to the user's actions and interaction with
// the current question.
class QuestionState {

	public:
		QuestionState(int numInputs, int numGates);
		~QuestionState();

		// Initialisation of the question state.
		void setGateType(int n, int gateType);
		void addInputToGate(int n, int inputNum);

		// Input events.
		void setInput(int n);
		void setFailedOnInput(int n);

		// Output events.
		int  getGateType(int n);
		void setHintForGate(int n);
		void setHintForGateType(int gt);
		void setHintForInput(int n);
		bool getHintForGate(int n);
		bool getHintForInput(int n);
		bool getFailedOnInput(int n);

		// Return the list and number of gate types corresponding
		// to the input that are not yet completed.
		int* getGatesForInput(int n, int& numGates);
		int* getUniqueGatesForInput(int n, int& numGates);
		int* getNumGatesPerType(int n);
	
	protected:
		int   numInputs;
		int   numGates;

		bool*  prevInputs;							// "True" is the user failed on a 
																		// previous attempt to enter a value
																		// value for that gate.
		bool*  gates;										// "True" if user entered the correct 
																		// value corresponding to that gate.
		bool*  gaveHintForGate;					// "True" if there was a hint given
																		// previously corresponding to that
																		// gate.
		bool*  gaveHintForInput;
		bool** gatesConnectedToInputs;
		int*   gateTypes;
};

#endif