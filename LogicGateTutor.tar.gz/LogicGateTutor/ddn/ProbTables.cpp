// Project includes.
#include "ProbTables.h"
#include "Stoker.h"

// Standard includes.
#include <stdlib.h>
#include <iostream>
#include <fstream>

using namespace std;

ProbTables::ProbTables (const char* fileName) {

	int i;
	int aSize = maxNumLinesInProbTable * maxWidthProbTable;

	good = false;

	// Allocate memory for probability tables.
	a = new double[aSize];
	if (!a) {
		cerr << "Unable to allocate enough memory for probability tables" << endl;
		return;
	}

	// First set the array to bogus values in case we accidentally 
	// use them.
	for (i = 0; i < aSize; i++)
		a[i] = probTableDefaultValue;

	// Open up the file.
	ifstream f = ifstream(fileName);

	// Check to see if the file opened successfully.
	if (!f.is_open()) {
		// In the future this should be an "error box".
		cerr << "Unable to open probability tables file." << endl;
		return;
	}

	// Read in the probabilities.
	char   buffer[maxNumCharsPerLine + 1];
	int    numTokens;
	char** tokens;
	int    lineNum = 0;
	double x;

	while (!f.eof()) {

		// Read the line into the buffer.
		f.getline(buffer, maxNumCharsPerLine, '\n');

		// We want to separate the items in the line.
		// The items are delimited by tabs.
		tokens = Stoker::tokenizeSpreadsheet(buffer, numTokens, '\t');

		// Now that we've retrieved the tokens, let's
		// put all of them into the array of probabilities.
		for (i = 0; i < numTokens; i++) {
			x = atof(tokens[i]);
			a[probCoord(lineNum,i)] = x;
		}

		// Delete the list of tokens since we're done with it.
		delete [] tokens;

		// Go to the next line in the file.
		lineNum++;
	}

	// If we've reached this point, then everything is dandy.
	good = true;
}


double ProbTables::at(int row, int column) {
	return a[probCoord(row - 1, column - 1)];
}