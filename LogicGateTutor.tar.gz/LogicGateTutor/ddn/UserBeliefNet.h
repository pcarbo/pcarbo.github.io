#ifndef USERBELIEFNET_DEFINED

#define USERBELIEFNET_DEFINED

#include "fx.h"
#include "ProbTables.h"
#include "QuestionState.h"
#include "network2.h"
#include <iostream>
#include <fstream>

// Comment out this next line if you don't want to debug.
//#define DEBUG_USERSTATE

#define numAgentActions         6

// The labels for the belief nodes.
#define andStateName            "AND"
#define orStateName             "OR"
#define notStateName            "NOT"
#define xorStateName            "XOR"
#define combAbilityStateName    "Combining Ability"
#define independenceStateName   "Independence"
#define moraleStateName         "Morale"
#define gateStateName           "Gates"
#define gkStateName             "General Knowledge"

#define andStateNameF           "AND (t+1)"
#define orStateNameF            "OR (t+1)"
#define notStateNameF           "NOT (t+1)"
#define xorStateNameF           "XOR (t+1)"
#define combAbilityStateNameF   "Combining Ability (t+1)"
#define independenceStateNameF  "Independence (t+1)"
#define moraleStateNameF        "Morale (t+1)"

#define andStateNameF2          "AND (t+2)"
#define orStateNameF2           "OR (t+2)"
#define notStateNameF2          "NOT (t+2)"
#define xorStateNameF2          "XOR (t+2)"
#define combAbilityStateNameF2  "Combining Ability (t+2)"
#define independenceStateNameF2 "Independence (t+2)"
#define moraleStateNameF2       "Morale (t+2)"
#define gateStateNameF2         "Gates (t+2)"
#define gkStateNameF2           "General Knowledge (t+2)"

#define successOnInputName      "Success on Input"
#define successOnInputSName     "Success on Input (Support)"
#define failedOnPrevInputName   "Failed Previously on Input"
#define gaveHintOnInputName     "Gave Hint For Input"
#define gaveAHintOnInputName    "Gave some kind of hint"
#define successOnGateName       "Success on Gate"
#define gaveHintOnGateName      "Gave Hint for Gate"

#define agentActionName         "Agent Action"
#define utilityNodeName         "Utility of Action"

// Indices for the prior probability tables.
#define priorCol           3
#define gkPrior            2
#define independencePrior  3
#define moralePrior        4

// Indices for conditional probability tables.
#define conditionalCol             3
#define utilityCol                 3

#define andConditional             13
#define orConditional              19
#define xorConditional             22
#define notConditional             16
#define gatesConditional           7
#define combAbilityConditional     10
#define independenceConditional    44
#define moraleConditional          61
#define combAbilityFromPrevCond    35
#define gateConditional            26
#define andAgentActionConditional  72
#define orAgentActionConditional   85
#define xorAgentActionConditional  98
#define notAgentActionConditional  111
#define combAbilityAgentActionCond 124
#define gaveHintOnInputConditional 137
#define gaveHintOnAndConditional   144
#define gaveHintOnOrConditional    151
#define gaveHintOnXorConditional   158
#define gaveHintOnNotConditional   165
#define gaveHintOnCombAbilityCond  137
#define supportUtilityConditional  177
#define utilityTable               197
#define userActionConditional      194
#define indKnowlConditional        172

#define probBarWidth               200
#define probBarHeight               12
#define drawOuterMargin             10
#define drawInnerMargin              8

#define setGateImportance(x)  (((x) <= 0) ? 0 : (((x) <= 3) ? x : (((x) <= 6) ? x/3.0+2 : 4)))
#define setCAImportance(x)    (((x) <= 1) ? 0 : (((x) <= 4) ? x-1 : (((x) <= 6) ? x/2.0+1 : 4)))

using namespace std;


// CLASS UserBeliefNet
// -------------------
// In this class we keep track of all the information on the user, and
// we have methods to update our belief in the state of the user based
// on GUI inputs. Also, we have methods to predict what the user will do
// based on our current information and we can make judgements about 
// what the best course of action is to take.
class UserBeliefNet {

	public:

		// Constructor.
		UserBeliefNet() { }
		UserBeliefNet(FXApp* owner);

		void readFromFile(ifstream f);
		void writeToFile(ofstream f);

		void setQuestion(QuestionState* q) { qs = q; }
		void updateState(int inputNum, bool inputGood);
		void doBestAction(int inputNum);
		void draw(FXDC& dc, FXint width, FXint height);

		// This is the flag to tell us that everything is okay.
		bool good;

	protected:
		// Protected functions.
		void   setConditionalTables(int node, int row, int col, int dim);
		void   setAgentActionCondTables(int node, int row, int col, int dim);
		void   setUserActionCondTables(int node, int row, int col, int inputNum);
		void   setUtilityTables(int node, int row, int col, int dim);
		void   setDirectConditionalTables(int node);
		void   setBinaryProb(int node, double p);
		double getProbOfBinaryNode(int node);
		void   printState (int node, const char* s);
		int    powerOf2(int p);
		void   drawProbRectangle (FXDC& dc, FXColor c, double p, int& y);

		// The decision network.
		DSL_network  bn;		
		FXApp*       app;

		// The probability tables.
		ProbTables*  probTables;

		double  policyValues[numAgentActions];
		char    cbArray[numAgentActions];

		// The nodes describing the user's state.
		int andState;						// Whether the user knows about AND gates.
		int orState;						// Whether the user knows about OR gates.
		int notState;						// Whether the user knows about NOT gates.
		int xorState;						// Whether the user knows about XOR gates.
		int combAbilityState;		// Whether the user has a grasp of how to 
														// combine several gate outputs.
		int independenceState;	// Whether the user is independent.
		int moraleState;				// Whether the user has a high morale.

		// Time.
		int t;

		// The question state.
		QuestionState* qs;
};

#endif