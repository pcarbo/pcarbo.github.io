// Project includes.
#include "QuestionState.h"

// Standard includes.


QuestionState::QuestionState (int numInputs, int numGates) {

	int i, j;

	this->numInputs = numInputs;
	this->numGates  = numGates;

	prevInputs             = new bool[numInputs];
	gaveHintForInput       = new bool[numInputs];

	gates                  = new bool[numGates];
	gaveHintForGate        = new bool[numGates];
	gatesConnectedToInputs = new bool*[numGates];
	gateTypes              = new int[numGates];

	for (i = 0; i < numGates; i++)
		gatesConnectedToInputs[i] = new bool[numInputs];

	// Initialize the gate-input connections and
	// other stuff.
	for (i = 0; i < numInputs; i++) {
		prevInputs[i]       = false;
		gaveHintForInput[i] = false;
	}

	for (i = 0; i < numGates; i++) {
		gaveHintForGate[i]        = false;
		gates[i]                  = false;
		gateTypes[i]              = gateTypeNone;
	}

	for (i = 0; i < numGates; i++)
		for (j = 0; j < numInputs; j++)
			gatesConnectedToInputs[i][j] = false;
}


QuestionState::~QuestionState() {

	delete [] gates;
	delete [] prevInputs;
	delete [] gaveHintForGate;
	delete [] gaveHintForInput;
	delete [] gateTypes;

	for (int i = 0; i < numGates; i++)
		delete [] gatesConnectedToInputs[i];
	delete [] gatesConnectedToInputs;
}


void QuestionState::setInput(int n) {

	// Set "true" all the gates connected to the input.
	for (int i = 0; i < numGates; i++)
		if (gatesConnectedToInputs[i][n])
			gates[i] = true;
}


void QuestionState::setFailedOnInput(int n) {
	prevInputs[n] = true;
}


bool QuestionState::getHintForInput(int n) {
	return gaveHintForInput[n];
}


int QuestionState::getGateType(int n) {
	return gateTypes[n];
}


void QuestionState::setGateType(int n, int gateType) {
	gateTypes[n] = gateType;
}


void QuestionState::addInputToGate(int n, int inputNum) {
	gatesConnectedToInputs[n][inputNum] = true;
}


void QuestionState::setHintForGate(int n) {
	gaveHintForGate[n]         = true;
}


void QuestionState::setHintForGateType(int gt) {
	for (int i = 0; i < numGates; i++)
		if (gateTypes[i] == gt)
			gaveHintForGate[i] = true;
}


void QuestionState::setHintForInput(int n) {
	gaveHintForInput[n] = true;
}


bool QuestionState::getHintForGate(int n) {
	return gaveHintForGate[n];
}


bool QuestionState::getFailedOnInput(int n) {
	return prevInputs[n];
}


int* QuestionState::getGatesForInput(int n, int& numGates) {

	int* result = new int[this->numGates];
	numGates = 0;

	for (int i = 0; i < this->numGates; i++)
		if (gatesConnectedToInputs[i][n] && !gates[i]) {
			result[numGates] = i;
			numGates++;
		}

	return result;
}


int* QuestionState::getUniqueGatesForInput(int n, int& numGates) {

	int* result = new int[this->numGates];
	bool haveThisType[5];
	int  i;
	numGates = 0;

	// Initialize the "haveThisType" array.
	for (i = 1; i < 5; i++)
		haveThisType[i] = false;

	for (i = 0; i < this->numGates; i++)
		if (gatesConnectedToInputs[i][n] && !gates[i]
			  && !haveThisType[gateTypes[i]]) {
			result[numGates] = i;
			haveThisType[gateTypes[i]] = true;
			numGates++;
		}

	return result;
}


int* QuestionState::getNumGatesPerType(int n) {

	int* result = new int[5];
	int  i;

	// Initialize the result array.
	for (i = 0; i < 5; i++)
		result[i] = 0;

	for (i = 0; i < this->numGates; i++)
		if (gatesConnectedToInputs[i][n] && !gates[i])
			result[getGateType(i)]++;

	return result;
}
