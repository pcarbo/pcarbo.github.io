#ifndef PROBTABLES_DEFINED

#define PROBTABLES_DEFINED

#define probTablesFileName      "probtables.txt"
#define maxNumLinesInProbTable  250
#define maxWidthProbTable       20
#define maxNumCharsPerLine      1024
#define probTableDefaultValue   -1.0

// CLASS ProbTables
// ----------------
// Using this class we can grab the values of the probabilities 
// from a tab-delimited Excel spreadsheet.
class ProbTables {

	#define probCoord(row,column) ((row)*maxWidthProbTable + (column))

	public:	

		// Constructor.
		ProbTables (const char* fileName);

		// Accessor.
		double at(int row, int column);
		
		// "true" if everything is okay. Otherwise, "false".
		bool good;

	private:

		// This is the 2-dimensional array of probability
		// values.
		double* a;
};

#endif