// Project includes.
#include "OpenSessionDialog.h"
#include "ErrorBox.h"

// Standard includes.
#include <string>

// Global variables.
static char chosenSession[256] = "";


// Function implementation map
FXDEFMAP(OpenSessionDialog) OpenSessionDialogMap[]={
  FXMAPFUNC(SEL_COMMAND, OpenSessionDialog::ID_TEXTFIELD, OpenSessionDialog::onCmdTextChange),
};

FXIMPLEMENT(OpenSessionDialog, FXDialogBox, OpenSessionDialogMap, ARRAYNUMBER(OpenSessionDialogMap))


OpenSessionDialog::OpenSessionDialog(FXApp* owner)
 : FXDialogBox(owner, "Choose a session", DECOR_TITLE | DECOR_BORDER) {

  // Bottom buttons
  buttons = new FXHorizontalFrame(this, LAYOUT_SIDE_BOTTOM|FRAME_NONE|LAYOUT_FILL_X|PACK_UNIFORM_WIDTH,0,0,0,0,40,40,20,20);

  // Separator
  new FXHorizontalSeparator(this,LAYOUT_SIDE_BOTTOM|LAYOUT_FILL_X|SEPARATOR_GROOVE);

  // Contents
  contents = new FXVerticalFrame(this,LAYOUT_SIDE_TOP|FRAME_NONE|LAYOUT_FILL_X|LAYOUT_FILL_Y|PACK_UNIFORM_WIDTH);

	// Text field
	new FXLabel(contents,"Enter your name to resume a session",NULL,0,0,0,0,0,0,0,4,0);
	new FXLabel(contents,"or start a new one:",NULL,0,0,0,0,0,0,0,0,4);
	FXTextField* textfield1 = new FXTextField(contents,40,this,ID_TEXTFIELD,JUSTIFY_LEFT|FRAME_SUNKEN|FRAME_THICK|LAYOUT_SIDE_TOP,0,0,0,0,2,2,2);
  textfield1->setText("");
  
  // Accept
  new FXButton(buttons,"OK",NULL,this,ID_ACCEPT,FRAME_RAISED|FRAME_THICK|LAYOUT_CENTER_X|LAYOUT_CENTER_Y);

  // Cancel
  new FXButton(buttons,"Cancel",NULL,this,ID_CANCEL,FRAME_RAISED|FRAME_THICK|LAYOUT_CENTER_X|LAYOUT_CENTER_Y);
}


// Handle all the stuff for getting the name of the session.
// Return NULL if the user did not enter a new session.
char* OpenSessionDialog::getUserInput(FXApp* owner, const char* curSessionName) {

	// Create the new dialog and execute it.
	OpenSessionDialog osDialog(owner);
	int result = osDialog.execute();

	// Remove the spaces surrounding the name.
	// Note that the chosen session is located in the global 
	// variable "chosenSession".
	int i = strlen(chosenSession) - 1;
	while (i >= 0 && chosenSession[i] == ' ')
		chosenSession[i] = 0;
	i = 0;
	while (i == ' ')
		i++;
	if (i)
		for (unsigned int j = i; j < strlen(chosenSession); j++)
			chosenSession[j - i] = chosenSession[j];

	// If the current session name is currently nothing, then we're at the
	// start of the program. The user MUST enter a session and MUST hit OK. 
	// Otherwise, we quit.
	if (!strlen(curSessionName) && (!strlen(chosenSession) || !result)) {
		ErrorBox::displayErrorMsg(owner, "You did not choose a session. Goodbye!");
		return NULL;
	}

	// Let's check to see if the user did one of the following, and if so, then
	// we don't change sessions:
	//		1. Hit "cancel"
	//		2. Did not enter a session.
	//    3. Entered a session name that's the same name as the current session.
	else if (!strlen(chosenSession) || !result || 
					(!stricmp(curSessionName, chosenSession))) {
		return NULL;
	}

	// If those two tests failed, then the user did everything properly and we
	// can return the name of the new session.
	else {
		return chosenSession;
	}
}


// This function is used to handle what happens the user inputs something in the 
// text box. In this case, we just update the "chosenSession" variable. Simple.
// And then return that we've handled it.	
long OpenSessionDialog::onCmdTextChange(FXObject* obj, FXSelector sel, void* ptr) {
	strcpy(chosenSession, (FXchar*) ptr);
	return 1;
}
