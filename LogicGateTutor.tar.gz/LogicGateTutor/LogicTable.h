
// CLASS LogicTable
// ----------------
class LogicTable {

	public:
		// Creates a 0-dimensional logic table with a 
		// single value (either 0 or 1).
		LogicTable(int val);

		// Creates a 1-dimensional logic table with values
		// of 0 and 1. Essentially, we can imagine this logic table 
		// as the identity gate.
		LogicTable();

		// Creates an n-dimensional logic table, where n is the dimension
		// of t1.
		LogicTable(const LogicTable& t, int gateType);

		// Creates an (n+m)-dimensional logic table, where n is the
		// dimension of t1 and m is the dimension of t2. Table t1 is in the
		// high-order rows, and table t2 is in the low-order rows.
		LogicTable(const LogicTable& t1, const LogicTable& t2, int gateType);
		
		// Accessors and modifiers.
		int  getSize()                { return size; }
		void setValue(int n, int val) { vals[n] = val; }
		int  getValue(int n)          { return vals[n]; }

		// Checks to see if two logic tables are equal.
		static bool areEqual(LogicTable t1, LogicTable t2);

		// Destructor.
		~LogicTable();

		void print();

	protected:
		int  dim;
		int  size;
		int* vals;
};