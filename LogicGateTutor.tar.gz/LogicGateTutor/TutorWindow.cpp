// Project Includes.
#include "TutorWindow.h"
#include "ErrorBox.h"
#include "ex1.h"

// Map
FXDEFMAP(TutorWindow) TutorWindowMap[]={
  FXMAPFUNC(SEL_PAINT,             TutorWindow::ID_CANVAS,			TutorWindow::onCanvasRepaint),
	FXMAPFUNC(SEL_LEFTBUTTONRELEASE, TutorWindow::ID_CANVAS,      TutorWindow::onMouseUp),
  FXMAPFUNC(SEL_COMMAND,           TutorWindow::ID_SHOWSTATS,		TutorWindow::onCmdShowStats),
  FXMAPFUNC(SEL_COMMAND,           TutorWindow::ID_NEWSESSION,	TutorWindow::onCmdNewSession),
  FXMAPFUNC(SEL_COMMAND,           TutorWindow::ID_SWITCHEX,		TutorWindow::onCmdSwitchExercise),
  FXMAPFUNC(SEL_COMMAND,           TutorWindow::ID_QUIT,				TutorWindow::onCmdQuit),
};


// ButtonApp implementation
FXIMPLEMENT(TutorWindow, FXMainWindow, TutorWindowMap, ARRAYNUMBER(TutorWindowMap))


// Constructor for the TutorWindow class.
TutorWindow::TutorWindow(FXApp* a)
	: FXMainWindow (a, windowTitle, NULL, NULL, DECOR_ALL, 0, 0, 800, 800) {

	// Set the user state variables.
	this->sessions    = NULL;
	this->curSession  = NULL;
	this->questions   = NULL;
	this->curQIndex   = -1;

	// Set up the graphics.
	// -------------------
	strcpy(wTitle, windowTitle);

  new FXTooltip(getApp());
  statusbar=new FXStatusbar(this,LAYOUT_SIDE_BOTTOM|LAYOUT_FILL_X|STATUSBAR_WITH_DRAGCORNER);
  menubar=new FXMenubar(this, LAYOUT_SIDE_TOP | LAYOUT_FILL_X);

  // File Menu
  filemenu=new FXMenuPane(this);
  new FXMenuCommand(filemenu, "New Session", NULL, this, ID_NEWSESSION);
  new FXMenuCommand(filemenu, "Switch Exercise", NULL, this, ID_SWITCHEX);
  new FXMenuCommand(filemenu, "Quit", NULL, this, ID_QUIT);
  new FXMenuTitle(menubar, "&File", NULL, filemenu);

  // Controls on right
  controls=new FXVerticalFrame(this,LAYOUT_SIDE_RIGHT|LAYOUT_FILL_Y|PACK_UNIFORM_WIDTH);
  new FXVerticalSeparator(this,LAYOUT_SIDE_RIGHT|LAYOUT_FILL_Y|SEPARATOR_GROOVE); 
  contents=new FXVerticalFrame(this,FRAME_SUNKEN|LAYOUT_FILL_X|LAYOUT_FILL_Y|LAYOUT_TOP|LAYOUT_LEFT,0,0,0,0,10,10,10,10);
  exerciseTitlebar = new FXLabel(contents, "Exercise", NULL, LAYOUT_CENTER_X | JUSTIFY_CENTER_X | LAYOUT_FILL_X);
  new FXHorizontalSeparator(contents, SEPARATOR_GROOVE|LAYOUT_FILL_X);
  canvas = new FXCanvas(contents, this, ID_CANVAS, FRAME_SUNKEN|FRAME_THICK|LAYOUT_FILL_X|LAYOUT_FILL_Y|LAYOUT_TOP|LAYOUT_LEFT);
	showStatsBtn = new FXCheckButton(controls, "Show statistics", this, ID_SHOWSTATS);
  showStatsBtn->setCheck(FALSE);

	// Create the switch exercise, quit and new session buttons.
	new FXButton(controls, "Switch exercise", NULL, this, ID_SWITCHEX, FRAME_RAISED | FRAME_THICK | LAYOUT_FILL_X);
	new FXButton(controls, "&New session", NULL, this, ID_NEWSESSION, FRAME_RAISED | FRAME_THICK | LAYOUT_FILL_X);
	new FXButton(controls, "&Quit", NULL, this, ID_QUIT, FRAME_RAISED | FRAME_THICK | LAYOUT_FILL_X);

	// Create the statistics dialog window.
	statsDlg = new StatsDialog(this, showStatsBtn);
}


// Destructor.
TutorWindow::~TutorWindow() {

	// Delete the user state variables.
	delete curSession;
	delete sessions;
	delete filemenu;
}


// Start
void TutorWindow::create() {
  FXMainWindow::create();
}


void TutorWindow::show() {
	FXMainWindow::show(PLACEMENT_SCREEN);
	canvas->update();
}


void TutorWindow::quit() {
	saveSession();
	if (sessions)
		sessions->write();

  getApp()->exit(0);
}


long TutorWindow::onMouseUp (FXObject*, FXSelector, void* ptr) {
	FXEvent *ev = (FXEvent*) ptr;
	int  response;
	int  inputNum;
	bool isCorrect;

	response = curQuestion->handleUserInput(Coord(ev->win_x, ev->win_y), inputNum, isCorrect);

	if (response) {
		canvas->update();

		if (inputNum != -1) {
			curSession->getUBNHandle()->updateState(inputNum, isCorrect);
			if (!isCorrect)
				curSession->getUBNHandle()->doBestAction(inputNum);
			else {
				ErrorBox::displayErrorMsg(getApp(), "Correct!");
				if (curQuestion->done()) {
					curSession->setCompletedQ(curQuestion->getLabel());
					if (!openQuestion()) {
						quit();
						return 1;
					}
				}
			}
			statsDlg->updateCanvas();
		}
	}

	return 1;
}


// Not yet implemented.
long TutorWindow::onCmdShowStats(FXObject*, FXSelector, void* ptr) {
	if (showStatsBtn->getCheck() == TRUE) {
		//showStatsBtn->setCheck(TRUE);
		statsDlg->show();
	}
	else {
		//showStatsBtn->setCheck(FALSE);
		statsDlg->hide();
	}
	return 1;
}


// Response to user hitting the Quit button.
long TutorWindow::onCmdQuit(FXObject*, FXSelector, void*) {
	quit();
  return 1;
}


// Response to user hitting the "new session" button.
long TutorWindow::onCmdNewSession(FXObject*, FXSelector, void*) {
	openSession();
	return 1;
}


// Response to user hitting "Switch Exercise" button.
long TutorWindow::onCmdSwitchExercise(FXObject*, FXSelector, void*) {
	openQuestion();
	return 1;
}


// Handle the clear message
long TutorWindow::onCanvasRepaint(FXObject*, FXSelector, void* ptr) {

	// FXCanvas *canvas=(FXCanvas*)sender;  // We don't need to do this since we know what the canvas is.
	FXEvent* ev = (FXEvent*) ptr;
  FXDCWindow dc(canvas, ev);

  dc.setForeground(canvas->getBackColor());
  dc.fillRectangle(ev->rect.x, ev->rect.y, ev->rect.w, ev->rect.h);

	// Draw all the stuff related to the question.
  curQuestion->draw(dc, canvas->getWidth(), canvas->getHeight());

  return 1;
}


bool TutorWindow::openSession() {

	char*     curSessionStr;
	Session*  tmpSession;
	char*     chosenSession;

	// Error checking.
	if (!sessions)
		return false;

	// An empty string ("") for NO current session.
	if (!curSession)
		curSessionStr = "";
	else
		curSessionStr = curSession->getName();
	
	chosenSession = OpenSessionDialog::getUserInput(this->getApp(), curSessionStr);
	if (!chosenSession && !curSession) {
		quit();
		return false;
	}
	if (!chosenSession)
		return false;
	
	// Next we have to create a session or find the old one.
	// First, let's see if we can find it in the session index.
	char* fileName = sessions->findSession(chosenSession);

	// If the file was not found, we have to create a new session.
	if (!fileName || !strlen(fileName)) {

		fileName = sessions->addSession(chosenSession);
		tmpSession = new Session(fileName, chosenSession, this->getApp());
	}
	else {
		// Create the new session and open it up.
		tmpSession = new Session(fileName, chosenSession, this->getApp());
		tmpSession->read();
	}

	if (!tmpSession->good) {
		quit();
		return false;
	}

	// Since everything is good, we need to save and get rid of all
	// the data structures associated with the old session.
	saveSession();

	// Now let's actually load all the data structures associated with the new session.
	curSession = tmpSession;

	// FINALLY, let's load the new question.
	if (!openQuestion()) {
		quit();
		return false;
	}

	// Change the title at the top.
	strcpy(wTitle, windowTitle);
	strcat(wTitle, " - ");
	strcat(wTitle, curSession->getName());
	setTitle(wTitle);
	statsDlg->setUserTitle(curSession->getName());

	// Change the exercise label.
	exerciseTitlebar->setText(curQuestion->getLabel());

	// Set the user belief net in the stats dialog
	// so we can draw the probability tables.
	statsDlg->ubn = curSession->getUBNHandle();
	statsDlg->updateCanvas();

	return true;
}


void TutorWindow::saveSession() {
	if (curSession && curSession->good) {
		; //curSession->write();
	}
}


// Return "false" if the user cancelled the open question.
bool TutorWindow::openQuestion() {

	int chosenQuestion = SwitchQuestionDialog::getUserInput(getApp(), curQIndex, questions,
		                                                      *curSession);
	if (chosenQuestion == -1)
		return false;

	// If the user did select a question, then load it.
	curQuestion = new Question(questions->filesIndex[chosenQuestion], 
														 questions->labelsIndex[chosenQuestion],
														 questions->descripIndex[chosenQuestion], this->getApp());
	if (!curQuestion->good)
		return false;

	// Set up the new question state. And once we've set it up, assign
	// it to the user belief net.
	stateOfQ = curQuestion->buildQuestionState();
	curSession->setQState(stateOfQ);

	// So far, so good. Let's let's set up the data structures for the question 
	// right now.
	curQIndex = chosenQuestion;

	return true;
}
