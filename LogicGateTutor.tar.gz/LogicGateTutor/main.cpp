// Project includes.
#include "ErrorBox.h"
#include "TutorWindow.h"

// Standard includes.
#include "fx.h"
#include <stdlib.h>
#include <time.h>


// Start the whole thing
int main(int argc,char *argv[]){

	// Set the rand seed.
	srand(clock());

	// First, we need to set up the main application stuff including
	// the main window. We make the application, open the display,
	// and create the main window.
  FXApp application("Logic Gate Tutor", "Peter");
  application.init(argc, argv);
  TutorWindow* tutorWin = new TutorWindow(&application);
  application.create();
 
	// The second thing we do is open up the sessions index and ask the user
	// to open up a session (or create a new one). We also open up the questions
	// index since we'll need that in the questioning process.
	SessionIndex* sessions = new SessionIndex(sessionIndexFileName, &application);
	QuestionIndex* questions = new QuestionIndex(problemIndexFileName, &application);
	tutorWin->setSessionIndex(sessions);
	tutorWin->setQuestionIndex(questions);
	if (!sessions->good || !questions->good)
		return 0;
	if (!tutorWin->openSession())
		return 0;

  // Run and first time repaint.
	tutorWin->show();

	int valToReturn = application.run();

	return valToReturn;
}
