#include "fx.h"
#include "LinkedList.h"
#include "CoordBox.h"
#include "LogicTable.h"
#include "LogicCalculus.h"


#define wireItemType    1

#define inputSyntax     "input"
#define gateSyntax      "gate"
#define wireSyntax      "wire"
#define userInputSyntax "user"
#define pictureSyntax   "picture"

#define squareWidth     16
#define squareHeight    16
#define squareImgWidth  17
#define squareImgHeight 17
#define okImgWidth      34
#define okImgHeight     34

#define userInputResponseInvalid     -1
#define userInputResponseCorrect     0
#define userInputResponseIncorrect   1
#define userInputResponseChange      2


// CLASS OutputElem
// ----------------
class OutputElem {

	public:	
		virtual LogicTable getOutput() { return LogicTable(); }
		virtual void       addInputWire(OutputElem* w) { }
		virtual bool       connectedToElem(OutputElem* w) { return false; }

		bool good;

	protected:
		static char* cpyLabel(const char* s);
		static char* setLabel(const char* s);
};


// CLASS Gate
// ----------
class Gate : public OutputElem {

	public:
		Gate(int gateType, const char* label);
		Gate(char** tokens, int n);
		~Gate();

		// Modifiers.
		void  addInputWire(OutputElem* w) { inputWires->addItem("", w, wireItemType); }

		// Accessors.
		LogicTable getOutput()   { return outputCalculated ? output: calculateOutput(); }
		char*      getLabel()    { return label; }
		int        getType()     { return gateType; }
		int        getNumInputWires() { return inputWires->getLength(); }
		bool       connectedToElem(OutputElem* w);

	protected:
		int        gateType;
		char*      label;
		LogicTable output;
		bool       outputCalculated;

		LinkedList* inputWires;

		LogicTable calculateOutput();
		void       init();
};


// Class InputNode
// ---------------
class InputNode : public OutputElem {

	public:
		InputNode(const char* label, LogicTable t);
		InputNode(char** tokens, int n);
		~InputNode();

		// Accessors.
		char*      getLabel()  { return label; }
		LogicTable getOutput() { return output; }
		bool       connectedToElem(OutputElem* w);
		
	protected:
		char*       label;
		LogicTable  output;
};


// Class Wire
// ----------
class Wire : public OutputElem {

	public:
		Wire(OutputElem* inElem, OutputElem* outElem);
		Wire(char** tokens, int n, LinkedList* gates, LinkedList* inputs);
		~Wire();

		// Accessors.
		LogicTable  getOutput()   { return calculateOutput(); }
		bool        connectedToElem(OutputElem* w);

		bool good;

	protected:
		OutputElem*  inElem;
		OutputElem*  outElem;

		LogicTable  calculateOutput();
		void        init();
};


// CLASS UserInput
// ---------------
class UserInput {

	public:
		UserInput(OutputElem* w);
		UserInput(char** tokens, int n, LinkedList* gates);

		bool connectedToElem(OutputElem* w);
		int  handleUserInput(Coord pt);
		void draw(FXDC& dc, int xoffset, int yoffset, FXImage* okImage, 
				  		FXImage* sq0Image, FXImage* sq1Image);

		bool good;
		bool correct;

	protected:
		OutputElem* w;
		CoordBox    okBox;
		CoordBox    outputBox;
		LogicTable  output;
		LogicTable  userValues;

		void        init();
};
