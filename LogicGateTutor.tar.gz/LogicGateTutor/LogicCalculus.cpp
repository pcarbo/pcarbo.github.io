#include "LogicCalculus.h"

int LogicCalculus::unary (int x, int gateType) {

	int result;

	switch (gateType) {
		case gateTypeNone:
			result = x;
			break;
		case gateTypeNOT:
			result = !x;
			break;
		case gateTypeZero:
			result = 0;
			break;
	}

	return result;
}


int LogicCalculus::binary (int x, int y, int gateType) {
	
	int result;

	switch (gateType) {
		case gateTypeAND:
			result = x && y;
			break;
		case gateTypeOR:
			result = x || y;
			break;
		case gateTypeXOR:
			result = (y && !x) || (!y && x);
	}

	return result;
}