#include "Stoker.h"
#include <string>

// As input, it is given a string of characters and a delimiter. It will
// parse the string into a series of tokens, and return as output an
// array of strings. It also stores in "n" the number of tokens.
// It treats the line as if it is in a text with words.
char** Stoker::tokenize (const char* s, int& n, char delim = ' ') {
	
	bool         inWord = false;
	const char*  wrdStart;
	int          nChars;
	char**       tokens = new char*[maxNumTokens];
	n = 0;
	
	for (const char* t = s; true; t++) {
		if (!inWord && *t != delim) {
			inWord = true;
			wrdStart = t;
			nChars = 0;
		}
		else if (inWord && (*t == delim || *t == 0)) {
			inWord = false;
			tokens[n] = new char[nChars + 1];
			strncpy(tokens[n], wrdStart, nChars);
			tokens[n][nChars] = 0;
			n++;

			if (*t == 0)
				break;
		}

		nChars++;
	}

	char** result = new char*[n];
	for (int i = 0; i < n; i++)
		result[i] = tokens[i];
	delete [] tokens;

	return result;
}


// As input, it is given a string of characters and a delimiter. It will
// parse the string into a series of tokens, and return as output an
// array of strings. It also stores in "n" the number of tokens.
// It treats the line as if it is in a spreadsheet. It does not
// include the delimiter in the token strings.
char** Stoker::tokenizeSpreadsheet (const char* s, int& n, char delim = '\t') {

	char** tokens   = new char*[maxNumTokens];
	int    nChars = 0;
	int    i;
	char   c;
	n = 0;

	for (i = 0; true; i++) {

		c = s[i];

		if (c == delim || c == 0) {
			tokens[n] = new char[nChars + 1];
			strncpy(tokens[n], &s[i - nChars], nChars);
			tokens[n][nChars] = 0;

			n++;
			nChars = 0;

			if (c == 0)
				break;
		}

		nChars++;
	}

	char** result = new char*[n];
	for (i = 0; i < n; i++)
		result[i] = tokens[i];
	delete [] tokens;

	return result;
}
