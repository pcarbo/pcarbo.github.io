// Project includes.
#include "SwitchQuestionDialog.h"
#include "ErrorBox.h"

// Standard includes.
#include <string>

static int             selectedQuestion  = -1;
static FXText*         gUpdateText       = NULL;
static QuestionIndex*  gQIndex           = NULL;

const unsigned char minidoc1[]={
  0x47,0x49,0x46,0x38,0x37,0x61,0x10,0x00,0x10,0x00,0xf1,0x00,0x00,0xbf,0xbf,0xbf,
  0x00,0x00,0x00,0xff,0xff,0xff,0x7f,0x7f,0x7f,0x2c,0x00,0x00,0x00,0x00,0x10,0x00,
  0x10,0x00,0x00,0x02,0x39,0x84,0x8f,0x89,0xc1,0x1d,0x7a,0x82,0x98,0x93,0x41,0x20,
  0x87,0x16,0xf2,0x29,0x49,0x71,0xcd,0x27,0x68,0x9b,0x16,0x0c,0x09,0x18,0x56,0xea,
  0x52,0x9a,0x5b,0xba,0xb6,0x14,0x0d,0xcb,0xf3,0x1b,0xd9,0x6e,0xad,0x1b,0x70,0x78,
  0x06,0x56,0x0b,0x17,0x71,0x28,0x89,0x86,0xa0,0xec,0x02,0x05,0x14,0x00,0x00,0x3b
  };


// Function prototypes.
char* addWhitespace (const char* s, unsigned int width);

// Function implementation map
FXDEFMAP(SwitchQuestionDialog) SwitchQuestionDialogMap[]={
  FXMAPFUNC(SEL_COMMAND, SwitchQuestionDialog::ID_SELECTQ, SwitchQuestionDialog::onCmdSelectListItem),
};

FXIMPLEMENT(SwitchQuestionDialog, FXDialogBox, SwitchQuestionDialogMap, ARRAYNUMBER(SwitchQuestionDialogMap))

SwitchQuestionDialog::SwitchQuestionDialog(FXApp* owner, QuestionIndex* qi, Session& ses)
 : FXDialogBox(owner, "Logic Gate Exercise", DECOR_TITLE | DECOR_BORDER,0,0,300,380) {

  // Bottom buttons
  buttons = new FXHorizontalFrame(this, LAYOUT_SIDE_BOTTOM|FRAME_NONE|LAYOUT_FILL_X|PACK_UNIFORM_WIDTH,0,0,0,0,40,40,20,20);

  // Separator
  new FXHorizontalSeparator(this,LAYOUT_SIDE_BOTTOM|LAYOUT_FILL_X|SEPARATOR_GROOVE);

  // Contents
  contents = new FXVerticalFrame(this,LAYOUT_SIDE_TOP|FRAME_NONE|LAYOUT_FILL_X|LAYOUT_FILL_Y|PACK_UNIFORM_WIDTH);

	// List of exercises.
	doc = new FXGIFIcon(getApp(),minidoc1);
	new FXLabel(contents,addWhitespace("Choose an exercise",questionListWidth),NULL,0,0,0,0,0,0,0,4,0);
	listOfQs = new FXList(contents, 1, this, ID_SELECTQ, LIST_EXTENDEDSELECT|LAYOUT_FILL_Y|LAYOUT_FILL_X); //new QuestionListBox(contents, this, qi, text1);
  text1 = new FXText(contents, NULL, 0, TEXT_READONLY | TEXT_WORDWRAP);
	text1->setText(addWhitespace("", questionListWidth));

	gUpdateText = text1;
	gQIndex = qi;

	// Add the exercises to the list.
	for (int i = 0; i < qi->numQuestions; i++) {
		if (ses.qIsCompleted(qi->labelsIndex[i])) {
			char s[1024];
			strcpy(s, qi->labelsIndex[i]);
			strcat(s, " (completed)");
			listOfQs->appendItem(addWhitespace(s, questionListWidth), doc);
		}
		else
			listOfQs->appendItem(addWhitespace(qi->labelsIndex[i], questionListWidth), doc);
	}

  // Accept
  new FXButton(buttons,"OK",NULL,this,ID_ACCEPT,FRAME_RAISED|FRAME_THICK|LAYOUT_CENTER_X|LAYOUT_CENTER_Y);

  // Cancel
  new FXButton(buttons,"Cancel",NULL,this,ID_CANCEL,FRAME_RAISED|FRAME_THICK|LAYOUT_CENTER_X|LAYOUT_CENTER_Y);
}


SwitchQuestionDialog::~SwitchQuestionDialog() {
	delete doc;
}


long SwitchQuestionDialog::onCmdSelectListItem(FXObject* obj, FXSelector sel, void* ptr) {

	FXList*    theList = (FXList*) obj;
	int           item = (int) ptr;

	gUpdateText->setText(gQIndex->descripIndex[item]);

	// Set the selected question.
	selectedQuestion = item;

	return 1;
}


int SwitchQuestionDialog::getUserInput(FXApp* owner, int curQIndex, QuestionIndex* qi,
																			 Session& ses) {

	// Create the new dialog and display it.
	SwitchQuestionDialog sqDialog(owner, qi, ses);
	selectedQuestion = -1;
	int result = sqDialog.execute();

	// If the user hit "cancel" or did not select a question and we need a 
	// question to be selected, then we quit.
	if ((selectedQuestion == -1 || !result) && (curQIndex == -1)) {
		ErrorBox::displayErrorMsg(owner, "You did not choose a question. Goodbye!");
		return -1;
	}
	// If the user hit "cancel" or did not select a question and we DON'T need
	// a question to be selected, then don't do anything.
	else if (selectedQuestion == -1 || !result)
		return -1;
	else
		return selectedQuestion;
}


// Functions that aren't part of the SwitchQuestionDialog class.
// ----------------------------------------------------------------------------------------------

char* addWhitespace (const char* s, unsigned int width) {

	char* t = new char[width + 1];
	strcpy(t, s);

	// Add the 0 character at the end.
	t[width] = 0;

	// Fill in the rest of the characters with spaces.
	for (unsigned int i = strlen(s); i < width; i++)
		t[i] = ' ';

	return t;
}
