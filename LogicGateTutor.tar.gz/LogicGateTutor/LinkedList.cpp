#include "LinkedList.h"
#include <string>


// CLASS LinkedListElem methods
// ----------------------------
LinkedListElem::LinkedListElem (const char* label, void* infoPtr, int type) {

	this->infoPtr = infoPtr;
	next          = NULL;

	this->label   = new char[strlen(label) + 1];
	strcpy(this->label, label);
}


LinkedListElem::~LinkedListElem() {
	delete label;
}


// CLASS LinkedList methods
// ------------------------
LinkedList::LinkedList() {
	first = last = cur = NULL;
}


int LinkedList::getLength() {
	int n = 0;
	LinkedListElem* cur = first;
	while (cur) {
		cur = cur->getNext();
		n++;
	}

	return n;
}


void LinkedList::addItem(LinkedListElem* item) {
	if (!first) {
		first = last = item;
	}
	else {
		last->setNext(item);
		last = item;
	}
}


void LinkedList::addItem(const char* label, void* infoPtr, int type) {
	LinkedListElem* newItem = new LinkedListElem(label, infoPtr, type);
	addItem(newItem);
}


LinkedListElem* LinkedList::getItem(const char* label) {
	LinkedListElem* curItem = first;
	while (curItem) {
		if (!strcmp(curItem->getLabel(), label))
			return curItem;
		curItem = curItem->getNext();
	}

	return NULL;
}


void* LinkedList::getInfo(const char* label) {
	LinkedListElem* theItem = getItem(label);
	if (theItem)
		return theItem->getInfo();
	else
		return NULL;
}


int LinkedList::getType(const char* label) {
	LinkedListElem* theItem = getItem(label);
	if (theItem)
		return theItem->getType();
	else
		return 0;
}


LinkedListElem* LinkedList::getNextItem() {
	LinkedListElem* tmp = cur;
	if (cur)
		cur = cur->getNext();
	return tmp;
}


const char* LinkedList::getNextLabel() {
	LinkedListElem* nextItem = getNextItem();
	if (nextItem)
		return nextItem->getLabel();
	else
		return NULL;
}


int LinkedList::getNextType() {
	LinkedListElem* nextItem = getNextItem();
	if (nextItem)
		return nextItem->getType();
	else
		return 0;
}


void* LinkedList::getNextInfo() {
	LinkedListElem* nextItem = getNextItem();
	if (nextItem)
		return nextItem->getInfo();
	else
		return NULL;
}
