#include "UserState.h"

UserState::UserState() {

	// Create the knowledge states.
	for (int i = 0; i < totalNumUserStates; i++) {
		int newNode;

		bnUserStates[i] = newNode = bn.AddNode(DSL_CPT, userStateNames[i]);

		// Add the outcomes to each state.
		DSL_stringArray someNames;
		someNames.Add("True");
		someNames.Add("False");
		bn.GetNode(newNode)->Definition()->SetNumberOfOutcomes(someNames);
	}

	// Now we need to add the arcs between the knowledge states.
	// At this point, we don't need to add any arcs for the affective 
	// state.
	//                     Parent                           Child
	bn.AddArc(bnUserStates[genKnowledgeState], bnUserStates[gatesState]);
	bn.AddArc(bnUserStates[genKnowledgeState], bnUserStates[CombiningAbility]);
	bn.AddArc(bnUserStates[gatesState], bnUserStates[andState]);
	bn.AddArc(bnUserStates[gatesState], bnUserStates[orState]);
	bn.AddArc(bnUserStates[gatesState], bnUserStates[xorState]);
	bn.AddArc(bnUserStates[gatesState], bnUserStates[notState]);

	// Next, we need to set the conditional probability tables for the 
	// arcs added.

	// Finally, we need to set the priors of the states.
}