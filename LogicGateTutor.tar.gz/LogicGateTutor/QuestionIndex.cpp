// Project includes.
#include "QuestionIndex.h"
#include "ErrorBox.h"

// Standard includes.
#include <iostream>
#include <fstream>

using namespace std;

// The class constructor.
QuestionIndex::QuestionIndex (char* fileName, FXApp* owner) {

	app  = owner;
	good = false;

	// Copy the name of the file into "indexFile".
	indexFile = new char[strlen(fileName) + 1];
	strcpy(indexFile, fileName);

	// Open the file for input only.
	ifstream f = ifstream(fileName);
	char     buf[256];
	char*    newStr;

	// Check to make sure that the question index was opened successfully.
	if (!f.is_open()) {
		ErrorBox::displayErrorMsg(app, "Unable to open question index file.");
		return;
	}

	numQuestions = 0;

	// Read in the question entries from the file.
	while (!f.eof()) {

		// Get the question label and put it in the array.
		f.getline(buf, 255);
		if (!strlen(buf))
			break;
		newStr = new char[strlen(buf) + 1];
		strcpy(newStr, buf);
		labelsIndex[numQuestions] = newStr;

		// Get the file name and put it in the array.
		f.getline(buf, 255);
		if (!strlen(buf))
			break;
		newStr = new char[strlen(buf) + 1];
		strcpy(newStr, buf);
		filesIndex[numQuestions] = newStr;
		
		// Get the description of the question and put it in the array.
		f.getline(buf, 255);
		if (!strlen(buf))
			break;
		newStr = new char[strlen(buf) + 1];
		strcpy(newStr, buf);
		descripIndex[numQuestions] = newStr;

		numQuestions++;
	}

	// Close the file.
	f.close();

	// Everything was completed successfully, so we can set the "good"
	// flag to "true".
	good = true;
}


// The class destructor.
QuestionIndex::~QuestionIndex() {

	// Delete all the data structures we allocated.
	for (int i = 0; i < numQuestions; i++) {
		delete [] labelsIndex[i];
		delete [] filesIndex[i];
		delete [] descripIndex[i];
	}

	delete [] indexFile;
}
