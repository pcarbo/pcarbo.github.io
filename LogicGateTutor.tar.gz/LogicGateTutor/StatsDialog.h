#include "fx.h"
#include "UserBeliefNet.h"

// CLASS StatsDialog
// -----------------------
// This is a non-modal dialog used to display some statistics we
// generate about the user.
class StatsDialog : public FXDialogBox {
		FXDECLARE(StatsDialog)

	public:
		StatsDialog(FXWindow* owner, FXCheckButton* correspBtn);
		~StatsDialog() { };
		
		void updateCanvas() { canvas->update(); }
		void show();
		void setUserTitle(const char* userStr);
		
		long onCanvasRepaint(FXObject*, FXSelector, void* ptr);
		long onCmdClose(FXObject* obj, FXSelector sel, void* ptr);

		enum {
			ID_CANVAS=FXDialogBox::ID_LAST,
		  ID_WELL
		};

		UserBeliefNet*     ubn;

	protected:
	  FXVerticalFrame*   contents;
	  FXHorizontalFrame* buttons;
		FXCheckButton*     showStatsBtn;
		FXCanvas*          canvas;        // Canvas to draw into
		FXLabel*           userLabel;

		StatsDialog() { }
};
