#ifndef SESSION_DEFINED

#define SESSION_DEFINED

#include "fx.h"
#include "UserBeliefNet.h"
#include "QuestionIndex.h"

#define sessionExtension       ".ses"


// CLASS Session
// -------------
// This keeps track of all the information in the user's session. We're going
// to write this information into a file at the end of a session so we can
// keep track of it over many uses of the program.
class Session {

	public:
		Session(char* fileName, char* name, FXApp* owner);
		~Session();

		char*          getName()      { return name; }
		bool           qIsCompleted(const char* label);
		void           setCompletedQ(char* label) { 
			completedQs[numCompletedQs] = label;
			numCompletedQs++; }
		UserBeliefNet* getUBNHandle() { return &ubn; }
		void           setQState(QuestionState* qs) { ubn.setQuestion(qs); }
		void  read();
		void  write();

		// The "good" flag.
		bool good;

	protected:
		FXApp*        app;
		char*         file;
		char*         name;

		UserBeliefNet ubn;
		int           numCompletedQs;
		char*         completedQs[maxNumQuestions];
};

#endif