// Project includes.
#include "Question.h"
#include "ErrorBox.h"
#include "Stoker.h"
#include "QuestionPictures.h"
#include "ok.h"
#include "square0.h"
#include "square1.h"

// Standard includes.
#include <fstream>
#include <iostream>
#include <string>
#include <stdlib.h>
#include <ctype.h>

using namespace std;


// CLASS Question methods
// ----------------------
Question::Question (char* fileName, char* label, char* descrip, FXApp* owner) {

	good = false;
	app  = owner;

	// Copy the file name.
	file = new char[strlen(fileName) + 1];
	strcpy(file, fileName);

	// Copy the label.
	this->label = new char[strlen(label) + 1];
	strcpy(this->label, label);

	// Copy the description.
	this->descrip = new char[strlen(descrip) + 1];
	strcpy(this->descrip, descrip);

	// Now read in the information from the question file.
	ifstream f = ifstream(file);

	// Check to make sure that the file was opened successfully.
	if (!f.is_open()) {
		ErrorBox::displayErrorMsg(app, "Unable to open question file.");
		return;
	}

	// Read in all the data structures here.
  // ------------------------------------

	// Initialise the linked lists.
	wires      = new LinkedList();
	gates      = new LinkedList();
	inputs     = new LinkedList();
	userInputs = new LinkedList();

	char*  buffer = new char[1024];
	int    numTokens;
	char** tokens;
	char*  firstToken;

	while (!f.eof()) {

		// Get the next line in the file.
		f.getline(buffer, 1023, '\n');

		// We want to separate the items in the line.
		tokens = Stoker::tokenize(buffer, numTokens, ' ');

		// If there are no tokens, then we just skip this line and move 
		// onto the next one.
		if (!numTokens || !strlen(buffer))
			continue;

		// Check to see what the first token is. That will tell us 
		// what kind of object to make.
		firstToken = tokens[0];
		if (!stricmp(inputSyntax, firstToken)) {

			// New input node.
			InputNode* newItem = new InputNode(tokens, numTokens);
			inputs->addItem(newItem->getLabel(), newItem, 0);

			if (!newItem->good) {
				char msg[1024];
				strcpy(msg, "Bad syntax: ");
				strcat(msg, buffer);
				ErrorBox::displayErrorMsg(app, msg);
				return;
			}
		}
		else if (!stricmp(gateSyntax, firstToken)) {

			// New gate.
			Gate* newItem = new Gate(tokens, numTokens);
			gates->addItem(newItem->getLabel(), newItem, 0);

			if (!newItem->good) {
				char msg[1024];
				strcpy(msg, "Bad syntax: ");
				strcat(msg, buffer);
				ErrorBox::displayErrorMsg(app, msg);
				return;
			}
		}
		else if (!stricmp(wireSyntax, firstToken)) {

			// New wire.
			Wire* newItem = new Wire(tokens, numTokens, gates, inputs);
			wires->addItem("", newItem, 0);

			if (!newItem->good) {
				char msg[1024];
				strcpy(msg, "Bad syntax: ");
				strcat(msg, buffer);
				ErrorBox::displayErrorMsg(app, msg);
				return;
			}
		}
		else if (!stricmp(userInputSyntax, firstToken)) {

			// New user input.
			UserInput* newItem = new UserInput(tokens, numTokens, gates);
			userInputs->addItem("", newItem, 0);

			if (!newItem->good) {
				char msg[1024];
				strcpy(msg, "Bad syntax: ");
				strcat(msg, buffer);
				ErrorBox::displayErrorMsg(app, msg);
				return;
			}
		}
		else if (!stricmp(pictureSyntax, firstToken)) {

			// The number of the picture.
			if (numTokens < 2) {
				char msg[1024];
				strcpy(msg, "Bad syntax: ");
				strcat(msg, buffer);
				ErrorBox::displayErrorMsg(app, msg);
				return;
			}

			int pictureNum = atoi(tokens[1]);
			picture = QuestionPictures::getPicture(pictureNum, pictureWidth, pictureHeight);
		}
		else {

			char msg[1024];
			strcpy(msg, "Bad syntax: ");
			strcat(msg, buffer);
			ErrorBox::displayErrorMsg(app, msg);
			return;
		}
	}

	f.close();

	// Set the picture offsets.
	pictureOffsetX = -1;
	pictureOffsetY = -1;

	// Open the images.
	image    = new FXGIFImage(app, picture);
	okImage  = new FXGIFImage(app, ok);
	sq0Image = new FXGIFImage(app, square0);
	sq1Image = new FXGIFImage(app, square1);
	if (!image || !okImage || !sq0Image || !sq1Image) {
		ErrorBox::displayErrorMsg(app, "Unable to acquire graphics for question.");
		return;
	}

	image->create();
	okImage->create();
	sq0Image->create();
	sq1Image->create();

	good = true;
}


Question::~Question() {

	delete file;
	delete label;
	delete descrip;

	gates->resetIterator();
	while (gates->thereIsNext())
		delete gates->getNextInfo();

	inputs->resetIterator();
	while (inputs->thereIsNext())
		delete inputs->getNextInfo();

	wires->resetIterator();
	while (wires->thereIsNext())
		delete wires->getNextInfo();

	userInputs->resetIterator();
	while (userInputs->thereIsNext())
		delete userInputs->getNextInfo();

	delete gates;
	delete inputs;
	delete wires;
	delete userInputs;
	delete image;
	delete okImage;
	delete sq0Image;
	delete sq1Image;
}


void Question::draw (FXDC& dc, FXint width, FXint height) {

	// Calculate offsets.
	pictureOffsetX = 6;
  pictureOffsetY = 6;

	// Draw the picture.
	dc.drawImage(image, pictureOffsetX, pictureOffsetY);

	// Draw the user inputs.
	userInputs->resetIterator();
	while (userInputs->thereIsNext())
		((UserInput*) userInputs->getNextInfo())->draw(dc, pictureOffsetX, pictureOffsetY,
		                                               okImage, sq0Image, sq1Image);
}


QuestionState* Question::buildQuestionState() {

	int i, j;

	QuestionState* result = new QuestionState(userInputs->getLength(), gates->getLength());

	// Set the gate types.
	gates->resetIterator();
	i = 0;
	while (gates->thereIsNext()) {
		result->setGateType(i, ((Gate*) gates->getNextInfo())->getType());
		i++;
	}
	
	// Find out which inputs are connected to the gates.
	i = 0;
	gates->resetIterator();
	while (gates->thereIsNext()) {

		j = 0;
		OutputElem* g = (OutputElem*) gates->getNextInfo();
		userInputs->resetIterator();
		while (userInputs->thereIsNext()) {

			if (((UserInput*) userInputs->getNextInfo())->connectedToElem(g))
				result->addInputToGate(i, j);
			j++;
		}

		i++;
	}

	return result;
}


bool Question::handleUserInput(Coord pt, int& inputNum, bool& inputGood) {

	int  response;
	bool result;
	int  i;

	inputNum  = -1;
	result    = false;
	inputGood = false;

	pt.x = pt.x - pictureOffsetX;
	pt.y = pt.y - pictureOffsetY;

	userInputs->resetIterator();
	i = 0;
	while (userInputs->thereIsNext()) {
		response = ((UserInput*) userInputs->getNextInfo())->handleUserInput(pt);
		if (response != userInputResponseInvalid) {

			if (response == userInputResponseCorrect) {
				inputNum = i;
				inputGood = true;
			}
			else if (response == userInputResponseIncorrect) {
				inputNum = i;
				inputGood = false;
			}

			result = true;
			break;
		}
		i++;
	}

	return result;
}


bool Question::done() {

	userInputs->resetIterator();
	while (userInputs->thereIsNext())
		if (!((UserInput*) userInputs->getNextInfo())->correct)
			return false;

	return true;
}
