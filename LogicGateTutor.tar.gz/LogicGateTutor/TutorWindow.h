#include "fx.h"
#include "SessionIndex.h"
#include "Question.h"
#include "Session.h"
#include "OpenSessionDialog.h"
#include "SwitchQuestionDialog.h"
#include "StatsDialog.h"

#define windowTitle  "Logic Gate Tutor"


// CLASS TutorWindow
// -----------------
class TutorWindow : public FXMainWindow {
  FXDECLARE(TutorWindow)

	public:
		TutorWindow(FXApp* a);
		~TutorWindow();
		void create();
		void show();
		void quit();

		void setSessionIndex(SessionIndex* si) { sessions = si; }
		void setQuestionIndex(QuestionIndex* qi) { questions = qi; }

		bool openSession();
		void saveSession();
		bool openQuestion();

		long onMouseUp(FXObject*, FXSelector, void* ptr);
		long onCmdQuit(FXObject*, FXSelector, void*);
		long onCmdShowStats(FXObject*, FXSelector, void*);
		long onCmdNewSession(FXObject*, FXSelector, void*);
		long onCmdSwitchExercise(FXObject*, FXSelector, void*);
		long onCanvasRepaint(FXObject*, FXSelector, void*);

		enum {
    ID_CANVAS=FXMainWindow::ID_LAST,
    ID_WELL,
    ID_ICON_AFTER_TEXT,
    ID_ICON_CENTER_HOR,
    ID_ICON_ABOVE_TEXT,
    ID_ICON_BELOW_TEXT,
    ID_ICON_CENTER_VER,
    ID_JUST_CENTER_X,
    ID_JUST_LEFT,
    ID_JUST_RIGHT,
    ID_JUST_HOR_APART,
    ID_JUST_CENTER_Y,
    ID_JUST_TOP,
    ID_JUST_BOTTOM,
    ID_JUST_VER_APART,
    ID_SHOWSTATS,
		ID_SWITCHEX,
		ID_NEWSESSION,
    ID_QUIT,
    ID_DEBUG
		};

	protected:
		SessionIndex*      sessions;			// List of all the sessions to choose from.
		Session*					 curSession;		// The session we are currently in.
		QuestionIndex*     questions;			// The list of all the questions to choose from.
		Question*          curQuestion;   // The question we are currently in.
		int                curQIndex;
		QuestionState*     stateOfQ;			// The state of the question.

		FXStatusbar*       statusbar;     // Status line
		FXVerticalFrame*   contents;      // Container for button
		FXVerticalFrame*   controls;      // Switchs to set various modes
		FXLabel*           exerciseTitlebar;
	  FXMenubar*         menubar;
		FXMenuPane*        filemenu;
		FXCanvas*          canvas;        // Canvas to draw into
		FXCheckButton*     showStatsBtn;  // Button for showing the stats dialog.
		StatsDialog*       statsDlg;      // Non-modal stats dialog window. 
		char               wTitle[355];   // The main title of the window.

		TutorWindow() { } 
};