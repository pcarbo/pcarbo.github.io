// CLASS LinkedListElem
// --------------------
class LinkedListElem {
	
	public:
		// Constructor.
		LinkedListElem(const char* label, void* infoPtr, int type);
		~LinkedListElem();

		// Modifiers.
		void setNext(LinkedListElem* next) { this->next = next; }
    
		// Accessors.
		LinkedListElem* getNext()  { return next; }
		int             getType()  { return type; }
		char*           getLabel() { return label; }
		void*           getInfo()  { return infoPtr; }

	protected:
		int             type;
		void*           infoPtr;
		char*           label;
		LinkedListElem* next;
};


// CLASS LinkedList
// ----------------
class LinkedList {

	public:
		// Constructor.
		LinkedList();

		// Modifiers.
		void addItem(LinkedListElem* item);
		void addItem(const char* label, void* infoPtr, int type);

		// Accessors.
		LinkedListElem* getLast()       { return last; }
		LinkedListElem* getItem(const char* label);
		void*           getInfo(const char* label);
		int             getType(const char* label);
		int             getLength();

		// Iterator stuff.
		void            resetIterator() { cur = first; }
		bool            thereIsNext()   { return cur ? true : false; }
		LinkedListElem* getNextItem();
		const char*     getNextLabel();
		void*           getNextInfo();
		int             getNextType();

	protected:
		LinkedListElem*  first;
		LinkedListElem*  last;
		LinkedListElem*  cur;
};


