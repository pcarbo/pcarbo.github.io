#include "QuestionElements.h"
#include "fx.h"


// CLASS OutputElem methods
// ------------------------

char* OutputElem::cpyLabel(const char* s) {

	char* result = new char[strlen(s) + 1];
	strcpy(result, s);

	return result;
}


char* OutputElem::setLabel(const char* s) {

	char* result = new char[strlen(s) - 1];
	strncpy(result, &s[1], strlen(s) - 2);
	result[strlen(s) - 2] = 0;

	return result;
}


// CLASS Gate methods
// ------------------
void Gate::init() {
	inputWires       = new LinkedList();
	outputCalculated = false; // We don't know the output yet.
}


Gate::Gate(int gateType, const char* label) {

	this->gateType = gateType;	
	this->label    = OutputElem::cpyLabel(label);

	init();
	good = true;
}


Gate::Gate(char** tokens, int n) {

	good = false;

	// Minimum number of tokens required is 4.
	if (n < 3)
		return;

	// Set the gate type.
	if (!stricmp(tokens[2], "AND"))
		gateType = gateTypeAND;
	else if (!stricmp(tokens[2], "OR"))
		gateType = gateTypeOR;
	else if (!stricmp(tokens[2], "XOR"))
		gateType = gateTypeXOR;
	else if (!stricmp(tokens[2], "NOT"))
		gateType = gateTypeNOT;

	// Set the label.
	label = OutputElem::setLabel(tokens[1]);

	// Other stuff.
	init();
	good = true;
}


Gate::~Gate() {
	delete label;
	delete inputWires;
}


LogicTable Gate::calculateOutput() {

	// If we have no outputs, then we generate default output.
	if (!inputWires->getLength())
		output = LogicTable();

	inputWires->resetIterator();

	if (gateType == gateTypeNOT) {
		output = ((OutputElem*) inputWires->getNextInfo())->getOutput();
		output = LogicTable(output, gateTypeNOT);
	}
	else {
		OutputElem* wire   = (OutputElem*) inputWires->getNextInfo();
		output             = wire->getOutput();
		wire               = (OutputElem*) inputWires->getNextInfo();
		LogicTable x;

		while (wire) {
			x = wire->getOutput();
			output = LogicTable(output, x, gateType);			
			wire = (OutputElem*) inputWires->getNextInfo();
		}
	}

	return output;
}


bool Gate::connectedToElem(OutputElem* w) {

	if (w == this)
		return true;

	inputWires->resetIterator();
	while (inputWires->thereIsNext())
		if (((OutputElem*) inputWires->getNextInfo())->connectedToElem(w))
			return true;

	return false;
}


// CLASS InputNode methods
// -----------------------
InputNode::InputNode(const char* label, LogicTable t) {

	// Set the input value.
	output = t;

	this->label = OutputElem::cpyLabel(label);
	strcpy(this->label, label);

	good = true;
}


InputNode::InputNode(char** tokens, int n) {

	good = false;

	// Minimum number of tokens required is 3.
	if (n < 2)
		return;

	// Set the label.
	label = OutputElem::setLabel(tokens[1]);

	// Set the output.
	if (n < 3 || !strlen(tokens[2]))
		output = LogicTable();
	else
		output = LogicTable(atoi(tokens[2]));

	good = true;
}


InputNode::~InputNode() {
	delete label;
}


bool InputNode::connectedToElem(OutputElem* w) {

	if (w == this)
		return true;
	else
		return false;
}


// CLASS UserInput methods
// -----------------------
void UserInput::init() {

	// Calculate the output. Therefore, we should
	// only add the UserInput nodes after the rest of the gates
	// and wires have been added to the network.
	output = w->getOutput();

	// Set up the user input logic table.
	userValues = LogicTable(output, gateTypeZero);

	// The user has not entered the correct value yet.
	correct = false;

	good = true;
}


UserInput::UserInput(OutputElem* w) { 
	this->w = w; 
	init();
}


UserInput::UserInput(char** tokens, int n, LinkedList* gates) {

	good = false;

	// Minimum number of tokens required is 3.
	if (n < 4)
		return;

	// Set the input gate.
	gates->resetIterator();
	OutputElem* item = (OutputElem*) gates->getInfo(tokens[1]);
	if (item)
		w = item;
	else
		return;

	init();

	// Set the bounding box for the "ok" input.
	Coord c = Coord(tokens[3]);
	okBox = CoordBox(c.x, c.y, c.x + okImgWidth, c.y + okImgHeight);

	// Set the bounding box for the 0s and 1s input.
	c = Coord(tokens[2]);
	outputBox = CoordBox(c.x, c.y, c.x + squareWidth, c.y + squareHeight * output.getSize());
}


int UserInput::handleUserInput(Coord pt) {

	// If the user has already entered the
	// correct response, do nothing.
	if (correct)
		return userInputResponseInvalid;
	// Check to see if the user clicked the "ok" button.
	else if (okBox.ptInBox(pt)) {

		// Check to see if the user's values are correct.
		if (LogicTable::areEqual(output, userValues)) {
			correct = true;
			return userInputResponseCorrect;
		}
		else
			return userInputResponseIncorrect;
	}
	// Check to see if the user clicked in order to enter a value
	// in the logic table.
	else if (outputBox.ptInBox(pt)) {

		// Find out which box exactly it is in!
		int h = (int) ((pt.y - outputBox.xy1.y) / squareHeight);
		userValues.setValue(h, 1 - userValues.getValue(h));

		return userInputResponseChange;
	}

	return userInputResponseInvalid;
}


void UserInput::draw(FXDC& dc, int xoffset, int yoffset, FXImage* okImage, 
										FXImage* sq0Image, FXImage* sq1Image) {

	// Draw the "ok" button.
	dc.drawImage(okImage, xoffset + (int) okBox.xy1.x, yoffset + (int) okBox.xy1.y);

	// Draw the squares.
	int h = 0;
	for (int i = 0; i < userValues.getSize(); i++, h += squareHeight) {
		if (userValues.getValue(i))
			dc.drawImage(sq1Image, xoffset + (int) outputBox.xy1.x, 
			             yoffset + (int) outputBox.xy1.y + h);
		else
			dc.drawImage(sq0Image, xoffset + (int) outputBox.xy1.x, 
			             yoffset + (int) outputBox.xy1.y + h);
	}
}


bool UserInput::connectedToElem(OutputElem* w) {
	return this->w->connectedToElem(w);	
}


// CLASS Wire methods
// ------------------
void Wire::init() {
	// Connect the wire to its output.
	outElem->addInputWire(this);
}


Wire::Wire(OutputElem* inElem, OutputElem* outElem) {

	// First set the input and output for the wire.
	this->inElem  = inElem;
	this->outElem = outElem;

	// Initialise the rest.
	init();

	good = true;
}


Wire::Wire(char** tokens, int n, LinkedList* gates, LinkedList* inputs) {

	good = false;

	// Minimum number of tokens required is 3.
	if (n < 3)
		return;

	// Set the input for the wire.
	inputs->resetIterator();
	OutputElem* item = (OutputElem*) inputs->getInfo(tokens[1]);
	if (item)
		inElem = item;
	else {
		item = (OutputElem*) gates->getInfo(tokens[1]);
		if (item)
			inElem = item;
		else
			return;
	}

	// Set the output for the wire.
	int i = 0;
	item = (OutputElem*) gates->getInfo(tokens[2]);
	if (item)
		outElem = item;
	else
		return;

	// Initialise the rest.
	init();

	good = true;
}


Wire::~Wire() { }


LogicTable Wire::calculateOutput() {
	return inElem->getOutput();
}


bool Wire::connectedToElem(OutputElem* w) {

	if (w == this)
		return true;
	else
		return inElem->connectedToElem(w);
}
