#include "QuestionPictures.h"


// Methods for class QuestionPictures.
const unsigned char* QuestionPictures::getPicture(int n, int& width, int& height) {

	width  = questionWidth;
	height = questionHeight;

	return listOfPictures[n-1];
}
