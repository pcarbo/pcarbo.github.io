// Project includes.
#include "StatsDialog.h"
#include "Session.h"

// Standard includes.


// Function implementation map.
FXDEFMAP(StatsDialog) StatsDialogMap[]={
	FXMAPFUNC(SEL_PAINT,    StatsDialog::ID_CANVAS,			 StatsDialog::onCanvasRepaint),
  FXMAPFUNC(SEL_COMMAND,  FXDialogBox::ID_CANCEL,      StatsDialog::onCmdClose),
  };

FXIMPLEMENT(StatsDialog, FXDialogBox, StatsDialogMap, ARRAYNUMBER(StatsDialogMap))


// StatsDialog constructor.
StatsDialog::StatsDialog(FXWindow* owner, FXCheckButton* correspBtn)
: FXDialogBox(owner, "Logic Gate Tutor - Statistics", DECOR_TITLE | DECOR_BORDER,0,0,320,440) {
 
	ubn = NULL;

	// Set the check button.
	showStatsBtn = correspBtn;

  // Bottom buttons
  buttons = new FXHorizontalFrame(this, LAYOUT_SIDE_BOTTOM|FRAME_NONE|LAYOUT_FILL_X|PACK_UNIFORM_WIDTH,0,0,0,0,40,40,20,20);

  // Separator
  new FXHorizontalSeparator(this,LAYOUT_SIDE_BOTTOM|LAYOUT_FILL_X|SEPARATOR_GROOVE);

  // Contents
  contents = new FXVerticalFrame(this,FRAME_NONE|LAYOUT_FILL_X|LAYOUT_FILL_Y|LAYOUT_TOP|LAYOUT_LEFT,0,0,0,0,10,10,10,10);
	userLabel = new FXLabel(contents, "User", NULL, LAYOUT_CENTER_X | JUSTIFY_CENTER_X | LAYOUT_FILL_X);
	canvas = new FXCanvas(contents, this, ID_CANVAS, FRAME_NONE|LAYOUT_FILL_X|LAYOUT_FILL_Y|LAYOUT_TOP|LAYOUT_LEFT);

  // Cancel
  new FXButton(buttons,"Close",NULL,this,ID_CANCEL,FRAME_RAISED|FRAME_THICK|LAYOUT_CENTER_X|LAYOUT_CENTER_Y);
}


void StatsDialog::show() {
	FXDialogBox::show();
	canvas->update();
}


void StatsDialog::setUserTitle(const char* userStr) {
	userLabel->setText(userStr);
}


// Handle the clear message
long StatsDialog::onCanvasRepaint(FXObject*, FXSelector, void* ptr) {

	FXEvent* ev = (FXEvent*) ptr;
  FXDCWindow dc(canvas, ev);

  dc.setForeground(canvas->getBackColor());
  dc.fillRectangle(ev->rect.x, ev->rect.y, ev->rect.w, ev->rect.h);

	if (ubn)
		ubn->draw(dc, canvas->getWidth(), canvas->getHeight());

  return 1;
}


long StatsDialog::onCmdClose(FXObject* obj, FXSelector sel, void* ptr) {
	
	// Uncheck the box.
	showStatsBtn->setCheck(FALSE);

	// Close the window.
	hide();

	return 1;
}
