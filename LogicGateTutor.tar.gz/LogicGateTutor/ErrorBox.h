#include "fx.h"

// We use the "ErrorBox" class to display urgent messages on the
// screen.
class ErrorBox : public FXDialogBox {
		FXDECLARE(ErrorBox)

	public:
		// The constructor and destructor. For the constructor,
		// in addition to the owner you also specify a string for
		// the message to display.
		ErrorBox(FXApp* owner, const char* msg);
		~ErrorBox() { };

		// This function will create, display and handle all the 
		// overhead for displaying the error message. All you 
		// have to provide is a pointer to the main application 
		// and a string message.
		static void displayErrorMsg (FXApp* owner, const char* msg);

		enum {
			ID_CANVAS=FXDialogBox::ID_LAST
		};

	protected:
		FXApp*             owner;				// Pointer to the owner application.
	  FXVerticalFrame*   contents;		// The error box has two frames.
	  FXHorizontalFrame* buttons;

		// This is just the default constructor in case the
		// system needs it.
		ErrorBox() { }
};


