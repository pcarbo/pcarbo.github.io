#include "fx.h"

// CLASS OpenSessionDialog
// -----------------------
// This dialog displays a text box for the user to enter his
// or her name.
class OpenSessionDialog : public FXDialogBox {
		FXDECLARE(OpenSessionDialog)

	public:
		OpenSessionDialog(FXApp* owner);
		~OpenSessionDialog() { };

		// Message handling.
		long onCmdTextChange(FXObject* obj, FXSelector sel, void* ptr);

		// This static function takes care of everything.
		static char* getUserInput(FXApp* owner, const char* curSessionName);

		enum {
			ID_CANVAS=FXDialogBox::ID_LAST,
			ID_TEXTFIELD
		};

	protected:
	  FXVerticalFrame*   contents;
	  FXHorizontalFrame* buttons;
		FXTextField*       textfield1;

		OpenSessionDialog() { }
};
