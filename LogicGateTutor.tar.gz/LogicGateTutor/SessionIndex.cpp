#include <iostream>
#include <fstream>

#include "SessionIndex.h"
#include "ErrorBox.h"

using namespace std;

// This is the constructor for the SessionIndex class.
SessionIndex::SessionIndex (char* fileName, FXApp* owner) {
	
	good = false;

	// Set the owner application.
	app = owner;

	// Copy the name of the file into "indexFile".
	indexFile = new char[strlen(fileName) + 1];
	strcpy(indexFile, fileName);

	// Open the file for input only.
	ifstream f = ifstream(fileName);
	char     buf[256];
	char*    newStr;

	// Check to make sure that the session index was opened successfully.
	if (!f.is_open()) {
		ErrorBox::displayErrorMsg(app, "Unable to open session index file.");
		return;
	}

	numSessions = 0;

	// Read in the session entries from the file.
	while (!f.eof()) {

		// Get the file name and put it in the array.
		f.getline(buf, 255, ' ');

		// If the file name is empty, stop. Otherwise, put it in 
		// the array.
		if (!strlen(buf))
			break;
		newStr = new char[strlen(buf) + 1];
		strcpy(newStr, buf);
		filesIndex[numSessions] = newStr;

		// Get the name of the person and put it in the array.
		f.getline(buf, 255);

		// If the session name is empty, stop. Otherwise, put it in
		// the array.
		if (!strlen(buf))
			break;
		newStr = new char[strlen(buf) + 1];
		strcpy(newStr, buf);
		namesIndex[numSessions] = newStr;

		numSessions++;
	}

	// Close the file.
	f.close();

	// Set the "good" flag to "true" to indicate that everything
	// is alright.
	good = true;
}


// Class destructor.
SessionIndex::~SessionIndex() {

	// Delete all the data structures we allocated.
	for (int i = 0; i < numSessions; i++) {
		delete [] namesIndex[i];
		delete [] filesIndex[i];
	}

	delete [] indexFile;
}

// Return the file name associated with the name, or NULL if it's not found.
// Note that the search is case insensitive.
char* SessionIndex::findSession(char* name) {

	for (int i = 0; i < numSessions; i++) {
		if (!stricmp(namesIndex[i], name))
			return filesIndex[i];
	}

	return NULL;
}


// Check to see if a file exists in the index. Return "false" if 
// unsuccessful.
bool SessionIndex::filenameInIndex(char* fileName) {

	for (int i = 0; i < numSessions; i++)
		if (!stricmp(fileName, filesIndex[i]))
			return true;

	return false;
}


// Add a session record to the session index. Return NULL
// if unsuccessful.
char* SessionIndex::addSession(char* name) {

	// Error checking.
	if (!name || !strlen(name))
		return NULL;

	// Copy the string.
	char* newStr = new char[strlen(name) + 1];
	strcpy(newStr, name);
	namesIndex[numSessions] = newStr;

	// Create the filename. First copy the name string and then
	// switch all the non-alphanumeric characters to underscores.
	// 4 more characters are added to the length to take into account
	// the extension '.ses'.
	newStr = new char[strlen(name) + 4 + 1];
	strcpy(newStr, name);

	// Convert the letters of the file name to lower case.
	for (int i = 0; i < strlen(newStr); i++)
		if (isalpha(newStr[i]))
			newStr[i] = tolower(newStr[i]);

	// '0' == 48     '9' == 57
	// 'a' == 97     'z' == 122
	char c;
	for (i = 0; newStr[i] != 0; i++) {
		c = newStr[i];
		if (!((c > 47 && c < 58) || (c > 96 && c < 121)))
			newStr[i] = '_';
	}
	strcat(newStr, sessionExtension);
	filesIndex[numSessions] = newStr;
		
	numSessions++;

	return newStr;
}
	

// Write all the information in the session index to the file.
void SessionIndex::write() {

	// Open up the file for writing.
	ofstream f = ofstream(indexFile, ios::trunc);

	// If we are unable to open the file, just display an error
	// message and quit.
	if (!f.is_open()) {
		ErrorBox::displayErrorMsg(app, "Unable to write the session index file.");
		return;
	}

	// Write all the names and file names.
	for (int i = 0; i < numSessions; i++)
		f << filesIndex[i] << ' ' << namesIndex[i] << endl;

	// Close the file.
	f.close();
}
