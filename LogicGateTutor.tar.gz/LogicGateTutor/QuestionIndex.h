#ifndef QUESTIONINDEX_DEFINED

#define QUESTIONINDEX_DEFINED

#include "fx.h"

#define maxNumQuestions        64
#define problemIndexFileName   "problems.pin"


// CLASS QuestionIndex
// -------------------
// This is the class that keeps track of the list of all the
// possible questions we can ask. Also, it keeps track of which
// questions the user has already completed. 
//
// Note that we use "question", "problem" and "exercise" interchangeably.
class QuestionIndex {

	public:
		QuestionIndex(char* fileName, FXApp* owner);
		~QuestionIndex();

		// The "good" flag.
		bool good;

	public:
		FXApp* app;														// Our owner application pointer.
		char*  indexFile;											// The name of the file to read and write to.
		int    numQuestions;									// Total number of questions.
		char*  labelsIndex[maxNumQuestions];	// The list of labels for each question.
		char*  filesIndex[maxNumQuestions];   // The list of file names for each question.
		char*  descripIndex[maxNumQuestions];	// The descriptions associated with each question.
};

#endif