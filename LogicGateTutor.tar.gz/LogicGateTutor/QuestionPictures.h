#include "ex1.h"
#include "ex2.h"
#include "ex3.h"
#include "ex4.h"

#define numQuestionPictures   4
#define questionHeight        500
#define questionWidth         500


static const unsigned char* listOfPictures[numQuestionPictures] 
                            = { ex1, ex2, ex3, ex4 };

// CLASS QuestionPictures
// ----------------------
class QuestionPictures {

	public:
		// Get the picture associated with the question. Note that
		// the first question is n=1.
		static const unsigned char* getPicture(int n, int& width, int& height);
};