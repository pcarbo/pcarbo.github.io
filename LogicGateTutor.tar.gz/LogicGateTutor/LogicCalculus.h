#define gateTypeNone    0
#define gateTypeAND     1
#define gateTypeOR      2
#define gateTypeXOR     3
#define gateTypeNOT     4
#define gateTypeZero    5


// CLASS LogicCalculus
// -------------------
class LogicCalculus {

	public:
		static int unary  (int x, int gateType);
		static int binary (int x, int y, int gateType);
};
