#include "Coord.h"

class WindowTransform {

	public:
		WindowTransform (int gHeight, int gWidth,
										 int winHeight, int winWidth, 
										 int marginHeight, int marginWidth);
		Coord t(Coord c);
		Coord tv(Coord c);

	protected:
		int gh, gw, wh, ww, mh, mw;
};