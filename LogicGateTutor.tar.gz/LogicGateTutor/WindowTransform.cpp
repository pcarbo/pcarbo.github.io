#include "WindowTransform.h"

WindowTransform::WindowTransform (int gHeight, int gWidth, 
																	int winHeight, int winWidth, 
																	int marginHeight, int marginWidth) {
	gh = gHeight;
	gw = gWidth;
	wh = winHeight;
	ww = winWidth;
	mh = marginHeight;
	mw = marginWidth;

	// Adjustment so that the whole window is not skewed.
	/* if (wh > ww) {
		mh = (wh - ww) / 2;
		wh = ww;
	}
	else { // ww >= wh
		mw = (ww - wh) / 2;
		ww = wh;
	}*/
}


Coord WindowTransform::t (Coord c) {
	double x = mw + c.x * (ww - 2 * mw) / gw;
	double y = mh + c.y * (wh - 2 * mh) / gh;
	return Coord(x, y);
}


Coord WindowTransform::tv (Coord c) {
	double x = c.x * (ww - 2 * mw) / gw;
	double y = c.y * (wh - 2 * mh) / gh;
	return Coord(x, y);
}