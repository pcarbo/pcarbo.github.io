#include "fx.h"

// CLASS Coord
// -----------
class Coord {
	public:
		Coord()                     { x = 0; y = 0; good = true;}
		Coord(double x1, double y1) { x = x1; y = y1; good = true; }
		Coord(const Coord& c)       { x = c.x; y = c.y; good = true; }
		Coord(const char* s);

		FXPoint toFXPt()            { return FXPoint((int) x, (int) y); }
		double x;
		double y;
		bool   good;
};
