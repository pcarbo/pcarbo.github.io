// Project includes.
#include "Session.h"
#include "ErrorBox.h"

// Standard includes.
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// The class constructor.
Session::Session (char* fileName, char* name, FXApp* owner) {

	good = false;
	app  = owner;

	// If either the name or the file name is blank, that's bad!
	// So let's do some error checking here.
	if (!fileName || !strlen(fileName) || 
		  !name || !strlen(name))
		return;

	// Copy the file name.
	file = new char[strlen(fileName) + 1];
	strcpy(file, fileName);

	// Copy the name.
	this->name = new char[strlen(name) + 1];
	strcpy(this->name, name);

	// Set the number of completed questions.
	numCompletedQs = 0;

	// Initialize the belief net.
	ubn = UserBeliefNet(app);

	good = true;
}


// The class destructor.
Session::~Session() {

	delete [] file;
	delete [] name;
}


void Session::read() {

	ifstream f = ifstream(file);

	if (!f.is_open()) {
		ErrorBox::displayErrorMsg(app, "Unable to open session file.");
		return;
	}

	// Read in all the data structures here.
	f >> numCompletedQs;

	for (int i = 0; i < numCompletedQs; i++)
		f >> completedQs[i];

	// Read in user belief net data structures.
	ubn.readFromFile(f);

	f.close();

	// We completed everything successfully, so set the "good" flag
	// to "true".
	good = true;
}


void Session::write() {

	ofstream f = ofstream(file, ios::trunc);
	
	if (!f.is_open()) {
		ErrorBox::displayErrorMsg(app, "Unable to write session index file.");
		return;
	}

	// Write all the data structures here.
	f << numCompletedQs;
	for (int i = 0; i < numCompletedQs; i++)
		f << completedQs[i];

	// Write the user belief net data structures.
	ubn.writeToFile(f);

	f.close();
}


bool Session::qIsCompleted(const char* label) {

	for (int i = 0; i < numCompletedQs; i++)
		if (!strcmp(completedQs[i], label))
			return true;

	return false;
}
