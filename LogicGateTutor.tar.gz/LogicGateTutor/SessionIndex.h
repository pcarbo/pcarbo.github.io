#include "fx.h"

#define maxNumSessions         256
#define sessionIndexFileName   "sessions.sin"
#define sessionExtension       ".ses"


//  CLASS SessionIndex
//  ------------------
//  We use the SessionIndex class to create a record of all the sessions
//  the various users have created. That way, if the user wants to resume
//  an old session, the SessionIndex will retrieve it. Otherwise, it will
//  create a new session.
class SessionIndex {

	public:
		SessionIndex(char* fileName, FXApp* owner);
		~SessionIndex();

		char* findSession(char* name);
		char* addSession(char* name);
		void  write();

		// This is our error flag. If good is "false", then something went wrong.
		bool good;

	protected:
		FXApp*  app;                         // We need a pointer to the main application
																				 // just in case we need to display an error 
																				 // message.
		char*   indexFile;                   // The name of the file for reading and writ
		int     numSessions;                 // Total number of sessions.
		char*   namesIndex[maxNumSessions];  // The names of the sessions.
		char*   filesIndex[maxNumSessions];  // The files corresponding to the sessions.

		bool filenameInIndex(char* fileName);
};
