// Project includes
#include "ErrorBox.h"


// The function implementation map for the ErrorBox dialog window.
FXIMPLEMENT(ErrorBox, FXDialogBox, NULL, 0)


// Constructor for ErrorBox class.
ErrorBox::ErrorBox(FXApp* owner, const char* msg)
 : FXDialogBox(owner, "Alert", DECOR_TITLE | DECOR_BORDER) {

	// Error checking.
	if (!(this->owner = owner))
		return;

	// Create the frame where "OK" will be displayed.
  buttons = new FXHorizontalFrame(this, LAYOUT_SIDE_BOTTOM|FRAME_NONE|LAYOUT_FILL_X|PACK_UNIFORM_WIDTH,0,0,0,0,40,40,20,20);

	// Create the frame where the message will be displayed.
  contents = new FXVerticalFrame(this,LAYOUT_SIDE_TOP|FRAME_NONE|LAYOUT_FILL_X|LAYOUT_FILL_Y|PACK_UNIFORM_WIDTH);

	// The message to display.
	new FXLabel(contents,msg,NULL,0,0,0,0,0,0,0,4,0);

	// Accept
  new FXButton(buttons,"OK",NULL,this,ID_ACCEPT,FRAME_RAISED|FRAME_THICK|LAYOUT_CENTER_X|LAYOUT_CENTER_Y);
}


// This function will create, display and handle all the overhead
// for displaying the error message. All you have to provide
// is a pointer to the main application and a string message.
void ErrorBox::displayErrorMsg (FXApp* owner, const char* msg) {

	// Error checking.
	if (!owner)
		return;

	// Create the error box dialog object.
	ErrorBox ebDialog(owner, msg);
	ebDialog.execute();
}
