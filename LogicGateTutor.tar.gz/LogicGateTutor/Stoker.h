#define maxNumTokens  1024

class Stoker {
	public:
		static char** tokenize (const char* s, int& n, char delim);
		static char** tokenizeSpreadsheet (const char* s, int& n, char delim);
};