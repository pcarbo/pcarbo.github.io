/*  Routines for loading from disk the model parameter specifications.  

    Peter Carbonetto
    Copyright (c) 2003, 2004 INRIA Rh�nes-Alpes
*/  

#ifndef INCLUDEMODELPARAMS
#define INCLUDEMODELPARAMS

#include "kernels.h"

// Type definitions.
typedef struct {
  double      ns;      // The number of samples to generate.
  double      sskip;   // Skip this number of iterations in the Gibbs 
                       // sampler before generating a sample. The 
                       // default is 1, which means we save the sample 
                       // at every Gibbs sampler iteration.
  char*       f;       // The metric function.
  char*       K;       // The kernel function.
  double      lambda;  // Scale parameter used by the kernel function. 
  double      mu;      // Inverse-gamma parameter for the delta, the
                       // variance of the betas. Sets the "flatness" of 
                       // the distribution.
  double      nu;      // Inverse-gamma parameter for the delta. Sets the
                       // location of the mode.
  double      a;       // Dirichlet prior on the variable selection
                       // hyperparameter tau. Note a >= 1.
  double      b;       // Dirichlet prior on tau. Note b >= 1.
  double      mua;     // Inverse-gamma parameter for the expansion 
                       // parameter, alpha.
  double      nua;     // Inverse-gamma parameter for alpha.
  double      epsilon; // The stabilisation weight on the covariance prior.
  int         soft;    // If soft = 1, then use the noisy measurement
		       // model. Otherwise (soft = 0), use the model
		       // with hard constraints (as specified by nc1
		       // and nc2).
  int         nc1;     // The minimum number of positive labels per 
                       // unlabelled document.
  int         nc2;     // The minimum number of negative labels per
                       // unlabelled document.
  double      m;       // Parameter for the noisy measurement
		       // model. User estimate of the fraction of
		       // positives in an unlabelled document.
  double      chi;     // Parameter for the noisy measurement model.
                       // User confidence in the above estimate m.
} Modelparams;

// Function declarations.
Modelparams* loadmodelparams (const char* fn);
void         freemodelparams (Modelparams* modelprms);

#endif
