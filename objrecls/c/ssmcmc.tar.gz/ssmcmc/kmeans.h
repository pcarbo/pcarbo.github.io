#ifndef INCLUDEKMEANS
#define INCLUDEKMEANS

// Project includes.
#include "matrix.h"
#include "rand.h"
#include "kernels.h"

#define infty  1e99

// Function declarations.
int kmeans (const Matrix* X, Metricfunc f, int k, Matrix* C, int* m, 
	    Matrix* D, int* cnts, rndtype(rng), int verbose, 
	    double tol);

#endif
