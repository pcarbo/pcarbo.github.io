// Project includes.
#include "files.h"

// Standard includes.
#include <stdlib.h>

// Function definitions.
// -------------------------------------------------------------------
// The function takes a file point F and returns the label (the text 
// before the colon) in string S and the value (the text after the 
// colon excluding whitespace) in string T. Note we assume that memory 
// has been reserved for both character arrays S and T.
void parseline (FILE* f, char* s, char* t) {
  char  c;
  int   n = 0;

  // Skip leading whitespace.
  c = skipwhitespace(f);

  // Get the characters until the colon.
  while (c != EOF && c != '\n' && c != ':' &&
	 n < maxLblSizeInFile) {
    s[n] = c;    
    n++;
    c = fgetc(f);
  };
  s[n] = 0;

  // Remove some more whitespace after the colon.
  c = skipwhitespace(f);

  // Get the non-whitespace string.
  n = 0;
  while (c != EOF && c != '\n' && c != ' ' &&
	 n < maxNumSizeInFile) {
    t[n] = c;    
    n++;
    c = fgetc(f);
  };
  t[n] = 0;
}

// -------------------------------------------------------------------
// Skip all characters until we hit a non-space (or until we reach the 
// end of the file), and return the last character seen.
char skipwhitespace (FILE* f) {
  char c;

  c = fgetc(f);
  while ((c == ' ' || c == '\n') && c != EOF)
    c = fgetc(f);

  return c;
}

// -------------------------------------------------------------------
// Repeat until we hit a character that is either D or end of file.
void skipuntil (FILE* f, char d) {
  char c;

  do {
    c = fgetc(f);
  } while (c != EOF && c != d);
}

// -------------------------------------------------------------------
// Skip a line in a file.
void skipline (FILE* f) {
  skipuntil(f,'\n');
}

// -------------------------------------------------------------------
// Move in the file until we hit the next colon.
void skipcolon (FILE* f) {
  skipuntil(f,':');
  fgetc(f);
}

// -------------------------------------------------------------------
// Read the string in the file and treat it as either an integer 
// (TYPE = 'i') or a floating-type (TYPE = 'f') number.
double readnum (FILE* f, char type) {
  char  s[maxNumSizeInFile];
  char  c  = fgetc(f);
  int   n  = 0;
  
  // Remove the beginning whitespace.
  while (c == ' ' || c == '\n')
    c = fgetc(f);

  // Get the non-whitespace string.
  while (c != EOF && c != '\n' && c != ' ' &&
	 n < maxNumSizeInFile) {
    s[n] = c;    
    n++;
    c = fgetc(f);
  };
  s[n] = 0;

  // Convert the string to an integer.
  if (type == 'i')
    return (double) atoi(s);
  else 
    return atof(s);
}
