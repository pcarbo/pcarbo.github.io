/*  Operations on matrices of doubles.

    Peter Carbonetto
    Copyright (c) 2003, 2004 INRIA Rh�nes-Alpes
*/  

// Project includes.
#include "matrix.h"
#include "util.h"
#include "files.h"

// Standard includes.
#include <stdlib.h>
#include <math.h>
#include <string.h>

// Function declarations.
int gaussjordan (double* A, double* B, int n, int m);
int choldc      (double* A, int n, double* p);

// Function definitions.
// -------------------------------------------------------------------
// Allocate memory for a vector with N elements and set the elements 
// to 0. 
Vector* initzerovector (int n) {
  return initvector(n,0);
}

// -------------------------------------------------------------------
// Allocate memory for a vector with N elements and set the elements 
// to 0. 
Intvector* initzerointvector (int n) {
  Intvector* v;
  int        i;

  v    = intvectormem;
  v->e = intmem(n);
  v->n = n;
  v->s = n;

  // Set all the elements of the vector to 0.
  for (i = 0; i < v->n; i++)
    v->e[i] = 0;

  return v;
}

// -------------------------------------------------------------------
// Allocate memory for a vector with N elements. Set the elements to A.
Vector* initvector (int n, double a) {
  Vector* v;

  initvectorptr(v,doublemem(n),n);

  // Set all the elements of the vector to A.
  avector(v,a);

  return v;
}

// -------------------------------------------------------------------
// Free the memory allocated for a vector.
void freevector (Vector* v) {
  free(v->e);
  free(v);
}

// -------------------------------------------------------------------
// Free the memory allocated for a vector.
void freeintvector (Intvector* v) {
  free(v->e);
  free(v);
}

// -------------------------------------------------------------------
// We assume memory for vector W has already been allocated.
void copyvector (const Vector* v, Vector* w) {
  w->n = v->n;
  memcpy(w->e, v->e, sizeof(double)*(v->n));
}

// -------------------------------------------------------------------
// Set the elements of vector V to A.
void avector (Vector* v, double a) {
  int i;
  for (i = 0; i < v->n; i++)
    v->e[i] = a;
}

// -------------------------------------------------------------------
// Multiply vector V by scalar A and put the result in X. Note that V
// and X can point to the same thing.
void scalevector (const Vector* v, double a, Vector* x) {
  int i;
  x->n = v->n;
  vectorunaryop(*v,*x,i,*,a);
}

// -------------------------------------------------------------------
// Add A to every element of V, and store the result in V. Note that V 
// and X can point to the same thing.
void addscalartovector (const Vector* v, double a, Vector* x) {
  int i;
  x->n = v->n;
  vectorunaryop(*v,*x,i,+,a);
}

// -------------------------------------------------------------------
// Add vectors V and W and put the result in X. We assume all the 
// vectors are of the same length. Note that X can point to either V 
// or W.
void addvectors (const Vector* v, const Vector* w, Vector* x) {
  int i;
  x->n = v->n;
  vectorbinop(*v,*w,*x,i,+);
}

// -------------------------------------------------------------------
// Subtract vectors V and W and put the result in X. We assume all the 
// vectors are of the same length. Note that X can point to either V 
// or W.
void subtractvectors (const Vector* v, const Vector* w, Vector* x) {
  int i;
  x->n = v->n;
  vectorbinop(*v,*w,*x,i,-);
}

// -------------------------------------------------------------------
// Return the dot product (or inner product) of two vectors V and W. 
// We assume all the vectors are of the same length. 
double dot (const Vector* v, const Vector* w) {
  double x = 0;
  int    i;

  for (i = 0; i < v->n; i++)
    x += v->e[i] * w->e[i];
  return x;
}

// -------------------------------------------------------------------
// Compute the outer product of two vectors V and W, and return the 
// result in matrix X. We assume X has already been allocated memory.
void outerprod (const Vector* v, const Vector* w, Matrix* X) {
  int c, r, n, m;

  n    = v->n;
  m    = w->n;
  X->n = n;
  X->m = m;

  // Repeat for each column of X, then for each row of X.
  for (c = 0; c < m; c++)
    for (r = 0; r < n; r++)
      refMatrix(*X,r,c) = v->e[r] * w->e[c];
}

// -------------------------------------------------------------------
double sumvectorelems (const Vector* v) {
  int    i;
  double x = 0;

  // Repeat for each element of V.
  for (i = 0; i < v->n; i++)
    x += v->e[i];
  return x;
}
  
// -------------------------------------------------------------------
// Increase the storage capacity of a vector V to X amount. Note that 
// the actual size of the vector does not change, nor its elements.
void incvectorsize (Vector* v, int x) {
  double* e = v->e;
  v->s      = x;
  v->e      = doublemem(x);

  memcpy(v->e, e, sizeof(double)*(v->n));
  free(e);
}

// -------------------------------------------------------------------
// Increase the storage capacity of an integer vector V to X amount. 
// Note that the actual size of the vector does not change, nor its 
// elements. 
void incintvectorsize (Intvector* v, int x) {
  int* e = v->e;
  v->s   = x;
  v->e   = intmem(x);

  memcpy(v->e, e, sizeof(int)*(v->n));
  free(e);
}

// -------------------------------------------------------------------
// Add an element A to the vector V. We assume enough memory has been 
// allocated for this concatenation.
void catelemtovector (Vector* v, double a) {
  v->e[v->n] = a;
  (v->n)++;
}

// -------------------------------------------------------------------
// Add an element A to the integer vector V. We assume enough memory 
// has been allocated for this concatenation.
void catelemtointvector (Intvector* v, int a) {
  v->e[v->n] = a;
  (v->n)++;
}

// -------------------------------------------------------------------
// Assign vector W selected elements of V. Integer array ELEMS 
// specifies the M indices. Note that memory for W must already be 
// allocated, and we assume it is sufficient for storage of the 
// M elements.
void selectvectorelems (const Vector* v, Vector* w, const int* elems, 
		       int n) {
  int i;
  
  w->n = n;

  // Repeat for each element.
  for (i = 0; i < n; i++)
    w->e[i] = v->e[elems[i]];
}

// -------------------------------------------------------------------
// Remove element I from vector V and store the result in W. We assume 
// enough memory has been allocated for W.
void remelemfromvector (const Vector* v, Vector* w, int i) {
  int n;

  n    = v->n - 1;
  w->n = n;

  // Copy the elements before I.
  memcpy(w->e, v->e, sizeof(double)*i);

  // Copy the elements after I.
  memcpy(&(w->e[i]), &(v->e[i+1]), sizeof(double)*(n-i));
}

// -------------------------------------------------------------------
// Remove element I from vector V and store the result in W. We assume 
// enough memory has been allocated for W.
void remelemfromintvector (const Intvector* v, Intvector* w, int i) {
  int n;

  n    = v->n - 1;
  w->n = n;

  // Copy the elements before I.
  memcpy(w->e, v->e, sizeof(int)*i);

  // Copy the elements after I.
  memcpy(&(w->e[i]), &(v->e[i+1]), sizeof(int)*(n-i));
}

// -------------------------------------------------------------------
// Remove element I from vector V. 
void remelemintvectorsafe (Intvector* v, int i) {
  int n, j;
  
  v->n = (n = v->n - 1);
  
  // Move the elements after element "i" down by one.
  for (j = i; j < n; j++)
    v->e[j] = v->e[j+1];
}

// -------------------------------------------------------------------
// Print the elements of a vector V.
void printvector (const Vector* v) {
  int    i, j;
  double x;
  int    d = 1;

  // Find the maximum number of digits before the dot.
  for (i = 0; i < v->n; i++)
    d = max(d,numdigits(v->e[i]));

  for (i = 0; i < v->n; i++) {
    x = v->e[i];
    for (j = 0; j < d - max(1,numdigits(x)); j++)
      printf(" ");
    printf("%0.4f\n", x);
  }
}

// -------------------------------------------------------------------
// Print the elements of a vector V to file stream FP.
void fprintvector (FILE* fp, const Vector* v) {
  fprintnums (fp, v->e, v->n);
}

// -------------------------------------------------------------------
// Read a vector of size N from the file stream FP.
Vector* fscanvector (FILE* fp, int n) {
  Vector* x;

  x = initzerovector(n);
  fscannums(fp,x->e,n);
  return x;
}

// -------------------------------------------------------------------
// Read an integer vector of size N from the file stream FP.
Intvector* fscanintvector (FILE* fp, int n) {
  Intvector* x;

  x = initzerointvector(n);
  fscanints(fp,x->e,n);
  return x;
}

// -------------------------------------------------------------------
// Allocate memory an N x M matrix and set the elements to 0. 
Matrix* initzeromatrix (int n, int m) {
  return initmatrix(n,m,0);
}

// -------------------------------------------------------------------
// Allocate memory an N x M matrix and set the elements to 0. 
Intmatrix* initzerointmatrix (int n, int m) {
  Intmatrix* X;
  int        c, r;

  X    = intmatrixmem;
  X->e = intmem(n*m);
  X->n = n;
  X->m = m;
  X->s = n*m;

  for (c = 0; c < X->m; c++)
    for (r = 0; r < X->n; r++)
      refMatrix(*X,r,c) = 0;

  return X;
}
  
// -------------------------------------------------------------------
// Allocate memory for an N x M matrix. Set the elements to A.
Matrix* initmatrix (int n, int m, double a) {
  Matrix* X;

  initmatrixptr(X,doublemem(n*m),n,m);

  // Set all the elements of the matrix to A.
  // Repeat for each column, then for each row.
  amatrix(X,a);

  return X;
}

// -------------------------------------------------------------------
// Free the memory allocated for a matrix.
void freematrix (Matrix* X) {
  free(X->e);
  free(X);
}

// -------------------------------------------------------------------
// Set the elements of matrix X to A.
void amatrix (Matrix* X, double a) {
  int c, r;

  // Repeat for each column, then for each row.
  for (c = 0; c < X->m; c++)
    for (r = 0; r < X->n; r++)
      refMatrix(*X,r,c) = a;
}

// -------------------------------------------------------------------
// Set the matrix X to the N x N identity matrix. We assume memory for
// the matrix has already been allocated.
void identity (Matrix* X, int n) {
  X->n = n;
  X->m = n;
  amatrix(X,0);
  adddiagterm(X,1);
}

// -------------------------------------------------------------------
// Copy matrix A into matrix B. Memory for B must already be allocated 
// and must be sufficient for storing all the elements of A.
void copymatrix (const Matrix* A, Matrix* B) {
  copymatrixdims(*A,*B);
  memcpy(B->e, A->e, sizeof(double)*(A->n)*(A->m));
}

// -------------------------------------------------------------------
// Remove column C from matrix A and store the result in matrix B.
// The memory allocated for matrix B must be sufficient to store all 
// the elements.
void remmatrixcol (const Matrix* A, Matrix* B, int c) {
  int n, m;

  n    = A->n;
  m    = A->m - 1;
  B->n = n;
  B->m = m;

  // Copy the columns before column C.
  memcpy(B->e, A->e, sizeof(double)*n*c);
  
  // Copy the columns after column C.
  memcpy(&refMatrix(*B,0,c), &refMatrix(*A,0,c+1), 
	 sizeof(double)*n*(m-c));
}

// -------------------------------------------------------------------
// Remove column C from matrix A.
void remmatrixcolsafe (Matrix* A, int i) {
  int n, m;
  int c, r;

  n    = A->n;
  m    = A->m - 1;
  A->m = m;

  // Repeat for each column after the one we remove, then for 
  // each row.
  for (c = i; c < m; c++)
    for (r = 0; r < n; r++)
      refMatrix(*A,r,c) = refMatrix(*A,r,c+1);
}

// -------------------------------------------------------------------
// Remove row C from matrix A and store the result in matrix B. The 
// memory allocated for matrix B must be sufficient to store all the 
// elements.
void remmatrixrow (const Matrix* A, Matrix* B, int r) {
  int n, m, c;
  
  n    = A->n - 1;
  m    = A->m;
  B->n = n;
  B->m = m;

  // Repeat for each column.
  for (c = 0; c < m; c++) {
    
    // Copy the rows before row R.
    memcpy(&refMatrix(*B,0,c), &refMatrix(*A,0,c), 
	   sizeof(double)*r);

    // Copy the rows after row R.
    memcpy(&refMatrix(*B,r,c), &refMatrix(*A,r+1,c),
	   sizeof(double)*(A->n-r));
  }
}

// -------------------------------------------------------------------
// Assign matrix B selected columns of A. Integer array COLS specifies 
// the M column indices. Note that memory for B must already be 
// allocated, and we assume it is sufficient for storage of the 
// columns.
void selectmatrixcols (const Matrix* A, Matrix* B, const int* cols, 
		       int m) {
  int c, n;
  
  n    = A->n;
  B->n = n;
  B->m = m;

  // Repeat for each column.
  for (c = 0; c < m; c++)
    memcpy(&refMatrix(*B,0,c), &refMatrix(*A,0,cols[c]), sizeof(double)*n);
}

// -------------------------------------------------------------------
// Assign matrix B selected rows of A. Integer array ROWS specifies 
// the N row indices. Note that memory for B must already be allocated, 
// and we assume it is sufficient for storage of the rows.
void selectmatrixrows (const Matrix* A, Matrix* B, const int* rows, 
		       int n) {
  int r, c;
  
  B->n = n;
  B->m = A->m;

  // Repeat for each column, and then for each row.
  for (c = 0; c < A->m; c++)
    for (r = 0; r < n; r++)
      refMatrix(*B,r,c) = refMatrix(*A,rows[r],c);
}

// -------------------------------------------------------------------
// Take column C from matrix A and put it in vector V. We assume 
// memory for V has already been allocated.
void getcolvector (const Matrix* A, int c, Vector* v) {
  v->n = A->n;
  memcpy(v->e, &refMatrix(*A,0,c), sizeof(double)*(A->n));
}

// -------------------------------------------------------------------
// Multiply matrix X by scalar A and store the result in Y. X and Y 
// can point to the same thing.
void scalematrix (const Matrix* X, Matrix* Y, double a) {
  int c, r;  
  copymatrixdims(*X,*Y);
  matrixunaryop(*X,*Y,c,r,*,a);
}

// -------------------------------------------------------------------
// Add matrices A and B and put the result in C. We assume all the 
// matrices are of the same length. Note that C can point to either A
// or B.
void addmatrices (const Matrix* A, const Matrix* B, Matrix* C) {
  int c, r;
  copymatrixdims(*A,*C);
  matrixbinaryop(*A,*B,*C,c,r,+);
}

// -------------------------------------------------------------------
// Subtract matrices A and B and put the result in C. We assume all the  
// matrices are of the same length. Note that C can point to either A
// or B.
void subtractmatrices (const Matrix* A, const Matrix* B, Matrix* C) {
  int c, r;
  copymatrixdims(*A,*C);
  matrixbinaryop(*A,*B,*C,c,r,-);
}

// -------------------------------------------------------------------
// Multiply A with B to obtain C.
//   A is N x F
//   B is F x M
//   C is N x M
void multmatrices (const Matrix* A, const Matrix* B, Matrix* C) {
  int    c, r, i;
  double z;
  
  C->n = A->n;
  C->m = B->m;

  // Repeat for each row of matrix A.
  for (r = 0; r < A->n; r++)
    
    // Repeat for each column of matrix B.
    for (c = 0; c < B->m; c++) {
      z = 0;

      // Repeat for each column of A / row of B.
      for (i = 0; i < A->m; i++)
	z += refMatrix(*A,r,i) * refMatrix(*B,c,i);

      // Store the result.
      refMatrix(*C,r,c) = z;
    }
}

// -------------------------------------------------------------------
// Increase the storage capacity of a matrix X to S amount. 
// Note that the actual size of the vector does not change, nor its 
// elements.
void incmatrixsize (Matrix* X, int s) {
  double* e = X->e;
  X->s      = s;
  X->e      = doublemem(s); 

  memcpy(X->e, e, sizeof(double)*(X->n)*(X->m));
  free(e);
}

// -------------------------------------------------------------------
// Concatenate a column vector V to the end of the matrix X. We assume 
// enough memory for X has already been allocated. We also assume that 
// the number of rows in X is equal to the length of V.
void catcoltomatrix (Matrix* X, const Vector* v) {
  memcpy(&refMatrix(*X,0,X->m), v->e, sizeof(double)*(v->n));
  (X->m)++;
}

// -------------------------------------------------------------------
// Concatenate a row vector V to the end of the matrix X. We assume 
// enough memory for X has already been allocated. We also assume that 
// the number of columns in X is equal to the length of V.
void catrowtomatrix (Matrix* X, const Vector* v) {
  int c, r, n, m;

  n = X->n;
  m = X->m;

  // Repeat for each column in reverse order.
  for (c = m-1; c >= 0; c--) {
    
    // Tack on the new element.
    MRef(X->e,n,c,n+1) = v->e[c];

    // Put back all the other column elements, again in reverse order.
    for (r = n-1; r >= 0; r--)
      MRef(X->e,r,c,n+1) = MRef(X->e,r,c,n);
  }

  (X->n)++;
}

// -------------------------------------------------------------------
// Print the elements of matrix X.
void printmatrix (const Matrix* X) {
  int    r, c, i;
  double x;
  int    d = 1;

  // Find the maximum number of digits before the dot.
  // Repeat for each column, and then for each row.
  for (c = 0; c < X->m; c++)
    for (r = 0; r < X->n; r++)
      d = max(d,numdigits(refMatrix(*X,r,c)));

  // Print out the elements of the matrix. Repeat for each row, and
  // then for each column.
  for (r = 0; r < X->n; r++) {
    for (c = 0; c < X->m; c++) {
      x = refMatrix(*X,r,c);
      for (i = 0; i < d - max(1,numdigits(x)) + (x >= 0); i++)
	printf(" ");
      printf("%0.4f ", x);
    }
    printf("\n");
  }
}

// -------------------------------------------------------------------
// Print the elements of matrix X to file stream FP.
void fprintmatrix (FILE* fp, const Matrix* X) {
  int c;

  // Repeat for each column, and then for each row.
  for (c = 0; c < X->m; c++)
    fprintnums(fp, &refMatrix(*X,0,c), X->n);
}

// -------------------------------------------------------------------
// Read an N x M matrix from the file stream FP.
Matrix* fscanmatrix (FILE* fp, int n, int m) {
  Matrix* X;
 
  X = initzeromatrix(n,m);
  fscannums(fp,X->e,n*m);
  return X;
}

// -------------------------------------------------------------------
// Compute the symmetric Gram matrix G = X'X. We assume sufficient 
// memory has been allocated for G. If X is an N x M matrix, then G is 
// an M x M matrix.
void gram (const Matrix* X, Matrix* G) {
 
  int    r, c, i, m;
  double x;
 
  m    = X->m;
  G->n = m;
  G->m = m;

  // Repeat for each column of G, and then for each row.
  for (c = 0; c < m; c++)
    for (r = 0; r < m; r++) {
      x = 0;

      // Repeat for all the rows in columns c/r of X.
      for (i = 0; i < X->n; i++)
	x += refMatrix(*X,i,c) * refMatrix(*X,i,r);
      
      // Store the result.
      refMatrix(*G,r,c) = x;
      refMatrix(*G,c,r) = x;
    }
}

// -------------------------------------------------------------------
// Add a diagonal term X to the square matrix A and store the result 
// in A. 
void adddiagterm (Matrix* A, double x) {
  int i;
  for (i = 0; i < A->n; i++)
    diagrefMatrix(*A,i) += x;
}  

// -------------------------------------------------------------------
// Compute the inverse of X and store it in Y. Y is the result. B is a 
// temporary result matrix of the same size. We assume memory for Y 
// and B has already been allocated. Return 1 if there's an error due 
// to a singular matrix. Note that X and Y can point to the same thing. 
int matrixinv (const Matrix* X, Matrix* Y, Matrix* B) {
  int n = X->n;
  identity(B,n);
  if (X != Y)
    copymatrix(X,Y);
  return gaussjordan(Y->e,B->e,n,n);
}

// -------------------------------------------------------------------
// A is an N x N matrix and B is an N x M matrix. Return 1 if there's 
// an error due to a singular matrix.
int gaussjordan (double* A, double* B, int n, int m) { 
  int     indxc[n];
  int     indxr[n];
  int     ipiv[n]; 
  int     i, icol, irow, j, k, l, ll; 
  double  big, dum, pivinv, temp, v; 
  double* a;
  icol = 0;
  irow = 0;

  // Initialise the pivot elements.
  for (i = 0; i < n; i++)
    ipiv[i] = 0;

  // This is the main loop over the columns to be reduced. 
  for (i = 0; i < n; i++) { 
    big = 0.0; 
    for (j = 0; j < n; j++) {

      // This is the outer loop of the search for a pivot element. 
      if (ipiv[j] != 1) {
	for (k = 0; k < n; k++) { 
	  if (ipiv[k] == 0) {
	    v = absd(MRef(A,j,k,n));
	    if (v >= big) {
	      big  = v;
	      irow = j; 
	      icol = k; 
	    } 
	  } 
	} 
      }
    }
    ++(ipiv[icol]);

    if (irow != icol) { 
      for (l = 0; l < n; l++)
	swap(MRef(A,irow,l,n), MRef(A,icol,l,n), temp);
      for (l = 0; l < m; l++)
	swap(MRef(A,irow,l,n), MRef(B,icol,l,n), temp);
    }
	
    // We are now ready to divide the pivot row by the pivot 
    // element, located at irow and icol. 
    indxr[i] = irow;
    indxc[i] = icol; 

    a = &MdRef(A,icol,n);
    if (*a == 0.0)
      return 1;
    pivinv = 1.0 / *a;
    *a     = 1.0;
    for (l = 0; l < n; l++) 
      MRef(A,icol,l,n) *= pivinv;
    for (l = 0; l < m; l++) 
      MRef(B,icol,l,n) *= pivinv;
    
    // Next, we reduce the rows, except for the pivot one, 
    // of course.
    for (ll = 0; ll < n; ll++) {
      if (ll != icol) { 
	a   = &MRef(A,ll,icol,n);
	dum = *a;
	*a  = 0.0;

	for (l = 0; l < n; l++)
	  MRef(A,ll,l,n) -= MRef(A,icol,l,n) * dum;
	for (l = 0; l < m; l++)
	  MRef(B,ll,l,n) -= MRef(B,icol,l,n) * dum;
      } 
    }
  }

  // This is the end of the main loop over columns of the reduction. 
  // It only remains to unscramble the solution in view of the 
  // column interchanges. We do this by interchanging pairs of 
  // columns in the reverse order that the permutation was built up. 
  for (l = n-1; l >= 0; l--)
    if (indxr[l] != indxc[l]) 
      for (k = 0; k < n; k++) 
	swap(MRef(A,k,indxr[l],n), MRef(A,k,indxc[l],n), temp);

  return 0;
}

// -------------------------------------------------------------------
// A is an N x N matrix. Returns 1 if A is not positive definite.
int choldc (double* A, int n, double* p) {

  int    i,j,k; 
  double s; 

  for (i = 0; i < n; i++) { 
    for (j = i; j < n; j++) { 
      s = MRef(A,j,i,n);
      for (k = i-1; k >= 0; k--) 
	s -= MRef(A,k,i,n) * MRef(A,k,j,n);
      if (i == j) { 
	if (s <= 0.0)
	  return 1;
	p[i] = sqrt(s); 
      } 
      else 
	MRef(A,i,j,n) = s / p[i]; 
    } 
  } 

  return 0;
}

// -------------------------------------------------------------------
// X and Y are N x N matrices. X is the original matrix. Y is the 
// upper triangular Cholesky decomposition of the symmetric positive 
// definite matrix X. P is a temporary storage vector of length N 
// (the diagonal elements are stored in P). Note that X and Y can 
// point to the same thing. 
int chol (const Matrix* X, Matrix* Y, Vector* p) {
  int e;
  int c, r;
  int n = X->n;
  
  if (X != Y)
    copymatrix(X,Y);

  e = choldc(Y->e,n,p->e);
  if (~e) {

    // Assign the diagonal elements.
    for (r = 0; r < n; r++)
      diagrefMatrix(*Y,r) = p->e[r];

    // Set the lower diagonal elements to zero. Repeat for each 
    // column, and then for each row.
    for (c = 0; c < n; c++)
      for (r = c+1; r < n; r++)
	refMatrix(*Y,r,c) = 0;
  }

  return e;
}

// -------------------------------------------------------------------
// This function gives two possible multiplications:
//   1. A is an N x M matrix and V is a M x 1 vector, and the result X 
//      is an N x 1 vector (transpose = 0). X = AV.
//   2. A is an N x M matrix and V is an N x 1 vector, and the result 
//      X is a M x 1 vector (transpose = 1). X = A'V.
// It is important to note that V and X cannot point to the same thing. 
void multmatrixwithvector (const Matrix* A, const Vector* v, Vector* x,
			   int transpose) {
  int    r, c, n, m;
  double z;

  n = A->n;
  m = A->m;
  if (transpose) {
    x->n = m;

    // Repeat for each element of X, then repeat for each row of A / 
    // element of V.
    for (c = 0; c < m; c++) {
      z = 0;
      for (r = 0; r < n; r++)
	z += refMatrix(*A,r,c) * v->e[r];
      x->e[c] = z;
    }
  }
  else {
    x->n = n;
    
    // Repeat for each element of X, then repeat for each column of 
    // A / element of V.
    for (r = 0; r < n; r++) {
      z = 0;
      for (c = 0; c < m; c++)
	z += refMatrix(*A,r,c) * v->e[c];
      x->e[r] = z;
    }
  }
}

// -------------------------------------------------------------------
// Sum the rows of N x M matrix A into M x 1 vector V. We assume 
// sufficient memory for V has been allocated.
void summatrixrows (Matrix* A, Vector* v) {
  int    c, r;
  double x;

  v->n = A->m;

  // Repeat for each column, and then repeat for each row.
  for (c = 0; c < A->m; c++) {
    x = 0;
    for (r = 0; r < A->n; r++)
      x += refMatrix(*A,r,c);
    v->e[c] = x;
  }
}

// -------------------------------------------------------------------
// X is a F x N matrix. F is the dimension of the data points and N is 
// the number of data points. This function will find the F x 1 mean 
// of the N data points. We assume storage has already been allocated 
// for MEAN.
void meancol (const Matrix* X, Vector* mean) {

  int c, r, f, n;

  f = X->n;
  n = X->m;

  // Initialise the mean.
  avector(mean,0);

  // Repeat for each column (i.e. data point), then for each row 
  // (i.e. feature).
  for (c = 0; c < n; c++)
    for (r = 0; r < f; r++)
      mean->e[r] += refMatrix(*X,r,c);

  // Divide the entries in MEAN by the total number of columns.
  scalevector(mean, 1/((double) n), mean);
}

// -------------------------------------------------------------------
// X is a F x N matrix. F is the dimension of the data points and N is 
// the number of data points. This function will find the F x 1 
// standard deviation of the N data points. We assume storage has 
// already been allocated for STD, and the MEAN must be given.
void stdcol (const Matrix* X, const Vector* mean, Vector* std) {

  int    c, r, f, n;
  double v;

  f = X->n;
  n = X->m;

  // Initialise the standard deviation.
  avector(std,0);

  // Repeat for each column (i.e. data point), then for each row 
  // (i.e. feature).
  for (c = 0; c < n; c++)
    for (r = 0; r < f; r++) {
      v          = refMatrix(*X,r,c) - mean->e[r];
      std->e[r] += v*v;
    }

  // Divide the entries in STD by the total number of columns and then 
  // take the square root.
  for (r = 0; r < f; r++)
    std->e[r] = sqrt(std->e[r]/((double) n));
}

// -------------------------------------------------------------------
// Normalize the columns of a matrix X. In other words, we subtract by 
// MEAN and then divide by STD.
void normalizecolumns (Matrix* X, const Vector* mean, const Vector* std) {

  int c, r;

  // Repeat for each column (i.e. data point), then for each row 
  // (i.e. feature).  
  for (c = 0; c < X->m; c++)
    for (r = 0; r < X->n; r++)
      refMatrix(*X,r,c) = (refMatrix(*X,r,c) - mean->e[r]) / std->e[r];
}
