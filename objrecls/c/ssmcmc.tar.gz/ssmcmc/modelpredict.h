/*  Routines for saving the model predictions to disk.

    Peter Carbonetto
    Copyright (c) 2003, 2004 INRIA Rh�nes-Alpes
*/  

#ifndef INCLUDEMODELPREDICT
#define INCLUDEMODELPREDICT

typedef struct {
  int     N;   // The number of data points.
  double* py;  // 2 x N array of the true label probabilities, where the 
               // first row is the probability of the positive label and 
               // the second row is the probability of the negative label.
} InferredLabels;

// Function declarations.
void savemodelpredict (char* fn, InferredLabels pred);

#endif
