/*  These are routines for loading from disk the simulated 
    semi-supervised data created in Matlab.  

    Peter Carbonetto
    Copyright (c) 2003, 2004 INRIA Rh�nes-Alpes
*/  

// Project includes.
#include "simdata.h"
#include "util.h"
#include "files.h"

// Standard includes.
#include <stdlib.h>
#include <stdio.h>

#define maxNumSizeInFile  256

// Function declarations.
void    freebindata (Data* data);
Data*   loaddataset (FILE* f);
void    skipuntil   (FILE* f, char d);
void    skipline    (FILE* f);
void    skipcolon   (FILE* f);
double  readnum     (FILE* f, char type);

// Function definitions.
// -------------------------------------------------------------------
Data* loadbindata (const char* fn) {

  Data* data;
  FILE* f;  

  // Open the file for reading.
  f = fopen(fn, "rt");
  if (!f) {
    fprintf(stderr, "Cannot open file %s for reading.\n", fn);
    return NULL;
  }

  // Load the training data.
  data = loaddataset(f);

  // Close the file.
  fclose(f);

  return data;
}

// -------------------------------------------------------------------
void freebindata (Data* data) {
  free(data->Y);
  free(data->L);
  free(data->docs);
  free(data->balls);
  free(data->y);
  freematrix(data->X);
  free(data);
}

// -------------------------------------------------------------------
Data* loaddataset (FILE* f) {

  Data*   data;   // The return value.
  int     d;      // The number of documents.
  int     F;      // The number of features.
  int*    Y;      // Document labels.
  int*    L;      // Document sizes.
  int     N;      // Number of data points.
  int     maxM;   // Maximum size of a document.
  int*    docs;   // Array of indices from data points to documents.
  int*    balls;  // Array of data points in each document.
  int*    y;      // Array of true data point labels.
  Matrix* X;      // Array of data points.

  // Loop variables.  
  int     di;
  int*    py;
  int*    pl;
  int*    pballs;
  int*    pdocs;
  double* px;
  int     i;
  int     j;
  int     li;

  // Allocate memory for the data.
  data = (Data*) malloc(sizeof(Data));

  // Get the number of documents.
  skipcolon(f);
  d = (int) readnum(f,'i');

  // Get the number of features.
  skipcolon(f);
  F = (int) readnum(f,'i');

  // Skip the next line.
  skipline(f);

  // Allocate memory for the document information.
  Y = intmem(d);
  L = intmem(d);

  // Repeat for each document.
  for (di = 0, py = Y, pl = L; di < d; di++, py++, pl++) {
    // Get the document label and the document size.
    *py = (int) readnum(f,'i');
    *pl = (int) readnum(f,'i');
  } 

  // Skip the next line.
  skipline(f);

  // Get the number of data points and the maximum size of a document. 
  N    = sumint(L,d);
  maxM = maxint(L,d);

  // Allocate memory for the data point information.
  docs  = intmem(N);
  balls = intmem(N*maxM);
  y     = intmem(N);
  X     = initzeromatrix(F,N);

  // Repeat for each document, and then for each data point in the document. 
  for (di = 0, i = 0, pl = L, pdocs = docs, py = y, px = X->e;
       di < d; di++, pl++) {
    li = i + *pl;
    for (pballs = &balls[di*maxM]; i < li; i++, pballs++, pdocs++, py++) {
      *pballs = i;
      *pdocs  = di;

      // Get the true label for the data point.
      *py = (int) readnum(f,'i');

      // Repeat for each feature.
      for (j = 0; j < F; j++, px++)
	*px = readnum(f,'f');
    }
  }

  // Return the data set information.
  data->d     = d;
  data->maxM  = maxM;
  data->Y     = Y;
  data->L     = L;
  data->docs  = docs;
  data->balls = balls;
  data->y     = y;
  data->X     = X;
  return data;
}
