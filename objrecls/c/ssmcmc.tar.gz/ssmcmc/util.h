#ifndef INCLUDEUTIL
#define INCLUDEUTIL

// Standard includes.
#include <stdio.h>

// Constants.
#define maxdirlength    1024

// Macros.
#define max(a,b)        (((a) > (b))*(a) + ((a) <= (b))*(b))
#define min(a,b)        (((a) < (b))*(a) + ((a) >= (b))*(b))
#define absd(a)         ((a)*((a) >= 0) - (a)*((a) < 0))
#define loga(a,x)       (log(x)/log(a))
#define log2(x)         loga(2,x)
#define numdigits(x)    ((int) floor(1+log10((double) x)))
#define sqr(a)          ((a)*(a))
#define swap(a,b,temp)  {temp=(a);(a)=(b);(b)=temp;} 

// Used to allocate memory.
#define charmem(n)   ((char*) malloc((n)*sizeof(char)))
#define strmem(s)    charmem(strlen(s)+1)
#define intmem(n)    ((int*) malloc((n)*sizeof(int)))
#define doublemem(n) ((double*) malloc((n)*sizeof(double)))
#define ptrmem(n)    ((void**) malloc((n)*sizeof(void*)))

// Function declarations.
char*  getmemandstrcpy (const char* s);
int    sumint          (const int* x, int n);
int    maxint          (const int* x, int n);
double maxdb           (const double* x, int n);
double mindb           (const double* x, int n);
void   printints       (int* a, int n);
void   fprintnums      (FILE* fp, const double* x, int n);
void   fprintints      (FILE* fp, const int* x, int n);
void   fscannums       (FILE* fp, double* x, int n);
void   fscanints       (FILE* fp, int* x, int n);
double erfc            (double x);
double normcdf         (double x);
char*  absolutepath    (const char* f);

#endif
