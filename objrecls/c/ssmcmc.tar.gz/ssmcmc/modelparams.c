/*  Routines for loading from disk the model parameter specifications.  

    Peter Carbonetto
    Copyright (c) 2003, 2004 INRIA Rh��nes-Alpes
*/  

// Project includes.
#include "modelparams.h"
#include "util.h"
#include "files.h"

// Standard includes.
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Function definitions.
// -------------------------------------------------------------------
Modelparams* loadmodelparams (const char* fn) {

  FILE*        f;
  Modelparams* modelprms;
  char         s[maxLblSizeInFile];
  char         t[maxNumSizeInFile];
  
  // Open the file for reading.
  f = fopen(fn, "rt");
  if (!f) {
    fprintf(stderr, "Cannot open file %s for reading.\n", fn);
    return NULL;
  }

  // Allocate memory for the model parameters structures we 
  // will fill when we read the data from the file.  
  modelprms = (Modelparams*) malloc(sizeof(Modelparams));

  // Set the defaults on the model parameters (for those 
  // that have defaults, anyway).
  modelprms->sskip = 1;

  // Skip the first line since it is a comment.
  skipline(f);

  // Repeat for each line of the parameters file.
  while (1) {
    parseline(f,s,t);
    if (!strcasecmp("metric",s)) {
      if (!strcasecmp("fdist2",t)) {
	char* stemp;
	stemp = strmem(t);
	strcpy(stemp,t);
	modelprms->f = stemp;
      }
    }
    else if (!strcasecmp("kernel",s)) {
      if (!strcasecmp("kgaussian",t)) {
	char* stemp;
	stemp = strmem(t);
	strcpy(stemp,t);
	modelprms->K = stemp;
      }
    }
    else if (!strcasecmp("ns",s))
      modelprms->ns = atoi(t);
    else if (!strcasecmp("nskip",s))
      modelprms->sskip = atoi(t);
    else if (!strcasecmp("lambda",s))
      modelprms->lambda = atof(t);
    else if (!strcasecmp("mu",s))
      modelprms->mu = atof(t);
    else if (!strcasecmp("nu",s))
      modelprms->nu = atof(t);
    else if (!strcasecmp("a",s))
      modelprms->a = atof(t);
    else if (!strcasecmp("b",s))
      modelprms->b = atof(t);
    else if (!strcasecmp("mua",s))
      modelprms->mua = atof(t);
    else if (!strcasecmp("nua",s))
      modelprms->nua = atof(t);
    else if (!strcasecmp("epsilon",s))
      modelprms->epsilon = atof(t);
    else if (!strcasecmp("nc1",s)) {
      modelprms->nc1  = atoi(t);
      modelprms->soft = 0;
    }
    else if (!strcasecmp("nc2",s)) {
      modelprms->nc2  = atoi(t);
      modelprms->soft = 0;
    }
    else if (!strcasecmp("m",s)) {
      modelprms->m    = atof(t);
      modelprms->soft = 1;
    }
    else if (!strcasecmp("chi",s)) {
      modelprms->chi  = atof(t);
      modelprms->soft = 1;
    }
    else
      break;
  }

  // Close the file.
  fclose(f);

  return modelprms;
}

// -------------------------------------------------------------------
void freemodelparams (Modelparams* modelprms) {
  free(modelprms->K);
  free(modelprms);
}
