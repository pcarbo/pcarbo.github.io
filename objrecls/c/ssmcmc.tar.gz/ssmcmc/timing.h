#ifndef INCLUDETIMING
#define INCLUDETIMING

// System includes.
#include <sys/time.h>

// Macros.
#define timevalmem  ((struct timeval*) malloc(sizeof(struct timeval)))

// Function declarations.
struct timeval* gettime        (void);
double          getelapsedtime (struct timeval* t);

#endif
