#ifndef INCLUDESSMCMC
#define INCLUDESSMCMC

// Project includes.
#include "kernels.h"
#include "rand.h"
#include "modelpredict.h"

// Type definitions.
typedef struct {
  int      ns;      // The number of samples.
  int      maxng;   // The maximum number of active RBF centres 
                    // in a single sample. 
  char*    f;       // String representing metric function.
  char*    K;       // String representing kernel function.
  double   lambda;  // Kernel scale.
  Matrix*  C;       // RBF centres.
  Vector*  mean;    // Mean for normalization.
  Vector*  std;     // Standard deviation for normalization.
  double** Beta;    // Beta samples.
  double** Betamem; // Memory for "Beta".
  int      nbeta;   // The number of memory pointers for "Betamem".
  int*     Ng;      // Number of active RBF centres per sample.
  int**    Gf;      // Indices of positive gamma samples.
  int**    Gfmem;   // Memory for "Gf".
  int      ngf;     // The number of memory pointers for "Gfmem".
} Model;

// Macros.
#define modelmem  ((Model*) malloc(sizeof(Model)))

// Function declarations.
Model* loadmodel   (const char* fn);
void   freemodel   (Model* model);
Model* ssmcmctrain (int d, int maxL, Matrix* X, int* Y, int* L, 
		    int* balls, int* docs, char* fstr, char* Kstr, 
		    double lambda, double mu, double nu, double mua, 
		    double nua, double a, double b, double epsilon, 
		    int ns, int sskip, int soft, int nc1, int nc2, 
		    double m, double chi, rndtype(rng), char* savef, 
		    int saveint, int verbose);
InferredLabels ssmcmctest   (Matrix* X, const Model* model, 
			     int burnin, int cutoff, double sp, 
			     int verbose, rndtype(rng));

#endif
