// Project includes.
#include "modelpredict.h"

// Standard includes.
#include <stdlib.h>
#include <stdio.h>

// Function definitions.
void savemodelpredict (char* fn, InferredLabels pred) {

  FILE* f;
  int   i, c;

  // Open the file for writing.
  f = fopen(fn, "wt");
  if (!f) {
    fprintf(stderr, "Cannot open file %s for writing.\n", fn);
    return;
  }
 
  // Repeat for each data point.
  for (i = 0; i < pred.N; i++) {

    // Repeat for each class.
    for (c = 0; c < 2; c++)
      fprintf(f, "%0.3f ", pred.py[2*i+c]);

    fprintf(f,"\n");
  }

  // Close the file.
  fclose(f);    
}
