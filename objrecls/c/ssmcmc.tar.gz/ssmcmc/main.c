/*  Main program.

    Peter Carbonetto
    Copyright (c) 2003, 2004 INRIA Rh�nes-Alpes
*/  

#define PSEUDORANDFILE "../../expmts/rand"

// Project includes.
#include "simdata.h"
#include "modelparams.h"
#include "ssmcmc.h"
#include "util.h"
#include "rand.h"
#include "matrix.h"
#include "timing.h"

// System includes.
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

#define numReqdArgs  2
#define rngType      gsl_rng_mt19937
#define dbInt        0.025
#define dbBorder     10

int main (int argc, char** argv) {

  // Main variables.
  Model* model = NULL;
  Data*  data;
  Data   d;

  // The random number generator.
  rndtype(rng);

  // Arguments. The optional arguments have default values.
  char*  datafile;
  char*  modelfile;
  int    numopts;
  char*  labelsfile    = NULL;
  char*  modelprmsfile = NULL;
  char*  dbfile        = NULL;
  int    seed          = 0;
  int    saveint       = 0;
  int    burnin        = 0;
  int    cutoff        = -1;
  int    verbose       = 0;
  double sp            = 1.0;  // The percentage of samples to keep for 
                               // testing purposes.
  {
    // Loop variables.
    int   n;
    char* s;
    char* optlbl;
    char* optval;
    char  c;
  
    // Parse the command line arguments. Repeat for each argument (except 
    // the first one, obviously). Note that we do not check to see if 
    // there are conflicting options. If so, this may cause unexpected 
    // behaviour.
    argc--;
    argv = &argv[1];
    for (numopts = 0; numopts < argc; numopts++) {
      s = argv[numopts];

      // Check to see if the argument is an option.
      if (s[0] == '-') {
	
	// Isolate the string after the '-' and before the '=', and the 
	// string after the '='. 
	n = 1;
	c = s[n];
	while (c && c != '=')
	  c = s[++n];
	
	// Get the option label.
	optlbl = charmem(n);
	strncpy(optlbl, &s[1], n-1);
	optlbl[n] = 0;
	
	// Get the option value string.
	optval = &s[n+1];
	
	// Process the optional argument.
	if (!strcasecmp("s",optlbl))
	  saveint = atoi(optval);
	else if (!strcasecmp("seed",optlbl))
	  seed = atoi(optval);
	else if (!strcasecmp("b",optlbl))
	  burnin = atoi(optval);
	else if (!strcasecmp("c",optlbl))
	  cutoff = atoi(optval);
	else if (!strcasecmp("t",optlbl))
	  modelprmsfile = absolutepath(optval);
	else if (!strcasecmp("p",optlbl))
	  labelsfile = absolutepath(optval);
	else if (!strcasecmp("db",optlbl))
	  dbfile = absolutepath(optval);
	else if (!strcasecmp("sp",optlbl))
	  sp = atof(optval);
	else if (!strcasecmp("v",optlbl))
	  verbose = 1;
	
	// Free memory.
	free(optlbl);
      }
      else {
	numopts = numopts - 1;
	break;
      }
    }
  }

  // The remaining arguments are not optional. Make sure we have enough. 
  // If not, print out usage. 
  if (argc - (numopts + 1) < numReqdArgs) {
    printf("\nUsage: [options] <data-file> <model-file>\n\nActions:\n  -t=<model-params-file>  Train the model using the parameter file. If this\n                          option is not specified, the model is loaded from\n                          the model file.\n  -p=<labels-file>        Infer labels on the data.\n  -db=<file>              Create decision boundary.\n\nOptions:\n  -seed=<int>             Initialises the random number sequence to the\n                          specified positive number.\n  -b=<int>                The burn-in for testing.\n  -c=<int>                The cut-off for testing.\n  -s=<interval>           Save model after each interval of training\n                          samples.\n  -sp=<percentage>        Keep only a proportion of the samples after\n                          burn-in for testing.\n  -v                      Verbose mode.\n\n");
    return -1;
  }

  // Get the required command line arguments.
  argv       = &argv[numopts];
  datafile   = absolutepath(argv[1]);
  modelfile  = absolutepath(argv[2]);

  // Initialise the random number generator.
  printf("Initialising the random number generator.\n");
  rndinit(rng,rngType,PSEUDORANDFILE,seed);

  // Load the data.
  printf("Loading data.\n");
  if ((data = loadbindata(datafile)) == NULL) 
    return -1;
  d  = *data;

  // Do one of three actions:
  //   1. If the "t" option is specified (and accordingly 
  //      the variable "modelprmsfile"), train the model 
  //      using the labels file. 
  //   2. If the "db" option is specified, produce the 
  //      decision boundary using the labels file as a 
  //      guide.
  //   3. If the "p" option is specified, ;oad the model 
  //      from disk and test it on the the labels file.
  {
    struct timeval* t;
    double          dt;

    if (modelprmsfile != NULL) {
      Modelparams* modelprms;
      Modelparams  mp;
      
      // Load the model parameters.
      printf("Loading model parameters.\n");
      if ((modelprms = loadmodelparams(modelprmsfile)) == NULL) 
	return -1;

      // Train the model.
      printf("Training the model.\n");
      t  = gettime();
      mp = *modelprms;
      d  = *data;
      if ((model = ssmcmctrain(d.d, d.maxM, d.X, d.Y, d.L, d.balls, d.docs, 
			       mp.f, mp.K, mp.lambda, mp.mu, mp.nu, mp.mua, 
			       mp.nua, mp.a, mp.b, mp.epsilon, mp.ns, 
			       mp.sskip, mp.soft, mp.nc1, mp.nc2, mp.m, 
			       mp.chi, rng, modelfile, saveint, 
			       verbose)) == NULL) {
        printf("Training failed.\n");
        return -1;
      }
      dt = getelapsedtime(t);
      printf("Training took %0.3g seconds, and used %d uniform deviates and %d Normal deviates.\n",
             dt, numusedu(rng), numusedn(rng));
      
      // Free memory.
      freemodelparams(modelprms);
    }
    else if (labelsfile != NULL) {
      InferredLabels pred;

      // Load the model.
      printf("Loading model.\n");
      if ((model = loadmodel(modelfile)) == NULL)
        return -1;      

      // Test the model.
      printf("Predicting labels.\n");
      t    = gettime();
#ifdef SSMCMCTESTBT
      pred = ssmcmctestbt(d.X, model, burnin, cutoff, sp, 0.5, verbose, rng);
#else      
      pred = ssmcmctest(d.X, model, burnin, cutoff, sp, verbose, rng);
#endif
      dt = getelapsedtime(t);
      printf("Inference took %0.3g seconds.\n", dt);
      savemodelpredict(labelsfile, pred);

      // Free memory.
      free(pred.py);
    }
    else if ((dbfile != NULL) && (d.X->n == 2)) {
      InferredLabels pred;
      double         x1min, x1max, x2min, x2max;
      double         x1, x2, N;
      Matrix*        X;
      int            i;
      FILE*          f;

      // Load the model.
      printf("Loading model.\n");
      if ((model = loadmodel(modelfile)) == NULL)
        return -1;      

      printf("Computing decision boundary.\n");
      t = gettime();
    
      // Get the max and min of the grid.
      x1min = d.X->e[0];
      x1max = d.X->e[0];
      x2min = d.X->e[1];
      x2max = d.X->e[1];
      for (i = 1; i < d.X->m; i++) {
	x1min = min(x1min, refMatrix(*(d.X),0,i));
	x1max = max(x1max, refMatrix(*(d.X),0,i));
	x2min = min(x2min, refMatrix(*(d.X),1,i));
	x2max = max(x2max, refMatrix(*(d.X),1,i));
      }
      
      x1min -= dbBorder*dbInt;
      x1max += dbBorder*dbInt;
      x2min -= dbBorder*dbInt;
      x2max += dbBorder*dbInt;
      
      // Create the grid points.
      N = ceil((x1max-x1min) / ((double) dbInt)) *
        ceil((x2max-x2min) / ((double) dbInt));
      X = initzeromatrix(2,N);
      i = 0;
      for (x1 = x1min; x1 < x1max; x1 += dbInt)
	for (x2 = x2min; x2 < x2max; x2 += dbInt) {
	  X->e[i++] = x1;
	  X->e[i++] = x2;
	}
      
      // Compute the prediction over the grid points.
      pred = ssmcmctest(X, model, burnin, cutoff, sp, verbose, rng);
      dt   = getelapsedtime(t);
      printf("Decision boundary computation took %0.3g seconds.\n", dt);

      // Save the decision boundary.
      printf("Saving decision boundary to disk.\n");
      
      // Open the file for writing.
      f = fopen(dbfile, "wt");
      if (!f) {
	fprintf(stderr, "Cannot open file %s for writing.\n", 
		dbfile);
	return -1;
      }
      
      // Save the grid dimensions and the increment.
      fprintf(f, "%0.6f\n", dbInt);
      fprintf(f, "%0.6f %0.6f %0.6f %0.6f\n", x1min, x1max, 
	      x2min, x2max);
      
      // Repeat for each data point.
      for (i = 0; i < pred.N; i++) {
	fprintf(f, "%0.3f ", pred.py[2*i]);
	fprintf(f, "%0.3f ", pred.py[2*i+1]);	
	fprintf(f,"\n");
      }
    
      // Close the file.
      fclose(f);  
    
      // Free memory.
      free(X);
      free(pred.py);      
    }
    else
      printf("No action has been specified.\n");
  }

  // Free memory.
  if (model != NULL)
    freemodel(model);
  freebindata(data);
  rndfree(rng);

  return 0;
}

