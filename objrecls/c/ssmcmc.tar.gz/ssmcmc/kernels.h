/*  The defined kernel functions.

    Peter Carbonetto
    Copyright (c) 2003, 2004 INRIA Rh�nes-Alpes
*/  

#ifndef INCLUDEKERNELS
#define INCLUDEKERNELS

#include "matrix.h"

// Macros.
// Find the distance between vectors X and Y. The vectors are of length F.
// We use counter R, temporary value V, and the result is returned in D.
#define dist2(x,y,f,r,v,d) {d=0; for ((r)=0; (r)<(f); (r)++) {(v)=(x)[r]-(y)[r]; (d)+=(v)*(v);}}

// Type definitions.
typedef void (*Metricfunc) (Matrix*, const Matrix*, const Matrix*);
typedef void (*Kernelfunc) (Matrix*, double);

// Function declarations.
Metricfunc getmetricptr (char* s);
Kernelfunc getkernelptr (char* s);
void       fdist2       (Matrix* D, const Matrix* X, const Matrix* Y);
void       kgaussian    (Matrix* X, double lambda);

#endif
