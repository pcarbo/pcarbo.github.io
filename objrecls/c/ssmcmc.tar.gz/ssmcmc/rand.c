/*  Routines for random and pseudo-random number generation. 

    Peter Carbonetto
    Copyright (c) 2003, 2004 INRIA Rh�nes-Alpes
*/  

// Project includes.
#include "rand.h"
#include "util.h"

// Standard includes.
#include <math.h>
#include <time.h>

// Function definitions.
// -------------------------------------------------------------------
// Initialise the native random number generator.
Nativerng* initnativerand (const gsl_rng_type* type, 
			   unsigned long int seed) {
  Nativerng* rng;
  gsl_rng*   r;

  r = gsl_rng_alloc(gsl_rng_taus);
  if (seed == 0) seed = time(NULL);
  gsl_rng_set(r,seed);
  
  rng       = (Nativerng*) malloc(sizeof(Nativerng));
  rng->uacc = 0;
  rng->nacc = 0;
  rng->r    = r;

  return rng;
}

// -------------------------------------------------------------------
// Initialise the pseudo random number generator but loading the 
// pregenerated random deviates from disk.
Pseudorng* initpseudorand (char* fn) {

  FILE*      f;
  Pseudorng* r;
  int        t;
  int        i;
  float      x;

  // Open the file for reading.
  f = fopen(fn, "rt");
  if (!f) {
    fprintf(stderr, "Cannot open file %s for reading.\n", fn);
    return NULL;
  }

  // Get the number of random numbers.
  fscanf(f, "%d", &t);

  // Allocate memory for the struct.
  r       = (Pseudorng*) malloc(sizeof(Pseudorng));
  r->t    = t;
  r->u    = -1;
  r->n    = -1;
  r->uacc = -1;
  r->nacc = -1;
  r->UR   = doublemem(t);
  r->NR   = doublemem(t);

  // Read in the random numbers.
  for (i = 0; i < t; i++) {
    fscanf(f, "%f", &x);
    r->UR[i] = (double) x;
  }
  for (i = 0; i < t; i++) {
    fscanf(f, "%f", &x);
    r->NR[i] = (double) x;
  }

  // Close the file.
  fclose(f);

  return r;
}

// -------------------------------------------------------------------
// Generate a random variate uniformly distributed on the set of 
// integers on the interval [A,B].
int randint (int a, int b, rndtype(r)) {
  return (int) floor(a + (b-a+1)*urand(r));
}

// -------------------------------------------------------------------
// Return several samples from the standard Normal.
void nrandm (Vector* x, rndtype(r)) {
  int i;
  for (i = 0; i < x->n; i++)
    x->e[i] = nrandstd(r);
}

// -------------------------------------------------------------------
// X is the storage for the N samples, and C is the N x N upper 
// Cholesky decomposition. V is a temporary storage of size N. If mu 
// is NULL, the mean of the samples is 0.
void mvnrandm (Vector* x, Vector* v, Vector* mu, const Matrix* C, 
	       rndtype(r)) {  
  x->n = C->n;
  v->n = C->n;

  // Get the Normally-distributed samples.
  nrandm(v,r);

  // Multiply the samples by the Cholesky decomposition, and then 
  // add by the mean.
  multmatrixwithvector(C,v,x,1);
  if (mu != 0)
    addvectors(x,mu,x);
}

// -------------------------------------------------------------------
// Generate a left-truncated Normal sample with mean MU and 
// variance SIG.
double nrandtl (double mu, double sig, double a, rndtype(r)) {

  double std;
  double x;    // The return value.

  // What we will do is sample from Z ~ N(0,1) instead.
  std = sqrt(sig);
  a   = (a - mu) / std;

  // If a < 0 then we sample from a normal distribution. 
  // If a > 0 then we sample from an exponential distribution.
  // Repeat until we've generated the sample successfully. 
  if (a < 0)
    while(1) {
      
      // Generate a normal sample.
      x = nrandstd(r);
      if (x >= a)
	break;
    }
  else {
    double lambda;

    // Generate exponential samples using the optimal lambda
    // values, as explained by C.P. Robert (1995), Proposition 
    // 2.3, p. 4. 
    lambda = 0.5*(a + sqrt(a*a+4));
    while(1) {
      x = a - log(urand(r)) / lambda;
      if (urand(r) <= exp(-0.5*sqr(x-lambda)))
	break;
    }
  }
  
  // Convert the N(0,1) variables back to their original
  // distribution. 
  return mu + std*x; 
}

// -------------------------------------------------------------------
// Return a set of numbers on the set [0,N-1] in X.
void randperm (int* x, int n, rndtype(r)) {
  int    i, j;
  double u[n];
  int    ti;
  double td;

  // Enter the numbers from 0 to (n-1) in X. At the same time, 
  // we generate the N random numbers.
  for (i = 0; i < n; i++) {
    x[i] = i;
    u[i] = urand(r);
  }

  // Sort the numbers using bubble sort, keeping track of the 
  // indices.
  for (i = 0; i < n; i++)
    for (j = 0; j < n-1; j++)
      if (u[j] > u[j+1]) {
	swap(u[j],u[j+1],td)
        swap(x[j],x[j+1],ti)
      }
}

// -------------------------------------------------------------------
// Return a random deviate from the gamma distribution. From Arnaud 
// Doucet's Matlab code.
double randgamma (double alpha, double beta, rndtype(r)) {
  
  double x;
  double gamma;
  double eta;
  double c;
  double aux;
  double u;
  double y;
  double v;
  int    flag   = 0;

  // If alpha = 1 we have a Beta exponential distribution.
  if (alpha == 1) {
    x = -log(1-urand(r))/beta;
    return x;
  }

  if (alpha < 1) {
    flag  = 1;
    alpha = alpha + 1;
  }

  gamma = alpha - 1;
  eta   = sqrt(2*alpha-1);
  c     = 0.5-atan(gamma/eta)/M_PI;
  aux   = -0.5;

  while (aux < 0) {
    y = -0.5;
    while (y <= 0) {
      u = urand(r);
      y = gamma + eta*tan(M_PI*(u-c)+c-0.5);
    }
    v   = -log(urand(r));
    aux = (y-gamma)/eta;
    aux = v+log(1+aux*aux)+gamma*log(y/gamma)-y+gamma;
  }

  if (flag) 
    x = y/beta*pow(urand(r),1.0/(alpha-1));
  else
    x = y/beta;

  return x;
}

