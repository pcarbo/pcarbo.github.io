/*  These are routines for loading from disk the simulated 
    semi-supervised data created in Matlab.  

    Peter Carbonetto
    Copyright (c) 2003, 2004 INRIA Rh�nes-Alpes
*/  

#ifndef INCLUDESIMDATA
#define INCLUDESIMDATA

// Project includes.
#include "matrix.h"

// Type definitions.
typedef struct {
  int     d;      // The number of documents.
  int     maxM;   // The maximum document size.
  int*    Y;      // Array of document labels.
  int*    L;      // Array of document sizes.
  int*    docs;   // Array of indices from data points to documents.
  int*    balls;  // Array of data points in each document.
  int*    y;      // Array of true data point labels.
  Matrix* X;      // F x N array of data points, where F is the number 
                  // of features and N is the number of data points.
} Data;

// Function declarations.
Data* loadbindata (const char* fn);
void  freebindata (Data* data);

#endif
