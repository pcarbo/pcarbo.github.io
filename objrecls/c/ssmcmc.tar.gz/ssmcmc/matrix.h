/*  Operations on matrices of doubles.

    Peter Carbonetto
    Copyright (c) 2003, 2004 INRIA Rh�nes-Alpes
*/  

#ifndef INCLUDEMATRIX
#define INCLUDEMATRIX

// Standard includes.
#include <stdio.h>

// Type definitions
typedef struct {
  int     n;  // The length of the vector.
  int     s;  // The maximum amount of elements the vector can hold. 
  double* e;  // The array of elements.
} Vector;

typedef struct {
  int  n;  // The length of the vector.
  int  s;  // The maximum amount of elements the vector can hold. 
  int* e;  // The array of elements.
} Intvector;

// This is an N x M matrix. Note that we store each column contiguously, 
// so that two elements in the same column but neighbouring rows are 
// next to each other in the array.
typedef struct {
  int     n;  // The number of rows in the matrix.
  int     m;  // The numbers of columns in the matrix.
  int     s;  // The maximum amount of elements the matrix can hold.
  double* e;  // The array of elements.
} Matrix;

typedef struct {
  int  n;  // The number of rows in the matrix.
  int  m;  // The numbers of columns in the matrix.
  int  s;  // The maximum amount of elements the matrix can hold.
  int* e;  // The array of elements.
} Intmatrix;

// Macros.
// For memory allocation and struct initialisation.
#define vectormem    ((Vector*)    malloc(sizeof(Vector)))
#define intvectormem ((Intvector*) malloc(sizeof(Intvector)))
#define matrixmem    ((Matrix*)    malloc(sizeof(Matrix)))
#define intmatrixmem ((Intmatrix*) malloc(sizeof(Intmatrix)))
#define initvectorptr(v,E,N)   {v=vectormem; (v)->e=E; (v)->n=N; (v)->s=N;}
#define initmatrixptr(x,E,N,M) {x=matrixmem; (x)->e=E; (x)->n=N; (x)->m=M; (x)->s=N*M;}

// Index an N x M matrix X with row R and column C.
#define MRef(X,r,c,n)      X[(r)+(c)*(n)]
#define MdRef(X,i,n)       X[(i)*((n)+1)]
#define refMatrix(X,r,c)   MRef((X).e,r,c,(X).n)
#define diagrefMatrix(X,i) MdRef((X).e,i,(X).n)

// Copy the dimensions from matrix X to matrix Y.
#define copymatrixdims(X,Y) {(Y).n = (X).n; (Y).m = (X).m;}

// Cycle through all the elements of vector V using counter R and perform 
// operation OP using argument A, storing the values in vector X. We 
// assume vectors V and X both have the same length.
#define vectorunaryop(v,x,i,op,a) {for ((i)=0; (i)<(v).n; (i)++) (x).e[i] = ((v).e[i] op (a));}

// Cycle through all the elements of vectors V and W using counter I and 
// perform binary operation OP, storing the result in vector X. We assume 
// vectors V, W and X have the same number of elements.
#define vectorbinop(v,w,x,i,op) {for ((i)=0; (i)<(v).n; (i)++) (x).e[i] = ((v).e[i] op (w).e[i]);}

// Cycle through all the elements of matrix X using counters C and R and 
// perform operation OP using argument A, storing the values in matrix 
// Y. We assume matrices X and Y have the same dimension. Repeat for 
// each column and then for each row.
#define matrixunaryop(X,Y,c,r,op,a) {for ((c)=0; (c)<(X).m; (c)++) for ((r)=0; (r)<(X).n; (r)++) refMatrix(Y,r,c) = (refMatrix(X,r,c) op (a));}

// Cycle through all the elements of matrices A and B using counters C 
// and R and perform binary operation OP, storing the values in matrix 
// C. We assume matrices A, B and C have the same dimension. Repeat for 
// each column and then for each row.
#define matrixbinaryop(A,B,C,c,r,op) {for ((c)=0; (c)<(A).m; (c)++) for ((r)=0; (r)<(A).n; (r)++) refMatrix(C,r,c) = (refMatrix(A,r,c) op refMatrix(B,r,c));}

// Function declarations.
Vector*    initzerovector       (int n);
Intvector* initzerointvector    (int n);
Vector*    initvector           (int n, double a); 
void       freevector           (Vector* v);
void       freeintvector        (Intvector* v);
void       copyvector           (const Vector* v, Vector* w);
void       avector              (Vector* v, double a);
void       scalevector          (const Vector* v, double a, Vector* x);
void       addscalartovector    (const Vector* v, double a, Vector* x);
void       addvectors           (const Vector* v, const Vector* w, Vector* x);
void       subtractvectors      (const Vector* v, const Vector* w, Vector* x);
double     dot                  (const Vector* v, const Vector* w);
void       outerprod            (const Vector* v, const Vector* w, Matrix* X);
double     sumvectorelems       (const Vector* v);
void       incvectorsize        (Vector* v, int x);
void       incintvectorsize     (Intvector* v, int x);
void       selectvectorelems    (const Vector* v, Vector* w, const int* elems, 
				 int n);
void       catelemtovector      (Vector* v, double a);
void       catelemtointvector   (Intvector* v, int a);
void       remelemfromvector    (const Vector* v, Vector* w, int i);
void       remelemfromintvector (const Intvector* v, Intvector* w, int i);
void       remelemintvectorsafe (Intvector* v, int i);
void       printvector          (const Vector* v);
void       fprintvector         (FILE* fp, const Vector* v);
Vector*    fscanvector          (FILE* fp, int n);
Intvector* fscanintvector       (FILE* fp, int n);

Matrix*    initzeromatrix       (int n, int m);
Intmatrix* initzerointmatrix    (int n, int m);
Matrix*    initmatrix           (int n, int m, double a);
void       freematrix           (Matrix* X);
void       amatrix              (Matrix* X, double a);
void       identity             (Matrix* X, int n);
void       copymatrix           (const Matrix* A, Matrix* B);
void       selectmatrixcols     (const Matrix* A, Matrix* B, const int* cols, int m);
void       selectmatrixrows     (const Matrix* A, Matrix* B, const int* rows, int n);
void       getcolvector         (const Matrix* A, int c, Vector* v);
void       scalematrix          (const Matrix* X, Matrix* Y, double a);
void       addmatrices          (const Matrix* A, const Matrix* B, Matrix* C);
void       subtractmatrices     (const Matrix* A, const Matrix* B, Matrix* C);
void       multmatrices         (const Matrix* A, const Matrix* B, Matrix* C);
void       incmatrixsize        (Matrix* X, int s);
void       catcoltomatrix       (Matrix* X, const Vector* v);
void       catrowtomatrix       (Matrix* X, const Vector* v);
void       remmatrixcol         (const Matrix* A, Matrix* B, int c);
void       remmatrixcolsafe     (Matrix* A, int i);
void       remmatrixrow         (const Matrix* A, Matrix* B, int r);
void       printmatrix          (const Matrix* X);
void       fprintmatrix         (FILE* fp, const Matrix* X);
Matrix*    fscanmatrix          (FILE* fp, int n, int m);
void       gram                 (const Matrix* X, Matrix* G);
void       adddiagterm          (Matrix* A, double x);
int        matrixinv            (const Matrix* X, Matrix* Y, Matrix* B);
int        chol                 (const Matrix* X, Matrix* Y, Vector* p);
void       multmatrixwithvector (const Matrix* A, const Vector* v, Vector* x,
				 int transpose);
void       summatrixrows        (Matrix* A, Vector* v);
void       meancol              (const Matrix* X, Vector* mean);
void       stdcol               (const Matrix* X, const Vector* mean, Vector* std);
void       normalizecolumns     (Matrix* X, const Vector* mean, const Vector* std);

#endif
