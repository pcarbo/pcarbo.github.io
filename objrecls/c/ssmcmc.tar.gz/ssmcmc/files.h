#ifndef INCLUDEFILES
#define INCLUDEFILES

// Standard includes.
#include <stdio.h>

#define maxLblSizeInFile  256
#define maxNumSizeInFile  256

// Function declarations.
void   parseline      (FILE* f, char* s, char* t);
char   skipwhitespace (FILE* f);
void   skipuntil      (FILE* f, char d);
void   skipline       (FILE* f);
void   skipcolon      (FILE* f);
double readnum        (FILE* f, char type);

#endif
