/*  Routines for random and pseudo-random number generation. 

    Peter Carbonetto
    Copyright (c) 2003, 2004 INRIA Rh�nes-Alpes
*/  

#ifndef INCLUDERAND
#define INCLUDERAND

// Standard includes.
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

// Project includes.
#include "matrix.h"

// Type definitions.
typedef struct {
  gsl_rng* r;
  int      uacc;  // The total number of uniform samples generated.
  int      nacc;  // The total number of Normal samples generated.
} Nativerng;

typedef struct {
  int     t;     // The number of samples available for each type.
  int     u;     // The index of the previous uniform sample.
  int     n;     // The index of the previous Normal sample.
  int     uacc;  // The total number of uniform samples generated.
  int     nacc;  // The total number of Normal samples generated.
  double* UR;    // Array of pregenerated uniform random deviates.
  double* NR;    // Array of pregenerated Normal random deviates.
} Pseudorng;

// Macros.
#ifndef PSEUDORAND

// If PSEUDORAND is not defined, then we have normal random number 
// generation using the library. The macros that change are "urand",
// "nrandstd" and "rndinit", and we also have a macro which declares a new 
// random number generator. 
#define rndtype(r)          Nativerng* r
#define rndinit(r,t,f,seed) (r = initnativerand(t,seed))
#define rndfree(rng)        {gsl_rng_free((rng)->r); free(rng);}

// Return a uniform random number on the interval [0,1].
#define uinc(x,rng) (((rng)->uacc)++, (x))
#define urand(rng)  uinc(gsl_rng_get((rng)->r)/(double) (gsl_rng_max((rng)->r)-gsl_rng_min((rng)->r)),rng)

// Return a random number distributed on the standard Normal.
#define ninc(x,rng)   (((rng)->nacc)++, (x))
#define nrandstd(rng) ninc(gsl_ran_ugaussian((rng)->r),rng)

// The next two macros are only informative in the "pseudo-random" case. 
// They give the number of deviates used. 
#define numusedu(r)  ((r)->uacc)
#define numusedn(r)  ((r)->nacc)
#else

// If we get here, that's because PSEUDORAND was defined, and we will 
// generate random numbers predefined lists of uniform and Normal random 
// deviates. The macros that change are "urand", "nrandstd" and 
// "rndinit", and not to mention that we have a special macro for declaring
// a new random number generator variable.
#define rndtype(r)           Pseudorng* r
#define rndinit(r,t,f,seed)  (r = initpseudorand(f))
#define rndfree(rng)         (free(rng))

#define nextru(r)       ((r)->u = (++((r)->uacc) % (r)->t))
#define nextrn(r)       ((r)->n = (++((r)->nacc) % (r)->t))
#define urand(r)        ((r)->UR[nextru(r)])
#define urandpeek(r)    ((r)->UR[(r)->u+1])
#define nrandstd(r)     ((r)->NR[nextrn(r)])
#define numusedu(r)     ((r)->uacc + 1)   
#define numusedn(r)     ((r)->nacc + 1)
#endif 

// Return a random number distributed on the Normal with mean MU 
// and variance SIG.
#define nrand(mu,sig,r) ((mu) + (sig)*nrandstd(r))

// Return a random number from a right-truncated Normal.
#define nrandtr(mu,sig,b,r) (-nrandtl(-(mu),sig,-(b),r))

// Function declarations.
gsl_rng*   initrand       (const gsl_rng_type* type);
Nativerng* initnativerand (const gsl_rng_type* type, unsigned long int seed);
Pseudorng* initpseudorand (char* fn);
int        randint        (int a, int b, rndtype(r));
void       nrandm         (Vector* x, rndtype(r));
void       mvnrandm       (Vector* x, Vector* v, Vector* mu, const Matrix* C, 
	                   rndtype(r));
double     nrandtl        (double mu, double sig, double a, rndtype(r));
void       randperm       (int* x, int n, rndtype(r));
double     randgamma      (double alpha, double beta, rndtype(r));

#endif
