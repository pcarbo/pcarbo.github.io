// Project includes.
#include "timing.h"

// System includes.
#include <stdlib.h>

// Macros.


// Function definitions.
// -------------------------------------------------------------------
struct timeval* gettime (void) {
  struct timeval* t;   // The return value.
  struct timezone tz;
  t = timevalmem;
  gettimeofday(t,&tz);

  return t;
}

// -------------------------------------------------------------------
// Return the number of seconds that elapsed since time T.
double getelapsedtime (struct timeval* t) {
  double          d;   // The return value.
  struct timeval  t2;
  struct timeval  t1 = *t;
  struct timezone tz;

  // Get the current time.
  gettimeofday(&t2,&tz);

  // Calculate the difference between the two times, in seconds.
  d = t2.tv_sec - t1.tv_sec + 0.000001*(t2.tv_usec - t1.tv_usec);

  return d;
}
  
