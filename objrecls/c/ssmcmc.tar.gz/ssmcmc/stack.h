#ifndef INCLUDESTACK
#define INCLUDESTACK

// Type definitions.
typedef struct Stacknode Stacknode;

struct Stacknode {
  void*      v;     // The node value.
  Stacknode* next;
};

typedef struct {
  Stacknode* top;
} Stack;

// Function declarations.
Stack* newstack (void);
int    isempty  (const Stack* S);
void*  pop      (Stack* S);
void   push     (Stack* S, void* i);

#endif
