// Project includes.
#include "kmeans.h"
#include "kernels.h"

// Standard includes.
#include "stdlib.h"

// Function definitions.
// -------------------------------------------------------------------
// Run k-means. X is an F x N matrix of data points to cluster, where 
// F is the dimension of the data and N is the number of data points. 
// K is the number of clusters to create. We assume the tolerance is 
// very low and there is no maximum on the number of iterations, so 
// k-means stops at near convergence. 
// 
// The return values are the F x K matrix of cluster centres C, and 
// an array M of length N that gives an index on the interval [0,K-1] 
// describing the cluster membership for each data point. We assume 
// memory for matrix C and array M has already been allocated. Also, 
// the function returns the best error for the k-means clustering. If 
// k-means fails for whatever reason, the function returns -1. 
// Otherwise, it returns 0.
//
// Matrix D and integer array CNTS are temporary storage variables. 
// D is an K x N matrix which holds the distances between the points 
// and centres. CNTS is an integer array of length K to hold some 
// counts for the cluster centres.
int kmeans (const Matrix* X, Metricfunc f, int k, Matrix* C, int* m, 
	    Matrix* D, int* cnts, rndtype(rng), int verbose, 
	    double tol) {

  int     n, F;         // Dimensions of the data.
  int     i, r, c, fi;  // Loop variables.
  int     rmin;
  double  v, d;         // Temporary values.
  double  olde, e;      // The clustering error.

  // Get the number of data points and the number of features.
  F = X->n;
  n = X->m;

  // Check to see if there are more centres than data points.
  if (n < k)
    return -1;

  // Initialise the cluster centres C by selecting K data points at 
  // random.
  randperm(m,n,rng);
  selectmatrixcols(X,C,m,k);

  // Run k-means. Repeat until we've hit the specified tolerance.
  e = infty;
  i = 0;
  do {

    // Save the old error.
    olde = e;

    // Calculate the distances between the points and the centres.
    (*f)(D,X,C);

    // Assign each point to the nearest centre. We keep track of 
    // the number of points assigned to each cluster. First, 
    // initialise the point count for each cluster to zero.
    for (c = 0; c < k; c++)
      cnts[c] = 0;

    // Repeat for each data point (i.e. column of the distance 
    // matrix).
    for (c = 0; c < n; c++) {

      // Find the cluster with the minimum distance to the 
      // current point.
      rmin = 0;
      d    = refMatrix(*D,0,c);
      for (r = 1; r < k; r++) {
	v = refMatrix(*D,r,c);
        if (v < d) {
	  d    = v;
	  rmin = r;
	}
      } 
      
      // Store the membership for that point.
      m[c] = rmin;
      cnts[rmin]++;
    }

    // Make sure that each cluster index is represented at least 
    // once. If not, steal the closest point from the cluster 
    // centre that has more than one point. There will always 
    // be at least one cluster centre like the latter.
    // Repeat for each cluster centre.
    for (r = 0; r < k; r++)
      if (cnts[r] == 0) {

	// Get the minimum distance from a point to this cluster 
	// centre.
	d = refMatrix(*D,r,0);
	for (c = 1; c < n; c++) {
	  v = refMatrix(*D,r,c);
	  if (v < d)
	    d = v;
	}

	// We steal a point if the current point belongs to 
	// another cluster and the other cluster contains more 
	// than one point.
	// Repeat for all points.
	for (c = 0; c < n; c++) {
	  rmin = m[c];
	  if ((refMatrix(*D,r,c) == d) && (cnts[rmin] > 1)) {
	    m[c] = r;
	    cnts[rmin]--;
	    break;
	  }
	}
      }

    // Adjust the centres of the clusters to be the average 
    // of the member points. Also, we compute the new error.
    // First, set the current centres to zero and initialise 
    // the error.
    amatrix(C,0);
    e = 0;

    // Repeat for each data point (i.e. column of the distance 
    // matrix).
    for (c = 0; c < n; c++) {
      rmin = m[c];
      d    = refMatrix(*D,rmin,c);

      // Update the error.
      e += d;

      // Add this data point's contribution to the cluster centre.
      // Repeat for each feature.
      for (fi = 0; fi < F; fi++)
	refMatrix(*C,fi,rmin) += refMatrix(*X,fi,c);
    }
    
    // Normalize the cluster centres.
    // Repeat for each cluster centre, then for each feature.
    for (c = 0; c < k; c++)
      for (fi = 0; fi < F; fi++)
	refMatrix(*C,fi,c) /= (double) cnts[c];

    i++;
    if (verbose) {
      printf("%d (%0.3g) ", i, (olde-e));
      fflush(stdout);
    }

  } while ((olde - e) > tol);

  if (verbose)
    printf("\n");
  return 0;
}
