// Project includes.
#include "stack.h"

// System includes.
#include <stdlib.h>

// Function definitions.
// -------------------------------------------------------------------
Stack* newstack (void) {
  Stack* S;  // The return value.

  S = (Stack*) malloc(sizeof(Stack));
  S->top = NULL;
  return S;
}

// -------------------------------------------------------------------
// Returns 1 if the stack is empty. Otherwise, it returns 0.
int isempty (const Stack* S) {
  return (S->top == NULL);
}

// -------------------------------------------------------------------
void* pop (Stack* S) {
  Stacknode* e;
  void*      v;  // The return value.

  if (S->top == NULL) 
    v = NULL;
  else {
    e      = S->top;
    v      = e->v;
    S->top = e->next;
    free(e);
  }

  return v;
}

// -------------------------------------------------------------------
void push (Stack* S, void* v) {
  Stacknode* e;
  
  // Create the new element.
  e       = (Stacknode*) malloc(sizeof(Stacknode));
  e->v    = v;
  e->next = S->top;

  // Add the element to the stack.
  S->top = e;
}
