/*  The defined kernel functions.

    Peter Carbonetto
    Copyright (c) 2003, 2004 INRIA Rh�nes-Alpes
*/  

// Project includes.
#include "kernels.h"

// Standard includes.
#include <stdlib.h>
#include <math.h>
#include <string.h>

// Function definitions.
// -------------------------------------------------------------------
Metricfunc getmetricptr (char* s) {
  Metricfunc f;

  if (!strcasecmp(s,"fdist2"))
    f = fdist2;
  else
    f = NULL;

  return f;
}

// -------------------------------------------------------------------
Kernelfunc getkernelptr (char* s) {
  Kernelfunc f;

  if (!strcasecmp(s,"kgaussian"))
    f = kgaussian;
  else
    f = NULL;

  return f;
}

// -------------------------------------------------------------------
// X is an F x N matrix, Y is an F x M matrix, and D is a M x N matrix.
// We assume sufficient memory for D has already been allocated.
void fdist2 (Matrix* D, const Matrix* X, const Matrix* Y) {

  // Loop variables.
  int    f, n, m;
  int    cx, cy, r;
  double v, d;

  f    = X->n;
  n    = X->m;
  m    = Y->m;
  D->n = m;
  D->m = n;
  
  // Repeat for each data point (i.e. column) in X.
  for (cx = 0; cx < n; cx++)

    // Repeat for each data point (i.e. column) in Y.
    for (cy = 0; cy < m; cy++) {

      // Compute the distance between the two points and 
      // store the result into the matrix D.
      dist2(&refMatrix(*X,0,cx),&refMatrix(*Y,0,cy),f,r,v,d);
      refMatrix(*D,cy,cx) = sqrt(d);
    }
}

// -------------------------------------------------------------------
void kgaussian (Matrix* X, double lambda) {
  int    c, r;
  double d;

  // Repeat for each column of X, then for each row of X.
  for (c = 0; c < X->m; c++)
    for (r = 0; r < X->n; r++) {
      d = refMatrix(*X,r,c);
      refMatrix(*X,r,c) = exp(-lambda*d*d);
    }
}
