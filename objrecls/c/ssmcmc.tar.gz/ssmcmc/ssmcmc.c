// Project includes.
#include "ssmcmc.h"
#include "kernels.h"
#include "util.h"
#include "matrix.h"
#include "files.h"
#include "kmeans.h"
#include "stack.h"

// Standard includes.
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <gsl/gsl_randist.h>

// Macros.
#define betapdf  gsl_ran_beta_pdf

// Type definitions.
typedef struct {
  Intvector* gf;   // K x 1 vector.
  Matrix*    Psi;  // N x K matrix.
  Matrix*    G;    // K x K matrix.
  Matrix*    S;    // K x K matrix.
  Matrix*    Q;    // K x K matrix.
  Matrix*    Q0;   // K x K matrix.
  Vector*    Ak;   // K x 1 vector.
  Vector*    Az;   // K x 1 vector.
  Vector*    Az0;  // K x 1 vector.
  Vector*    QAk;  // K x 1 vector.
  Matrix*    T;    // K x K matrix.
  Vector*    t;    // K x 1 vector.
} KernelMatrices;

// Function declarations.
KernelMatrices* initkernelmatrices (int N, int ng);
void            growkernelmatrices (KernelMatrices* km);
void            freekernelmatrices (KernelMatrices* km);

Model*  returnmodel   (Model* model, double lambda, Matrix* C, int ns, 
		       Vector* mean, Vector* std, int maxng, int* Ng, 
		       int** Gf, double** Beta);
void    kernelmatrix  (Metricfunc f, Kernelfunc K, double lambda, 
		       const Matrix* X, const Matrix* C, 
		       const Intvector* gf, Matrix* Psi);
void    kernelrow     (Metricfunc f, Kernelfunc K, double lambda, 
		       const Matrix* X, const Matrix* C, int i, 
		       Vector* psi);
void    kernelcol     (Metricfunc f, Kernelfunc K, double lambda, 
		       const Matrix* X, const Matrix* C, int i, 
		       Vector* psi);
void    metricrow     (Metricfunc f, const Matrix* C, const Vector* x, 
		       Vector* d);
Matrix* gprior        (const Matrix* G, double epsilon);
int     computeq      (double epsilon, double delta, const Matrix* G, 
		       Matrix* T, Matrix* Q);
int     initgamma     (Metricfunc f, const Matrix* C, int* g, int* gind, 
		       Intvector* gf, int verbose, rndtype(rng));
Vector* initbeta      (const Matrix* S, double delta, rndtype(rng));
Vector* initz         (const int* L, int maxL, const int* balls, int d0, 
		       const int* yu, int N1, int N2, const int* yk1, 
		       const int* yk2, int nc1, int nc2, const Matrix* Psi, 
		       const Vector* beta, rndtype(rng));
void    inituzs       (Vector* z, const Vector* psiB, const int* L, 
		       int maxL, const int* balls, int d0, const int* yu, 
		       int nc1, int nc2, rndtype(rng));
void    inituzsoft    (Vector* z, const Vector* psiB, const int* L, 
		       int maxL, const int* balls, int d0, const int* yu, 
		       rndtype(rng));
int  samplegammagibbs (const Matrix* X, const Matrix* C, int k, 
		       Metricfunc f, Kernelfunc K, double lambda, int a, 
		       int b, double epsilon, double delta, const Vector* z, 
		       int* g, int* gind, KernelMatrices* km, 
		       Vector* psi, int* U, int verbose, rndtype(rng));
int     samplegammamh (const Matrix* X, const Matrix* C, int k, 
		       Metricfunc f, Kernelfunc K, double lambda, int a, 
		       int b, double epsilon, double delta, const Vector* z, 
		       int* g, int* gind, KernelMatrices* km, 
		       Vector* psi, int* U, int verbose, 
		       int* naccept, int* nreject, rndtype(rng));
double  samplealpha   (double mua, double nua, double epsilon, 
		       const Matrix* G, const Matrix* Q, const Vector* Az, 
		       const Vector* z, double delta, Matrix* Q2, 
		       Matrix* T, Vector* t, rndtype(rng));
int     samplebeta    (const Matrix* Q, const Vector* Az, const Vector* z, 
		       double aratio, Matrix* T, Vector* t1, Vector* t2, 
		       Vector* beta, rndtype(rng));
double  sampledelta   (double epsilon, double mu, double nu, 
		       const Matrix* G, const Vector* beta, Matrix* T, 
		       Vector* t, rndtype(rng));
void    samplez       (const int* L, const int* balls, int maxL, 
		       const int* yu, int d0, int N1, int N2, 
		       const int* yk1, const int* yk2, int soft, int nc1, 
		       int nc2, double m, double chi, Matrix* Psi, 
		       Vector* beta, Vector* psiB, Vector* z, rndtype(rng));
void    samplekzs     (Vector* z, const Vector* psiB, int N1, int N2,
		       const int* yk1, const int* yk2, rndtype(rng));
void    sampleuzs     (Vector* z, const int* L, const int* balls, int maxL,
		       const int* yu, int d0, int nc1, int nc2, 
		       const Vector* psiB, rndtype(rng));
void    sampleuzsoft  (Vector* z, const int* L, const int* balls, int maxL,
		       const int* yu, int d0, double m, double chi,
		       const Vector* psiB, rndtype(rng));
void   classifypoints (double* p, const Matrix* X, const int* is, int n,
		       Metricfunc f, Kernelfunc K, double lambda, 
		       const Matrix* C, const int* Ng, int** Gf,
		       double** Beta, int ns, int* R, Vector* Psi, 
		       Vector* psi, int verbose);

// Function definitions.
// -------------------------------------------------------------------
void savemodel (const Model* model, const char* fn) {
  
  Model m = *model;
  FILE* f;
  int   s, i;  // Loop variables.
  int   ng;
  int   F;     // The number of features.
  int   k;     // The number of kernels.
  int   ku;    // The number of used kernels.
  int*  gu;    // The indices of the used kernels.
  int*  g;     // An entry is 1 if the kernel is used.
  int*  gind;  // The indices corresponding to the "gu" array.
  int*  gf;    // Array containing the modified indices for a 
               // single sample.
  Matrix* Cu;  // The set of used kernel centres.
  
  F = m.C->n;
  k = m.C->m;

  // Get the indices of the kernels that are used at least once.
  g    = intmem(k);
  gind = intmem(k);
  for (i = 0; i < k; i++) {
    g[i]    = 0;
    gind[i] = 0;
  }

  // Set entry of "g" to 1 if we found it in the set of samples.
  // Repeat for every sample, and then for every active kernel 
  // (i.e. index contained in Gf).
  for (s = 0; s < m.ns; s++)
    for (i = 0; i < m.Ng[s]; i++)
      g[(m.Gf[s])[i]] = 1;

  // Create new indices for the used kernels. Repeat for each 
  // kernel. At the end, "ku" will be the number of used 
  // kernels. 
  ku = sumint(g,k);
  gu = intmem(ku);
  ku = 0;
  for (i = 0; i < k; i++)
    if (g[i] == 1) {
      gu[ku]  = i;
      gind[i] = ku;
      ku++;
    }

  // Get the set of used kernel centres.
  Cu = initzeromatrix(F,ku);
  selectmatrixcols(m.C,Cu,gu,ku);

  // Open the file for writing.
  f = fopen(fn, "wt");
  if (!f) {
    fprintf(stderr, "Cannot open file %s for writing.\n", fn);
    return;
  }

  // Save some preliminary information.
  fprintf(f, "Number of features: %d\n", F);
  fprintf(f, "Number of kernels: %d\n", ku);
  fprintf(f, "metric: %s\n", m.f);
  fprintf(f, "kernel: %s\n", m.K);
  fprintf(f, "lambda: %0.6f\n", m.lambda);
  fprintf(f, "Number of samples: %d\n", m.ns);
  fprintf(f, "Max. num. gammas: %d\n", m.maxng);

  // Save the mean and standard deviation of the data.
  fprintf(f, "Sample mean: ");
  fprintvector(f, m.mean);
  fprintf(f, "Sample stddev: ");
  fprintvector(f, m.std);

  // Save the kernel centres.
  fprintf(f, "Kernel centres:\n");
  fprintmatrix(f, Cu);

  // Save the sums of gammas.
  fprintf(f, "Sums of gammas: ");
  fprintints(f, m.Ng, m.ns);

  // Save the indices of active gammas.
  fprintf(f, "Active gamma indices:\n");
  gf = intmem(m.maxng);
  for (s = 0; s < m.ns; s++) {
    ng = m.Ng[s];
    for (i = 0; i < ng; i++)
      gf[i] = gind[(m.Gf[s])[i]];   
    fprintints(f, gf, ng);
  }

  // Save Beta.
  fprintf(f, "Beta:\n");
  for (s = 0; s < m.ns; s++)
    fprintnums(f, m.Beta[s], m.Ng[s]);

  // Close the file.
  fclose(f);  

  // Free memory.
  freematrix(Cu);
  free(gf);
  free(gu);
  free(gind);
  free(g);
}

// -------------------------------------------------------------------
Model* loadmodel (const char* fn) {

  Model*  model;
  Model   m;
  FILE*   f;
  char    s[maxLblSizeInFile];
  char    t[maxNumSizeInFile];
  int     si, i, ng;
  int     F, k;
  int     sum;

  // Open the file for reading.
  f = fopen(fn, "rt");
  if (!f) {
    fprintf(stderr, "Cannot open file %s for reading.\n", fn);
    return NULL;
  }

  // Get the number of features.
  skipcolon(f);
  F = (int) readnum(f,'i');  

  // Get the number of kernels.
  skipcolon(f);
  k = (int) readnum(f,'i');    

  // Get the metric type.
  parseline(f,s,t);
  m.f = strmem(t);
  strcpy(m.f,t);

  // Get the kernel type.
  parseline(f,s,t);
  m.K = strmem(t);
  strcpy(m.K,t);

  // Get lambda.
  skipcolon(f);
  m.lambda = readnum(f,'f');    

  // Get the number of samples.
  skipcolon(f);
  m.ns = (int) readnum(f,'i');    

  // Get the maximum number of active gammas.
  skipcolon(f);
  m.maxng = (int) readnum(f,'i');    

  // Get the sample mean and standard deviation.
  skipcolon(f);
  m.mean = fscanvector(f,F);
  skipcolon(f);
  m.std = fscanvector(f,F);

  // Get the kernel centres. Repeat for each kernel centre, 
  // then for each feature.
  skipcolon(f);
  m.C = fscanmatrix(f,F,k);

  // Get the sums of gammas. Repeat for each sample.
  skipcolon(f);
  m.Ng = intmem(m.ns); 
  fscanints(f,m.Ng,m.ns);
  sum = sumint(m.Ng,m.ns);

  // Get the gamma indices. Repeat for each sample, then for 
  // each active kernel in the sample.
  skipcolon(f);
  m.ngf      = 1;
  m.Gfmem    = (int**) ptrmem(1);
  m.Gf       = (int**) ptrmem(m.ns);  
  *(m.Gfmem) = intmem(sum);
  si         = 0;
  for (i = 0; i < m.ns; i++) {
    ng      = m.Ng[i];
    m.Gf[i] = &((*(m.Gfmem))[si]);
    fscanints(f,m.Gf[i],ng);
    si += ng;
  }

  // Get Beta.
  skipcolon(f);
  m.nbeta      = 1;
  m.Betamem    = (double**) ptrmem(1);
  m.Beta       = (double**) ptrmem(m.ns);
  *(m.Betamem) = doublemem(sum);
  si           = 0;
  for (i = 0; i < m.ns; i++) {
    ng        = m.Ng[i];
    m.Beta[i] = &((*(m.Betamem))[si]);
    fscannums(f,m.Beta[i],ng);
    si += ng;
  }

  // Close the file and return the model.
  fclose(f);  
  model  = modelmem;  
  *model = m;
  return model;
}

// -------------------------------------------------------------------
// If SAVEF is a valid string, then the function saves the trained 
// model to disk. If SAVEINT is greater than zero, the function saves 
// the trained model periodically. VERBOSE = 1 sets messages to be on.
Model* ssmcmctrain (int d, int maxL, Matrix* X, int* Y, int* L, 
		    int* balls, int* docs, char* fstr, char* Kstr, 
		    double lambda, double mu, double nu, double mua, 
		    double nua, double a, double b, double epsilon, 
		    int ns, int sskip, int soft, int nc1, int nc2, 
		    double m, double chi, rndtype(rng), char* savef, 
		    int saveint, int verbose) {

  Model*     model;
  Metricfunc f;     // The metric function pointer.
  Kernelfunc K;     // The kernel function pointer.
  Matrix*    C;     // The kernel centres.

  int     F = X->n; // The dimension of the data points.
  int     N = X->m; // The number of data points.
  int     k = N;    // The number of kernel centres.
  int     ng;       // The number of active kernels.
  int     maxng;    // The maximum number of active kernels in a sample.
  int     N1;       // Number of data points with positive labels.
  int     N2;       // Number of data points with negative labels.
  int     d0;       // Number of documents without a label.
  int*    yk1;      // Indices of data points with positive labels.
  int*    yk2;      // Indices of data points with negative labels.
  int*    yu;       // Indices of documents without labels.
  double  delta;
  int     g[k];     // An element of this array is 1 iff the respective 
                    // kernel is active.
  int     gind[k];  // Indices corresponding to "gf".

  // Vectors and matrices.
  Vector*         beta;   // K x 1 vector.
  Vector*         z;      // N x 1 vector.
  Vector*         psi;    // N x 1 vector.
  Vector*         psiB;   // N x 1 vector.
  Vector*         mean;   // Mean for normalization.
  Vector*         std;    // Standard deviation for normalization.
  KernelMatrices* km;     // All the matrices associated with the 
                          // number of active kernels.
  
  // Storage for the samples.
  int*     Ng;      // Number of active kernels per sample.
  int**    Gf;      // Indices of active kernels.
  double** Beta;    // Beta samples.

  // Normalize the data points.
  mean = initzerovector(F);
  std  = initzerovector(F);
  meancol(X,mean);
  stdcol(X,mean,std);
  normalizecolumns(X,mean,std);
  
  // Get the kernel centres and kernel function. 
  f = getmetricptr(fstr);
  K = getkernelptr(Kstr);
  C = initzeromatrix(F,k);
  copymatrix(X,C);

  // Get the number of data points with the positive and negative 
  // classes, and the number of documents with question marks.
  {
    int di;
    int yi;
    int li;

    N1 = 0;
    N2 = 0;
    d0 = 0;

    // Repeat for each document.
    for (di = 0; di < d; di++) {
      yi  = Y[di];
      li  = L[di];
      N1 += (yi == 1) * li;
      N2 += (yi == 2) * li;
      d0 += (yi == 0);
    }
  }

  // Get the set of data points with the positive and negative 
  // classes, and the number of documents with question marks. 
  {
    int di; 
    int yi; 
    int li;
    int i, nu, n1, n2;

    yk1 = intmem(N1);
    yk2 = intmem(N2);
    yu  = intmem(d0);
    n1  = 0;
    n2  = 0;
    nu  = 0;

    for (di = 0; di < d; di++) {
      yi = Y[di];
      li = L[di];
      if (yi == 1) {
	
	// Repeat for data point in the document. These data 
	// points have positive labels.
	for (i = 0; i < li; i++, n1++)
	  yk1[n1] = MRef(balls,i,di,maxL);
      }
      else if (yi == 2) {

	// Repeat for data point in the document. These data 
	// points have negative labels.
	for (i = 0; i < li; i++, n2++)
	  yk2[n2] = MRef(balls,i,di,maxL);
      }
      else {
	yu[nu] = di;
	nu++;
      }
    }
  }

  // Initialise the number of gammas.
  { 
    double tau;
    tau   = a/(a+b); 
    ng    = (int) ceil(k*tau);
    maxng = ng;
  }

  // Allocate memory for the matrices.
  km   = initkernelmatrices(N,ng);
  beta = initzerovector(ng);
  psi  = initzerovector(N);
  psiB = initzerovector(N);
  
  // Initialise gamma.
  if (initgamma(f,C,g,gind,km->gf,verbose,rng) < 0)
    return NULL;

  // Initialise delta.
  delta = mu/(nu+1);

  // Compute Psi.
  kernelmatrix(f,K,lambda,X,C,km->gf,km->Psi);

  // Compute the Gram matrix.
  gram(km->Psi,km->G);
  printmatrix(km->G);

  // Compute the S prior.
  if ((km->S = gprior(km->G,epsilon)) == NULL)
    return NULL;

  // Initialise beta.
  if ((beta = initbeta(km->S,delta,rng)) == NULL)
    return NULL;

  // Initialise the z samples. We have to ensure from 
  // the start that the z's follow the constraints.
  z = initz(L,maxL,balls,d0,yu,N1,N2,yk1,yk2,nc1,nc2,
	    km->Psi,beta,rng); 

  if (verbose) {
    printf("0 (%d) ", ng);
    fflush(stdout);
  }

  // Reserve storage for the samples gamma and beta.
  Ng       = intmem(ns);
  Gf       = (int**) ptrmem(ns);
  Beta     = (double**) ptrmem(ns);
  model    = modelmem;
  model->f = getmemandstrcpy(fstr);
  model->K = getmemandstrcpy(Kstr);
  
  // Simulate the samples.
  {
    // Loop variables.
    int s, si;
    
    int    U[k];   // Storage for random order that we sample gammas.
    double aratio; // The ratio uses for the expansion parameter.
    
    // Repeat for each sample.
    for (s = 0; s < ns; s++) {

      // Repeat for each skipped sample.
      for (si = 0; si < sskip; si++) {

	// Sample the gammas using Gibbs sampling.
	if ((ng = samplegammagibbs(X,C,k,f,K,lambda,a,b,epsilon,delta,z,
				   g,gind,km,psi,U,verbose,rng)) == 0)
	  return NULL;
	
	if (ng > maxng) {
	  maxng = ng;
	  incvectorsize(beta,ng);
	  incvectorsize(beta,ng);
	}

	// Sample alpha.
	if ((aratio = samplealpha(mua,nua,epsilon,km->G,km->Q,
				  km->Az,z,delta,km->T,km->Q0,
				  km->t,rng)) < 0)
	  return NULL;
	
	// Sample beta.
	if (samplebeta(km->Q,km->Az,z,aratio,km->T,km->t,
		       km->Az0,beta,rng) == -1)
	  return NULL;
	
	// Sample delta.
	delta = sampledelta(epsilon,mu,nu,km->G,beta,km->T,
			    km->t,rng);
	
	// Sample the z's.
	samplez(L,balls,maxL,yu,d0,N1,N2,yk1,yk2,soft,
		nc1,nc2,m,chi,km->Psi,beta,psiB,z,rng);
      }

      if (verbose) {
	int i, np;
	
	// Get the number of positive z's.
	np = 0;
	for (i = 0; i < N; i++)
	  np += (z->e[i] > 0);
	
	printf("%d (%d|%d) ", s*sskip+si, ng, np);
	fflush(stdout);
      }
      
      // Store the samples.
      Ng[s]   = ng;
      Beta[s] = doublemem(ng);
      Gf[s]   = intmem(ng);
      memcpy(Beta[s],beta->e,sizeof(double)*ng);
      memcpy(Gf[s],km->gf->e,sizeof(int)*ng);

      // We may want to save the results periodically. The user will
      // only be interested in doing so if "saveint" is greater than
      // zero. Don't save results if we are on the last iteration, 
      // because we're going to do so anyhow. 
      if ((saveint > 0) && (((s+1) % saveint) == 0) && (s+1 != ns)) {
	if (verbose) {
	  printf("Saving samples. ");
	  fflush(stdout);
	}
	
	model = returnmodel(model,lambda,C,s+1,mean,std,maxng,Ng,Gf,Beta);
	savemodel(model,savef);
      }
    }

  }

  // Return the model and save it.
  if (verbose) {
    printf("Saving samples.\n");
    fflush(stdout);
  }
  model = returnmodel(model,lambda,C,ns,mean,std,maxng,Ng,Gf,Beta);
  savemodel(model,savef);

  // Free memory associated dynamically-allocated blocks.
  freekernelmatrices(km);
  freevector(beta);
  freevector(z);
  freevector(psi);
  freevector(psiB);
  free(yk1);
  free(yk2);
  free(yu);

  // Return the model.
  return model;
}

// -------------------------------------------------------------------
// s0 is the "burn in", "ns" is the cutoff and sp is the probability 
// of keeping a sample. 
InferredLabels ssmcmctest (Matrix* X, const Model* model, int burnin, 
			   int cutoff, double sp, int verbose, 
			   rndtype(rng)) {

  InferredLabels result;
  Model          m = *model;
  int            N = X->m;
  int            k = m.C->m;
  int            s, i;
  int            ns;
  double*        p;
  int*           is;
  int*           R;      // The indices of the samples in a random order.
  Metricfunc     f;
  Kernelfunc     K;
  Vector*        Psi;    // Kernel response row.
  Vector*        psi;    // Selected columns from the kernel 
                         // response row.

  // Adjust the cutoff if necessary.
  if ((cutoff == -1) || (cutoff > m.ns))
    cutoff = m.ns;

  // Find a random order for the samples.
  ns  = cutoff - burnin;
  R   = intmem(ns);
  randperm(R,ns,rng);
  ns  = (int) ceil(ns*sp);
  for (s = 0; s < ns; s++)
    R[s] += burnin;

  // Normalize the data.
  normalizecolumns(X, m.mean, m.std);

  // Initialise some other stuff.
  f   = getmetricptr(m.f);
  K   = getkernelptr(m.K);
  p   = doublemem(N);
  is  = intmem(N);
  Psi = initzerovector(k);
  psi = initzerovector(m.maxng);

  // Initialise the result.
  result.N  = N;
  result.py = doublemem(2*N);

  // Classify the points.
  for (i = 0; i < N; i++)
    is[i] = i;
  classifypoints(p,X,is,N,f,K,m.lambda,m.C,m.Ng,m.Gf,
		 m.Beta,ns,R,Psi,psi,verbose);
  for (i = 0; i < N; i++) {
    result.py[2*i]   = 1 - p[i];
    result.py[2*i+1] = p[i];
  }

  // Free allocated memory.
  freevector(Psi);
  freevector(psi);
  free(is);
  free(p);
  free(R);

  return result;
}

// -------------------------------------------------------------------
// "Psi" and "psi" are temporary storage vectors. "Psi" is a vector of
// length K, where K is size of the set of kernels centres. "psi" is a 
// vector of length greater than or equal to the maximum number of 
// active kernels in a single sample.
void classifypoints (double* p, const Matrix* X, const int* is, int n,
		     Metricfunc f, Kernelfunc K, double lambda, 
		     const Matrix* C, const int* Ng, int** Gf,
		     double** Beta, int ns, int* R, Vector* Psi, 
		     Vector* psi, int verbose) {

  double pi;     // The probability of negative classification
                 // for a single point.
  int    i, ri;  // Loop variables.
  int    s, rs;  // Loop variables.
  int    ng;
  int*   gf;
  Vector beta;

  // Repeat for each data point.
  for (i = 0; i < n; i++) {
    ri = is[i];

    if (verbose) {
      printf("%d ", i+1);
      fflush(stdout);
    }

    // Compute the kernel response for the current data point.
    kernelrow(f,K,lambda,X,C,ri,Psi);
    
    // Repeat for each sample.
    pi = 0;
    for (s = 0; s < ns; s++) {
      rs = R[s];

      // Get the number of active kernels, the indices of the active 
      // kernels and Beta.
      ng     = Ng[rs];
      gf     = Gf[rs];
      beta.e = Beta[rs];
      beta.n = ng;
      beta.s = ng;

      // Compute this sample's contribution.
      selectvectorelems(Psi,psi,gf,ng);
      pi += normcdf(-dot(psi,&beta));
    }

    pi    = pi / ((double) ns);
    p[ri] = pi;
  }
}

// -------------------------------------------------------------------
void freemodel (Model* model) {
  int i;

  free(model->f);
  free(model->K);
  freematrix(model->C);
  freevector(model->mean);
  freevector(model->std);
  free(model->Ng);
  for (i = 0; i < model->nbeta; i++)
    free(model->Betamem[i]);
  for (i = 0; i < model->ngf; i++)
    free(model->Gfmem[i]);
  free(model->Betamem);
  if (model->Betamem != model->Beta)
    free(model->Beta);
  free(model->Gfmem);
  if (model->Gfmem != model->Gf)
    free(model->Gf);
  free(model);
}

// -------------------------------------------------------------------
// Fill in all the values of the model except "K".
Model* returnmodel (Model* model, double lambda, Matrix* C, int ns, 
		    Vector* mean, Vector* std, int maxng, int* Ng, 
		    int** Gf, double** Beta) {

  model->lambda  = lambda;
  model->C       = C;
  model->mean    = mean;
  model->std     = std;
  model->ns      = ns;
  model->maxng   = maxng;
  model->Ng      = Ng;
  model->Gfmem   = Gf;
  model->Gf      = Gf;
  model->ngf     = ns;
  model->Betamem = Beta;
  model->Beta    = Beta;
  model->nbeta   = ns;

  return model;
}

// -------------------------------------------------------------------
KernelMatrices* initkernelmatrices (int N, int ng) {
  KernelMatrices* km;  // The return value.

  km      = (KernelMatrices*) malloc(sizeof(KernelMatrices));
  km->gf  = initzerointvector(ng);
  km->Psi = initzeromatrix(N,ng);
  km->G   = initzeromatrix(ng,ng);
  km->S   = initzeromatrix(ng,ng);
  km->Q   = initzeromatrix(ng,ng);
  km->Q0  = initzeromatrix(ng,ng);
  km->Ak  = initzerovector(ng);
  km->Az  = initzerovector(ng);
  km->Az0 = initzerovector(ng);
  km->QAk = initzerovector(ng);
  km->T   = initzeromatrix(ng,ng);
  km->t   = initzerovector(ng);

  return km;
}

// -------------------------------------------------------------------
void growkernelmatrices (KernelMatrices* km) {
  int ng = km->gf->s + 1;
  int N  = km->Psi->n;

  incintvectorsize(km->gf,ng);
  incvectorsize(km->Ak,ng);
  incvectorsize(km->Az,ng);
  incvectorsize(km->Az0,ng);
  incvectorsize(km->QAk,ng);
  incvectorsize(km->t,ng);
  incmatrixsize(km->Psi,N*ng);
  incmatrixsize(km->G,ng*ng);
  incmatrixsize(km->S,ng*ng);
  incmatrixsize(km->Q,ng*ng);
  incmatrixsize(km->Q0,ng*ng);
  incmatrixsize(km->T,ng*ng);
}

// -------------------------------------------------------------------
void freekernelmatrices (KernelMatrices* km) {
  freeintvector(km->gf);
  freevector(km->Ak);
  freevector(km->Az);
  freevector(km->Az0);
  freevector(km->QAk);
  freevector(km->t);
  freematrix(km->Psi);
  freematrix(km->G);
  freematrix(km->S);
  freematrix(km->Q);
  freematrix(km->Q0);
  freematrix(km->T);
}
  
// -------------------------------------------------------------------
void kernelmatrix (Metricfunc f, Kernelfunc K, double lambda, 
		   const Matrix* X, const Matrix* C, 
		   const Intvector* gf, Matrix* Psi) {
  int F  = X->n;
  int ng = gf->n;

  Matrix* Ck;   // The F x K matrix of active kernels.
    
  // Get the set of active kernels.
  Ck = initzeromatrix(F,ng);
  selectmatrixcols(C,Ck,gf->e,ng);

  // Fill Psi with the kernel responses.
  (*f)(Psi,Ck,X);
  (*K)(Psi,lambda); 

  // Free memory and return the matrix.
  freematrix(Ck);
}

// -------------------------------------------------------------------
// Return the repsonse for a single data point in 1 x K vector "psi".
void kernelrow (Metricfunc f, Kernelfunc K, double lambda, 
		const Matrix* X, const Matrix* C, int i, 
		Vector* psi) {
  int    F    = X->n;
  int    k    = C->m;
  Matrix x;            // Shadows "X".
  Matrix psim;         // Shadows "psi".

  x.n = F;
  x.m = 1;
  x.s = F;
  x.e = &refMatrix(*X,0,i);
  
  psim.n = 1;
  psim.m = k;
  psim.s = k;
  psim.e = psi->e;

  // Compute psi.
  (*f)(&psim,C,&x);
  (*K)(&psim,lambda);
}

// -------------------------------------------------------------------
// Return the response for a single kernel in N x 1 vector "psi".
void kernelcol (Metricfunc f, Kernelfunc K, double lambda, 
		const Matrix* X, const Matrix* C, int i, 
		Vector* psi) {

  int    F    = X->n;
  int    N    = X->m;
  Matrix Ck;           // Shadows "C".
  Matrix psim;         // Shadows "psi".

  Ck.n = F;
  Ck.m = 1;
  Ck.s = F;
  Ck.e = &refMatrix(*C,0,i);

  psim.n = N;
  psim.m = 1;
  psim.s = N;
  psim.e = psi->e;

  // Compute psi.
  (*f)(&psim,&Ck,X);
  (*K)(&psim,lambda);
}

// -------------------------------------------------------------------
void metricrow (Metricfunc f, const Matrix* C, const Vector* x, 
		Vector* d) {
  int    F = x->n;
  int    k = C->m;
  Matrix xm;  // Shadows "x".
  Matrix dm;  // Shadows "d".

  xm.n = F;
  xm.m = 1;
  xm.s = F;
  xm.e = x->e;
  
  dm.n = 1;
  dm.m = k;
  dm.s = k;
  dm.e = d->e;

  // Compute the distance.
  (*f)(&dm,C,&xm);
}

// -------------------------------------------------------------------
Matrix* gprior (const Matrix* G, double epsilon) {
  int     ng = G->n;
  Matrix* S;
  Matrix* T;

  S = initzeromatrix(ng,ng);
  T = initzeromatrix(ng,ng);

  copymatrix(G,S);
  adddiagterm(S,epsilon);
  if (matrixinv(S,S,T)) {
    fprintf(stderr, "The Gram matrix is singular.\n");
    return NULL;
  }

  // Free memory and return the matrix.
  freematrix(T);
  return S;
}

// -------------------------------------------------------------------
// Returns 0 on success, or -1 on failure.
int computeq (double epsilon, double delta, const Matrix* G, 
	      Matrix* T, Matrix* Q) {
  scalematrix(G,Q,(1+delta)/delta);
  adddiagterm(Q,epsilon/delta);
  if (matrixinv(Q,Q,T)) {
    fprintf(stderr, "The inverse of Q is singular.\n");
    return -1;
  }

  return 0;
}

// -------------------------------------------------------------------
Vector* initbeta (const Matrix* S, double delta, rndtype(rng)) {
  int     ng = S->n;
  Vector* beta;
  Matrix* T;
  Vector* t;

  // Initialise beta.
  beta  = initzerovector(ng);
  t     = initzerovector(ng);
  T     = initzeromatrix(ng,ng);

  if (chol(S,T,t)) {
    fprintf(stderr, "The prior S is singular.\n");
    return NULL;
  }
  mvnrandm(beta,t,0,T,rng);
  scalevector(beta,sqrt(delta),beta);

  // Free the memory and return the vector.
  freematrix(T);
  freevector(t);
  return beta;
}

// -------------------------------------------------------------------
// Returns 0 on success, or -1 on failure.
int initgamma (Metricfunc f, const Matrix* C, int* g, int* gind, 
	       Intvector* gf, int verbose, rndtype(rng)) {

  int        F  = C->n;
  int        k  = C->m;
  int        ng = gf->n;

  Matrix*    Ck;    // The cluster centres for the active kernels.
  Matrix*    D;     // Distance matrix used during k-means.
  int*       M;     // The membership of the kernel centres to the
                    // the clusters.
  int*       Mi;    // The membership for a particular cluster.
  int*       cnts;  // Temporary storage variable.
  int        i, j;  // Loop variables.
  int        ni;    // Loop variables.

  // Allocate memory for the arrays and matrices.
  Ck   = initzeromatrix(F,ng);
  D    = initzeromatrix(ng,k);
  M    = intmem(k);
  Mi   = intmem(k);
  cnts = intmem(ng);

  // Initialises the gammas to zero.
  for (i = 0; i < k; i++) {
    g[i]    = 0;
    gind[i] = 0;
  }

  if (ng > 0) {
    
    // Run k-means.
    if (verbose)
      printf("Running k-means: ");
    if (kmeans(C,f,ng,Ck,M,D,cnts,rng,verbose,1e-10) == -1) {
      printf("K-means failed.\n");
      return -1;
    }
    
    // Repeat for each cluster centre.
    for (i = 0; i < ng; i++) {
      
      // Find the indices of the members of the 
      // current cluster.
      ni = 0;
      for (j = 0; j < k; j++)
	if (M[j] == i) {
	  Mi[ni] = j;
	  ni++;
	}
      
      // From the members of the current cluster, randomly
      // select a single kernel.
      j        = Mi[randint(0,ni-1,rng)];
      gf->e[i] = j;
      g[j]     = 1;
      gind[j]  = i;
    }
  }
  else {
    
    // Make sure there is at least one active kernel; the 
    // first one.
    ng   = 1;
    g[0] = 1;
  }

  // Free the allocated memory.
  freematrix(Ck);
  freematrix(D);
  free(M);
  free(Mi);
  free(cnts);

  return 0;
}

// -------------------------------------------------------------------
Vector* initz (const int* L, int maxL, const int* balls, int d0, 
	       const int* yu, int N1, int N2, const int* yk1, 
	       const int* yk2, int nc1, int nc2, const Matrix* Psi, 
	       const Vector* beta, rndtype(rng)) {

  int     N = Psi->n;
  Vector* z;         // The return value.
  Vector* psiB;      // N x 1 vector.

  psiB = initzerovector(N);
  z    = initzerovector(N);
  multmatrixwithvector(Psi,beta,psiB,0);

  // Sample the z's associated with known labels.
  samplekzs(z,psiB,N1,N2,yk1,yk2,rng);

  // Initialise the z's from the documents with 
  // unknown labels.
#ifdef SOFTCONSTRAINTS
  inituzsoft(z,psiB,L,maxL,balls,d0,yu,rng);
#else
  inituzs(z,psiB,L,maxL,balls,d0,yu,nc1,nc2,rng);
#endif

  // Free memory and return the vector.
  freevector(psiB);
  return z;
}

// -------------------------------------------------------------------
void inituzs (Vector* z, const Vector* psiB, const int* L, int maxL, 
	      const int* balls, int d0, const int* yu, int nc1, 
	      int nc2, rndtype(rng)) {

  int nct = nc1 + nc2;
  int i, di, li;
  int j, rj;
  int R[maxL];

  // The z's from the unknown y's are not sampled in a very
  // intelligent fashion. Repeat for each unlabelled document. 
  for (i = 0; i < d0; i++) {
    di = yu[i];          // The document index.
    li = L[di];          // The number of points in the document.
    randperm(R,li,rng);  // Create a random permutation of the points.
    for (j = 0; j < li; j++)
      R[j] = MRef(balls,R[j],di,maxL);
    
    // We cannot apply the constraints when there are not enough
    // data points in the document, so we sample the z's
    // independently.  
    if (li < nct) {
      
      // Repeat for each data point in the document. Sample the 
      // z's without any constraints.
      for (j = 0; j < li; j++) {
	rj       = R[j];
	z->e[rj] = nrand(psiB->e[rj],1,rng);
      }
    } 
    else {
      
      // Sample z's indepedently, keeping in mind the constraints. 
      // Sample the z's chosen to be positive.
      for (j = 0; j < nc1; j++) {
	rj       = R[j];
	z->e[rj] = nrandtl(psiB->e[rj],1,0,rng);
      }
      
      // Sam the z's chosen to be negative.
      for (j = nc1; j < nct; j++) {
	rj       = R[j];
	z->e[rj] = nrandtr(psiB->e[rj],1,0,rng);
      }          
      
      // Sample the z's without any constraints.
      for (j = nct; j < li; j++) {
	rj       = R[j];
	z->e[rj] = nrand(psiB->e[rj],1,rng);
      }
    }
  }
}

// -------------------------------------------------------------------
void inituzsoft (Vector* z, const Vector* psiB, const int* L, int maxL, 
	      const int* balls, int d0, const int* yu, rndtype(rng)) {

  int i, di, li;
  int j, xj;

  // Repeat for each unlabeled document.
  for (i = 0; i < d0; i++) {
    di = yu[i];          // The document index.
    li = L[di];          // The number of points in the document.

    // Sample the z's from the prior. We don't really need to worry 
    // about the soft constraints during initialisation. Repeat for 
    // each data point in the document. 
    for (j = 0; j < li; j++) {
      xj       = MRef(balls,j,di,maxL);
      z->e[xj] = nrand(psiB->e[xj],1,rng);
    }
  }
}

// -------------------------------------------------------------------
// Returns the current number of active kernels, or 0 on failure.
int samplegammagibbs (const Matrix* X, const Matrix* C, int k, 
		      Metricfunc f, Kernelfunc K, double lambda, 
		      int a, int b, double epsilon, double delta, 
		      const Vector* z, int* g, int* gind, 
		      KernelMatrices* km, Vector* psi, int* U, 
		      int verbose, rndtype(rng)) {

  // Values and matrices that depend on the number
  // of active kernels.
  int         ng    = km->gf->n;
  Intvector** gf    = &(km->gf);
  Matrix**    Psi   = &(km->Psi);
  Matrix**    G     = &(km->G);
  Matrix**    S     = &(km->S);
  Matrix**    Q     = &(km->Q);
  Matrix**    Q0    = &(km->Q0);
  Vector**    Ak    = &(km->Ak);
  Vector**    Az    = &(km->Az);
  Vector**    Az0   = &(km->Az0);
  Vector**    SAk   = Az0;
  Vector**    QAk   = &(km->QAk);
  Matrix**    T     = &(km->T);
  Vector**    t     = &(km->t);

  double v, zeta, xi, x, q;
  double az, ak, alphar;

  // Loop variables.
  int i, j, ri, ti; 

  // Swap variables.
  Matrix* swapmatrix;
  Vector* swapvector;

  // Compute some preliminary values.
  v = (1+delta)/delta;                      // Compute v.
  multmatrixwithvector(*Psi,z,*Az,1);       // Compute Az.
  if (computeq(epsilon,delta,*G,*T,*Q) < 0) // Compute Q.
    return 0;
  
  // Repeat for each kernel in a random order. 
  randperm(U,k,rng);
  for (i = 0; i < k; i++) {
    ri = U[i];
    if (g[ri]) {
      
      // Conduct a death move.
      // Compute the proposal probability.
      q = (k-ng+b) / ((double) (k+a+b-1));
      
      // Sample from the proposal.
      if ((urand(rng) < q) & (ng > 1)) {
	
	// Find the index of the element "ri" in the set of active 
	// kernels.
	j = gind[ri];
	
	// Compute some values.
	getcolvector(*Psi,j,psi);                   // Compute psi. 
	getcolvector(*G,j,*t);                      // Compute Ak.
	remelemfromvector(*t,*Ak,j);
	remelemfromvector(*Az,*Az0,j);              // Compute Az0.
	az   = (*Az)->e[j];                         // Compute az.
	zeta = refMatrix(**S,j,j);                  // Compute zeta.
	xi   = refMatrix(**Q,j,j);                  // Compute xi.
	remmatrixrow(*Q,*T,j);                      // Compute Q0.
	getcolvector(*T,j,*t);    
	remmatrixcol(*T,*Q0,j);
	outerprod(*t,*t,*T);
	scalematrix(*T,*T,-1/xi);
	addmatrices(*Q0,*T,*Q0);
	multmatrixwithvector(*Q0,*Ak,*t,0);         // Compute x.
	x      = az - v*dot(*Az0,*t);
	alphar = sqrt(delta*zeta/xi*exp(-xi*x*x));
	
	if (urand(rng) < min(1,alphar)) {
	  
	  // Remove kernel ri.
	  g[ri] = 0;                                // Update g.
	  remelemintvectorsafe(*gf,j);              // Update gf.
	  ng--;
	  gind[ri] = 0;                             // Update gind.
	  for (ti = j; ti < ng; ti++)
	    gind[(*gf)->e[ti]]--;
	  remmatrixcolsafe(*Psi,j);                 // Update Psi.
	  swap(*Az,*Az0,swapvector);                // Update Az.
	  remmatrixrow(*G,*T,j);                    // Update G.
	  remmatrixcol(*T,*G,j);	  
	  remmatrixrow(*S,*T,j);                    // Update S.
	  getcolvector(*T,j,*t);
	  remmatrixcol(*T,*S,j);
	  outerprod(*t,*t,*T);
	  scalematrix(*T,*T,-1/zeta);
	  addmatrices(*S,*T,*S);	  
	  swap(*Q,*Q0,swapmatrix);                  // Update Q.
	}
      }
    }
    else {
      
      // Compute the proposal probability.
      q = (ng+a) / ((double) (k+a+b-1));
      
      // Sample from the proposal.
      if (urand(rng) < q) {

	// Compute some values.
	kernelcol(f,K,lambda,X,C,ri,psi);                // Compute psi.
	ak = dot(psi,psi);                               // Compute ak.
	az = dot(z,psi);                                 // Compute az.
	multmatrixwithvector(*Psi,psi,*Ak,1);            // Compute Ak.
	multmatrixwithvector(*S,*Ak,*SAk,0);             // Compute SAk.
	multmatrixwithvector(*Q,*Ak,*QAk,0);             // Compute QAk.	
	zeta   = 1/(ak+epsilon-dot(*Ak,*SAk));           // Compute zeta.
	xi     = 1/(epsilon/delta+                       // Compute xi.
		    v*(ak-v*dot(*Ak,*QAk)));
	x      = az - v*dot(*Az,*QAk);                   // Compute x.
	alphar = sqrt(xi/(delta*zeta)*exp(xi*x*x)); 
	  
	if (urand(rng) < min(1,alphar)) {
	  g[ri]    = 1;    // Update g.
	  gind[ri] = ng;   // Update gind.
	  ng++;
	    
	  // First make sure that the vectors and matrices are big 
	  // enough to handle the addition of another kernel.
	  if (ng > (*gf)->s) {
	    if (verbose) {
	      printf("+");
	      fflush(stdout);
	    }
	    growkernelmatrices(km);
	  }
	  
	  catelemtointvector(*gf,ri);  // Update gf.
	  catcoltomatrix(*Psi,psi);    // Update Psi.
	  catcoltomatrix(*G,*Ak);      // Update G.
	  catelemtovector(*Ak,ak);
	  catrowtomatrix(*G,*Ak);
	  catelemtovector(*Az,az);     // Update Az.
	  scalevector(*SAk,zeta,*t);   // Update S.
	  outerprod(*t,*SAk,*T);
	  addmatrices(*S,*T,*S);
	  scalevector(*t,-1,*t);
	  catcoltomatrix(*S,*t);
	  catelemtovector(*t,zeta);
	  catrowtomatrix(*S,*t);
	  scalevector(*QAk,v*xi,*t);   // Update Q.
	  scalevector(*QAk,v,*QAk);
	  outerprod(*t,*QAk,*T);
	  addmatrices(*Q,*T,*Q);
	  scalevector(*t,-1,*t);
	  catcoltomatrix(*Q,*t);
	  catelemtovector(*t,xi);
	  catrowtomatrix(*Q,*t);	
	}
      }
    }
  }
	
  return ng;
}

// -------------------------------------------------------------------
// Returns the alpha ratio, or a negative number on failure. We assume 
// memory for K x K temporary matrices "Q2" and "T" and K x 1 vector 
// "t" has already been allocated.
double samplealpha (double mua, double nua, double epsilon, 
		    const Matrix* G, const Matrix* Q, 
		    const Vector* Az, const Vector* z, double delta, 
		    Matrix* Q2, Matrix* T, Vector* t, rndtype(rng)) {
  int N = z->n;

  double alpha0;
  double alpha;
  double x;

  // Sample alpha0.
  alpha0 = 1/randgamma(0.5*(mua+1), 0.5*nua, rng);

  // Sample alpha.
  scalematrix(G,Q2,2*delta+1);  // Compute Q2.
  adddiagterm(Q2,epsilon);
  if (matrixinv(Q2,Q2,T)) {
    fprintf(stderr, "Computation of the expansion parameter failed due to matrix singularity.\n");
    return -1;
  }
  scalematrix(Q2,Q2,4*delta);
  subtractmatrices(Q,Q2,Q2);
  multmatrixwithvector(Q2,Az,t,0);
  x     = dot(z,z) + dot(Az,t);
  alpha = 1/randgamma(0.5*(N+mua+1), 0.5*(nua + alpha0*x), rng);
  
  // Compute the ratio.
  return sqrt(alpha0/alpha);
}

// -------------------------------------------------------------------
// We assume memory for K x K matrix "T", K x 1 vectors "t1" and "t2" 
// and K x 1 vector "beta" has already been allocated. Returns a 0 on 
// success, or -1 on failure. 
int samplebeta (const Matrix* Q, const Vector* Az, const Vector* z, 
		double aratio, Matrix* T, Vector* t1, Vector* t2, 
		Vector* beta, rndtype(rng)) {

  multmatrixwithvector(Q,Az,t1,0);
  scalevector(t1,aratio,t1);
  if (chol(Q,T,t2)) {
    fprintf(stderr, "Q is not positive semi-definite.\n");
    return -1;
  }
  mvnrandm(beta,t2,t1,T,rng);
  return 0;
}

// -------------------------------------------------------------------
// We assume storage for K x K matrix "T" and K x 1 vector "t" has 
// already been allocated.
double sampledelta (double epsilon, double mu, double nu, 
		    const Matrix* G, const Vector* beta, Matrix* T, 
		    Vector* t, rndtype(rng)) {
  int ng = beta->n;

  copymatrix(G,T);
  adddiagterm(T,epsilon);
  multmatrixwithvector(T,beta,t,0);
  return 1/randgamma(0.5*(mu+ng), 0.5*(nu+dot(beta,t)), rng);
}

// -------------------------------------------------------------------
// We assume storage for N x 1 vector "psiB" and N x 1 vector "z" has 
// already been allocated.  
void samplez (const int* L, const int* balls, int maxL, const int* yu, 
	      int d0, int N1, int N2, const int* yk1, const int* yk2, 
	      int soft, int nc1, int nc2, double m, double chi, 
	      Matrix* Psi, Vector* beta, Vector* psiB, Vector* z, 
	      rndtype(rng)) {
  
  // Sample the z's.
  multmatrixwithvector(Psi,beta,psiB,0);
  samplekzs(z,psiB,N1,N2,yk1,yk2,rng);
  if (soft)
    sampleuzsoft(z,L,balls,maxL,yu,d0,m,chi,psiB,rng);
  else
    sampleuzs(z,L,balls,maxL,yu,d0,nc1,nc2,psiB,rng);
}

// -------------------------------------------------------------------
// Sample the z's coupled with known labels.
void samplekzs (Vector* z, const Vector* psiB, int N1, int N2, 
		const int* yk1, const int* yk2, rndtype(rng)) {
  int i, j;

  // Repeat for each data point.
  for (i = 0; i < N1; i++) {
    j       = yk1[i];
    z->e[j] = nrandtl(psiB->e[j],1,0,rng);
  }

  for (i = 0; i < N2; i++) {
    j       = yk2[i];
    z->e[j] = nrandtr(psiB->e[j],1,0,rng);
  }
}

// -------------------------------------------------------------------
// Sample the z's in documents with unknown labels.
void sampleuzs (Vector* z, const int* L, const int* balls, int maxL,
		const int* yu, int d0, int nc1, int nc2, 
		const Vector* psiB, rndtype(rng)) {

  int     nct = nc1 + nc2;
  int     i, di, li, j, rj;
  int     R[maxL];  // The random permutation of points.
  double* zp;
  int     np;

  // Sample z from unknown labels with constraints. We use Gibbs
  // sampling, so we are sampling from the conditionals of the
  // z's. Repeat for each unlabelled document.  
  for (i = 0; i < d0; i++) {
    di = yu[i];          // The document index.
    li = L[di];          // The number of points in the document.
    randperm(R,li,rng);
    for (j = 0; j < li; j++)
      R[j] = MRef(balls,R[j],di,maxL);

    // We cannot apply the constraints when there are not enough
    // data points in the document, so we sample the z's
    // independently.  
    if (li < nct) {
      
      // Repeat for each data point in the document. Sample the 
      // z's without any constraints.
      for (j = 0; j < li; j++) {
	rj       = R[j];
	z->e[rj] = nrand(psiB->e[rj],1,rng);
      }
    } 
    else {

      // Perform Gibbs sampling. 
      // Get the number of positive z's in the document.
      np = 0;
      for (j = 0; j < li; j++) {
	rj  = R[j];
	np += (z->e[rj] > 0);
      }

      // Repeat for each data point in the document.
      for (j = 0; j < li; j++) {
	rj = R[j];
	zp = &(z->e[rj]);

        // We have three situations:
        //  1. We do not meet the positive constraint, so sample
        //     from a Normal distribution truncated to the left at 0.  
        //  2. We do not meet the negative constraint, so sample
        //     from a Normal distribution truncated to the right at 0. 
        //  3. The two cases above do not apply, so sample from a
        //     Normal distribution.
        //
        // Do not count the current "z" in the sum of positives or
        // negatives. 
	np = np - (*zp > 0);
	if (np < nc1) {
	  *zp = nrandtl(psiB->e[rj],1,0,rng);
	  np++;
	}
	else if (li-np-1 < nc2)
	  *zp = nrandtr(psiB->e[rj],1,0,rng);
	else {
	  *zp = nrand(psiB->e[rj],1,rng);
	  np += (*zp > 0);
	}
      }
    }
  }
}

// -------------------------------------------------------------------
// Sample the z's in documents with unknown labels using the noisy
// measurement model (soft constraints).
void sampleuzsoft (Vector* z, const int* L, const int* balls, int maxL,
		   const int* yu, int d0, double m, double chi,
		   const Vector* psiB, rndtype(rng)) {

  int     i, di, li, j, rj;
  int     R[maxL];  // The random permutation of points.
  double* zp;
  int     np;
  double  frac, pzlt0, ap, an;

  // Sample z from unknown labels with constraints. We use Gibbs
  // sampling, so we are sampling from the conditionals of the
  // z's. Repeat for each unlabelled document.  
  for (i = 0; i < d0; i++) {
    di = yu[i];          // The document index.
    li = L[di];          // The number of points in the document.
    randperm(R,li,rng);
    for (j = 0; j < li; j++)
      R[j] = MRef(balls,R[j],di,maxL);

    // Get the number of positive z's in the document.
    np = 0;
    for (j = 0; j < li; j++) {
      rj  = R[j];
      np += (z->e[rj] > 0);
    }

    // Sample each z conditioned on the rest. Repeat for each data
    // point in the document.
    for (j = 0; j < li; j++) {
      rj = R[j];
      zp = &(z->e[rj]);

      // Do not count the current "z" in the sum of positives or
      // negatives. 
      np = np - (*zp > 0);

      // Find the area under the distribution when z is greater than
      // zero, and when z is less than zero.
      frac  = (np + 1) / (double) li;
      pzlt0 = normcdf(-psiB->e[rj]);
      ap    = betapdf(m,chi*frac+1,chi*(1-frac)+1) * (1 - pzlt0);
      frac  = np / (double) li;
      an    = betapdf(m,chi*frac+1,chi*(1-frac)+1) * pzlt0;

      // Decide if z will be less than or greater than 0, then sample
      // from the appropriate truncated normal distribution.
      if (urand(rng) < ap / (ap+an)) {

	// z is positive.
	*zp = nrandtl(psiB->e[rj],1,0,rng);
	np++; 
      } else
	*zp = nrandtr(psiB->e[rj],1,0,rng);
    }
  }
}
