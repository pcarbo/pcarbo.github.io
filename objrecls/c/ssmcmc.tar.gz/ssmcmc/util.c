// Project includes.
#include "util.h"
#include "files.h"

// Standard includes.
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <unistd.h>

// Function definitions.
// -------------------------------------------------------------------
// Copy string S into the return value.
char* getmemandstrcpy (const char* s) {
  char* t;  // The return value.

  t = strmem(s);
  strcpy(t,s);
  return t;
}

// -------------------------------------------------------------------
// Get the sum of an array of integers of length N.
int sumint (const int* x, int n) {
  int s = 0;
  int i;
  for (i = 0; i < n; i++)
    s = s + x[i];
  return s;
}

// -------------------------------------------------------------------
// Get the maximum of an array of integers of length N.
int maxint (const int* x, int n) {
  int i;
  int s = *x;
  for (i = 0; i < n; i++)
    s = max(x[i],s);
  return s;
}

// -------------------------------------------------------------------
// Print the N elements of integer array A.
void printints (int* a, int n) {
  int i, j;
  int x;
  int d = 1;

  // Find the maximum number of digits before the dot.
  for (i = 0; i < n; i++)
    d = max(d,numdigits(a[i]));

  for (i = 0; i < n; i++) {
    x = a[i];
    for (j = 0; j < d - max(1,numdigits(x)); j++)
      printf(" ");
    printf("%d\n", x);
  }
}

// -------------------------------------------------------------------
// Print the N elements of array of doubles, X, to file stream FP.
void fprintnums (FILE* fp, const double* x, int n) {
  int i;

  for (i = 0; i < n; i++)
    fprintf(fp, "%0.6g ", x[i]);
  fprintf(fp, "\n");  
}

// -------------------------------------------------------------------
// Print the N elements of integer array X to file stream FP.
void fprintints (FILE* fp, const int* x, int n) {
  int i;

  for (i = 0; i < n; i++)
    fprintf(fp, "%d ", x[i]);
  fprintf(fp, "\n");  
}

// -------------------------------------------------------------------
// Read N doubles from the file stream FP into the array X. Note that 
// sufficient memory must already have been allocated for X.
void fscannums (FILE* fp, double* x, int n) {
  int i;

  for (i = 0; i < n; i++)
    x[i] = readnum(fp, 'f');
}

// -------------------------------------------------------------------
// Read N integers from the file stream FP into the array X. Note that 
// sufficient memory must already have been allocated for X.
void fscanints (FILE* fp, int* x, int n) {
  int i;

  for (i = 0; i < n; i++)
    x[i] = (int) readnum(fp, 'i');
}

// -------------------------------------------------------------------
// Get the maximum of an array of doubles of length N.
double maxdb (const double* x, int n) {
  int    i;
  double s = *x;
  for (i = 0; i < n; i++)
    s = max(x[i],s);
  return s;
}

// -------------------------------------------------------------------
// Get the minimum of an array of doubles of length N.
double mindb (const double* x, int n) {
  int    i;
  double s = *x;
  for (i = 0; i < n; i++)
    s = min(x[i],s);
  return s;
}

// -------------------------------------------------------------------
// Returns the complementary error function with fractional error 
// everywhere less than 1.2 � 10^-7. 
double erfc (double x) {
  double t, z, ans; 

  z   = fabs(x); 
  t   = 1.0/(1.0 + 0.5*z); 
  ans = t*exp(-z*z - 1.26551223 + t*(1.00002368 + t*(0.37409196 + t*(0.09678418 + 
	      t*(-0.18628806 + t*(0.27886807 + t*(-1.13520398 + t*(1.48851587 + 
	      t*(-0.82215223 + t*0.17087277))))))))); 

  return x >= 0.0 ? ans : 2.0 - ans; 
}

// -------------------------------------------------------------------
// Return the standard Normal CDF at X.
double normcdf (double x) {
  return min(1, 0.5*erfc(-x / sqrt(2)));
}
  
// -------------------------------------------------------------------
// Get the absolute path name of F if it is not already an absolute 
// path. Either way, it allocates memory for the string and returns 
// the new (or possibly unchanged) path string.
char* absolutepath (const char* f) {
  char  d[maxdirlength];
  char* fnew;
  int   n;

  // Check to see if the path name is already absolute.
  if (f[0] == '/') {
    fnew = getmemandstrcpy(f);
    return fnew;
  }
  else {
    getcwd(d,maxdirlength);
    n    = strlen(d);
    fnew = charmem(n+strlen(f)+2);
    strcpy(fnew,d);
    fnew[n]   = '/';
    fnew[n+1] = '\0';
    strcat(fnew,f);
    return fnew;
  }
}
