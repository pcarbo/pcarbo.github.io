% Display method fro the grid graph class.

function display (g)

  % Get the height and width of the grid.
  h = g.h;
  w = g.w;

  % Show the vertices for the entire graph.
  fprintf('Entire graph:\n');
  showvertices(g,vertices(g));

  % Get the number of partitions.
  np = numpartitions(g);

  % Show the partitions if there is more than one.
  if np > 1
    % Repeat for each partition.
    for p = 1:np
      fprintf('Partition %i:\n', p);
      showvertices(g,vertices(g,p));
    end
  end

% ----------------------------------------------------------------------
function showvertices (g, V)

  % Get the maximum size of a displayed vertex index.
  s = length(sprintf('%i',max(V)));

  % Get the (h,w) positions of the vertices in the graph.
  H    = height(g,V);
  W    = width(g,V);
  h1   = min(H);
  h2   = max(H);
  w1   = min(W);
  w2   = max(W);
  grid = sparse(H,W,V,h2+1,w2+1);

  % Repeat for all the height positions, then for all the width
  % positions. 
  for h = h1:h2
    for w = w1:w2
      v = grid(h,w);
      if v
	fprintf(['%' sprintf('%i',s) 'i'], v);
	if grid(h,w+1)
	  fprintf('-');
	else
	  fprintf(' ');
	end
      else
	fprintf(repmat(' ',1,s+1));
      end
    end
    fprintf('\n');
    for w = w1:w2
      fprintf(repmat(' ',1,s-1));
      if grid(h,w) & grid(h+1,w)
	fprintf('| ');
      else
	fprintf('  ');
      end
    end
    fprintf('\n');
  end