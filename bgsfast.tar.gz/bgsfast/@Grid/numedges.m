% Overloaded class method. See ADJGRAPH/NUMEDGES for more information.

function m = numedges (g)

  h = g.h;
  w = g.w;
  m = 2*h*w - w - h;


