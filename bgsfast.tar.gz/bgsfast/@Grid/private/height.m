% Determine the height of the vertex in the grid.

function H = height (g, V)
  
  % Get the height of the grid.
  h = g.h;

  % Get the heights of the vertices.
  H = 1 + mod(V-1,h);
