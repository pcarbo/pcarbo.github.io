% Get the width of the vertex in the grid.

function W = width (g, V)

  % Get the height of the grid.
  h = g.h;

  % Get the widths of the vertices.
  W = ceil(V / h);
