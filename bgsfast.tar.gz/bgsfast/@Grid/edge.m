% Overloaded class method. See ADJGRAPH/EDGEIND for more information.

function [I, J] = edge (g, U)

  % Get the number of vertical edges.
  m = (g.h - 1)*g.w;

  % 1 means the edge is vertical. 0 means it is horizontal.
  B = U <= m;

  I = (B == 1) .* (U + floor((U-1) / (g.h-1))) + ...
      (B == 0) .* (U - m);
  J = (B == 1) .* (I + 1) + ...
      (B == 0) .* (I + g.h);
