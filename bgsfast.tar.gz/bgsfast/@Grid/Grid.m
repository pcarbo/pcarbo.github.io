% GRID(H,W) creates a grid graph object of height H and width W.

function g = Grid (h, w)

  g.h = h;
  g.w = w;
  g   = class(g,'Grid',Adjgraph(h*w));

