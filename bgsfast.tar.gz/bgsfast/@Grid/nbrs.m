% Overloade class method. See ADJGRAPH/NBRS for more information.

function js = nbrs (g, i, varargin)

  % Get the height and width of the grid.
  h = g.h;
  w = g.w;

  % Get the (h,w) position of the vertex.
  hi = height(g,i);
  wi = width(g,i);

  % Get all the neighbours.
  js = [];
  if hi > 1  
    js = [js i-1];  
  end
  if hi < h  
    js = [js i+1];
  end
  
  if wi > 1
    js = [js i-h];
  end
  if wi < w
    js = [js i+h];
  end

  if length(varargin)

    % Get the candidate vertices.
    J  = vertices(g,varargin{:});
    js = intersect(js,J);
  end