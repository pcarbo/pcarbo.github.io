% Overloaded class method. See ADJGRAPH/ADJ for more information.

function A = adj (g, varargin)

  [I J] = parseadjargs(g,varargin{:});
  I     = I(:);
  J     = J(:);
  ni    = length(I);
  nj    = length(J);

  % Get the height and width of the grid.
  h = g.h;
  w = g.w;

  % Get the (h,w) positions of the vertices.
  Hi = repmat(height(g,I),1,nj);
  Hj = repmat(height(g,J)',ni,1);
  Wi = repmat(width(g,I),1,nj);
  Wj = repmat(width(g,J)',ni,1);

  % Construct the adjacencies based on the heights and widths.
  A = ((Hi == Hj-1) & (Wi == Wj)) | ((Hi == Hj) & (Wi == Wj-1)) | ...
      ((Hj == Hi-1) & (Wi == Wj)) | ((Hi == Hj) & (Wj == Wi-1));
  