% Overloaded class method. See ADJGRAPH/EDGEIND for more information.

function U = edgeind (g, I, J)

  % Make sure I < J.
  [I J] = unorderedpair(g,I,J);

  % Get the height and width of the vertices.
  Hi = height(g,I);
  Hj = height(g,J);
  Wi = width(g,I);
  Wj = width(g,J);

  % Get the number of vertical edges.
  m = g.w * (g.h - 1);

  % Compute the edge indices. The vertical edges are counted first.
  U = ((Wi == Wj) & (Hi+1 == Hj)) .* ((Wi-1)*(g.h-1)+Hi) + ...
      ((Hi == Hj) & (Wi+1 == Wj)) .* (m+(Wi-1)*g.h+Hi);
  