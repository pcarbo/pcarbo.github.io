#include "rndtreepartition.h"
#include "matlabinterface.h"
#include "vector.h"
#include "stack.h"
#include "rand.h"

#define numInputParams          6
#define numOptionalInputParams  1
#define numOutputParams         2

#define leftEdgeVertex(C,u,m)  (C[u])
#define rightEdgeVertex(C,u,m) (C[m+(u)])
#define pot(fij,i,j,xi,xj,nc)  matrixRef(fij,xi,xj,nc[i])

// Function declarations.
// -------------------------------------------------------------------
void bgs      (int n, int m, int** A, int** E, const int* nb, 
	       const int* C, const int* nc, double** g, double** f, 
	       int s, double** b, double** bc, randtype r, int verbose);
void potnl    (int n, int m, double** f, int u, const int* C, 
	       const int* nc, int i, int j, int xj, double* fi);
void marginal (int n, int m, double** f, int u, double** p, 
	       const int* C, const int* nc, int i, int j, double* pi);

// Function definitions.
// -------------------------------------------------------------------
#ifdef MEX_BGSFAST
void mexFunction (int nlhs, mxArray* plhs[], 
		  int nrhs, const mxArray* prhs[]) {

  int            verbose;
  const mxArray* p;        // Pointer to argument list.

  randtype  r;    // The random number generator.
  int       s;    // The number of samples to generate.
  int       n;    // The number of vertices in the graph.
  int       m;    // The number of undirected edges in the graph.
  int**     A;    // The neighbour lists.
  int**     E;    // The edge indices.
  int*      C;    // The mapping from edge index to edge vertices.
  int*      nb;   // The number of neighbours for each vertex.
  int*      nc;   // The number of classes or assignments for each variable.
  int*      nci;  // The size of the first dimension of each pairwise 
                  // potential table.
  int*      ncj;  // The size of the second dimension of each pairwise
                  // potential table.
  int*      ones; // An array of ones.
  double**  g;    // Each entry is a pointer to the first element of the 
                  // unary potential table.
  double**  f;    // Each entry is a pointer to the first element of the
                  // pairwise clique potential table.
  double**  b;    // Each entry is a pointer to the first element of the
                  // node marginals.
  double**  bc;   // Each entry is a pointer to the first element of the 
                  // clique marginals.

  // Verify and process the input parameters.
  // ---------------------------------------
  if (nrhs < numInputParams | 
      nrhs > (numInputParams + numOptionalInputParams))
    mexErrMsgTxt("Incorrect number of input arguments");

  // Get the list of neighbours A.
  p = prhs[0];
  {
    int i, j;

    n = getCellArrayOfIntMatrices(p,A,ones,nb);
    if (!mxIsCell(p) || mxGetM(p) != n)
      mexErrMsgTxt("Input argument A must be an N x 1 cell array, where N is the number of vertices, and each entry is a matrix of type int32");
    mxFree(ones);

    // Subtract one from all the indices since they must start at 0.
    for (i = 0; i < n; i++)
      for (j = 0; j < nb[i]; j++)
	A[i][j]--;
  }

  // Get the edge indices.
  p = prhs[1];
  {
    int i, j;

    mxFree(nb);
    n = getCellArrayOfIntMatrices(p,E,ones,nb);
    if (!mxIsCell(p) || mxGetM(p) != n)
      mexErrMsgTxt("Input argument E must be an N x 1 cell array, where N is the number of vertices, and each entry is a matrix of type int32");
    mxFree(ones);

    // Subtract one from all the indices since they must start at 0.
    for (i = 0; i < n; i++)
      for (j = 0; j < nb[i]; j++)
	E[i][j]--;
  }

  // Get the mapping from edge index to edge vertices. m is the 
  // number of edges. Note that we have to subtract 1 from the indices, 
  // since C arrays start at 0, not at 1 like in Matlab. Also, we need to 
  // make sure that the size of "int" in C++ is compatible with the Int32
  // type in Matlab.
  p = prhs[2];
  {
    int t, u;

    getIntMatrix(p,C,m,t);
    if (!mxIsInt32(p) || 2 != mxGetN(p))
      mexErrMsgTxt("Input argument C must be an M x 2 matrix of type int32");

    // Substract one from the indices since they much start at 0.
    for (u = 0; u < m; u++) {
      leftEdgeVertex(C,u,m)--;
      rightEdgeVertex(C,u,m)--;
    }
  }

  // Get the unary potentials.
  p = prhs[3];
  getCellArrayOfMatrices(p,g,nc,ones);
  if (!mxIsCell(p) || mxGetM(p) != n)
    mexErrMsgTxt("Input argument g must be an N x 1 cell array");

  // Get the pairwise clique potentials.
  p = prhs[4];
  getCellArrayOfMatrices(p,f,nci,ncj);
  if (!mxIsCell(p) || mxGetM(p) != m)
    mexErrMsgTxt("Input argument f must be an M x 1 cell array, where M is the number of edges in the graph");
  
  // Get the number of samples.
  p = prhs[5];
  s = (int) mxGetScalar(p);
  if (mxGetM(p) != 1 || mxGetN(p) != 1 || !mxIsDouble(p))
    mexErrMsgTxt("Input argument s must be a scalar");
  
  // Get the optional "verbose" input argument.
  if (nrhs > numInputParams) {
    p = prhs[6];
    verbose = (int) mxGetScalar(p);
    if (mxGetM(p) != 1 || mxGetN(p) != 1 || !mxIsDouble(p))
      mexErrMsgTxt("Input argument VERBOSE must be a scalar");
  } else verbose = 0;

  // Initialize the output arguments.
  // -------------------------------
  if (nlhs != numOutputParams)
    mexErrMsgTxt("Incorrect number of output arguments");

  // The node marginals are returned in the first output argument.
  plhs[0] = createCellOfMatrices(n,nc,ones,b);

  // The clique marginals are returned in the second output argument.
  plhs[1] = createCellOfMatrices(m,nci,ncj,bc);

  // Set up the random number generator.
  r = initrand();

  // Run the blocked sampling routine.
  bgs(n,m,A,E,nb,C,nc,g,f,s,b,bc,r,verbose);

  // Free temporarily allocated structures.
  // -------------------------------------
  randfree(r);
  mxFree(A);
  mxFree(E);
  mxFree(nb);
  mxFree(nc);
  mxFree(nci);
  mxFree(ncj);
  mxFree(ones);
  mxFree(g);
  mxFree(f);
  mxFree(b);
  mxFree(bc);
}
#endif

// -------------------------------------------------------------------
// Run blocked Gibbs sampling to compute Monte Carlo estimates of the 
// marginals.
void bgs (int n, int m, int** A, int** E, const int* nb, const int* C, 
	  const int* nc, double** g, double** f, int s, double** b, 
	  double** bc, randtype r, int verbose) {
  double*  gt[n];  // The updated unary potentials for a particular 
                   // tree partition. Similar to "g" in structure.
  double*  pf[n];  // The filtering densities p(xi|yDi).
  double*  gtm;    // The memory allocated for the "gt" variable.
  double*  pfm;    // The memory allocated for the "pf" variable.
  int      X[n];   // The array of samples.
  double   R[n];   // Storage for uniform random deviates.
  int      P[n];   // The tree partition.
  int*     V[n];   // Each entry is a pointer to the set of vertices
                   // in the respective partition.
  int      N[n];   // The number of vertices in each partition.
  int      L[n];   // Labels indicating whether or not a vertex 
                   // is marked for visitation.
  double*  fi;     // A single potential table.
  int      np;     // The number of tree partitions.
  int      Q[n];   // Collect schedule.

  // Loop variables.
  int     i, j, k, si, p;
  int     vi, vj, vk;
  int     nci, u;
  double* gi;            
  double* pfi;     

  // 1.) Set up some temporary dynamic structures
  // We want to keep track of the updated unary potentials. This
  // has approximately the same structure as "g". At the same time,
  // let's initialize the structure for the filtering densities.
  {
    int cnt = 0;
    int nct = sumInts(nc,n);

    gtm = (double*) mxMalloc(sizeof(double) * nct);
    pfm = (double*) mxMalloc(sizeof(double) * nct);

    for (i = 0; i < n; i++) {
      gt[i]  = &gtm[cnt];
      pf[i]  = &pfm[cnt];
      cnt   += nc[i];
    }
  }

  // This is temporary storage for a single potential table.
  fi = (double*) mxMalloc(sizeof(double) * maxInts(nc,n));

  // 2.) Initialize the samples according to the unary potentials
  mexRand(n,R,r);
  for (i = 0; i < n; i++)
    X[i] = randtable(nc[i],g[i],R[i]);

  // 3.) Perform blocked Gibbs sampling. Repeat the for each sample.
  for (si = 0; si < s; si++) {
    if (verbose)
      mexPrintf("%i ", si);

    // 3.a) Compute a random tree partition.    
    np = rndtreepartition(n,A,nb,P,Q,r);

    // Compute the size of each partition.
    for (p = 0; p < np; p++)
      N[p] = 0;
    for (i = 0; i < n; i++)
      N[P[i]]++;

    // Set up the vertex sets for all the partitions.
    V[0] = Q;
    for (p = 1; p < np; p++)
      V[p] = V[p-1] + N[p-1];    

    // Generate a whole bunch of random numbers.
    mexRand(n,R,r);
      
    // 3.b) Perform forward filtering and backward sampling for
    // each tree partition.
    for (p = 0; p < np; p++) {

      // 3.b.i) Set each unary potential to be the evidence 
      // potential times the potentials induced by the 
      // observations of its neighbours in other partitions.
      for (i = 0; i < N[p]; i++) {
	vi  = V[p][i];
	gi  = gt[vi];   // The current evidence potential.
	nci = nc[vi];   // The current number of classes.
	
	// Copy the unary evidence potential.
	copyVector(nci,g[vi],gi);

	// Multiply by the neighbours that are in different
	// partitions. Repeat for each neighbour.
	for (j = 0; j < nb[vi]; j++) {
	  vj = A[vi][j];
	  if (P[vj] != p) {
	    potnl(n,m,f,E[vi][j],C,nc,vi,vj,X[vj],fi);
	    multVectors(nci,gi,fi,gi);
	  }
	}
      }

      // 3.b.ii) Compute the filtering densities, which are simply
      // the unnormalized expressions for p(xi|yDi), by following the
      // collect schedule. Keep track of which nodes we've visited.
      for (i = 0; i < N[p]; i++) {
	vi    = V[p][i];
	L[vi] = 0;
      }
      
      // Repeat for every node in the schedule.
      for (i = N[p]-1; i >= 0; i--) {
	vi  = V[p][i];
	nci = nc[vi];
	pfi = pf[vi];

	// Compute the filtering density.
	copyVector(nci,gt[vi],pfi);

	// Repeat for all the children of node I. They are the nodes
	// adjacent to i that have already been visited in the same
	// partition. Note that this set will be empty for the leaves.
	for (j = 0; j < nb[vi]; j++) {
	  vj = A[vi][j];
	  if ((P[vj] == p) && L[vj]) {
	    marginal(n,m,f,E[vi][j],pf,C,nc,vi,vj,fi);
	    multVectors(nci,pfi,fi,pfi);
	  }
	}

	// It's important to normalize the filtering densities,
	// due to concerns of floating-point precision.
	scaleVector(nci,pfi,1/sumDoubles(pfi,nci),pfi);

	// Declare that we've visited the current node.
	L[vi] = 1;
      }

      // 3.b.iii) Sample from the smoothing densities p(xi|xPi,yDi),
      // where Pi is the parent of node i. What we will do is run the
      // distribute schedule, which is simply the reverse of the
      // collect schedule. We need to keep track of which nodes we've
      // visited (so we know what a "parent" is).
      for (i = 0; i < N[p]; i++) {
	vi    = V[p][i];
	L[vi] = 0;
      }

      // Repeat for every node in the schedule.
      for (i = 0; i < N[p]; i++) {
	vi  = V[p][i];
	nci = nc[vi];

        // Draw from p(xi|xj,yDi) proportional to fij(xi,xj) x
	// p(xi|yDi), where j is the parent of i. Node j is simply the
	// unique adjacent node that has already been visited. In the
	// case when xi is the root, the parent does not exist (the
	// filtering density p(xi|yDi) is already the the smoothing
	// density).

	// Get the parent J of node I.
	j = vj = -1;
	for (k = 0; k < nb[vi]; k++) {
	  vk = A[vi][k];
	  if ((P[vk] == p) && L[vk]) {
	    j  = k;
	    vj = vk;
	    break;
	  }
	}

	// Compute the smoothing distribution. In the first case,
	// node I doesn't have a parent.
	if (j == -1)
	  zeroVector(nci,fi,1);  // Create a vector of ones.
	else
	  potnl(n,m,f,E[vi][j],C,nc,vi,vj,X[vj],fi);	
	multVectors(nci,fi,pf[vi],fi);
	
	// Generate a sample from the smoothing distribution.
	X[vi] = randtable(nci,fi,R[vi]);
	
	// Declare that we've visited this node.
	L[vi] = 1;
      }
    }

    // Add the samples to the histograms.
    for (i = 0; i < n; i++)
      b[i][X[i]]++;
    
    for (u = 0; u < m; u++) {
      i = leftEdgeVertex(C,u,m);
      j = rightEdgeVertex(C,u,m);
      pot(bc[u],i,j,X[i],X[j],nc)++;
    }
  }

  // Normalize the histograms.
  for (i = 0; i < n; i++)
    scaleVector(nc[i],b[i],1/(double) s,b[i]);

  for (u = 0; u < m; u++) {
    i = leftEdgeVertex(C,u,m);
    j = rightEdgeVertex(C,u,m);
    scaleVector(nc[i]*nc[j],bc[u],1/(double) s,bc[u]);
  }

  // Free dynamically allocated structures.
  mxFree(gtm);
  mxFree(pfm);
  mxFree(fi);
}

// -------------------------------------------------------------------
// Returns in FI the potential F(XI,XJ) for an observed XJ.
void potnl (int n, int m, double** f, int u, const int* C, 
	    const int* nc, int i, int j, int xj, double* fi) {

  const double* fu;  // The edge potential.
  int           xi;  // Loop variable.

  // Get the potential.
  fu = f[u];

  if (leftEdgeVertex(C,u,m) == i)
    // The variable xi is represented by the table rows.
    for (xi = 0; xi < nc[i]; xi++)
      fi[xi] = pot(fu,i,j,xi,xj,nc);
  else
    // The variable xi is represented by the table columns.
    for (xi = 0; xi < nc[i]; xi++)
      fi[xi] = pot(fu,j,i,xj,xi,nc);
}

// -------------------------------------------------------------------
// Returns the in PI the potential F(XI).
void marginal (int n, int m, double** f, int u, double** p, 
	       const int* C, const int* nc, int i, int j, double* pi) {

  const double* fu;      // The edge potential.
  double*       pj;      // The filtering density of node j.
  int           xi, xj;  // Loop variables.

  // Get the potential.
  fu = f[u];

  // Get the filtering density of node j.
  pj = p[j];

  if (leftEdgeVertex(C,u,m) == i) {

    // The variable xi is represented by the table rows.
    for (xi = 0; xi < nc[i]; xi++) {
      pi[xi] = 0;
      for (xj = 0; xj < nc[j]; xj++)
	pi[xi] += pot(fu,i,j,xi,xj,nc) * pj[xj];
    }
  } else {

    // The variable xi is represented by the table columns.
    for (xi = 0; xi < nc[i]; xi++) {
      pi[xi] = 0;
      for (xj = 0; xj < nc[j]; xj++)
	pi[xi] += pot(fu,j,i,xj,xi,nc) * pj[xj];
    }
  }
}

