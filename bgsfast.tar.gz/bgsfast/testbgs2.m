% This tests blocked Gibbs sampling on a small graph with varying numbers
% of multinomial assignments for each variable.

% Script parameters.
N       = 100;   % Dimension of the grid.
cmin    = 2;
cmax    = 20;
s       = 1000;  % Number of samples to generate.
verbose = 0;

% Set the random number generator seed.
rand('state',676);

% Create the adjacency graph.
fprintf('Generating graph and potentials.\n');
a = Grid(N,N);

% Randomly select the number of assignments per variable.
n = numvertices(a);
c = randint(cmin,cmax,1,n);

% Generate random observation potentials.
g = cell(n,1);
for i = 1:n
  g{i} = rand(c(i),1);
  g{i} = g{i} / sum(g{i});
end
clear i n

% Generate random clique potentials.
m = numedges(a);
f = cell(m,1);
for u = 1:m
  [i j] = edge(a,u);
  f{u}  = rand(c(i),c(j));
  f{u}  = f{u} ./ sum(sum(f{u}));
end
clear i j u m

% Create the set of potentials.
p = Tabular(a,f,g);

% Compute the Monte Carlo estimates of the marginals.
fprintf('Computing MC estimates of marginals. \n');
tic;
[x xc] = bgsf(a,p,s,verbose);
fprintf('Inference took %i seconds. \n', round(toc));
