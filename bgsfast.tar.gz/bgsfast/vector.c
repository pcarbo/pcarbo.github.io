#include "vector.h"
#include <string.h>

// Function definitions.
// -------------------------------------------------------------------
// Set all the entries of an array of length N to 0. Optionally, one 
// can set the entries to a different value a.
void zeroVector (int n, double* X, double a) {
  for (int i = 0; i < n; i++)
    X[i] = a;
}

// -------------------------------------------------------------------
void zeroInts (int n, int* X, int a) {
  for (int i = 0; i < n; i++)
    X[i] = a;
}

// -------------------------------------------------------------------
// Get the sum of an array of integers of length N.
int sumInts (const int* X, int n) {
  int s, i;

  for (s = i = 0; i < n; i++)
    s = s + X[i];
  return s;
}

// -------------------------------------------------------------------
// Get the maximum of an array of integers of length N.
int maxInts (const int* X, int n) {
  int i;
  int s = X[0];
  for (i = 1; i < n; i++)
    s = max(X[i],s);
  return s;
}
// -------------------------------------------------------------------
// Get the sum of an array of doubles of length N.
double sumDoubles (const double* X, int n) {
  double s;
  int    i;

  for (s = i = 0; i < n; i++)
    s = s + X[i];
  return s;
}

// -------------------------------------------------------------------
// Copy source X into destination Y.
void copyVector (int n, const double* X, double* Y) {
  memcpy(Y,X,sizeof(double)*n);
}

// -------------------------------------------------------------------
void multVectors (int n, const double* V, const double* W, double* X) {
  int i;

  for (i = 0; i < n; i++)
    X[i] = V[i] * W[i];
}

// -------------------------------------------------------------------
void scaleVector (int n, const double* V, double a, double* X) {
  int i;

  for (i = 0; i < n; i++)
    X[i] = a * V[i];
}
