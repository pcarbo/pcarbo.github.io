#ifndef INCLUDE_MATLAB_INTERFACE
#define INCLUDE_MATLAB_INTERFACE

#include "mex.h"

// Macros.
// m is the number of rows in the matrix (i.e. its height).
#define matrixRef(X,r,c,m)  (X[(r)+(c)*(m)])

// Function declarations.
void     getIntMatrix           (const mxArray* p, int*& X, int& m, int& n);
int      getCellArrayOfMatrices (const mxArray* p, double**& C,
                                 int*& M, int*& N);
int   getCellArrayOfIntMatrices (const mxArray* p, int**& C, 
				 int*& M, int*& N);
double*  createScalar           (mxArray*& p);
double*  createMatrix           (mxArray*& p, int m, int n);
mxArray* createCellOfMatrices   (int n, const int* M, const int* N,
                                 double**& C);

#endif
