% MANAGEVARGS    Set up variable argument list with either default
%                or user-specified arguments.
%    VARARGOUT = MANAGE_VARGS(VARARGIN,DEFARGS) returns a list of
%    arguments, where the number of arguments is specified by the length
%    of DEFARGS. VARARGIN is a cell array of user-specified argument
%    values and DEFARGS are the default argument values. If the user does
%    not provide a value for an argument, the default value is used.

function varargout = managevargs (x, defargs)
  
  varargin = x;
  
  % Get the number of default and user-specified arguments.
  n = length(defargs);
  m = length(varargin);

  % Get the parameters from varargin or defargs.
  for i = 1:n,
    if m >= i,
      varargout{i} = varargin{i};
    else,
      varargout{i} = defargs{i};
    end;
  end;
  
  