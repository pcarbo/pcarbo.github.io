#ifndef INCLUDE_RAND
#define INCLUDE_RAND

#include "gsl/gsl_rng.h"

// Macros.
#define swap(a,b,temp)  {temp=(a);(a)=(b);(b)=temp;}
#define randset(S,n,r)  ((S)[randint(n,r)]);

#ifdef RAND_MATLAB
// Use the Matlab random number generator.
#define randtype  void* 
#else
// Use the GSL random number generator.
#define randtype  gsl_rng*
#endif

// Function declarations.
randtype initrand  (unsigned long int seed = 0);
void     randfree  (randtype r);
void     mexRand   (int n, double* X, randtype r);
int      randint   (int n, double r);
int      randtable (int n, const double* P, double r);
void     randperm  (int* X, int n, double* R);

#endif
