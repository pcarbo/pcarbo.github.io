function [b, bc] = bgsf (a, p, s, verbose)

  % Get the number of vertices and edges.
  n = numvertices(a);
  m = numedges(a);
  
  % Get the mapping from edges indices and the vertices.
  [I J] = edge(a,1:m);
  C     = int32([I(:) J(:)]);

  % Create a sparse adjacency graph representation consisting of lists of
  % neighbours. That is, we have an N x 1 cell array, where N is the number
  % of vertices, and each entry is a matrix, itself containing the indices
  % of the neighbouring vertices.
  A = cell(n,1);
  for i = 1:n
    A{i} = int32(nbrs(a,i));
  end

  % Create another cell array with the same structure as A, only this
  % time we store the edge indices.
  E = cell(n,1);
  for i = 1:n
    E{i} = int32(edgeind(a,i,nbrs(a,i)));
  end

  % Get the unary potentials.
  g = cell(n,1);
  for i = 1:n
    g{i} = potnl(p,i);
  end
  
  % Get the pairwise clique potentials.
  f = cell(m,1);
  for u = 1:m
    f{u} = potnl(p,I(u),J(u));
  end

  % Call the optimized C function.
  [b bc] = bgsfast(A,E,C,g,f,s,verbose);
