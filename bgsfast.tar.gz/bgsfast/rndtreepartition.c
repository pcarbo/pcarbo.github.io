#include "rndtreepartition.h"
#include "matlabinterface.h"
#include "vector.h"
#include "stack.h"
#include "mex.h"

#define numInputParams   1
#define numOutputParams  2

// Function definitions.
// -------------------------------------------------------------------
#ifdef MEX_RNDTREEPARTITION
void mexFunction (int nlhs, mxArray* plhs[],
                  int nrhs, const mxArray* prhs[]) {

  int     n;    // The number of vertices in the graph.  
  int**   A;    // The neighbour lists.
  int*    nb;   // The number of neighbours for each vertex.
  int*    ones; // An array of ones.
  double* P;    // The first output.
  double* Q;    // The second output.
  randtype(r);  // The random number generator.

  // Verify and process the single input argument.
  if (nrhs != numInputParams)
    mexErrMsgTxt("Incorrect number of input arguments");

  // Get the neighbour lists.
  {
    int i, j;

    const mxArray* p = prhs[0];
    n = getCellArrayOfIntMatrices(p,A,ones,nb);
    if (!mxIsCell(p) || mxGetM(p) != n)
      mexErrMsgTxt("Input argument A must be an N x 1 cell array, where N is the number of vertices, and each entry is a matrix of type int32");
    mxFree(ones);

    // Subtract one from all the indices since they must start at 0.
    for (i = 0; i < n; i++)
      for (j = 0; j < nb[i]; j++)
	A[i][j]--;
  }

  // Verify and process and the single output argument.
  if (nlhs != numOutputParams)
    mexErrMsgTxt("Incorrect number of output arguments");

  // Set up the output.
  P = createMatrix(plhs[0],1,n);
  Q = createMatrix(plhs[1],1,n);

  // Set up the random number generator.
  r = initrand();
  
  // Run the main part of the routine. Note that we add one to the 
  // partition indices returned by the C function.
  {
    int Pt[n];  // Temporary storage of the tree partition.
    int Qt[n];  // Temporary storage for the visitation schedule.
    int i;
    int np;     // The number of partitions.

    np = rndtreepartition(n,A,nb,Pt,Qt,r);
    for (i = 0; i < n; i++) {
      P[i] = (double) Pt[i] + 1;
      Q[i] = (double) Qt[i] + 1;
    }
  }

  // Free allocated memory.
  mxFree(nb);
  mxFree(A);
  randfree(r);
}
#endif

// -------------------------------------------------------------------
// Create a random tree partition on the undirected graph specified by
// the neighbour lists A. N is the number of vertices in the graph.
// The partition is returned in P, which must be initialized to an
// array of length N. The return value is the number of partitions
// created. Q is the visitation order, starting with the first
// partition. The partitions are always singly connected components
// (in order words, it is possible to visit a particular vertex
// starting at any vertex in the same partition).
int rndtreepartition (int n, int** A, const int* nbrs, int* P, int* Q,
		      randtype r) {
  
  int    V[n];        // Vertex labels.
  int    p;           // The number of partitions.
  int    nb;          // Number of vertices belonging to partitions.
  int    nv;          // Number of vertices we need to visit.
  int    nr;          // Number of random numbers used.
  Stack  S;           // Depth-first search stack.
  double R[n];        // Storage for random samples.
  int    J[n];        // A set of vertex elements.
  int    i, j;        // Vertex indices.
  int    vi, vj;      // More vertex indices.
  int    c;           // Counting variable.

  Stacknode Se[n];    // Storage for the elements of stack S.

  // Initialize the set of partitions.
  zeroInts(n,P);
  p  = 0;
  nb = 0;
  nv = n;
  nr = n;

  // We label the nodes as follows:                                           
  //   0  means that we need to visit the vertex.                             
  //   1  means that the vertex is scheduled for a visit.
  //   2  means that the vertex belongs to a partition.
  zeroInts(n,V);

  // Initialize the depth-first search stack.
  S = newStack(n,Se);

  // Repeat as long as there remain vertices that do not belong to
  // partitions.
  while (nb < n) {

    // Save the random numbers from the previous iteration that
    // haven't been used.
    for (i = 0; i < nv-nr; i++)
      R[i] = R[i+nr];
    
    // Generate some new random numbers, if necessary.
    nr = nv - nr;
    nv = n - nb;
    if (nv > nr) mexRand(nv-nr,&R[nr],r);
    nr = 1;

    // Find a vertex that doesn't belong to a partition, and make it
    // the starting point for tree search.
    i = randint(n,R[0]);
    while (V[i] > 0)
      i = (i+1) % n;
    push(S,i);
    V[i] = 1;

    // Perform depth-first search. Repeat as long as the stack is
    // not empty.
    while (!isempty(S)) {	
      vi = pop(S);
      
      // Find out how many of the neighbours belong to the
      // partition. If there is more than one, we'll create a cycle,
      // so we won't add it to the partition. Note that a vertex
      // only has no neighbours if it's the first one visited.
      // Repeat for each neighbour.
      for (c = j = 0; j < nbrs[vi]; j++) {
	vj  = A[vi][j];
	c  += (P[vj] == p) && (V[vj] == 2);
      }
      
      if (c < 2) {
	
	// Add the vertex to the partition.
	P[vi] = p;
	V[vi] = 2;
	Q[nb] = vi;
	nb++;
	
	// Get the set of neighbours J that haven't been visited.
	for (c = j = 0; j < nbrs[vi]; j++) {
	  vj = A[vi][j];
	  if (V[vj] == 0)
	    J[c++] = vj;
	}
	
	// Mark elements of J for visitation in random order.
	randperm(J,c,&R[nr]);
	nr += c;
	for (j = 0; j < c; j++) {
	  vj    = J[j];
	  V[vj] = 1;
	  push(S,vj);
	}
      }
    }

    // Set the "tried to visit" labels (1) to "need to visit" (0).
    for (i = 0; i < n; i++)
      V[i] = 2 * (V[i] == 2);
    
    // Go to the next partition.
    p++;
  }

  return p;
}
