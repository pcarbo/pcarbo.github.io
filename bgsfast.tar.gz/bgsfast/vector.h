#ifndef INCLUDE_VECTOR
#define INCLUDE_VECTOR

// Macros.
#define max(a,b)  (((a) > (b))*(a) + ((a) <= (b))*(b))

// Function declarations.
void   zeroInts    (int n, int* X, int a = 0);
void   zeroVector  (int n, double* X, double a = 0);
int    sumInts     (const int* X, int n);
int    maxInts     (const int* X, int n);
double sumDoubles  (const double* X, int n);
void   copyVector  (int n, const double* X, double* Y);
void   multVectors (int n, const double* V, const double* W, double* X);
void   scaleVector (int n, const double* V, double a, double* X);

#endif
