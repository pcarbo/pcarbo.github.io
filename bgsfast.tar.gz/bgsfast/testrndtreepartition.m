% Tree partition test.

fprintf('Partition of a 7 x 7 Markov random field.\n');
a = Grid(7,7)
fprintf('Press a key to continue.\n\n');
pause;
a = callrndtreepartition(a)

fprintf('Partition of a chain.\n');
a = Chain(7)
fprintf('Press a key to continue.\n\n');
pause;
a = callrndtreepartition(a)

fprintf('Partition of a fully-connected graph.\n\n');
a = Adjgraph(7)
fprintf('Press a key to continue.\n\n');
pause;
a = callrndtreepartition(a)
