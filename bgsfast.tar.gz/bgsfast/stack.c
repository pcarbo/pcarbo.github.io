#include "stack.h"
#include "mex.h"

// Function definitions.
// -------------------------------------------------------------------
// Create a new stack that can hold at most N elements. ELEMS is an
// array of stack elements of length N, and must have been previously
// allocated into memory.
Stack newStack (int n, Stacknode* elems) {
  Stack S;  // The return value.

  S.top   = 0;
  S.n     = n;
  S.elems = elems;
  
  return S;
}

// -------------------------------------------------------------------
// Returns 1 if the stack is empty. Otherwise, it returns 0.
int isempty (const Stack& S) {
  return (S.top == 0);
}

// -------------------------------------------------------------------
// Remove an element from the stack and return its value.
int pop (Stack& S) {
  int& top = S.top;

  if (top == 0)
    return 0;
  else {
    top--;
    return S.elems[top].v;
  }
}

// -------------------------------------------------------------------
// Push and element onto the stack.
void push (Stack& S, int v) {
  int& top = S.top;

  if (top < S.n) {
    S.elems[top].v = v;
    top++;
  }
}
