function [a, Q] = callrndtreepartition (a)

  n = numvertices(a);
  A = cell(n,1);
  for i = 1:n
    A{i} = int32(nbrs(a,i));
  end
  [P Q] = rndtreepartition(A);
  a     = setpartition(a,P);
