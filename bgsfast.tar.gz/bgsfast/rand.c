#include "rand.h"
#include "mex.h"
#include "vector.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// Function definitions.
// -------------------------------------------------------------------
// Initialise the GSL random number generator.
randtype initrand (unsigned long int seed) {
  randtype r; // The return value.

#ifdef RAND_MATLAB

  // Use the Matlab random number generator, which means that there is
  // no initialization required.
  r = NULL;
#else

  // Use the GSL random number generator.
  r = gsl_rng_alloc(gsl_rng_taus);

  // Set the seed.
  if (seed == 0) 
    seed = time(NULL);
  gsl_rng_set(r,seed);
#endif

  return r;
}

// -------------------------------------------------------------------
// Deallocate memory for random number generator.
void randfree (randtype r) {
#ifndef RAND_MATLAB
  gsl_rng_free(r);
#endif
}

// -------------------------------------------------------------------
// Grab an array of uniform random deviates using the Matlab random
// number generator.
void mexRand (int n, double* X, randtype r) {

#ifdef RAND_MATLAB
  // Use the Matlab random number generator.
  mxArray* plhs;     // The return value of "rand".
  mxArray* prhs[2];  // The input arguments to "rand".

  // Set up the input arguments.
  prhs[0] = mxCreateDoubleScalar(n);
  prhs[1] = mxCreateDoubleScalar(1);

  // Call the Matlab "rand" routine.
  mexCallMATLAB(1,&plhs,2,prhs,"rand");

  // Copy the result into the user's array.
  memcpy(X,mxGetPr(plhs),sizeof(double)*n);
  mxDestroyArray(plhs);

#else
  // Use the GSL random number generator.
  for (int i = 0; i < n; i++)
    X[i] = gsl_rng_uniform(r);
#endif
}

// -------------------------------------------------------------------
// Given a random deviate and a set of indices, return an integer 
// between 0 and n-1 distributed according to the random deviate R.
int randint (int n, double r) {
  // r = r * (r < 1);
  return (int) floor(n*r);
}

// -------------------------------------------------------------------
// Return a single sample on [0,N-1] distributed according to the 
// table P of unnormalized probabilities. R is a uniform random 
// deviate. 
int randtable (int n, const double* P, double r) {
  int    i;     // Loop variable.
  double Q[n];  // The cumulative distribution.

  // Normalize the probability table.
  {
    double s = sumDoubles(P,n);
    for (i = 0; i < n; i++)
      Q[i] = P[i] / s;
  }

  // Create the cumulative distribution. Q now acts as the upper
  // bound for the piecewise distribution.
  for (i = 1; i < n-1; i++)
    Q[i] += Q[i-1];
  Q[n-1] = 1;

  // Compute the final sample. Note this can be made more efficient
  // using binary search.
  for (i = 0; i < n-1; i++)
    if (r < Q[i])
      return i;
  return n-1;
}

// -------------------------------------------------------------------
// Permute the elements of X. R is an array of random deviates of
// length N. Note that the values of R will be altered, so they should
// not be used again.
void randperm (int* X, int n, double* R) {
  int    i, j;
  int    ti;
  double td;

  // Sort the numbers using bubble sort, keeping track of the
  // indices.
  for (i = 0; i < n; i++)
    for (j = 0; j < n-1; j++)
      if (R[j] > R[j+1]) {
        swap(R[j],R[j+1],td)
	swap(X[j],X[j+1],ti)
      }
}
