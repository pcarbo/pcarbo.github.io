% Overloaded class method. See ADJGRAPH/EDGEIND for more information.

function U = edgeind (g, I, J)

  U = min(I,J);
  