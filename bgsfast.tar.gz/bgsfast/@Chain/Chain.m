% CHAIN(N) constructs a chain graph with N vertices.

function g = Chain (n)

  g = struct([]);
  g = class(g,'Chain',Adjgraph(n));
