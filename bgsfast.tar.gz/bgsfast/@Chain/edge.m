% Overloaded class method. See ADJGRAPH/EDGEIND for more information.

function [I, J] = edge (g, U)

  I = U;
  J = U + 1;
