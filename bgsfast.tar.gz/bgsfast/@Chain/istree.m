% Overloaded class method. See ADJGRAPH/ISTREE for more information.

function [b, varargout] = istree (g)

  b = false;

  if nargout == 2
    varargout{1} = g;
  end
