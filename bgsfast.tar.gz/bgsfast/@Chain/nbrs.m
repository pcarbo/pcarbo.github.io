% Overloaded class method. See ADJGRAPH/NBRS for more information.

function js = nbrs (g, i, varargin)

  % Get all the neighbours.
  n = numvertices(g);
  if i > 1
    js = i-1;
  else
    js = [];
  end
  if i < n
    js = [js i+1];
  end

  if length(varargin)

    % Get the candidate vertices.
    J  = vertices(g,varargin{:});
    js = intersect(js,J);
  end
