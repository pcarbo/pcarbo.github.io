% Overloaded class method. See ADJGRAPH/NUMEDGES for more information.

function m = numedges (g)

  m = numvertices(g) - 1;
