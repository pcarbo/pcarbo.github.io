% Display method for the chain graph class.

function display (g)

  % Get the number of partitions and the total number of vertices.
  np = numpartitions(g);
  n  = numvertices(g);

  % Show the vertices for the entire graph.
  fprintf('Entire graph: ');
  showvertices(1:n);
  fprintf('\n');

  % Show the partitions if there is more than one.
  if np > 1
    % Repeat for each partition.
    for p = 1:np
      fprintf('Partition %i: ', p);
      showvertices(vertices(g,p));
      fprintf('\n');
    end
  end

% ----------------------------------------------------------------------
function showvertices (V)
  V = sort(V);
  n = length(V);

  for i = 1:n-1
    fprintf('%i', V(i));
    if V(i+1) == V(i)+1
      fprintf('-');
    else
      fprintf(' ');
    end
  end

  fprintf('%i', V(end));
