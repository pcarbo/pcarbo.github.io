% Overloaded class method. See ADJGRAPH/ADJ for more information.

function A = adj (g, varargin)

  [I J] = parseadjargs(g,varargin{:});

  % Outpute the adjacency matrix on the selected indices.
  n = numvertices(g);
  A = sparse(1:n,1:n,ones(1,n),n,n);
  A = A(I,J);
