% TABULAR(A,F,G) is the constructor for the tabular potential set class. A
% is an ADJGRAPH object with N vertices, G is a cell array of length N, and
% entry G{u} is the unary potential table for variable node u. F is a cell
% array of length M, where M is the number of undirected edges in graph A,
% and each entry is a pairwise potential. F{u} is a matrix such that the
% rows correspond to assignments of Xi and the columns correspond to
% assignments of Xj, where (i,j) = EDGE(A,U).

function p = Tabular (a, f, g)

  % Get the number of nodes and the number of pairwise potentials, the
  % latter which should be equivalent to the number of undirected edges in
  % the graph.
  n = numvertices(a);
  m = numedges(a);

  % Set up the object fields.
  p.a = a;
  p.f = f;
  p.g = g;

  % Initialize the object with the given structure.    
  p = class(p,'Tabular');
