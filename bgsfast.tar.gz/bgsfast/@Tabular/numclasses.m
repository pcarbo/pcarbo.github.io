% NUMCLASSES(P,I) returns the number of discrete class assignments to
% the variable defined on vertex I.

function n = numclasses (p, i)

  n = length(p.g{i});
