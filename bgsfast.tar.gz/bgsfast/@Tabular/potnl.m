% POTNL(P,I) returns the potential defined on vertex I in tabular
% potential object P.
%
% POTNL(P,I,J) returns the potential defined on vertices I and J.

function f = potnl (p, varargin)

  switch length(varargin)
  case 1
    i = varargin{1};

    % Return the unary potential.
    f = p.g{i}(:);

  case 2
    i = varargin{1};
    j = varargin{2};

    % Return the pairwise potential.
    u       = edgeind(p.a,i,j);
    [ti tj] = edge(p.a,u);
    f       = p.f{u};
    if i == tj
      f = f';
    end
  otherwise
    error('Invalid number of arguments.');
  end
