% BGSFAST   blocked Gibbs sampling for undirected graphical models.
% The call to the function in Matlab should look something like
%  [b bc] = bgsfast(A,E,C,g,f,s) where the input parameters are
% 
%    A  N x 1 cell array, where N is the number of vertices in the
%       graph. Each entry A{i} is an Ni x 1 signed Int32 array, where Ni
%       is the number of vertices that are adjacent to vertex i. Each
%       entry in A{i} is the index of a neighbour to vertex i, in no
%       particular order.
%    E  The same structure as A, except that entry A{i}(vj) is the index
%       of the edge between vertices i and vj = A{i}(j).
%    C  M x 2 signed 32-bit integer array, where M is the number of 
%       undirected edges in the graph. The array represents the mapping 
%       from edge index to edge vertices. Note that the index of the first
%       edge vertex is 0, unlike Matlab where it is 1.
%    g  N x 1 cell array, where N is the number of vertices and each 
%       entry g{i} is a Ci x 1 array of doubles, Ci being the number of 
%       possible assignments to variable i.
%    f  M x 1 cell array, where M is the number of edges in the graph
%       and each entry f{u} is a Ci x Cj array of doubles, Ci and Cj 
%       being the number of possible assignments to variables i and j, 
%       respectively. i and j correspond to the first and second columns 
%       in row u of table C.
%    s  Scalar indicating the number of samples to generate.
%
%  and the output parameters are
%
%    b   the node marginals, following the same structure as input g.
%    bc  the clique marginals, following the same structure as input f.
% 
%  Optionally, one can specify an additional input parameter VERBOSE. If 
%  it is set to 1, then progress is displayed. Otherwise, it is set to 0,
%  which is the default.
function [b, bc] = bgsfast (A, C, g, f, s, verbose)
