function [b, bc] = computemarginals (a, p)

  % Compute the unnormalized marginals.
  [b bc] = getmarginals(a,p,[]);

  % Normalize the unary marginals.
  for i = 1:numvertices(a)
    b{i} = b{i} / sum(b{i});
  end

  % Normalize the clique marginals.
  for i = 1:numedges(a)
    bc{i} = bc{i} / sum(sum(bc{i}));
  end
  
% ------------------------------------------------------------------
function [b, bc] = getmarginals (a, p, C)

  % Get the number of vertices and edges.
  n = numvertices(a);
  m = numedges(a);
  
  % Get the number of variables assigned.
  na = length(C);

  if na < n

    % Repeat for each possible assignment of the next unassigned
    % variable.
    [b bc] = initbeliefs(a,p);
    for ci = 1:numclasses(p,na+1)
      [bi bci] = getmarginals(a,p,[C ci]);
      b        = addbeliefs(b,bi);
      bc       = addbeliefs(bc,bci);
    end
  else

    % Get the unnormalized joint of the variable assignments.
    z = 1;
    for i = 1:n
      g = potnl(p,i);
      z = z * g(C(i));
    end

    for u = 1:m
      [i j] = edge(a,u);
      f     = potnl(p,i,j);
      z     = z * f(C(i),C(j));
    end

    % Create the belief tables.
    [b bc] = initbeliefs(a,p);
    for i = 1:n
      b{i}(C(i)) = z;
    end
    for u = 1:m
      [i j]            = edge(a,u);
      bc{u}(C(i),C(j)) = z;
    end
  end

% ------------------------------------------------------------------
function [b, bc] = initbeliefs (a, p)

  % Get the number of vertices and edges.
  n = numvertices(a);
  m = numedges(a);
  
  % Create the unary beliefs structure.
  b = cell(n,1);
  for i = 1:n
    b{i} = zeros(numclasses(p,i),1);
  end

  % Create the pairwise beliefs structure.
  bc = cell(m,1);
  for u = 1:m
    [i j] = edge(a,u);
    bc{u} = zeros(numclasses(p,i),numclasses(p,j));
  end

% ------------------------------------------------------------------
function b = addbeliefs (b1, b2)

  % Get the number of belief tables.
  n = length(b1);
  b = cell(n,1);

  % Repeat for each belief table.
  for i = 1:n
    b{i} = b1{i} + b2{i};
  end
