#ifndef INCLUDE_STACK
#define INCLUDE_STACK

// Type definitions.
typedef struct {
  int v;  // The node value.
} Stacknode;

typedef struct {
  Stacknode* elems;  // The array of stack elements.
  int        top;    // The top element of the stack.
  int        n;      // The maximum number of elements allowed in 
                     // the stack.
} Stack;

// Function declarations.
Stack newStack  (int n, Stacknode* elems);
int   isempty   (const Stack& S);
int   pop       (Stack& S);
void  push      (Stack& S, int v);

#endif
