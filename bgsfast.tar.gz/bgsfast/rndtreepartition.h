#ifndef INCLUDE_RNDTREEPARTITION
#define INCLUDE_RNDTREEPARTITION

#include "rand.h"

// Function declarations.
// -------------------------------------------------------------------
int rndtreepartition (int n, int** A, const int* nbrs, int* P, int* Q,
		      randtype r);

#endif
