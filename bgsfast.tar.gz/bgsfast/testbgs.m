% This tests blocked Gibbs sampling on a small graph with varying numbers
% of multinomial assignments for each variable.

% Script parameters.
c         = [2 5 2 3 2 2 2 2 4];  % Number of discrete states 
                                  % for each variable.
s         = 10000;                % Number of samples to generate.
verbose   = 0;
compexact = 1;

% Set the random number generator seed.
rand('state',676);

% Create the adjacency graph.
a = Grid(3,3);

% Generate random observation potentials.
n = numvertices(a);
g = cell(n,1);
for i = 1:n
  g{i} = rand(c(i),1);
  g{i} = g{i} / sum(g{i});
end
clear i n

% Generate random clique potentials.
m = numedges(a);
f = cell(m,1);
for u = 1:m
  [i j] = edge(a,u);
  f{u}  = rand(c(i),c(j));
  f{u}  = f{u} ./ sum(sum(f{u}));
end
clear i j u m

% Create the set of potentials.
p = Tabular(a,f,g);

% Compute the exact marginals.
if compexact
  fprintf('Computing exact marginals. \n');
  [b bc] = computemarginals(a,p);
end

% Compute the Monte Carlo estimates of the marginals.
fprintf('Computing MC estimates of marginals. \n');
tic;
[x xc] = bgsf(a,p,s,verbose);
fprintf('Inference took %i seconds. \n', round(toc));
fprintf('Press a key to continue...\n');
pause;

% Compare the exact and Monte Carlo estimates.
for i = 1:numvertices(a)
  fprintf('         p(x%i)      \n', i);
  fprintf('    True      MCMC   \n');
  fprintf('    ------    ------ \n');
  disp([b{i} x{i}]);
  fprintf('\n');
end

fprintf('(Showing only the first two assignments to each variable.)\n');
fprintf('\n');
for u = 1:numedges(a)
  [i j] = edge(a,u);
  fprintf('                 p(x%i,x%i)              \n', i, j)
  fprintf('    True                MCMC             \n');
  fprintf('    ----------------    ---------------- \n');
  disp([bc{u}(1:2,1:2) xc{u}(1:2,1:2)]);
  fprintf('\n');
end
