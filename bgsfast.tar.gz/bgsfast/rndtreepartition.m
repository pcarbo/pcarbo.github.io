% RNDTREEPARTITION(A) takes as input a sparse adjacency representation A. A
% is an N x 1 cell array, where N is the number of vertices in the graph.
% Each entry A{i} is a 1 x Ni signed Int32 array, where Ni is the number of
% vertices that are adjacent to vertex i. Each entry in A{i} is the index of
% a neighbour to vertex i, in no particular order. The output P is a 1 x N
% vector describing the graph partition, where P(i) = p means vertex i is in
% partition p.

function P = rndtreepartition (A)