#include "matlabinterface.h"
#include "vector.h"

// Function definitions.
// -------------------------------------------------------------------
// Get an integer matrix from its Matlab structure and return it in the
// argument X. Return its dimensions in M and N.
void getIntMatrix (const mxArray* p, int*& X, int& m, int& n) {

  X = (int*) mxGetPr(p);
  m = mxGetM(p);
  n = mxGetN(p);

  if (sizeof(int) != 4)
    mexErrMsgTxt("Int type in C incompatible with Int32 Matlab format");
}

// -------------------------------------------------------------------
// Get an L x 1 cell array, where each cell entry is a matrix of
// doubles. C is an array of length of L, and the routine fills it in
// with pointers to the matrices. M and N are also arrays of length L,
// where each entry indicates the size of the corresponding
// matrix. The return value is the length of the cell array.
int getCellArrayOfMatrices (const mxArray* p, double**& C, 
			    int*& M, int*& N) {

  int      n;   // The length of the cell array.
  int      i;
  mxArray* cp;  // Pointer to an individual cell.

  // Get the length of the cell array.
  n = mxGetM(p);

  // Allocate memory for the structures.
  C  = (double**) mxMalloc(sizeof(double*) * n);
  M  = (int*)     mxMalloc(sizeof(int) * n);
  N  = (int*)     mxMalloc(sizeof(int) * n);

  // Repeat for each node.
  for (i = 0; i < n; i++) {
    cp   = mxGetCell(p,i);
    C[i] = mxGetPr(cp);
    M[i] = mxGetM(cp);
    N[i] = mxGetN(cp);
  }

  return n;
}

// -------------------------------------------------------------------
// Same as the above function, only this time the matrices are filled
// with integer entries instead of doubles.
int getCellArrayOfIntMatrices (const mxArray* p, int**& C, 
			       int*& M, int*& N) {

  int      n;   // The length of the cell array.
  int      i;
  mxArray* cp;  // Pointer to an individual cell.

  // Get the length of the cell array.
  n = mxGetM(p);

  // Allocate memory for the structures.
  C  = (int**) mxMalloc(sizeof(int*) * n);
  M  = (int*)  mxMalloc(sizeof(int) * n);
  N  = (int*)  mxMalloc(sizeof(int) * n);

  // Repeat for each node.
  for (i = 0; i < n; i++) {
    cp   = mxGetCell(p,i);
    C[i] = (int*) mxGetPr(cp);
    M[i] = mxGetM(cp);
    N[i] = mxGetN(cp);
  }

  return n;
}

// -------------------------------------------------------------------
// Creates the new scalar argument in p, and returns a pointer to its
// value.
double* createScalar (mxArray*& p) {
  double* sp;  // Pointer to the scalar.
  
  p  = mxCreateScalarDouble(0);
  sp = mxGetPr(p);

  return sp;
}

// -------------------------------------------------------------------
// Creates an M x N matrix of doubles in Matlab format, and returns
// a pointer to the first element.
double* createMatrix (mxArray*& p, int m, int n) {
  double* xp; // Pointer to the array of doubles.

  p  = mxCreateDoubleMatrix(m,n,mxREAL);
  xp = mxGetPr(p);

  return xp;
}

// -------------------------------------------------------------------
// Create an n x 1 cell array, where each entry is a matrix, and 
// return the pointer to the Matlab structure. In C we return an 
// array of pointers to the matrices. M and N are arrays of length N,
// where each entry indicates the dimensions of the corresponding
// matrix.
mxArray* createCellOfMatrices (int n, const int* M, const int* N,
			       double**& C) {

  mxArray* p;   // The return value.
  mxArray* cp;  // Pointer to a cell entry.
  int      i;

  p = mxCreateCellMatrix(n,1);
  C = (double**) mxMalloc(sizeof(double*) * n);

  // Create a matrix in each cell.                      
  for (i = 0; i < n; i++) {
    cp   = mxCreateDoubleMatrix(M[i],N[i],mxREAL);
    C[i] = mxGetPr(cp);
    zeroVector(M[i]*N[i],C[i]);
    mxSetCell(p,i,cp);
  }

  return p;
}
