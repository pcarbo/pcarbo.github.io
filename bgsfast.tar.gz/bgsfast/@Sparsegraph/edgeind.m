% Overloaded class method. See ADJGRAPH/EDGEIND for more information.

function U = edgeind (g, I, J)

  [n m] = size(I);
  U     = zeros(n,m);

  for i = 1:n
    for j = 1:m
      U(i,j) = g.A(I(i,j),J(i,j));
    end
  end
  