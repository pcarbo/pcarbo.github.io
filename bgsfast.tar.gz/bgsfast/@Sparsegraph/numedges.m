% Overloaded class method. See ADJGRAPH/NUMEDGES for more information.

function m = numedges (g)

  m = length(find(triu(adj(g))));

