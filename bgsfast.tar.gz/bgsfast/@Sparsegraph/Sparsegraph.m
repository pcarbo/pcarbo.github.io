% SPARSEGRAPH(A) constructs an object defining the adjacency relation over
% the set of vertices 1:N. The object stores the adjacency relation using a
% sparse matrix. The argument A an N x N symmetric (possibly sparse) matrix,
% where N is the number of vertices, such that A(i,j) = 0 if and only if
% vertices i and j are not adjacent.

function g = Sparsegraph (A)

  % Get the number of vertices.
  n = size(A,1);

  % Convert the matrix A to a sparse matrix, even if it is already is one.
  [i j] = find(triu(A));
  m     = length(i);  % The number of undirected edges or cliques.
  g.A   = sparse(i,j,1:m,n,n);
  g.A   = g.A + g.A';

  % Create the mapping from edge index to edge vertices.
  g.C = [i j];

  % It is currently unknown whether the graph is a tree or not.
  g.istree = -1;
  
  % Initialize the object with the given structure.
  g = class(g,'Sparsegraph',Adjgraph(n));
