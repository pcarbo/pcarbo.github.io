% Overloaded class method. See ADJGRAPH/EDGEIND for more information.

function [I, J] = edge (g, U)

  I = g.C(I,1);
  J = g.C(I,2);
