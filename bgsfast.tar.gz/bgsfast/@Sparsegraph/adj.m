% Overloaded class method. See ADJGRAPH/ADJ for information.

function A = adj (g, varargin)

  [I J] = parseadjargs(g,varargin{:});

  % Output the adjacency matrix on the selected indices.
  A = g.A(I,J) > 0;
