% Overloaded class method. See ADJGRAPH/ISTREE for more information.

function [b, varargout] = istree (g)

  if g.istree ~= -1
    b = g.istree;
  else
    
    % If we get through the graph without encountering a cycle, then the
    % graph must be a tree.
    g.istree = true;

    % Get the number of vertices.
    n = numvertices(g);

    % Perform depth-first search on the graph, starting at the first
    % vertex. Keep track of which nodes have been visited by labeling
    % them. 
    L    = zeros(1,n);
    Q    = 1;
    L(1) = 1;

    % Repeat as long as there still is an element in the queue.
    while length(Q)

      % Grab the first element from the queue and remove it. Label the
      % vertex as visited.
      i    = Q(1);
      Q    = Q(2:end);
      L(i) = 1;

      % Get the neighbours.
      js = nbrs(g,i);
      
      % If one of the neighbours has already been visited, then we know
      % the graph is not a tree.
      if sum(L(js))
	b = false;
	break
      end

      % Queue up the the neighbours.
      Q = [js Q];
    end
  end

  g.istree = b;
  if nargout == 2
    varargout{1} = g;
  end
