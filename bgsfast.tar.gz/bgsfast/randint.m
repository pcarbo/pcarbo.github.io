% RANDINT   Generate a matrix of random integers.
%    RANDINT(A,B,M,N) generates an M x N matrix of random numbers
%    uniformly distributed in the set of integers between A and B.
%    If A and B are not specified, then binary values are
%    generated. The default values for M and N are 1, if not
%    specified. 

function X = randint (varargin)

  [a b m n] = managevargs(varargin, {0 1 1 1});

  U = rand(m,n);
  U = U .* (U < 1);
  X = floor(a + (b-a+1)*U);
