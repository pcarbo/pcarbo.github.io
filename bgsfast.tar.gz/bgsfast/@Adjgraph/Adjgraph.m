% ADJGRAPH(N) constructs an object defining a simple adjacency relation
% over the set of vertices {1,2,...,N}. This class is mainly meant to
% provide basic functionality of adjacency graphs, since it it not very
% practical. ADJGRAPH defines a full connected graph with N vertices.

function g = Adjgraph (n)
  
  % Initially, we have a single partition of the graph, which is just 
  % the graph itself. The fields of the class are:
  %   T  1 x N array
  %   P  1 x N array
  %   V  1 x P cell array
  % where N is the number of vertices in the graph and P is the number of
  % partitions.
  g.P = partitiontype(ones(1,n));
  g.T = [];
  g.V = {};

  % Initialize the object with the given structure.  
  g   = class(g,'Adjgraph');
  g.T = keytype(g,1:n);
  g.V = {keytype(g,1:n)};

% ----------------------------------------------------------------------
function Y = partitiontype (X)
  Y = uint16(X);
