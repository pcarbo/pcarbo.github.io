% NUMEDGES(G) returns the number of undirected edges in the adjacency graph
% G.

function m = numedges (g)

  n = numvertices(g);
  m = n*(n-1)/2;
