% NUMPARTITIONS(G) returns the number of partitions in adjacency graph G.

function np = numpartitions (g)
  np = length(g.V);
