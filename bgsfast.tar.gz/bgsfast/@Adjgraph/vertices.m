% VERTICES(G) returns the set of vertices in adjacency graph G. 
% VERTICES(G,P) and VERTICES(G,P,'in') returns the set of vertices in
% partition P of adjacency graph G.
% VERTICES(G,P,'out') returns the set of vertices outside partition P.

function v = vertices (g, varargin)

  [p s] = managevargs(varargin, {0 'in'});

  if ~p

    % Return the set of vertices in the entire graph.
    n = numvertices(g);
    v = 1:n;
  else

    % Return the set of vertices in a given partition.
    switch s
    case 'in'
      v = verticesinside(g,p);
    case 'out'
      v = verticesoutside(g,p);
    otherwise
      error('Invalid string: specify "in" or "out".');
    end
  end

% ----------------------------------------------------------------------
function v = verticesinside (g, p)
  v = double(g.V{p});

% ----------------------------------------------------------------------
function v = verticesoutside (g, p)
  V = g.V{p};
  n = numvertices(g);
  v = find(~sparse(1,double(V),ones(length(V),1),1,n));
