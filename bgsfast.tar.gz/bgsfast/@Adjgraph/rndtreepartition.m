% RNDTREEPARTITION(G) partitions the graph G such that each partition is
% a collection of trees (i.e. it contains no cycles).

function g = rndtreepartition (g)

  % Get the total number of vertices.
  n = numvertices(g);

  % If the graph is already a tree, then we don't need to partition the
  % graph. 
  if istree(g)
    g = setpartition(g,ones(1,n));
  else,
  
    % Initialize the set of partitions. "nb" is the number of vertices that
    % belong to partitions.
    P  = zeros(1,n);
    p  = 0;
    nb = 0;
    
    % We label the nodes as follows:
    %   0  means that we need to visit the vertex.
    %   1  means we have added the vertex to the queue to be visited, or
    %      we don't need to visit it (because It already belongs to a
    %      partition). 
    %   2  means that the vertex belongs to a partition.
    V = zeros(n,1);

    % Repeat as long as there is at least one vertex that doesn't belong to
    % a partition.
    while nb < n
      p = p + 1;

      % "nv" is the number of nodes we need to visit, and "v" is the number
      % of nodes we have visited so far.
      nv = n - nb;
      v  = 0;

      % Set all the "visited" (1) labels to "need to visit" (0).
      V = 2 * (V == 2);
      
      % Repeat depth-first search as long as there is at least one vertex
      % that we need to visit (labeled as 0). The reason that we have to
      % perform tree search multiple times is that the partition may turn
      % out to be a collection of trees.
      while v < nv
	
	% Perform random tree search. 
	% Initialize the stack randomly from the set of nodes that haven't
	% been visited.
	i    = randelem(find(V == 0));
	v    = v + 1;
	V(i) = 1;
	S    = i;
	
	% Perform depth-first search. Repeat as long as the stack is not
        % empty.
	while length(S)
	  
	  % Get the top element in the stack and remove it.
	  i = S(1);
	  S = S(2:end);

	  % Get the neighbours.
	  js = nbrs(g,i);
	  
	  % Add the vertex to the current partition, but only if there is only
	  % one neighbour that already belongs to the partition. If there is
	  % more than one, then we'll create a cycle, and we don't want to do
	  % that. Note that the following test is 0 only for the first
          % vertex visited.
	  if sum(P(js) == p) < 2

	    % Add the vertex to the partition.
	    P(i) = p;
	    V(i) = 2;
	    nb   = nb + 1;
	    
	    % Get the set of neighbours that haven't been visited.
	    js = js(find(V(js) == 0));

	    % Mark these vertices for visitation in a random order by
            % popping them on the stack.
	    v     = v + length(js);
	    V(js) = 1;
	    js    = js(randperm(length(js)));
	    S     = [fliplr(js) S];
	  end
	end
      end
    end
    
    % Create the partition.
    g = setpartition(g,P);
  end

% ----------------------------------------------------------------------
% Draw a random element uniformly from the set S.
function e = randelem (S)
  e = S(randint(1,length(S)));
