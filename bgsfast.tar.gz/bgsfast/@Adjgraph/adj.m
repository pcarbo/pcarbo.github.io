% ADJ(G) returns the entire adjacency matrix for graph G.
% ADJ(G,I,J) returns the adjacency matrix between vertices I and J. For the
% call ADJ(G,I), we define J = I.

function A = adj (g, varargin)

  [I J] = parseadjargs(g,varargin{:});

  % Outpute the adjacency matrix on the selected indices.
  n = numvertices(g);
  A = logical(ones(n) - eye(n));
  A = A(I,J);
