% ISTREE(G) returns TRUE if and only if the graph G is a tree
% (i.e. contains
% no cycles).

function [b, varargout] = istree (g)

  n = numvertices(g);
  b = n < 3;

  if nargout == 2
    varargout{1} = g;
  end
