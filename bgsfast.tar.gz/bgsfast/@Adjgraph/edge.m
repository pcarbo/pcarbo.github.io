% [I J] = EDGE(G,U) returns the edges (pairs of vertices) corresponding to
% the edge indices U. The return values are ambiguous since we could equally
% return [I J] or [J I], so we enforce the constraint that I < J.

function [I, J] = edge (g, U)

  % NOT WORKING RIGHT NOW.

  