function Y = keytype (g, X)
  Y = uint32(X);
