% Display method for the adjacency graph class. Displays the adjacencies
% for all the partitions. Note that since this is the edges are
% undirected, and hence the adjacency matrix is symmetric, we only show
% the upper triangular matrix.

function display (g)

  % Get the number of partitions and the total number of vertices.
  np = numpartitions(g);
  n  = numvertices(g);

  % Show the adjacencies for the entire graph.
  fprintf('Entire graph: ');
  showvertices(vertices(g));
  showadj(adj(g),vertices(g));
  fprintf('\n');

  % Show the partitions if there is more than one.
  if np > 1
    % Repeat for each partition.
    for p = 1:np
      v = vertices(g,p);
      fprintf('Partition %i: ', p);
      showvertices(v);
      showadj(adj(g,v),v);
      fprintf('\n');
    end
  end

% ----------------------------------------------------------------------
function showvertices (V)
  fprintf('%i ', V);

% ----------------------------------------------------------------------
function showadj (A, V)
  [i j] = find(triu(A));
  
  % Repeat for each undirected edge.
  for u = 1:length(i)
    fprintf('(%i,%i) ', V(i(u)), V(j(u)));
  end

