function [I, J] = parseadjargs (g, varargin)

  nargin = length(varargin);

  if nargin < 1
    I =  vertices(g);
  else
    I = varargin{1};
  end

  if nargin < 2
    J = I;
  else
    J = varargin{2};
  end
