% NUMVERTICES(G) returns the number of vertices in the adjacency graph G.
% NUMVERTICES(G,P) returns the number of vertices in partition P of graph G.

function n = numvertices (g, varargin)

  switch nargin
  case 1
    n = length(g.T);
  case 2
    p = varargin{1};
    n = length(g.V{p});
  otherwise
    error('Invalid number of arguments.');
  end
