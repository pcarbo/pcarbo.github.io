% [U V] = UNORDEREDPAIR(G,I,J) returns new pairs (U,V) such that they
% contain the same unordered pairs of (I,J), but U < V.

function [U, V] = unorderedpair (g,I,J)  

  U = (I < J) .* I + (J < I) .* J;
  V = (I < J) .* J + (J < I) .* I;
