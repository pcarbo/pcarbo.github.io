% SETPARTITION(G,P) partitions the adjacency graph according to P. P is a
% vector of length N, where N is the number of vertices in G. Entry P(i) is
% the partition number, and the number of partitions is max(P).

function g = setpartition (g, P)

  % Get the partition sizes.
  N  = partitionsizes(P);
  np = length(N);
  n  = length(P);

  % Build the partitioned adjacency graphs.
  g.V = cell(1,np);

  % Repeat for each partition.
  for p = 1:np
    g.V{p} = keytype(g,zeros(1,N(p)));
  end

  N = zeros(1,np);

  % Repeat for each vertex.
  for i = 1:n
    pi          = P(i);
    N(pi)       = N(pi) + 1;
    ni          = N(pi);
    g.V{pi}(ni) = i;
    g.P(i)      = pi;
    g.T(i)      = ni;
  end

% ----------------------------------------------------------------------
function N = partitionsizes (P)

  % Get the partition sizes.
  n  = length(P);
  np = double(max(P));
  N  = zeros(1,np);

  % Repeat for each vertex.
  for i = 1:n
    pi    = P(i);
    N(pi) = N(pi) + 1;
  end
