% EDGEIND(G,I,J) returns the index of the edge between vertices I and
% J. This is useful if we have a function that maps edge index to
% something. Each index is between 1 and M, where M is the number of
% undirected edges in the graph.

function U = edgeind (g, I, J)

  n     = numvertices(g);
  [I J] = unorderedpair(g,I,J);
  U     = (2*n-I).*(I-1)/2 + J - I;
  