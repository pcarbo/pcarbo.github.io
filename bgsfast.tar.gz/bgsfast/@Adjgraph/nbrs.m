% NBRS(G,I) returns all the neighbours of vertex I in graph G.  
% NBRS(G,I,P) and NBRS(G,I,P,'in') returns all the neighbours of vertex I
% inide partition P.
% NBRS(G,I,P,'out') returns all the neighbours of vertex I outside of
% partition P.

function js = nbrs (g, i, varargin)

  % Get the set of candidate vertices.
  J = vertices(g,varargin{:});

  % Return the neighbours.
  js = J(find(adj(g,i,J)));
