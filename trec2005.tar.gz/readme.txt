                          MATLAB VERSION OF
                         TREC2005 CORPUS FOR
                        ON-LINE EVALUATION OF 
                           SPAM FILTERING

Peter Carbonetto
Dept. of Computer Science
University of British Columbia
Copyright 2008

License
-------
By download and making use of this data, you accept the terms of
agreement for use of the 2005 TREC public spam corpus. This license
agreement is found here:
http://plg.uwaterloo.ca/~gvcormac/treccorpus

Attribution of authorship
-------------------------
This data set was originally created by Gordon Cormack and Thomas
Lynam as part of the the 2005 TREC Spam Filter Evaluation Tool Kit.
The open source software SpamBayes was used to extract the features
from the original emails.

Relevant Web links:
Peter Carbonetto   http://www.cs.ubc.ca/~pcarbo
Gordon V. Cormack  http://plg.uwaterloo.ca/~gvcormac
Thomas R. Lynam    http://plg1.cs.uwaterloo.ca/~trlynam
SpamBayes          http://spambayes.sourceforge.net

Descrption of data
------------------
The MATLAB data file trec2005.mat contains two variables, an M x N
matrix A and an N x 1 vector y, where N is the number of emails, and M
is the number of extracted features. Each entry of the vector y is a
class label; a 1 signifies spam, and a 0 says that the email is not
spam. 

The matrix A contains the feature data for all the emails. Notice that
the matrix A is extremely sparse---less than 1 out of every 5,000
entries of the matrix is a nonzero.

See the publications of Gordon Cormack and Thomas Lynam for more
information on how this data set can be used to assess the performance
of classification algorithms for spam filtering.
