function A = spdiag (d)
  A = diag(sparse(d));
  