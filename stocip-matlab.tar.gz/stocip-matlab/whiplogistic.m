% [W PY] = WHIPLOGISTIC(A,Y,LAMBDA,NS,A0,ALPHA) is the same as the function
% WHIP, except that it learns a the regression coefficients for a logistic
% regression model in an on-line manner. See the functions WHIP and
% LOGISTICL1 for more details. 
%
% This function outputs two things: the vector of regression weights W, and
% a vector PY of the same size as Y., where PY(i) is the model's estimated
% probability that the ith binary output is 1, and this prediction is
% computed *before* having trained on the ith training example.

function [w, py] = whiplogistic (A, y, lambda, ns, a0, alpha)
  
  % Algorithm parameters.
  verbose  = true;
  alphamax = 0.995; % Maximum step size.
  mumin    = 1e-9;  % Minimum barrier parameter.
  sigma    = 0.5;   % Centering parameter.
  
  % Generate the sequence of step sizes.
  a = 1 ./ ((1:ns) + a0).^alpha;

  % Get the number of samples, which we denote by n, and the number of
  % features (and regression variables), which we denote by m.
  [n m] = size(A);

  % Initialize the primal variables x and the dual variables z. Note that
  % the Hessian is constant and positive-definite.
  x = ones(2*m,1);
  z = ones(2*m,1);
  P = [A -A];
  
  % This will store the classification of the ith data point before
  % training on it.
  py = zeros(n,1);
  
  % Repeat for each sample to simulate.
  mu = 1;
  H  = speye(2*m);
  for s = 1:ns
    
    % Classify the ith data point, and get the on-line estimate of the
    % gradient, and compute an averaged estimate of the Hessian.
    i     = mod(s-1,n) + 1;
    p     = P(i,:);
    u     = sigmoid(p*x);
    py(i) = u;
    g     = gradient(p,y(i),u,lambda/n);
    Ht    = hessian(p,u);
    H     = (s-1)/s*H + 1/s*Ht;
    
    % Compute the new log-barrier penalty based on the duality gap.
    mu = max(mumin,sigma*x'*z/(2*m));
    
    % Report the status of the algorithm.
    if verbose
      fprintf('%d (%d) ',s,i);
    end

    % Compute the search direction of x and z. Here, gb is the gradient of
    % the log-barrier function.
    S  = diag(sparse(z./(x+eps)));
    gb = g - mu./(x+eps);
    px = (H + S) \ (-gb);
    pz = mu./(x+eps) - z - S*px;

    % Determine the largest step size ensuring that x and z remain feasible.
    as  = a(s);
    xz  = [x;  z];
    pxz = [px; pz];
    is  = find(pxz < 0);
    if length(is)
      as = min(as,alphamax * min(xz(is) ./ -pxz(is)));
    end
    
    % Move to the next point.
    x = x + as * px;
    z = z + as * pz;
  end

  if verbose
    fprintf('\n');
  end
  
  % Output the solution.
  w = x(1:m) - x(m+1:end);

% ------------------------------------------------------------------
% Compute the stochastic estimate of the gradient.
function g = gradient (p, y, u, lambda)
  g = -p'*(y - u) + lambda;

% ------------------------------------------------------------------
% Compute the stochastic estimate of the Hessian.
function H = hessian (p, u)
  U = diag(sparse(u.*(1-u)));
  H = p'*U*p;

