% LASSOIP(A,Y,LAMBDA,USENEWTON) returns the L1-regularized least squares
% solution. It is calculating using an primal-dual interior-point with a
% proper merit function for guaranteeing descent during backtracking line
% search. If USENEWTON is false, no second-order information is used in
% computation of the primal-dual search direction.
%
% See the function LASSOIP for more information.

function w = lassoip (A, y, lambda, usenewton)

  % Optimization parameters.
  verbose   = false;
  eps       = 1e-8;   % A number close to zero.
  maxiter   = 100;    % The maximum number of iterations.
  tolerance = 1e-6;   % Stopping criterion.
  sigmamax  = 0.5;    % The maximum centering parameter.
  etamax    = 0.25;   % The maximum forcing number.
  mumin     = 1e-9;   % Minimum barrier parameter.
  alphamax  = 0.995;  % Maximum step size.
  alphamin  = 1e-6;   % Minimum step size.
  beta      = 0.75;   % Granularity of backtracking search.
  tau       = 0.01;   % Amount of actual decrease we will accept in 
                      % line search.

  % Get the number of samples, which we denote by n, and the number of
  % features (and regression variables), which we denote by m.
  [n m] = size(A);

  % Initialize the primal variables x and the dual variables z. Note that
  % the Hessian is constant and positive-definite.
  x = ones(2*m,1);
  z = ones(2*m,1);
  P = [A -A];
  
  if usenewton
    H = P'*P/n;
  else
    H = speye(2*m);
  end

  if verbose
    fprintf('  i f(x)       lg(mu) sigma   ||rx||  ||rc||  alpha\n');
  end
  
  % Repeat while the convergence criterion has not been satisfied, and
  % we haven't reached the maximum number of iterations.
  alpha = 0;
  for iter = 1:maxiter
    
    % Compute the response of the objective, the gradient of the objective
    % and the responses of the unperturbed Karush-Kuhn-Tucker optimality
    % conditions.
    f       = objective(P,y,x,lambda);
    g       = gradient(P,y,x,lambda);
    [rx rc] = residual(x,z,g);
    r0      = [rx; rc]; 
    
    % Set some parameters that affect convergence of the interior-point
    % method. This particular forcing sequence should ensure superlinear (or
    % maybe quadratic) convergence. See p. 572 of Nocedal and Wright
    % (2006). We use the mu update rule described in Boyd and Vandenberghe
    % (2004) and Bellavia (1998). Here we divide sigma and eta by the number
    % of variables to ensure that it doesn't depend on the problem
    % size. Also, note that the duality gap has a negative sign here because
    % the constraints are less than or equal to zero; see p. 612 of Boyd and
    % Vandenberghe (2004).
    eta   = min(etamax,norm(r0)/(4*m));
    sigma = min(sigmamax,sqrt(norm(r0)/(4*m)));
    mu    = max(mumin,sigma*x'*z/(2*m));

    % Print the status of the algorithm.
    if verbose
      fprintf('%3d %+0.3e  %+5.2f %0.1e %0.1e %0.1e %0.1e\n',iter,...
	      f,log10(mu),sigma,norm(rx),norm(rc),alpha);
    end

    % CONVERGENCE CHECK.
    % If the norm of the responses is less than the specified tolerance,
    % we are done. This is the convergence criterion used by Yamashita
    % and Yabe (1998).
    if norm(r0)/(4*m) < tolerance
      break
    end

    % SOLUTION TO PERTURBED KKT SYSTEM.
    % Compute the search direction of x. Here, gb is the gradient of the
    % log-barrier function.
    warning('off','MATLAB:nearlySingularMatrix');
    S  = spdiag(z./(x+eps));
    gb = g - mu./(x+eps);
    px = (H + S) \ (-gb);

    % Compute the search direction of z.
    pz = mu./(x+eps) - z - S*px;
    
    % BACKTRACKING LINE SEARCH.
    % To ensure global convergence, execute backtracking line search to
    % determine the step length. First, we have to find the largest step
    % size which ensures that z remains feasible. Next, we perform
    % backtracking line search; see p.37 of Nocedal and Wright (2006) and
    % Sec. 11.7.3 of Boyd and Vandenberghe (2004).
    alpha = alphamax;
    xz    = [x; z];
    pxz   = [px; pz];
    is    = find(xz + pxz < 0);
    if length(is)
      alpha = alpha * min(1,min(xz(is) ./ -pxz(is)));
    end

    % Compute the response of the merit function and the directional
    % gradient at the current point and search direction; see p. 206 of
    % Armand, Gilbert and Jan-Jegou (2000).
    psi = merit(f,x,z,mu,eps);
    d   = gradmerit(g,x,z,px,pz,mu,eps);

    % Repeat until we've found a step size that satisfies the sufficient
    % decrease condition.
    while true

      % Compute the candidate point.
      xnew = x + alpha * px;
      znew = z + alpha * pz;

      % Compute the response of the objective function and merit function at
      % the candidate point.
      fnew   = objective(P,y,xnew,lambda);
      psinew = merit(fnew,xnew,znew,mu,eps);
      
      % Stop backtracking search if we've found a candidate point that
      % sufficiently decreases the norm of the residual.
      if psinew < psi + tau*eta*alpha*d
	break
      end
      
      % The candidate point does not meet our criteria, so decrease the step
      % size for 0 < beta < 1.
      alpha = alpha * beta;
      if alpha < alphamin
	error('Step size too small');
      end
    end
    
    % Move to the next point.
    x = xnew;
    z = znew;
  end

  % Output the solution.
  wp = x(1:m);
  wn = x(m+1:end);
  w  = wp - wn;

  % Next, let's check the extent to which we violate the optimality
  % conditions reported in Sec. 2.1 of Schmidt, Fung and Rosalas (2007).
  if verbose
    g = -A'*(y - A*w)/n;
    e = zeros(m,1);
    
    % For every positive weight, the gradient of the loss function should
    % be equal to -lambda.
    is = find(w > eps);
    if length(is)
      e(is) = g(is) + lambda/n;
    end
    
    % For every negative weight, the gradient of the loss function should
    % be equal to lambda.
    is = find(w < -eps);
    if length(is)
      e(is) = g(is) - lambda/n;
    end
    
    % For every weight equal to zero, the gradient of the loss function
    % should be bounded by lambda.
    is = find(abs(w) < eps & abs(g) > lambda/n);
    if length(is)
      e(is) = abs(g) - lambda/n;
    end
    
    fprintf('The mean of squared constraint violations is %0.3g.\n',...
	    norm(e)/m);
  end
  
% ------------------------------------------------------------------
% Compute the response of the objective function.
function f = objective (P, y, x, lambda)
  n = length(y);
  f = norm(y - P*x)^2/(2*n) + lambda/n*sum(x);
  
% ------------------------------------------------------------------
% Compute the gradient of the objective function.
function g = gradient (P, y, x, lambda)
  n = length(y);
  g = -P'*(y - P*x)/n + lambda/n;
  
% ------------------------------------------------------------------
% Compute the residual of the unperturbed Karush-Kuhn-Tucker system.
function [rx, rc] = residual (x, z, g)
  rx = g - z;  % Dual residual.
  rc = x.*z;   % Complementarity.

% ------------------------------------------------------------------
function psi = merit (f, x, z, mu, eps)  
  psi = f + x'*z - mu*sum(log(x.^2.*z+eps));
  
% ------------------------------------------------------------------
function d = gradmerit (g, x, z, px, pz, mu, eps)
  d = px'*(g + z - 2*mu./(x+eps)) + ...
      pz'*(x - mu./(z+eps));
  