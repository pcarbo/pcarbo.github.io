% Run an experiment for spam filtering.
clear

% Experiment parameters.
lambda  = 50;    % L1-regularization weight.
ns      = 6034;  % Number of iterations of stochastic gradient.
a0      = 1;     % Specifies the sequence of step sizes.
alpha   = 1;     % Specifies the sequence of step sizes.

% Load the data.
load('spamassassin.mat');

% Compute the maximum likelihood estimator for logistic regression.
tic;
[w p] = whiplogisticfast(A',y,lambda,ns,a0,alpha);
disp(toc);

t = 0.5;
a = sum(y == 0 & p <= t);
b = sum(y == 1 & p <= t);
c = sum(y == 0 & p > t);
d = sum(y == 1 & p > t);
disp([a b; c d]);
