% Make each column of A be zero mean and standard deviation of 1.
function [S, mu, sigma2] = standardizecols (A)

  n = size(A,1);
  A = double(A);
  
  mu     = mean(A);
  sigma2 = std(A);
  
  S = A - repmat(mu,[n 1]);
  S = S ./ repmat(sigma2,[n 1]);
  