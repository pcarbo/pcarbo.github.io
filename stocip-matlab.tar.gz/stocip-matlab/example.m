% This MATLAB script demonstrates how to use the batch and on-line
% primal-dual interior point methods to learn the regression weights for
% a binary classifier based on a logistic regression model.
clear

% Experiment parameters.
lambda   = 0.4;   % L1-regularization weight.
maxiter  = 100;   % The maximum number of solver iterations.
ns       = 1000;  % Number of iterations of stochastic gradient.
a0       = 1;     % Specifies the sequence of step sizes.
alpha    = 1;     % Specifies the sequence of step sizes.
fullhess = false; % If true, use full second-order information.
seed     = 7;     % Random number generator seed.

% Parameters controlling generation of synthetic data.
n       = 100;  % The number of synthetic examples.
m       = 8;    % The number of synthetic features.
epsilon = 0.1;  % Standard deviation in noise of outputs.

% Set the random number generator seed.
seed = 7;
rand('state',seed);
randn('state',seed);

% Generate the input vectors from the standard normal, and generate the
% binary responses from the regression with some additional noise, and then
% transform the results using the logistic function. "beta" is the set of
% true regression coefficients, and "p1" is the probability that the
% binary response is 1.
beta = [ 0 0 2 -4 0 0 -1 3 ]';
A    = randn(n,m);
p1   = sigmoid(A*beta + epsilon*randn(n,1));
y    = rand(n,1) < p1;

% Compute the maximum likelihood estimator for logistic regression,
% either in batch or on-line fashion.
w       = logisticl1(A,y,lambda);
[w2 py] = whiplogistic(A,y,lambda,ns,a0,alpha);
disp([w w2]);
