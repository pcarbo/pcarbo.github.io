function W = sgproj (A, y, lambda, ns, a0, alpha)
  eps = 1e-4;  % Small number used to check whether the bound
               % constraint is active.

  % Generate the sequence of step sizes.
  a = 1 ./ ((1:ns) + a0).^alpha;

  % Get the number of samples, which we denote by n, and the number of
  % features (and regression variables), which we denote by m.
  [n m] = size(A);

  % Initialize the optimization variables x.
  x = ones(2*m,1);
  P = [A -A];
  
  % This is storage for the sequence of iterates in the simulation.
  W = zeros(m,ns);

  % Repeat for each sample to simulate.
  for s = 1:ns
    
    % Get an on-line estimate of the gradient.
    i = mod(s-1,n) + 1;
    g = gradient(P,y,x,lambda,i);

    % Take a descent step along all dimensions in the working set, and
    % then project the iterate back into the positive quadrant.
    x = x - a(s) * g;
    x = max(x,0);
    
    % Store the point.
    wp     = x(1:m);
    wn     = x(m+1:end);
    w      = wp - wn;
    W(:,s) = w;
  end
