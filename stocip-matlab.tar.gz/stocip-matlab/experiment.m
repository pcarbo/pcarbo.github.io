% This MATLAB script runs all the experiments shown in the 2008
% conference paper, except for the spam filtering experiments.
clear

% Experiment parameters.
a         = 2.5;    % Generate variances from the inverse gamma with
b         = 1;      % shape a and scale b.
n         = 100;    % The number of synthetic examples.
m         = 40;     % The number of synthetic features.
lambda    = 125;    % L1-regularization weight.
ns        = 100;    % Number of iterations of stochastic gradient.
A0        = 1:1:50; % Specifies the sequence of step sizes.
alpha     = 1;      % Specifies the sequence of step sizes.
epsilon   = 1;      % Standard deviation of output noise.
numtrials = 4;      % The number of trials for each experiment.
seed      = 7;      % The random number generator seed.

% The stochastic algorithms to run.
methods    = { 'whip', 'sgaug', 'sgsub', 'sgproj', 'sgsmooth' };
strings    = { 'primal-dual interior-point stochastic gradient'
	       'augmented Lagrangian stochastic gradient'
	       'stochastic sub-gradient'
	       'projected stochastic gradient'
	       'smoothed stochastic gradient' };
linestyles = { 'k-', 'm-', 'c--', 'g-.', 'b-.' };
legendstr  = { 'Interior-point'
	       'Augmented Lagrangian', 
	       'Sub-gradient'
	       'Metric projection'
	       'Smoothed approx.' };

% Experiment #1
% -------------
N          = length(A0);
nummethods = length(methods);
E1         = zeros(nummethods,N);
beta       = repmat([0 2 0 2],m/4,1);
beta       = beta(:);

% Repeat for each value of a0.
for i = 1:N
  a0 = A0(i);
  
  rand('state',seed);
  randn('state',seed);
  
  % Repeat for each trial.
  for t = 1:numtrials
    fprintf('a0 = %d, trial #%d\n',a0,t);

    % Generate the synthetic data.
    [A y] = syntheticdata(beta,a,b,n,epsilon);

    % Run the exact solver.
    fprintf('- Running the exact interior-point solver.\n');
    wexact = lassoip2(A,y,lambda,true);

    % Run the stochastic solvers.
    for k = 1:nummethods
      fprintf('- Running %s.\n',strings{k});
      W       = feval(methods{k},A,y,lambda,ns,a0,alpha);
      w       = W(:,end);
      e       = mean(abs(w - wexact));
      E1(k,i) = E1(k,i) + e;
    end        
    fprintf('\n');
  end
end

% Normalize the errors.
E1 = E1 / numtrials;

% Plot the results.
figure(1);
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','Experiment #1');
set(gcf,'Color','white');

linewidth = 3;
semilogy(A0,E1(1,:),linestyles{1},'LineWidth',linewidth);
hold on
for k = 2:nummethods
  semilogy(A0,E1(k,:),linestyles{k},'LineWidth',linewidth);
end
hold off
xlabel('a_0');
ylabel(sprintf('1/m||w^{exact} - w^{stoc.}||_1 averaged over %d trials',...
	       numtrials));
legend(legendstr,'Location','NorthEast');
legend boxoff

set(gca,'XMinorTick','off');
set(gca,'YMinorTick','off');
set(gca,'XLim',[min(A0) max(A0)]);
set(gca,'YLim',[10^(-1) 10^(4)]);

% Experiment #2
% -------------
% Experiment parameters.
a0 = 50;            % Specifies sequence of step sizes.
B  = 0.5:0.25:4.5;  % Inverse-gamma scale b.

N  = length(B);
E2 = zeros(nummethods,N);

% Repeat for each value of b.
for i = 1:N
  b = B(i);
  
  rand('state',seed);
  randn('state',seed);
  
  % Repeat for each trial.
  for t = 1:numtrials
    fprintf('b = %0.2f, trial #%d\n',b,t);

    % Generate the synthetic data.
    [A y] = syntheticdata(beta,a,b,n,epsilon);

    % Run the exact solver.
    fprintf('- Running the exact interior-point solver.\n');
    wexact = lassoip2(A,y,lambda,true);

    % Run the stochastic solvers.
    for k = 1:nummethods
      fprintf('- Running %s.\n',strings{k});
      W       = feval(methods{k},A,y,lambda,ns,a0,alpha);
      w       = W(:,end);
      e       = mean(abs(w - wexact));
      E2(k,i) = E2(k,i) + e;
    end        
    fprintf('\n');
  end
end

% Normalize the errors.
E2 = E2 / numtrials;

% Plot the results.
figure(2);
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','Experiment #2');
set(gcf,'Color','white');
sigma     = B./(a-1);
linewidth = 3;
semilogy(sigma,E2(1,:),linestyles{1},'LineWidth',linewidth);
hold on
for k = 2:nummethods
  semilogy(sigma,E2(k,:),linestyles{k},'LineWidth',linewidth);
end
hold off
xlabel('E(\sigma)');
ylabel(sprintf('1/m||w^{exact} - w^{stoc.}||_1 averaged over %d trials',...
	       numtrials));
legend(legendstr,'Location','NorthEast');
legend boxoff

set(gca,'XMinorTick','off');
set(gca,'YMinorTick','off');
set(gca,'XLim',[min(sigma) max(sigma)]);
set(gca,'YLim',[10^(-1) 10^(4)]);

% Experiment #3
% -------------
% Experiment parameters.
Lambda = [1:9 10:10:90 100:25:300];
b      = 1;

N  = length(Lambda);
E3 = zeros(nummethods,N);

% Repeat for each value of lambda.
for i = 1:N
  lambda = Lambda(i);
  
  rand('state',seed);
  randn('state',seed);
  
  % Repeat for each trial.
  for t = 1:numtrials
    fprintf('lambda = %d, trial #%d\n',lambda,t);

    % Generate the synthetic data.
    [A y] = syntheticdata(beta,a,b,n,epsilon);

    % Run the exact solver.
    fprintf('- Running the exact interior-point solver.\n');
    wexact = lassoip2(A,y,lambda,true);

    % Run the stochastic solvers.
    for k = 1:nummethods
      fprintf('- Running %s.\n',strings{k});
      W       = feval(methods{k},A,y,lambda,ns,a0,alpha);
      w       = W(:,end);
      e       = mean(abs(w - wexact));
      E3(k,i) = E3(k,i) + e;
    end        
    fprintf('\n');
  end
end

% Normalize the errors.
E3 = E3 / numtrials;

% Plot the results.
figure(3);
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','Experiment #3');
set(gcf,'Color','white');

linewidth = 3;
plot(Lambda/n,E3(1,:),linestyles{1},'LineWidth',linewidth);
hold on
for k = 2:nummethods
  plot(Lambda/n,E3(k,:),linestyles{k},'LineWidth',linewidth);
end
hold off
xlabel('\lambda/n');
ylabel(sprintf('1/m||w^{exact} - w^{stoc.}||_1 averaged over %d trials',...
	       numtrials));
legend(legendstr,'Location','NorthEast');
legend boxoff

set(gca,'XMinorTick','off');
set(gca,'YMinorTick','off');
set(gca,'XLim',[min(Lambda) max(Lambda)]/n);
set(gca,'YLim',[0.5 1]);

% Experiment #4
% -------------
% Experiment parameters.
p   = 0.5;    % Proportion of non-zero weights in synthetic data set.
m   = 8;      % The number of synthetic features.
a   = 2.5;    % Generate variances from the inverse gamma with
b   = 1;      % shape a and scale b.
ns1 = 100;    % Number of iterations of stochastic gradient (1).
ns2 = 1000;   % Number of iterations of stochastic gradient (2).

% L1-regularization weights.
Lambda = [1:9 10:10:90 100:25:500];
N      = length(Lambda);

rand('state',seed);
randn('state',seed);

% Generate the synthetic data.
beta  = [ 0 0 2 -4 0 0 -1 3 ]';
[A y] = syntheticdata(beta,a,b,n,epsilon);

% Storage for the simulation results.
Wexact = zeros(m,N);
Wstoc1 = zeros(m,N);
Wstoc2 = zeros(m,N);

% Repeat for each value of lambda.
for i = 1:N
  lambda = Lambda(i);
  
  fprintf('lambda = %d\n',lambda);
  
  % Run exact solver.
  fprintf('- Running the exact solver.\n');
  w = lassoip2(A,y,lambda,true);
  Wexact(:,i) = w;
  
  % Run stochastic gradient algorithm (1).
  fprintf('- Running stochastic gradient algorithm (1).\n');
  w = whip(A,y,lambda,ns1,a0,alpha);
  Wstoc1(:,i) = w(:,end);

    % Run stochastic gradient algorithm (2).
  fprintf('- Running stochastic gradient algorithm (2).\n');
  w = whip(A,y,lambda,ns2,a0,alpha);
  Wstoc2(:,i) = w(:,end);

  fprintf('\n');
end

figure(4);
clf
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','Experiment #4');
set(gcf,'Color','white');
linewidth = 2;

% Plot the results for the exact solver.
subplot(1,3,1);
hold on
for j = 1:m
  plot(Lambda/n,Wexact(j,:),'k-','LineWidth',linewidth);
end
hold off
xlabel('\lambda/n');
ylabel('Regression coefficient');
title('Exact solver');
set(gca,'XMinorTick','off');
set(gca,'YMinorTick','off');
set(gca,'XLim',[Lambda(1) Lambda(end)]/n);
set(gca,'YLim',[-4 4]);
set(gca,'Box','on');

% Plot the results for the stochastic solver (1).
subplot(1,3,2);
hold on
for j = 1:m
  plot(Lambda/n,Wstoc1(j,:),'k-','LineWidth',linewidth);
end
hold off
xlabel('\lambda/n');
ylabel('Regression coefficient');
title('Stochastic solver (100 iterations)');

set(gca,'XMinorTick','off');
set(gca,'YMinorTick','off');
set(gca,'XLim',[Lambda(1) Lambda(end)]/n);
set(gca,'YLim',[-4 4]);          
set(gca,'Box','on');

% Plot the results for the stochastic solver (2).
subplot(1,3,3);
hold on
for j = 1:m
  plot(Lambda/n,Wstoc2(j,:),'k-','LineWidth',linewidth);
end
hold off
xlabel('\lambda/n');
ylabel('Regression coefficient');
title('Stochastic solver (1000 iterations)');

set(gca,'XMinorTick','off');
set(gca,'YMinorTick','off');
set(gca,'XLim',[Lambda(1) Lambda(end)]/n);
set(gca,'YLim',[-4 4]);
set(gca,'Box','on');