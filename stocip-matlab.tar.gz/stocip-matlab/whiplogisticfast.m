% An slightly clever, optimized version of the function WHIPLOGISTIC.
function [w, py] = whiplogisticfast (A, y, lambda, ns, a0, alpha)

  % Some algorithm parameters.
  verbose  = true;
  alphamax = 0.995; % Maximum step size.
  mumin    = 1e-9;  % Minimum barrier parameter.
  sigma    = 0.5;   % The centering parameter.

  % Generate the sequence of step sizes.
  a = 1 ./ ((1:ns) + a0).^alpha;

  % Get the number of samples, which we denote by n, and the number of
  % features (and regression variables), which we denote by m. Initialize
  % the primal variables x and the dual variables z.
  [n m] = size(A);
  x     = ones(2*m,1);
  z     = ones(2*m,1);
  P     = [A -A];
  
  % This will store the classification of the ith data point before
  % training on it.
  py = zeros(n,1);
  
  % Repeat for each sample to simulate.
  mu = 1;
  H  = ones(2*m,1);
  for s = 1:ns
    
    % Classify the ith data point, get the on-line estimate of the
    % gradient, and compute an averaged estimate of the Hessian.
    i     = mod(s-1,n) + 1;
    p     = P(i,:);
    u     = sigmoid(p*x);
    py(i) = u;
    g     = lambda/n - p'*(y(i) - u);
    Ht    = (u.*(1-u).*p.^2)';
    H     = ((s-1)*H + Ht)/s;
    
    % Compute the new log-barrier penalty based on the duality gap.
    mu = max(mumin,sigma*(x'*z)/(2*m));
    
    % Report the status of the algorithm.
    if verbose
      fprintf('%d (%d) ',s,i);
    end
    
    % Compute the search direction of x and z.
    S  = z./x;
    px = (mu./x - g) ./ (H + S);
    pz = mu./x - z - S.*px;

    % Determine the largest step size ensuring that x and z remain feasible.
    as  = a(s);
    xz  = [x;  z];
    pxz = [px; pz];
    is  = find(pxz < 0);
    if length(is)
      as = min(as,alphamax * min(xz(is) ./ -pxz(is)));
    end    
    
    % Move to the next point.
    x = x + as * px;
    z = z + as * pz;
  end

  if verbose
    fprintf('\n');
  end
  
  % Output the solution.
  w = x(1:m) - x(m+1:end);
