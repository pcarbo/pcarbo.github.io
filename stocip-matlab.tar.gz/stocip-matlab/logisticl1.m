% LOGISTICL1(A,Y,LAMBDA) returns the L1-regularized least squares solution
% for a binary classification problem modeled with logistic regression. See
% function LASSOIP for more information on the inputs. Y is the a vector of
% binary (0 or 1) classification outputs used to train the logistic
% regression model.

function w = logisticl1 (A, y, lambda)

  % Optimization parameters.
  verbose   = true;
  eps       = 1e-8;   % A number close to zero.
  maxiter   = 100;    % The maximum number of iterations.
  tolerance = 1e-5;   % Stopping criterion.
  sigmamax  = 0.9;    % The maximum centering parameter.
  etamax    = 0.25;   % The maximum forcing number.
  mumin     = 1e-9;   % Minimum barrier parameter.
  alphamax  = 0.995;  % Maximum step size.
  alphamin  = 1e-6;   % Minimum step size.
  beta      = 0.75;   % Granularity of backtracking search.
  tau       = 0.01;   % Amount of actual decrease we will accept in 
                      % line search.

  % Get the number of samples (n), the number of features (m), and the
  % total number of (primal-dual) variables.
  [n m] = size(A);
  nv    = 4*m;

  % Initialize the primal variables x and the dual variables z. Note that
  % the Hessian is constant and positive-definite.
  x = ones(2*m,1);
  z = ones(2*m,1);
  P = [A -A];

  if verbose
    fprintf('  i f(x)       lg(mu) sigma   ||rx||  ||rc||  alpha   #ls\n');
  end
  
  % Repeat while the convergence criterion has not been satisfied, and
  % we haven't reached the maximum number of iterations.
  alpha = 0;
  ls    = 0;
  for iter = 1:maxiter
    
    % Compute the response of the objective, the gradient of the objective,
    % the Hessian of the objective, and the responses of the unperturbed
    % Karush-Kuhn-Tucker optimality conditions.
    u       = sigmoid(P*x);
    f       = objective(y,x,u,lambda);
    g       = gradient(P,y,u,lambda);
    H       = hessian(P,u);
    [rx rc] = residual(x,z,g);
    r0      = [rx; rc]; 
    
    % Set some parameters that affect convergence of the interior-point
    % method.
    eta   = min(etamax,norm(r0)/nv);
    sigma = min(sigmamax,norm(r0)/nv);
    mu    = max(mumin,sigma*x'*z/(2*m));

    % Print the status of the algorithm.
    if verbose
      fprintf('%3d %+0.3e  %+5.2f %0.1e %0.1e %0.1e %0.1e %3d\n',...
	      iter,f,log10(mu),sigma,norm(rx),norm(rc),alpha,ls);
    end

    % CONVERGENCE CHECK.
    % If the norm of the responses is less than the specified tolerance,
    % we are done.
    if norm(r0)/nv < tolerance
      break
    end

    % SOLUTION TO PERTURBED KKT SYSTEM.
    % Compute the search direction of x and z.
    S  = diag(sparse(z./(x+eps)));
    gb = g - mu./(x+eps);
    px = (H + S) \ (-gb);
    pz = mu./(x+eps) - z - S*px;
    
    % BACKTRACKING LINE SEARCH.
    % To ensure global convergence, execute backtracking line search to
    % determine the step length. First, we have to find the largest step
    % size which ensures that x and z remain feasible. Next, we perform
    % backtracking line search.
    alpha = alphamax;
    xz    = [x; z];
    pxz   = [px; pz];
    is    = find(pxz < 0);
    if length(is)
      alpha = alphamax * min(1,min(xz(is) ./ -pxz(is)));
    end

    % Compute the response of the merit function and the directional
    % gradient at the current point and search direction.
    psi  = merit(f,x,z,mu,eps);
    dpsi = gradmerit(g,x,z,px,pz,mu,eps);

    % Repeat until we've found a step size that satisfies the sufficient
    % decrease condition.
    ls = 0;
    while true

      % Compute the candidate point.
      xnew = x + alpha * px;
      znew = z + alpha * pz;
      ls   = ls + 1;

      % Compute the response of the objective function and merit function at
      % the candidate point.
      u      = sigmoid(P*xnew);
      f      = objective(y,xnew,u,lambda);
      psinew = merit(f,xnew,znew,mu,eps);
      
      % Stop backtracking search if we've found a candidate point that
      % sufficiently decreases the norm of the residual.
      if psinew < psi + tau*eta*alpha*dpsi
	x = xnew;
	z = znew;
	break
      end
      
      % The candidate point does not meet our criteria, so decrease the step
      % size for 0 < beta < 1.
      alpha = alpha * beta;
      if alpha < alphamin
	error('Step size is too small');
      end
    end
  end

  % Output the solution.
  w = x(1:m) - x(m+1:end);

% ------------------------------------------------------------------
% Compute the response of the objective function at x.
function f = objective (y, x, u, lambda)
  f = -sum(y.*log(u) + (1-y).*log(1-u)) + lambda*sum(x);
  
% ------------------------------------------------------------------
% Compute the gradient of the objective function at x.
function g = gradient (P, y, u, lambda)
  g = -P'*(y - u) + lambda;
  
% ------------------------------------------------------------------
% Compute the Hessian of the objective at x.
function H = hessian (P, u)
  U = diag(sparse(u.*(1-u)));
  H = P'*U*P;
  
% ------------------------------------------------------------------
% Compute the residual of the unperturbed Karush-Kuhn-Tucker system.
function [rx, rc] = residual (x, z, g)
  rx = g - z;  % Dual residual.
  rc = x.*z;   % Complementarity.

% ------------------------------------------------------------------
% Compute the response of the merit function at (x,z).
function psi = merit (f, x, z, mu, eps)  
  psi = f + x'*z - mu*sum(log(x.^2.*z+eps));
  
% ------------------------------------------------------------------
% Compute the directional deriative of the merit function at (x,z).
function dpsi = gradmerit (g, x, z, px, pz, mu, eps)
  dpsi = px'*(g + z - 2*mu./(x+eps)) + pz'*(x - mu./(z+eps));
    