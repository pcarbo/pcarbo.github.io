function u = sigmoid (x)
  u = 1./(1 + exp(-x));
  