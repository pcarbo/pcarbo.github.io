% Implementation of the stochastic gradient method for a smooth,
% unconstrained approximation to the L1-regularized objective.
function W = sgsmooth (A, y, lambda, ns, a0, alpha)
  eps = 0.01;  % Small number for controlling smoothing term.

  % Generate the sequence of step sizes.
  a = 1 ./ ((1:ns) + a0).^alpha;

  % Get the number of samples, which we denote by n, and the number of
  % features (and regression variables), which we denote by m.
  [n m] = size(A);

  % Initialize the optimization variables and regression weights w.
  w = zeros(m,1);
  
  % This is storage for the sequence of iterates in the simulation.
  W = zeros(m,ns);

  % Repeat for each sample to simulate.
  for s = 1:ns
    
    % Get an on-line estimate of the gradient.
    i = mod(s-1,n) + 1;
    g = gradient(A,y,w,i);

    % Compute the gradient of the smoothed objective.
    gsmooth = g + lambda/n * w ./ (sqrt(w.^2 + eps));

    % Move in a direction opposite to that of the sub-gradient.
    w = w - a(s) * gsmooth;
    
    % Store the point.
    W(:,s) = w;
  end

% ----------------------------------------------------------------
% Compute an online estimate of the gradient of the loss function (not
% including the L1 regularization term).
function g = gradient (A, y, w, i)
  n = length(y);
  a = A(i,:);
  g = -a'*(y(i) - a*w);
