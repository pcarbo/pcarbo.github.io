% Generate the synthetic data from Example #4 of Tibshirani (1996).
function [A, y] = syntheticdata (beta, a, b, n, e)
  m = length(beta);
  v = 1./gamrnd(a,1/b,1,m);
  z = 0.9428 * randn(n,1);
  Z = repmat(sqrt(v),n,1) .* randn(n,m);
  A = Z + repmat(z,1,m);
  y = A*beta + e*randn(n,1);

