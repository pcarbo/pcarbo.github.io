********************************************************************

                MATLAB CODE FOR ON-LINE LEARNING OF 
                     LINEAR REGRESSION MODELS, 
                    LOGISTIC REGRESSION MODELS,
                        AND A SPAM FILTER

********************************************************************

Peter Carbonetto
Dept. of Computer Science
University of British Columbia
Copyright 2008

License
-------
See the file license.txt included in this software package.

Summary
-------
This software package contains all the MATLAB code that was used to
run the experiments for the research paper

   Peter Carbonetto, Mark Schmidt and Nando de Freitas (2008). An
   interior-point stochastic approximation method and an L1-
   regularized delta rule. Neural Information Processing Systems.
 
In particular, it includes MATLAB functions for learning a linear
regression (or logistic regression) model subject to L1
regularization, which serves to select only the most useful features
for regression or classification. (This model is also known in the
statistics community as the LASSO.) 

All the code was run in MATLAB version 7.3, and may or may not be
compatible with earlier versions of MATLAB.

Description of MATLAB functions
-------------------------------
Here, I briefly describe the key MATLAB functions included in this
softiware package. Use the help function in MATLAB to get more
information about these functions. Also, it will help to look at how
they are used in the experiment.m script, and to read the conference
paper in order to understand the meaning of the variables.

experiment.m - This simulated the experiments described in the
conference paper.

example.m - Short demonstration script of the on-line learning
algorithm for logistic regression.

expspam.m - Runs the SPAM filtering experiment as described in the
conference paper.

lassoip.m - Implementation of the (batch) primal-dual interior-point
method for computing the feature weights of a linear regression model
that maximizes the maximum likelihood objective or, equivalently, the
mean squared error loss function, subject to an L1 penalty.

lassoip2.m - This is the same as lassoip.m, except that I use a more
robust merit function to verify the Wolfe conditions in backtracking
line search. Generally, this function should be used.

logisticl1.m - Implementation of the (batch) primal-dual
interior-poing method for computing the maximum likelihood estimator
for logistic regression, subject to L1 regularization.

whip.m - This is the implementation of the stochastic primal-dual
interior-point method for solving the L1-regularized least squares
objective in an on-line fashion. It stands for "Widrow-Hoff
interior-point" method.

whiplogistic.m - This is the same as whip.m, except that the linear
regression model is replaced with a logistic regression.

whiplogisticfast.m - An optimized implementation of whiplogistic.m.
This function is used for learning to classify email as spam.
