% WHIP(A,Y,LAMBDA,NS,A0,ALPHA) is an on-line interior-point learning
% algorithm for linear regression subject to L1 regularization. It stands
% for "Widrow-Hoff interior-point". See the function LASSOIP for more
% information on the first three inputs. NS is the number of iterations, and
% the inputs AO and ALPHA determine the sequence of step sizes, so that the
% step size a(k) at the kth iteration is given by 1 / (k + a0)^alpha.

function W = whip (A, y, lambda, ns, a0, alpha)

  % Some algorithm parameters.
  alphamax = 0.995; % Maximum step size.
  mumin    = 1e-9;  % Minimum barrier parameter.
  eps      = 1e-8;  % A small number.
  
  % Generate the sequence of step sizes.
  a = 1 ./ ((1:ns) + a0).^alpha;

  % Get the number of samples, which we denote by n, and the number of
  % features (and regression variables), which we denote by m.
  [n m] = size(A);

  % Initialize the primal variables x and the dual variables z. Note that
  % the Hessian is constant and positive-definite.
  x = ones(2*m,1);
  z = ones(2*m,1);
  P = [A -A];
  H = speye(2*m);
  
  % This is storage for the sequence of iterates in the simulation.
  W = zeros(m,ns);

  % Repeat for each sample to simulate.
  mu = 1;
  for s = 1:ns
    
    % Get an on-line estimate of the gradient.
    i = mod(s-1,n) + 1;
    g = gradient(P,y,x,lambda,i);
    
    % Compute the new log-barrier penalty based on the duality gap.
    sigma = 0.5;
    mu    = max(mumin,sigma*x'*z/(2*m));
    
    % Compute the search direction of x and z.
    S  = spdiag(z./(x+eps));
    gb = g - mu./(x+eps);
    px = (H + S) \ (-gb);
    pz = mu./(x+eps) - z - S*px;

    % Determine the largest step size ensuring that x and z remain feasible.
    as  = a(s);
    xz  = [x;  z];
    pxz = [px; pz];
    is  = find(pxz < 0);
    if length(is)
      as = min(as,alphamax * min(xz(is) ./ -pxz(is)));
    end
    
    % Move to the next point.
    x = x + as * px;
    z = z + as * pz;
    
    % Store the point.
    wp     = x(1:m);
    wn     = x(m+1:end);
    w      = wp - wn;
    W(:,s) = w;
  end

