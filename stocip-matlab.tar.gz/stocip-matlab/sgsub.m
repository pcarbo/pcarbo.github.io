% Implementation of the stochastic subgradient method.
function W = sgsub (A, y, lambda, ns, a0, alpha)
  eps = 1e-4;  % Small number used to check whether x = 0.

  % Generate the sequence of step sizes.
  a = 1 ./ ((1:ns) + a0).^alpha;

  % Get the number of samples, which we denote by n, and the number of
  % features (and regression variables), which we denote by m.
  [n m] = size(A);

  % Initialize the optimization variables and regression weights w.
  w = zeros(m,1);
  
  % This is storage for the sequence of iterates in the simulation.
  W = zeros(m,ns);

  % Repeat for each sample to simulate.
  for s = 1:ns
    
    % Get an on-line estimate of the gradient.
    i = mod(s-1,n) + 1;
    g = gradient(A,y,w,i);

    % Compute the sub-gradient.
    gsub = zeros(m,1);
    I    = find(abs(w) > eps);
    if length(I)
      gsub(I) = g(I) + sign(w(I))*lambda/n;
    end
    
    I = find(abs(w) <= eps & g > -lambda/n);
    if length(I)
      gsub(I) = g(I) + lambda/n;
    end
    
    I = find(abs(w) <= eps & g > lambda/n);
    if length(I)
      gsub(I) = g(I) - lambda/n;
    end
    
    % Move in a direction opposite to that of the sub-gradient.
    w = w - a(s) * gsub;
    
    % Store the point.
    W(:,s) = w;
  end

% ----------------------------------------------------------------
% Compute an online estimate of the gradient of the loss function (not
% including the L1 regularization term).
function g = gradient (A, y, w, i)
  n = length(y);
  a = A(i,:);
  g = -a'*(y(i) - a*w);
