% Compute the response of the L1-regularized mean squared error objective.
function f = objective (A, y, lambda, w);
  n = size(A,1);
  f = norm(y - A*w)^2/(2*n) + lambda/n*norm(w,1);
