% Compute an on-line estimate of the gradient of the L1-regularized
% least-squares objective.
function g = gradient (P, y, x, lambda, i)
  n = length(y);
  p = P(i,:);
  g = -p'*(y(i) - p*x) + lambda/n;
