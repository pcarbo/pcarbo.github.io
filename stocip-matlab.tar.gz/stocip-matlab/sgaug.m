% Implementation of stochastic gradient with an augmented Lagrangian to
% handle constraints.
function W = sgaug (A, y, lambda, ns, a0, alpha)
  pc    = 50;   % Specifies the sequence of penalty terms.
  beta  = 0.1;  % Specifies the sequence of penalty terms.
  p0    = a0;   % Specifies the sequence of penalty terms.

  % Generate the sequence of step sizes.
  a = 1 ./ ((1:ns) + a0).^alpha;
  p = pc ./ ((1:ns) + p0).^beta;

  % Get the number of samples, which we denote by n, and the number of
  % features (and regression variables), which we denote by m.
  [n m] = size(A);

  % Initialize the optimization variables x.
  x = ones(2*m,1);
  P = [A -A];
  
  % This is storage for the sequence of iterates in the simulation.
  W = zeros(m,ns);

  % Repeat for each sample to simulate.
  for s = 1:ns
    
    % Get an on-line estimate of the gradient.
    i = mod(s-1,n) + 1;
    g = gradient(P,y,x,lambda,i);

    % Move to the next point via a stochastic gradient update.
    x = x - a(s) * (g + p(s)*max(0,x));
    
    % Store the point.
    wp     = x(1:m);
    wn     = x(m+1:end);
    w      = wp - wn;
    W(:,s) = w;
  end
