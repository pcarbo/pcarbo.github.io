% Q2 with the Gibbs sampler in which we integrate out the parameters p.

n = [10 27 17 7 1 5 6 15 9 18 16 5 7 19]; % The data.

verbose = 0;

model  = 2;          % Model type.
a      = 1;          % Beta prior.
b      = 1;          % Beta prior.
xi     = 0.1;        % Standard deviation of random walk proposal for (a,b).
I      = length(n);  % Size of data set.
ns     = 10000;      % Number of samples to generate.
burnin = 5000;
p      = zeros(1,I); % Capture probabilities.

% Get the largest capture sample.
m = max(n);

% Initialize N.
N  = sum(n);
Ns = zeros(1,ns);

% Keep track of the Metropolis-Hastings acceptance rates.
ar.N  = 0;
ar.ab = 0;

fprintf('Running Gibbs sampler...\n');
tic;
  
% Run Gibbs sampler.
for s = 1:ns
  
  % Sample p | N, a, b.
  for i = 1:I
    p(i) = betarnd(a+n(i),b+N-n(i));
  end
  
  % Sample N | p, a, b.
  % Get the probability of proposing a growth to the population.
  if N == m
    q = 1;
  else
    q = 1/2;
  end
  
  if rand < q
    
    % Propose to grow the population by 1.
    A = N/(N+1)*prod((N+1)*(1-p)./(N+1-n))...  % Ratio of posteriors.
        *((N == m)/2 + (N > m));               % Ratio of proposals.
    if rand < A
      N    = N + 1;
      ar.N = ar.N + 1;      
    end
  else
    
    % Propose to shrink the population by 1.
    A = N/(N-1)*prod((N-n)./(N*(1-p)))...      % Ratio of posteriors.
        *((N-1 == m)*2 + (N-1 > m));           % Ratio of proposals.
    if rand < A
      N    = N - 1;
      ar.N = ar.N + 1;      
    end
  end

  % If model = 2, we need to sample a new value for (a,b).
  if model == 2
    
    % Propose a move.
    ua = xi*randn;
    ub = xi*randn;
    an = a*exp(ua);
    bn = b*exp(ub);
    
    % Compute the Metropolis-Hastings acceptance probability.
    A = exp(ua+ub) ...                   % Jacobian.
        *((a+b)/(an+bn))^2 ...           % Ratio of priors.
        *((gamma(an+bn)/gamma(a+b)) ...  % Ratio of likelihoods.
          *(gamma(a)/gamma(an)) ...
          *(gamma(b)/gamma(bn)))^I ...
        *prod(p)^(an-a)*prod(1-p)^(bn-b);
    if rand < A
      a     = an;
      b     = bn;
      ar.ab = ar.ab + 1;
    end
  end
  
  % Store the sample.
  Ns(s) = N;

  if verbose
    fprintf('%i (%i) ', s, N);
  end
end
fprintf('\n');
fprintf('The Gibbs sampler took %i seconds.\n', round(toc));

fprintf('The M-H acceptance rate for N:   %0.3f.\n', ar.N/ns);
if model == 2
  fprintf('The M-H acceptance rate for a,b: %0.3f.\n', ar.ab/ns);
end

Nsb = Ns(burnin+1:ns);

fprintf('The mean population size:       %i.\n', round(mean(Nsb)));
fprintf('The STD of the population size: %i.\n', round(std(Nsb)));

set(gcf,'MenuBar','figure');
set(gcf,'NumberTitle','off');
set(gcf,'Name','Estimated mixture density');
set(gcf,'Color','white');
clf
margin = 0.06;
A1 = subplot('position',[[0.0 0.1]+margin  [0.5 0.9]-margin*2]);
A2 = subplot('position',[[0.5 0.1]+margin  [0.5 0.9]-margin*2]);

% Plot a histogram of the data points.
axes(A1);
[H x] = hist(Nsb,min(Nsb):max(Nsb));
c = [102 102 255]/255;
bar(x,H,1,'EdgeColor',c,'FaceColor',c);
set(gca,'YColor','white');
set(gca,'XColor','black');
set(gca,'Box','off');
set(gca,'YTick',[]);
set(gca,'XLim',[-0.5+min(Nsb) max(Nsb)+0.5]);
xlabel('N','Color','black');
ylabel('\pi(N)      ','Rotation',0,'Color','black');

% Plot the evolution of the population size over time.
axes(A2);
plot(burnin+1:ns,Nsb,'r-');
xlabel('time');
ylabel('N   ','Rotation',0);
