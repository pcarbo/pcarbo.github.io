function x = betarnd (a, b)
  
  x1 = gengamma(a,1);
  x2 = gengamma(b,1);

  x = x1 / (x1+x2);
  