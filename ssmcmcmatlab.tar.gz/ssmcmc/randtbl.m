% RANDTBL   Generate a random sample from a piecewise uniform
%           probability table.
%   X = RANDTBL(P,M,N) returns an M x N matrix of samples X from the
%   unnormalised probability table P. P is a 1 x C table where C
%   is the number of classes. P essentially acts as the probability 
%   density function for X. The default values for M and N are 1.
%
%   X = RANDTBL(P,N) returns an M x N matrix of samples X. P is an M x C
%   matrix of probability tables. Row m of P is the unnormalized
%   probability table for the corresponding row of samples X. By default,
%   N is 1.

function X = randtbl (P, varargin)

  % Figure out what the parameters P, M and N are.
  m = size(P,1);
  if m == 1
    [m n] = managevargs(varargin, {1 1});
    P     = repmat(P, [m 1]);
  else
    n = managevargs(varargin, {1});
  end

  % Get the number of classes.
  C = size(P,2);

  % Normalise the probability table.
  P = P ./ repmat(sum(P,2), [1 C]);

  % Create the CDF for the distribution. P now acts as the upper
  % bound for the piecewise distribution.
  P = cumsum(P,2);
  
  LB = repmat([zeros(m,1) P(:,1:C-1)]', [1 1 n]);
  UB = repmat(P', [1 1 n]);
  
  % Get the uniform random integers.
  U = repmat(rand(1,m,n), [C 1 1]);  
  X = reshape(sum((LB <= U & U < UB) .* repmat([1:C]', [1 m n])), ...
              [m n]);
  