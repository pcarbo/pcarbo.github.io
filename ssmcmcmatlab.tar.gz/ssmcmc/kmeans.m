% [C, M] = KMEANS2(X,K,D) Run the K-means algorithm. X an F x N matrix of
% data points, where F is the dimension of the sample space and N is the
% number of points. K is the number of k-means clusters and D is the
% distance function (see DIST2 for more information). The return value C is
% an F x K matrix of cluster centres. M describes the cluster membership for
% each data point.

function [C, M] = kmeans (X, k, d)

  tol = 1e-10;

  % Function constants.
  infty = 1e99;

  % Get the number of data points.
  n = size(X,2);

  % Check to see if there are more centres than data points.
  if n < k,
    error('More centres than data points');
  end;
  
  % Initialise the cluster centres "C" by selecting "k" data
  % points at random. "C" is a f x k matrix of cluster centres. 
  R = randperm(n);
  C = X(:,R(1:k));
  
  % Run k-means. Repeat until we've hit the specified tolerance
  % or maximum number of iterations.
  i = 0;
  e = infty;
  while 1,
      
    % Save the old error.
    olde = e;
      
    % Calculate the distances between the points and the centres.
    D = feval(d,X,C);

    % Assign each point to the nearest centre. "M" describes the
    % cluster membership for each data point. "minD" is the
    % distance to the nearest cluster for each data point.
    [minD M] = min(D);
      
    % Make sure that each cluster index is represented at least
    % once. If not, steal the closest point from the cluster centre
    % that has more than one point. There will always be at least
    % one cluster centre like this.
    for ki = 1:k,
      Mi = find(M == ki);
      if ~length(Mi),
        
        % Get the minimum distance from a point to this cluster
        % centre, then find all the points that obey that
        % distance. 
        mind = min(D(ki,:));
        is   = find(D(ki,:) == mind);
        
        % Steal a point such that its current cluster contains more
        % than one point.
        for i = is,
          if sum(M == M(i)) > 1,
            M(i) = ki;
            break;
          end;
        end;
      end;
    end;
    
    % Adjust centres to the average of the member points. 
    for ki = 1:k,
      Mi      = find(M == ki);
      C(:,ki) = sum(X(:,Mi),2) / length(Mi);
    end;
      
    % Compute the new error and check to see if we should stop
    % based on the tolerance.
    e = sum(minD);
    if (olde - e) <= tol,
      break;
    end;
  end;
