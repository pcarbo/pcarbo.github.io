function model = ssmcmctrainhard (X, Y, L, balls, docs, f, K, lambda, ...
				  mu, nu, mua, nua, epsilon, a, b, ...
                                  nc1, nc2, s)

  % Get the number of data points.
  N = size(X,2);
  
  % Normalize the data.
  smean = mean(X,2);
  sstd  = std(X',1)';
  X     = normalizedata(X, smean, sstd);
  
  % Get the sets of data points with the positive class, negative
  % class, or question mark.
  yk1 = find(Y(docs) == 1);
  yk2 = find(Y(docs) == 2);
  yu  = find(~Y);
  
  % Get the RBF centres. C is an F x K matrix where F is the number
  % of features and K is the number of RBF centres.
  C = X;
  k = N;

  % Initialise the samples. Initialise gamma by running k-means, and
  % sampling randomly from each cluster. 
  [g gf] = initgamma(f,C,k,a,b);
  ng     = length(gf);
  maxng  = ng;

  % Compute some matrices deriving from psi.
  %   G   The Gram matrix.
  %   S   The (unscaled) covariance prior.
  %   A   Psi' x 1
  Psi = kernelmatrix(f,K,C,X,lambda,gf);
  G   = Psi'*Psi;
  S   = gprior(G,epsilon);
  
  % Initialise the rest of the unobserved variables.
  delta = initdelta(mu,nu);
  beta  = initbeta(S,delta);
  
  % Initialise the z samples. We have to ensure from the start that
  % the z's follow the constraints.
  z = initz(N,L,balls,yk1,yk2,yu,nc1,nc2,Psi,beta);

  % Reserve storage for the samples gamma and beta.
  Beta = zeros(maxng,s);
  Gf   = zeros(maxng,s);
  Ng   = zeros(1,s);
  
  % Repeat for each sample.
  fprintf('Running MCMC algorithm.\n');
  fprintf(['The number enclosed in the parentheses is the number of ' ...
           'active basis functions.\n']);
  fprintf('0 (%i) ', ng);
  for si = 1:s

    % Sample gamma.
    [ng g gf Psi G S Q Az] = ...
	samplegammagibbs(f,K,C,X,lambda,epsilon,k,g,gf,...
			 a,b,Psi,G,S,delta,z);

    % Sample alpha.
    aratio = samplealpha(N,epsilon,mua,nua,G,Q,Az,delta,z);
    
    % Sample beta.
    beta = samplebeta(Q,Az,aratio);
    
    % Sample delta.
    delta = inv(gengamma(0.5*(mu+ng),...
            0.5*(nu+beta'*(G+epsilon*eye(ng))*beta)));
    
    % Sample the z's.
    z = samplez(N,L,balls,yk1,yk2,yu,nc1,nc2,Psi,beta,z);
    
    fprintf('%i (%i) ',si,ng);

    % Store the samples.
    if ng > maxng
      Beta  = [Beta; zeros(ng-maxng,s)];
      Gf    = [Gf; zeros(ng-maxng,s)];
      maxng = ng;
    end
    Beta(1:ng,si) = beta;
    Gf(1:ng,si)   = gf;
    Ng(si)        = ng;
  end
    
  % Return the model and save it, if requested.
  model = returnmodel(Beta,Gf,Ng,C,lambda,f,K,smean,sstd);
  
% -------------------------------------------------------------------
function model = returnmodel (Beta, Gf, Ng, C, lambda, f, K, ...
                              mean, std, s)
  model.Beta   = Beta;
  model.Gf     = Gf;
  model.Ng     = Ng;
  model.C      = C;
  model.lambda = lambda;
  model.f      = f;
  model.K      = K;
  model.mean   = mean;
  model.std    = std;
  
% -------------------------------------------------------------------
function Psi = kernelmatrix (f, K, C, X, lambda, gf)
  Psi = feval(K,feval(f,C(:,gf),X),lambda);
  
% -------------------------------------------------------------------
function psi = kernelcol (f, K, C, X, lambda, i)
  psi = feval(K,feval(f,C(:,i),X),lambda);
  
% -------------------------------------------------------------------
function S = gprior (G, epsilon)
  ng = size(G,1);
  S  = inv(G + epsilon*eye(ng));

% -------------------------------------------------------------------
function [g, gf] = initgamma (f, C, k, a, b)

  tau = a/(a+b);
  ng  = round(k*tau);
  g   = zeros(k,1);
  gf  = [];
  if ng
    
    % If there is at least one active kernel, run k-means then
    % repeat for each cluster, randomly selecting a single kernel.
    fprintf('Running kmeans.\n');
    [ans M] = kmeans(C,ng,f);
    for i = 1:ng
      f    = find(M == i);
      j    = f(randint(1,length(f)));
      g(j) = 1;
      gf   = [gf; j];
    end
  else

    % Upon initialisation, we require there to be at least one
    % active kernel. We choose the first one.
    g(1) = 1;
    gf   = 1;
  end

% -------------------------------------------------------------------
function delta = initdelta (mu, nu)
  delta  = mu/(nu+1);  

% -------------------------------------------------------------------
function beta = initbeta (S, delta)
  ng    = size(S,1);
  beta  = sqrt(delta)*chol(S)'*randn(ng,1);

% -------------------------------------------------------------------
function z = initz (N, L, balls, yk1, yk2, yu, nc1, nc2, Psi, beta)

  psiB = Psi*beta;
  z    = zeros(N,1);
  
  % Sample the known z's.
  z = samplekzs(yk1,yk2,psiB,z);

  % Sample the unknown z's.
  z = inituzs(L,balls,yu,nc1,nc2,psiB,z);
  
% -------------------------------------------------------------------
function z = inituzs (L, balls, yu, nc1, nc2, psiB, z)

  % The z's from the unknown y's are not sampled in a very
  % intelligent fashion. Repeat for each unlabelled document. 
  nct = nc1 + nc2;
  for di = yu
      
    % Get the set of data points in the document.
    li = L(di);
    is = balls(di,1:li);
    is = is(randperm(li));
    
    % We cannot apply the constraints when there are not enough
    % data points in the document, so we sample the z's
    % independently.  
    if li < nc1 + nc2
      
      % Sample z's independently.
      z(is) = psiB(is) + randn(li,1);
    else
      
      % Sample z's indepedently, keeping in mind the constraints. 
      z(is(1:nc1))     = randntl(psiB(is(1:nc1)),1,0);
      z(is(1+nc1:nct)) = randntr(psiB(is(1+nc1:nct)),1,0);
      z(is(1+nct:li))  = psiB(is(1+nct:li)) + randn(li-nct,1);
    end
  end

% -------------------------------------------------------------------
% Sample the gammas using a Metropolised Gibbs sampler.
function [ng, g, gf, Psi, G, S, Q, Az] = ...
    samplegammagibbs (f, K, C, X, lambda, epsilon, k, g, gf, ...
                      a, b, Psi, G, S, delta, z)

  N  = length(z);
  ng = size(G,1);
  
  % We compute a few values invariant over the sampling algorithm. 
  %   Q   Defined in the paper.
  %   sz  Z' x 1
  %   Az  Psi' x Z
  v  = (1+delta)/delta;
  Q  = inv(v*G+epsilon/delta*eye(ng));
  Az = Psi'*z;

  % Repeat for each kernel in a random order.
  for i = randperm(k)
    if g(i)
      
      % Conduct a death move.
      % Compute the proposal probability.
      q = (k-ng+b)/(k+a+b-1);
      
      % Sample from the proposal.
      if (rand < q) & (ng > 1)
            
        % Find the kernel "i" and the kernels that are not "i".
        j  = find(gf == i);
        nj = [1:j-1 j+1:ng];
        
        % Compute some values.
        %   Ak0   Psi0' x psi
        %   az    psi' x Z
        psi    = Psi(:,j);
        Ak0    = G(nj,j);
        az     = Az(j);
        Az0    = Az(nj);
        zeta   = S(j,j);
        xi     = Q(j,j);
        V      = Q(nj,j);
        Q0     = Q(nj,nj) - V*V'/xi;
        x      = az - v*(Az0'*Q0*Ak0);
        alphar = sqrt(delta*zeta/xi*exp(-xi*x^2));

        if rand < min(1,alphar)
          g(i) = 0; 
          gf   = gf(nj);
          ng   = ng - 1;
          Psi  = Psi(:,nj);
          Az   = Az0;
          G    = G(nj,nj);
          V    = S(nj,j);
          S    = S(nj,nj) - V*V'/zeta;
          Q    = Q0;
        end
      end
    else
          
      % Conduct a birth move.
      % Compute the proposal probability.
      q = (ng+a)/(k+a+b-1);
          
      % Sample from the proposal.
      if rand < q
        
        % Compute some values.
        %   ak   psi' x psi
        %   Ak   Psi' x psi
        %   az   psi' x Z
        %   SAk  S x Ak
        %   QAk  Q x Ak
        psi    = kernelcol(f,K,C,X,lambda,i);
        ak     = psi'*psi;
        Ak     = Psi'*psi;
        az     = psi'*z;
        SAk    = S*Ak;
        QAk    = Q*Ak;
        zeta   = 1/(epsilon + ak - Ak'*SAk);
        xi     = 1/(epsilon/delta + v*(ak - v*(Ak'*QAk)));
        x      = az - v*(Az'*QAk);
        alphar = sqrt(xi/(delta*zeta)*exp(xi*x^2));
              
        if rand < min(1,alphar)
          g(i) = 1;
          gf   = [gf; i];
          ng   = ng + 1;  
          Psi  = [Psi psi];
          G    = [G Ak; Ak' ak];
          Az   = [Az; az];
          V    = zeta*SAk;
          S    = [S+V*SAk' -V; -V' zeta];
          V    = v*xi*QAk;
          Q    = [Q+v*V*QAk' -V; -V' xi];
        end
      end 
    end
  end

% -------------------------------------------------------------------
function aratio = samplealpha (N, epsilon, mua, nua, G, Q, Az, delta, z)

  ng = size(G,1);

  % Sample alpha0.
  alpha0 = inv(gengamma(0.5*(mua+1), 0.5*nua));
  
  % Sample alpha.
  Q2    = (2*delta)*inv((2*delta+1)*G + epsilon*eye(ng));
  x     = z'*z + Az'*(Q-2*Q2)*Az;
  alpha = inv(gengamma(0.5*(N+mua+1), 0.5*(nua + alpha0*x)));

  % Compute the ratio.
  aratio = sqrt(alpha0/alpha);

% -------------------------------------------------------------------
function beta = samplebeta (Q, Az, aratio)

  ng   = size(Q,1);
  beta = aratio*Q*Az + chol(Q)'*randn(ng,1);
  
% -------------------------------------------------------------------
function z = samplez (N, L, balls, yk1, yk2, yu, nc1, nc2, Psi, beta, z)

    psiB = Psi*beta;
    z    = samplekzs(yk1,yk2,psiB,z);
    z    = sampleuzs(L,balls,yu,nc1,nc2,psiB,z);
    
% -------------------------------------------------------------------
function z = samplekzs (yk1, yk2, psiB, z)
  
  % Sample z from known labels. 
  if length(yk1)
    z(yk1) = randntl(psiB(yk1),1,0);
  end
  
  if length(yk2)
    z(yk2) = randntr(psiB(yk2),1,0);
  end
  
% -------------------------------------------------------------------
function z = sampleuzs (L, balls, yu, nc1, nc2, psiB, z)

  nct = nc1 + nc2;

  % Sample z from unknown labels with constraints. We use Gibbs
  % sampling, so we are sampling from the conditionals of the
  % z's. Repeat for each unlabelled document.  
  for di = yu
      
    % Get the set of data points in the document.
    li = L(di);
    is = balls(di,1:li);
    R  = randperm(li);
    is = is(R);
    
    % When the number of data points is greater than or equal to
    % the number of constraints, we perform Gibbs sampling. 
    % Otherwise, we cannot apply the constraints so we sample the
    % z's independently. 
    if li < nct
      
      % Sample z's independently.
      z(is) = psiB(is) + randn(li,1);
    else
      
      % Perform Gibbs sampling. Repeat for each data point in the
      % document.
      np = sum(z(is) > 0);
      for i = is

        % We have three situations:
        %  1. We do not meet the positive constraint, so sample
        %     from a Normal distribution truncated to the left at 0.  
        %  2. We do not meet the negative constraint, so sample
        %     from a Normal distribution truncated to the right at 0. 
        %  3. The two cases above do not apply, so sample from a
        %     Normal distribution.
        %
        % Do not count the current "z" in the sum of positives or
        % negatives. 
        np = np - (z(i) > 0);
        if np < nc1
          z(i) = randntl(psiB(i),1,0);
          np   = np + 1; 
        elseif li-np-1 < nc2
          z(i) = randntr(psiB(i),1,0);
        else
          z(i) = psiB(i) + randn;
          np   = np + (z(i) > 0);
        end
      end
    end
  end
