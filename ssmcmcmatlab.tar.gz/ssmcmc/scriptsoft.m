% Small script for running the MCMC algorithm for simulating the
% semi-supervised classification model using "soft" data association
% constraints, as described in:
%
%   * Hendrik Kueck and Nando de Freitas. Learning to Classify
%     Individuals Based on Group Statistics. Conference on Uncertainty
%     in Artificial Intelligence, 2005.
%
%   * Peter Carbonetto, Gyuri Dorko and Cordelia Schmid. Bayesian
%     learning for weakly supervised object classification. Technical
%     Report, INRIA Rhone-Alpes, July 2004.
%
% Note that this model can be somewhat fragile, and occasionally the MCMC
% algorithm will fail due to a matrix that is not positive definite.
%
% All the code contained in this directory is free for non-profit
% use. Distribution of this code, for profit or otherwise, requires
% express permission from the author.
%
%     Peter Carbonetto
%     University of British Columbia
%     http://www.cs.ubc.ca/~pcarbo
%
% Some of the code included in this package was written from the Matlab
% Econometrics Library (James P. Lesage) and Arnaud Doucet.
clear

% Files.
createdata = 0;
mdatafile  = 'data.mat';
          
% Data parameters.
py  = [0.0 0.3];
px  = [1 1];
sig = 0.01;
M   = 16;
L   = [10 15 20];
D   = [8 8];
F   = 2;

% Testing parameters.
dbint  = 0.025;

% Model and simulation parameters. Most of these parameters are described
% in detail in the technical report. 
%   - f is the distance function. See DIST2 for more information. It must
%     be a metric.
%   - K is the kernel function. See KGAUSSIAN for more information. It
%     must be monotonically decreasing with distance (i.e. converts the
%     distance into a similarity).
%   - lambda is the scale or width of the kernel function.
%   - m is the user's estimate of the average fraction of positive 
%     (class 1) in each document. chi is approximately the confidence in
%     these guesses. See the paper by Kuck and de Freitas (2005) to get a
%     better sense of what these parameters mean. 
%   - s is the number of samples to generate.
f          = 'dist2';
K          = 'kgaussian';
mu         = 0.01;
nu         = 0.01;
mua        = 0.01;
nua        = 0.01;
epsilon    = 0.025;
a          = 1.0;
b          = 5.0;
lambda     = 10;
m          = 0.6;
chi        = 500;
s          = 250;

% Do not edit anything after the dotted line.
% -------------------------------------------------------------------
if createdata

  % Create the data. If necessary, save the data to disk.
  fprintf('Creating data. \n');
  data = createbindata(py,px,sig,M,L,D,F,nc);
  
  fprintf('Saving data to disk. \n');
  save(mdatafile, 'data');
else
  
  % Load the data from disk.
  fprintf('Loading data from disk. \n');
  load(mdatafile);
  F = size(data.train.X,1);
  N = data.train.N;
end

% Set properties of the figure.
clf
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','Semi-supervised classification experiment');
set(gcf,'Color','white');

if F == 2

  % Plot the data.
  D   = data.train;
  D.X = normalizedata(D.X,mean(data.train.X,2),std(data.train.X',1)');

  subplot(2,2,1);
  plotbindata(D);
  title('Training data');
  set(gca,'YTick',[]);
  set(gca,'XTick',[]);
  set(gca,'Box','on');
  clear D
end
drawnow

% Train the model.
fprintf('Training the model.\n');
tic;
model = trainmodel(data.train,'ssmcmctrainsoft',f,K,lambda,mu,nu,...
		   mua,nua,epsilon,a,b,m,chi,s);
t = toc;
fprintf('Training took %0.2f seconds.\n', t);

% Get the label predictions.
fprintf('Evaluating on training and test sets.\n');
pytrain = testmodel(data.train,'ssmcmctest',model,0,-1,1);
pytest  = testmodel(data.test,'ssmcmctest',model,0,-1,1);

% Evaluate the model on the training and test data.
fprintf('Plotting ROC curves.\n');
subplot(2,2,3);
Rtrain = evaluateresults(data.train.y, pytrain);
title('ROC curve - training data');
set(gca,'XTick',[0 1/2 1]);
set(gca,'YTick',[0 1/2 1]);

subplot(2,2,4);
Rtest = evaluateresults(data.test.y, pytest);
title('ROC curve - test data');
set(gca,'XTick',[0 1/2 1]);
set(gca,'YTick',[0 1/2 1]);
drawnow

if F == 2
   
  % Plot the decision boundary.
  % Get the max and min of the data points.
  ds    = data.train;
  x1max = max(ds.X(1,:)) + 10*dbint;
  x1min = min(ds.X(1,:)) - 10*dbint;
  x2max = max(ds.X(2,:)) + 10*dbint;
  x2min = min(ds.X(2,:)) - 10*dbint;
  
  % Compute the prediction over a grid of points.
  [X1 X2] = meshgrid(x1min:dbint:x1max, x2min:dbint:x2max);
  X       = [reshape(X1, [1 prod(size(X1))]);
	     reshape(X2, [1 prod(size(X2))])];
  pydb    = feval('ssmcmctest',X,model,0,-1,1);
  clear X X1 X2 ds

  fprintf('Plotting decision boundary.\n');
  subplot(2,2,2);
  plotdecisionbndry(dbint, x1min, x1max, x2min, x2max, ...
		    data.train, pydb);
  title('Decision boundary, p(y=1)');
  set(gca,'XTick',[]);
  set(gca,'YTick',[]);
  clear x1min x1max x2min x2max pydb
end

% See how well the lambdas (the estimated number of positives per
% document) approximate the true number of positives per document.
fprintf(['Comparison of the true and estimated number of positives per ' ...
         'document.\n']); 
fprintf('  #   true    est.\n');
for d = find(data.train.Y == 0)
  l  = data.train.L(d);
  is = data.train.balls(d,1:l);
  fprintf('%3i   %.3f   %.3f \n', d, ...
	  sum(data.train.y(is) == 1)/l, ...
	  sum(pytrain(1,is))/l);
end

