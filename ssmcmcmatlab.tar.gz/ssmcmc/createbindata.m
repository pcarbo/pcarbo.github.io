% CREATEBINDATA - Create simulated data for semi-supervised
%                 binary classification.  
%   CREATEBINDATA(PY,PX,SIG,M,L,D) returns a struct containing the
%   data. The entries of this struct are described below. The input
%   to the function is:
%     - PY is a 1 x 2 matrix where entry P(c) is the normalised
%       probability that a document will be labelled by class
%       c. The probability that a document will not have a label is 
%       1 - (PY(1) + PY(2)).
%     - PX is a 1 x 2 matrix where entry PX(c) is the unnormalised
%       probability that class c will occur in an unlabelled
%       document.  
%     - SIG is the variance of the data.
%     - M is the total number of modes in the two classes.
%     - L is a 1 x 3 vector where L(1) is the minimum number of
%       data points in a document, L(3) is the maximum number and
%       L(2) is the mean.
%     - D is a 1 x 2 matrix describing the number of documents to
%       put in the training and test sets.
%     - F is the dimension of the data.
%     - NC is a 1 x 2 matrix describing the constraints on the
%       unlabelled documents, such that NC(1) declares how many
%       positive examples must exist in a single unlabelled
%       document. Likewide, NC(2) is for the negative class.
%
%   The return value is a struct with data set entries "train" and
%   "test". Each data set contains the following fields:
%     - d      The number of documents.
%     - N      The number of data points.
%     - L      1 x d vector of data point counts for each
%              document. 
%     - Y      The document labels. 0 indicates that there is no
%              label. 
%     - X      F x N matrix of data points where F is the dimension 
%              of the data points.
%     - y      1 x N vector of true labels for the data points.
%     - docs   1 x N vector describing the document containing each 
%              data point.
%     - balls  d x n matrix, where row i lists all the data point
%              indices contained in document i. n is the maximum
%              number of data points contained in a single
%              document. 

function data = createbindata (py, px, sig, M, l, d, f, nc)

  % Normalise the class probabilities for the data points.
  px = px / sum(px);

  % What we're going to do is generate data points from mixtures of 
  % Gaussians. The parameter "M" will tell us how many modes to
  % generate from, and "sig" details the variance of these modes. 
  % First, find out how many modes we need per class. "M" is the
  % total number of modes, while "m" is the number of modes for
  % each class. 
  x = min(M-1,max(1,round(M*(py(1)+(1-sum(py))*px(1)))));
  m = [x M-x];

  % Randomly generate the modes for each class. The means are
  % generated in the space of the (-1,1) hypercube.
  mu = 2*rand(f,M) - 1;

  % Generate the data sets.
  data.train = generatedata(f,py,px,M,mu,sig,m,d(1),l,nc);
  data.test  = generatedata(f,py,px,M,mu,sig,m,d(2),l,nc);
  
% -----------------------------------------------------------------
% Create a data set. "d" is the number of documents to generate. 
% "M" is the total number of means. "mu" is the f x M matrix of
% means, where f is the dimension. "sig" is the variance. "m" is 
% 1 x 2 matrix describing how many modes there are for each class. 
function ds = generatedata (f, py, px, M, mu, sig, m, d, l, nc)

  % "d" is the number of documents.
  ds.d = d;

  % Generate:
  %   1. The document labels.
  %   2. The sizes of each document; i.e. the number of data
  %      points. 
  %   3. The total number of data points.
  ds.Y = randtbl([1-sum(py) py],1,d) - 1;
  ds.L = round(randntra(repmat(l(2),[d 1]),(l(3)-l(1))/4,...
                        l(1),l(3)));
  ds.N = sum(ds.L);
  
  % Generate:
  %   1. The document each data point is in.
  %   2. The data point labels for each document.
  %   3. The location in "f" dimensional space for each data point. 
  ds.docs  = zeros(1,ds.N);
  ds.balls = zeros(d,max(ds.L));
  ds.y     = zeros(1,ds.N);
  i = 1;
  for di = 1:d,
    li = ds.L(di);
    is = i:i+li-1;
    ds.docs(is) = di;
    ds.balls(di,1:li) = is;
    if ds.Y(di),
      ds.y(is) = ds.Y(di);
    else,
      % Sample the labels for the data points randomly, but make
      % sure that at least a certain number of labels are positive
      % (1) and a certain number are negative (2).
      r                     = randperm(li);
      y                     = zeros(1,li);
      y(r(1:nc(1)))         = 1;
      y(r(nc(1)+1:sum(nc))) = 2;
      y(r(sum(nc)+1:li))    = randtbl(px,1,li-sum(nc));
      ds.y(is) = y;
    end;
    i = i + li;
  end;
  ds.X = mu(:,(ds.y == 1).*randint(1,m(1),1,ds.N) + ...
              (ds.y == 2).*randint(m(1)+1,m(2),1,ds.N)) ...
         + sqrt(sig)*randn(f,ds.N);  
  