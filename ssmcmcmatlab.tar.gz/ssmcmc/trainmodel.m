% TRAINMODEL   Train classification model.
%   TRAINMODEL(DS,F,...) trains a model using function F and data
%   set DS and further optional parameters. It returns a struct
%   containing the model information.

function model = trainmodel (ds, f, varargin)

  % Train the model.
  model = feval(f,ds.X,ds.Y,ds.L,ds.balls,ds.docs,varargin{:});