% RANDNTR   Right-truncated Normal samples using Robert'95 algorithm.
%   RANDNTR(MU,SIG,B) generates an M x 1 matrix of random 
%   samples from the one-dimensional Normal distribution where M is 
%   the length of MU. MU is a M x 1 vector of means and the 
%   variance is either a scalar or M x 1 vector SIG. The samples
%   are bounded above by B. B is either a scalar or a M x 1 vector
%   of truncation points. 

function [X, nrej] = randntr (mu, sig, b)
  [X nrej] = randntl(-mu,sig,-b);
  X = -X;