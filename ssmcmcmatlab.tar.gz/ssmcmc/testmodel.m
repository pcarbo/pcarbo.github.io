% TESTMODEL   Use the trained model to predict labels.
%   TESTMODEL(DS,F,MODEL,...) returns a 1 x N vector of binary
%   labels, where N is the number of data points in the data
%   set. DS is the data set (see function CREATEBINDATA for more
%   information), F is the function to call for predicting the
%   labels and MODEL a struct containing the trained model (see 
%   function TRAINMODEL for more information). F may require
%   parameters.

function py = testmodel (ds, f, model, burnin, cutoff, sp, varargin)

  % Test the model.
  py = feval(f, ds.X, model, burnin, cutoff, sp, varargin{:});