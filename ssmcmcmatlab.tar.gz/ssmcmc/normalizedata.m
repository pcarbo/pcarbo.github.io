function X = normalizedata (X, mean, std)

  N = size(X,2);
  X = (X - repmat(mean, [1 N])) ./ repmat(std, [1 N]);

