% Small script for running the MCMC algorithm for simulating the
% semi-supervised classification model using hard data association
% constraints, as described in:
%  
%   * Peter Carbonetto, Gyuri Dorko and Cordelia Schmid. Bayesian
%     learning for weakly supervised object classification. Technical
%     Report, INRIA Rhone-Alpes, July 2004.
%
%   * Hendrik Kuck, Peter Carbonetto and Nando de Freitas. A Constrained 
%     Semi-Supervised Learning Approach to Data Association. European
%     Conference on Computer Vision, May 2004.
%
% All the code contained in this directory is free for non-profit
% use. Distribution of this code, for profit or otherwise, requires
% express permission from the author.
%
%     Peter Carbonetto
%     University of British Columbia
%     http://www.cs.ubc.ca/~pcarbo
%
% Some of the code included in this package was written from the Matlab
% Econometrics Library (James P. Lesage) and Arnaud Doucet.
clear

% Files.
mdatafile  = 'data.mat';
createdata = 0;
          
% Data parameters. See CREATEBINDATA for more information on these
% variables.
py  = [0.0 0.3];
px  = [1 1];
sig = 0.01;
M   = 16;
L   = [10 15 20];
D   = [8 8];
F   = 2;           
nc  = [4 0];        

% Testing parameters.
dbint = 0.025;

% Model and simulation parameters. Most of these parameters are described
% in detail in the technical report. 
%   - f is the distance function. See DIST2 for more information. It must
%     be a metric.
%   - K is the kernel function. See KGAUSSIAN for more information. It
%     must be monotonically decreasing with distance (i.e. converts the
%     distance into a similarity).
%   - lambda is the scale or width of the kernel function.
%   - nc1 and nc2 are the constraints on the number of instances of class
%     1 and class 2, respectively, in each document. Note that here we
%     need constraints on the number of instances of class 1 since all
%     the class 1 data is unlabeled (without any constraints, the
%     posterior would be equal to the prior).
%   - s is the number of samples to generate.
f        = 'dist2';
K        = 'kgaussian';
mu       = 0.01;
nu       = 0.01;
mua      = 0.01;
nua      = 0.01;
epsilon  = 0.01;
a        = 1.0;
b        = 5.0;
lambda   = 5;
nc1      = 10;
nc2      = 0;
s        = 250;

% Do not edit anything after the dotted line.
% -------------------------------------------------------------------
if createdata

  % Create the data. If necessary, save the data to disk.
  fprintf('Creating data. \n');
  data = createbindata(py,px,sig,M,L,D,F,nc);
  
  fprintf('Saving data to disk. \n');
  save(mdatafile, 'data');
else
  
  % Load the data from disk.
  fprintf('Loading data from disk. \n');
  load(mdatafile);
  F = size(data.train.X,1);
  N = data.train.N;
end

% Set properties of the figure.
clf
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','Semi-supervised classification experiment');
set(gcf,'Color','white');

if F == 2

  % Plot the data.
  D   = data.train;
  D.X = normalizedata(D.X,mean(data.train.X,2),std(data.train.X',1)');

  subplot(2,2,1);
  plotbindata(D);
  title('Training data');
  set(gca,'YTick',[]);
  set(gca,'XTick',[]);
  set(gca,'Box','on');
  clear D
end
drawnow

% Train the model.
fprintf('Training the model.\n');
tic;
model = trainmodel(data.train,'ssmcmctrainhard',f,K,lambda,mu,nu,...
		   mua,nua,epsilon,a,b,nc1,nc2,s);
fprintf('Training took %0.2f seconds.\n', toc);

% Get the label predictions.
fprintf('Evaluating on training and test sets.\n');
pytrain = testmodel(data.train,'ssmcmctest',model,0,-1,1);      
pytest  = testmodel(data.test,'ssmcmctest',model,0,-1,1);      

% Evaluate the model on the training and test data.
fprintf('Plotting ROC curves.\n');
subplot(2,2,3);
Rtrain = evaluateresults(data.train.y, pytrain);
title('ROC curve - training data');
set(gca,'XTick',[0 1/2 1]);
set(gca,'YTick',[0 1/2 1]);

subplot(2,2,4);
Rtest = evaluateresults(data.test.y, pytest);
title('ROC curve - test data');
set(gca,'XTick',[0 1/2 1]);
set(gca,'YTick',[0 1/2 1]);
drawnow

if F == 2
   
  % Plot the decision boundary.
  % Get the max and min of the data points.
  ds    = data.train;
  x1max = max(ds.X(1,:)) + 10*dbint;
  x1min = min(ds.X(1,:)) - 10*dbint;
  x2max = max(ds.X(2,:)) + 10*dbint;
  x2min = min(ds.X(2,:)) - 10*dbint;
  
  % Compute the prediction over a grid of points.
  [X1 X2] = meshgrid(x1min:dbint:x1max, x2min:dbint:x2max);
  X       = [reshape(X1, [1 prod(size(X1))]);
	     reshape(X2, [1 prod(size(X2))])];
  pydb    = feval('ssmcmctest',X,model,0,-1,1);
  clear X X1 X2 ds

  fprintf('Plotting decision boundary.\n');
  subplot(2,2,2);
  plotdecisionbndry(dbint, x1min, x1max, x2min, x2max, ...
		    data.train, pydb);
  title('Decision boundary, p(y=1)');
  set(gca,'XTick',[]);
  set(gca,'YTick',[]);
  clear x1min x1max x2min x2max pydb
end
