% EVALUATERESULTS   Plot an ROC curve.
%   EVALUATERESULTS(Y,PY) plots the ROC curve for 1 x N labels Y
%   and 2 x N probabilities PY of binary class predictions. The
%   return value is a 2 x T matrix, where T is the number of
%   intervals to check. The first row of R is the percentage of
%   false positives and the second row is the percentage of correct 
%   positives.

function R = evaluateresults (y, py)

  % Function constants.
  int = 0.01;
  
  % Reserve storage for the results.
  T  = 0:int:1;
  nt = length(T);
  R  = zeros(2,nt);
  
  % Repeat for each decision threshold.
  for t = 1:nt,
    pos = py(1,:) >= T(t);
    
    % Get the percentage of negatives falsely classified as
    % postives. 
    R(1,t) = sum(pos == 1 & y == 2) / sum(y == 2);
    
    % Get the percentage of correctly classified positives.
    R(2,t) = sum(pos == 1 & y == 1) / sum(y == 1);
  end;
  
  % Plot the results.
  plot(R(1,:),R(2,:),'r-','LineWidth',2);
  axis([0 1 0 1]);
  xlabel('false positives');
  ylabel('correct positives');
