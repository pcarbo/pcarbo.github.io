function plotdecisionbndry (int, x1min, x1max, x2min, x2max, ds, py)

  % Compute the prediction over a grid of points.
  [X1 X2] = meshgrid(x1min:int:x1max, x2min:int:x2max);
  X = [reshape(X1, [1 prod(size(X1))]); 
       reshape(X2, [1 prod(size(X2))])];
  
  % Plot the graph.
  py = reshape(py(1,:),size(X1));
  map = [ones(10,1) [0.775:0.025:1]' [0.55:0.05:1]'];
  colormap(map);
  contourf(X1,X2,py);
  hold on, shading flat
  [c h] = contour(X1,X2,py>0.5,1,'k-'); 
  colorbar
  xlabel('x_1');
  ylabel('x_2   ','Rotation',0);
  zlabel('p(y)');
  axis([x1min x1max x2min x2max]);
  
  % Plot the true values of the data points.
  plotbindata(ds);
  legend off
  hold off
  