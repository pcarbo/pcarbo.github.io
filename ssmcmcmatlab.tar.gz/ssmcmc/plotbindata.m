% PLOTBINDATA   Plot binary semi-supervised data set.
%   The function call is PLOTBINDATA(DS) where DS is the data set
%   to plot. Only works for 2D data.

function plotbindata (ds)

  % We want to plot four different points: 
  % (labelled / unlabelled) x (positive class / negative class) 
  hold on;
  s = {};
  s = plotpts(ds,1,1,'bo',s);
  s = plotpts(ds,1,0,'bx',s);
  s = plotpts(ds,2,1,'ro',s);
  s = plotpts(ds,2,0,'rx',s);
  hold off;
  
  xlabel('x_1');
  ylabel('x_2   ','Rotation',0);
  legend(s{:});

% -------------------------------------------------------------------
function s = plotpts (ds, c, lbled, clr, s)

  X = ds.X(:,find(ds.y == c & (ds.Y(ds.docs) > 0) == lbled));
  if length(X),
    if lbled,
      sx = 'Labelled';
    else,
      sx = 'Unlabelled';
    end;
    s{length(s)+1} = sprintf('%s class %i',sx,c);
    plot(X(1,:),X(2,:),clr);
  end;
  