% KGAUSSIAN(X,LAMBDA) takes as input a matrix of distances X and scale
% parameter LAMBDA and returns the responses of the Gaussian kernel
% function. 

function Y = kgaussian (X, lambda)
  Y = exp(-lambda*(X.^2));
  