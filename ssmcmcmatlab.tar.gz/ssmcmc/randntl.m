% RANDNTL   Left-truncated Normal samples using Robert'95 algorithm.
%   RANDNTL(MU,SIG,A) generates an M x 1 matrix of random 
%   samples from the one-dimensional Normal distribution where M is 
%   the length of MU. MU is a M x 1 vector of means and the 
%   variance is either a scalar or M x 1 vector SIG. The samples
%   are bounded below by A. A is either a scalar or a M x 1 vector
%   of truncation points. 

function [X, nrej] = randntl (mu, sig, a)
 
  % Get the number of samples to generate.
  n = size(mu,1);
  
  % "X" is the final result we will return.
  X = zeros(n,1);
  
  % What we will do is sample from Z ~ N(0,1) instead.
  std = sqrt(sig);
  a   = (a - mu) ./ std;
  if length(a) == 1,
    a = repmat(a, [n 1]);
  end;
  
  % "s" is the number of samples generated so far. gs(i) is 1 if
  % we've generated the respective sample.
  s  = 0;
  gs = zeros(1,n);
  
  % Keep track of how many rejects we have.
  nrej = 0;
  
  % Repeat until the number of samples generated matches the number 
  % we demand.
  while s < n,
    
    % Find the samples that need to be generated.
    gsf = find(~gs);
    
    % If a < 0 then we sample from a normal distribution. If a > 0
    % then we sample from an exponential distribution.
    fns = gsf(find(a(gsf) < 0));
    fes = gsf(find(a(gsf) >= 0));
    
    % Generate the normal samples.
    if length(fns),
      x             = randn(length(fns),1);
      gdns          = find(x >= a(fns));
      ngdns         = length(gdns);
      X(fns(gdns))  = x(gdns);
      gs(fns(gdns)) = 1;
    else,
      ngdns = 0;
    end;
    
    % Generate the exponential samples using the optimal lambda
    % values, as explained by C.P. Robert (1995), Proposition 2.3,
    % p. 4. Steps 1-3 are all implemented in lines 1-3 below.
    if length(fes),
      lambda        = 0.5*(a(fes) + sqrt(a(fes).^2+4));
      x             = a(fes)-log(rand(length(fes),1))./lambda;
      gdes          = find(rand(length(fes),1) <= exp(-0.5*(x-lambda).^2));
      ngdes         = length(gdes);
      X(fes(gdes))  = x(gdes);
      gs(fes(gdes)) = 1;
    else,
      ngdes = 0;
    end;
    
    % Increment the number of good samples generated.
    s = s + ngdns + ngdes;
    
    % Increment the number of rejects. 
    nrej = nrej + length(gsf) - ngdns - ngdes;
  end;

  % Convert the N(0,1) variables back to their original
  % distribution. 
  X = mu + std.*X; 
