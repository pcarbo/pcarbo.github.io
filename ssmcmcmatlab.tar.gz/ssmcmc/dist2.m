% DIST2   Compute the L2-norm distance.
%   The function call is DIST2(X,Y). X and Y are the matrices of
%   data points. Let X be an F x N matrix and let Y be an F x M
%   matrix. The return value is an M x N matrix of distances.

function D = dist2 (X, Y)

  n = size(X,2);
  m = size(Y,2);

  D = sqrt(max(0,repmat(sum(X.^2),[m 1]) + ...
               repmat(sum(Y.^2)',[1 n]) - ...
               2*(Y'*X)));