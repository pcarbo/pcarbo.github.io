% SSMCMCTEST   Test the trained semi-supervised MCMC classification 
%              model.
%   SSMCMCTEST(X,MODEL,S0,S,SP) returns a 2 x N vector of label
%   probabilities. X is an F x N matrix of data points, MODEL is
%   the trained model, and S is the number of samples to use for
%   prediction, and cannot be greater than the samples generated
%   during training. S0 is the burn-in and SP-1 is the number of 
%   number of samples to skip (on average). 

function py = ssmcmctest (X, model, s0, s, sp)

  % Get some parameters.
  N = size(X,2);
  if s == -1,
    s = length(model.Ng);
  end;
  
  % Get the parameters from the samples.
  if sp == 1,
    ss = [(s0+1):s];
  else,
    ss = s0 + find(rand(s-s0,1) < sp);
  end;
  model.Beta = model.Beta(:,ss);
  model.Gf   = model.Gf(:,ss);
  model.Ng   = model.Ng(ss);
  s          = length(ss);
  clear ss
  
  % Normalize the data.
  X = normalizedata(X, model.mean, model.std);

  % Allocate memory for the final result.
  py0 = zeros(1,N);
  
  % Compute the N x K+1 kernel matrix using the kernel "K".
  % Repeat for each sample.
  gfo = [];
  psi = [];
  for si = 1:s,
    fprintf('%i ',si);
    ng    = model.Ng(si);
    gf    = model.Gf(1:ng,si);
    
    % Only compute the values for psi that we haven't computed in
    % the last iteration. This should save some computation time.
    [ans in io] = intersect(gf,gfo);
    psi(:,in)   = psi(:,io);
    g           = ones(1,ng);
    g(in)       = 0;
    in          = find(g);
    psi(:,in)   = kernelmatrix(model.f,model.K,model.C,X,...
                               model.lambda,gf(in));
    clear g in io
    
    % Produce samples from the approximated posterior distribution
    % of the model. 
    py0 = py0 + norm_cdf(-psi(:,1:ng)*model.Beta(1:ng,si))';
    
    % Save the gamma indices for the next sample.
    gfo(1:ng) = gf;
  end;
  py0 = py0 / s;
  fprintf('\n');
  
  % Return the result.
  py = [1-py0; py0];

% -------------------------------------------------------------------
function Psi = kernelmatrix (f, K, C, X, lambda, gf)
  Psi = feval(K,feval(f,C(:,gf),X),lambda);
