% RANDNTRA   Truncated Normal samples using rejection sampling.
%   RANDNTRA(MU,SIG,A,B) generates an M x 1 matrix of random 
%   samples from the one-dimensional Normal distribution where M is 
%   the length of MU. MU is a M x 1 vector of means and the 
%   variance is either a scalar or M x 1 vector SIG. The samples
%   bounded below by A and above by B. A and B are either scalars
%   or M x 1 vectors of truncation points.

function [X, nrej] = randntra (mu, sig, a, b)
 
  % Get the number of samples to generate.
  n = size(mu,1);
  
  % "X" is the final result we will return.
  X = zeros(n,1);
  
  % What we will do is sample from Z ~ N(0,1) instead.
  std = sqrt(sig);
  a   = (a - mu) ./ std;
  b   = (b - mu) ./ std;
  
  % "s" is the number of samples generated so far. gs(i) is 1 if
  % we've generated the respective sample.
  s  = 0;
  gs = zeros(1,n);
  
  % Keep track of how many rejects we have.
  nrej = 0;
  
  % Repeat until the number of samples generated matches the number 
  % we demand.
  while s < n,
    
    % Generate the samples.
    ns = n - s;
    x  = randn(ns,1);
    
    % Keep only the samples that are within the truncated
    % normal. However, don't store more samples than we need.
    gsf  = find(~gs);
    gds  = find(x >= a(gsf) & x <= b(gsf));
    ngds = length(gds);
    X(gsf(gds))  = x(gds);
    gs(gsf(gds)) = 1;
    s = s + ngds;
    
    % Increment the number of rejects. 
    nrej = nrej + ns - ngds;
  end;

  % Convert the N(0,1) variables back to their original
  % distribution. 
  X = mu + std.*X; 