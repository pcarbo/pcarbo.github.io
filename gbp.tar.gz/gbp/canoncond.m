% CANONCOND  Compute the conditional p(xs|xt), where p is a Normal
%            density following the canonical parameterization. 
%   The function call is [NU L] = CANONCOND(NUS,LSS,LST,XT) where the
%   joint p(xs,xt) is parameterized by
%       [NUS;   [LSS  LST
%        NUT]    LST' LTT].
%   XT is the observed value of the corresponding random variable.
%   The output is are the canonical parameters of the conditional 
%   p(xs|xt).

function [nu, L] = canoncond (nus, Lss, Lst, xt)
  
  nu = nus - Lst*xt;
  L  = Lss;
  