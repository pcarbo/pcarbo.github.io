% [MU, S] = CANONTOMOMENT(NU,L) converts the canonical parameterization of
% the Normal density to the momemnt parameterization with mean MU and
% covariance S.

function [mu, S] = canontomoment (nu, L)
  
  S  = inv(L);
  mu = S*nu;
  