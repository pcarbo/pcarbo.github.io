% REVSCHEDULE(S) returns the reverse of message passing schedule S. See the
% function MPP for more information on message passing schedules.

function R = revschedule (S)
  
  % Get the number of edges.
  m = length(S);
  
  R = repmat(struct('i',0,'j',0),m,1);
  for u = 1:m
    i      = S(u).i;
    j      = S(u).j;
    v      = m-u+1;
    R(v).i = j;
    R(v).j = i;
  end
  