% CANONMARG  Compute the marginal p(xs), where p is a Normal density
%            following the canonical parameterization.
%   The function call is [NU L] = CANONMARG(NUS,NUT,LSS,LTT,LST) where
%   the joint p(xs,xt) is parameterized by
%       [NUS;   [LSS  LST
%        NUT]    LST' LTT].
%   Note we assume LTS = LST'. The output is are the canonical parameters
%   of the marginal p(xs).

function [nu, L] = canonmarg (nus, nut, Lss, Ltt, Lst)  

  nu = nus - Lst*inv(Ltt)*nut;
  L  = Lss - Lst*inv(Ltt)*Lst';
  