function M = canonpar (f,n)
  M = repmat(struct('nu',zeros(f,1),'L',diag(ones(f,1))),n,1);
