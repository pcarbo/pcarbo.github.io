function M = momentpar (f,n)
  M = repmat(struct('mu',zeros(f,1),'S',diag(ones(f,1))),n,1);
