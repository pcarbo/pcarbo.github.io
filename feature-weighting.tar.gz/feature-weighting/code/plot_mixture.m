% PLOT_MIXTURES - Plot the mixture distribution.
%   The function call is PLOT_MIXTURES(MODEL,MODELNAME,GRAPHTYPE). 
%   Note this only works with two-dimensional data. A GRAPHTYPE of 1
%   plots a 3-D mesh graph and a GRAPHTYPE of 0 creates a contour
%   plot. The struct MODEL must have the entries MU, SIG and P. See the
%   function CREATE_DATA for more information. MODELNAME is a string.
%
%   Copyright (c) 2003 University of British Columbia. All Rights
%   Reserved. Created by Peter Carbonetto, Department of Computer
%   Science.

function plot_mixtures (model, modelName, graphType)
  
  % Function constants.
  k    = 0.1;
  nsig = 3;
  
  % Get the number of clusters and the number of features.
  C = length(model.p);
  F = size(model.mu,1);
  
  % Do the mesh plot.
  xmin = zeros(F,C);
  xmax = zeros(F,C);
  for c = 1:C,
    xmin(:,c) = model.mu(:,c) - nsig * sqrt(diag(model.sig(:,:,c)));
    xmax(:,c) = model.mu(:,c) + nsig * sqrt(diag(model.sig(:,:,c)));
  end;
  
  xmin = min(xmin');
  xmax = max(xmax');
  [X Y] = meshgrid(xmin(1):k:xmax(1), xmin(2):k:xmax(2));
  clear x
  
  % Find the indicator values.
  x = [ reshape(X, [1 prod(size(X))]); 
	reshape(Y, [1 prod(size(Y))])  ];
  N   = size(x,2);
  ind = zeros(C,N);
  for c = 1:C,
    u = (x - repmat(model.mu(:,c),[1 N]))';
    ind(c,:) = model.p(c) * exp((-0.5)*dot(u*inv(model.sig(:,:,c)),u,2))' ...
	/ sqrt(2*pi*det(model.sig(:,:,c)));
  end;
  
  Z = reshape(sum(ind),size(X));
    
  if graphType,
    % Plot the mesh.
    mesh(X,Y,Z);
    title(modelName);
    xlabel('x_1');
    ylabel('x_2');
    
  else,
    % Plot the contours.
    contour(X,Y,Z);
    title(modelName);
    xlabel('x_1');
    ylabel('x_2');
  end;
  