% EM - Run EM for the mixture of Gaussians with Bayesian priors.
%   EM(X,EMITER,EMTOL,NUMTRIALS,C,A,B,ALPHA,V) returns a struct MODEL with
%   the model parameters P, MU, SIGMA and TAU. X is a F x N matrix, where F
%   is the number of features and N is the number of data points for
%   training. EMITER and EMTOL are the maximum number of iterations and the
%   tolerance for the EM algorithm. NUMTRIALS is the number of times to
%   repeat the EM algorithm, selecting the result with the highest log
%   posterior. C is the number of mixture components. A and B are the priors
%   on Tau. ALPHA is the prior on mixture covariances and V is the prior on
%   the mixture probabilities, p.
%
%   Copyright (c) 2003 University of British Columbia. All Rights
%   Reserved. Created by Peter Carbonetto, Department of Computer
%   Science.

function model = em (x, EMiter, EMtol, numTrials, C, a, b, alpha, v)
   
  % Find some parameters:
  %   - the number of features, F.
  %   - the number of data points in the training set, N.
  F = size(x,1);
  N = size(x,2);
  
  % Get the sample mean and variance.
  muStar  = mean(x')';
  sigStar = diag(diag(cov(x')'));
  
  % Calculate the normalising constants on the Inverse-Wishart
  % distribution for the sigma parameter and on the Inverse-Gamma
  % distribution for the tau parameter.
  zIW = -C*(log(2^(0.5*alpha*F) * pi^(0.25*F*(F-1)) * ...
		prod(gamma(0.5*(alpha+1-[1:F])))) ...
	    + log(det(alpha*sigStar)^(0.5*alpha)));
  zIG = F*log(b^a / gamma(a));
  
  % Reserve storage space for some latent variables.
  indicator = zeros(C,N);
  A1        = zeros(1,C);
  A2        = zeros(F,C);
  A3        = zeros(F,F,C);
    
  % Repeat for each trial.
  model.posterior = 0;
  for trial = 1:numTrials,
    
    fprintf('MAP training, trial %i \n', trial);

    % Initialize the parameters by randomly sampling from their prior
    % distributions. Note that we assume the data is normalised. 
    %   - tau is a F x 1 matrix.
    %   - mu is a F x C matrix.
    %   - sig is a F x F x C matrix.
    %   - p is a 1 x C matrix where sum(p) = 1;
    % We do not sample randomly for the TAU parameter since we can
    % often get some pretty strange values.
    
    % Initialize p uniformly.
    p = ones(1,C) / C;
    
    % Initialize tau.
    % We take the mode of the inverse gamma distribution.
    % for f = 1:F,
    %   tau(f) = inv(gengamma(a,b));
    % end;
    tau = b / (a + 1) * ones(F,1);
    
    % Initialize mu.
    % We take random samples from the multivariate Gaussian
    % distribution. 
    mu = mvnormrnd(repmat(muStar',[C 1]), diag(tau), C)';

    % Initialize sigma.
    % We take random ramples from the inverse Wishart distribution.
    for c = 1:C,
      sig(:,:,c) = invwishirnd(alpha*sigStar, alpha+1+F);
    end;

    % Run EM.
    posteriors = [];
    for iter = 1:EMiter,
    
      fprintf('EM iteration %i - ', iter);
      
      % E step
      % ------
      for c = 1:C,
	u = (x - repmat(mu(:,c),[1 N]))';
	indicator(c,:) = ...
	    exp((-0.5)*dot(u*inv(sig(:,:,c)),u,2))' ...
	    / sqrt(det(sig(:,:,c)));
      end;
      
      % Normalize the indicator values by summing over the clusters.
      indicator = indicator ./ repmat(sum(indicator), [C 1]);
      
      % M step
      % ------
      % Save the old tau for the mu update step.
      Tau = diag(tau);
      
      % Calculate the sums over the indicators.
      A1 = sum(indicator,2)';
      A2 = reshape(sum(repmat(reshape(indicator',[1 N C]),[F 1 1]) ...
		       .* repmat(x, [1 1 C]),2),[F C]);
      for c = 1:C,
	u = x - repmat(mu(:,c),[1 N]);
	A3(:,:,c) = (repmat(indicator(c,:),[F 1]).*u)*u';
      end;
      
      % Update p. We don't have to normalize because the lambdas
      % already sum to 1. 
      p = (A1 + v - 1) / (N + (v-1)*C);
      
      % Update tau, mu and sigma. Note that the order is important!
      tau = b/(a + 0.5*C + 1) + ...
	    sum((mu - repmat(muStar,[1 C])).^2,2) / ...
	    (2*a + C + 2);
      for c = 1:C,
	z          = inv(sig(:,:,c) + Tau*A1(c));
	mu(:,c)    = Tau * z * A2(:,c) + sig(:,:,c) * z * muStar;	
	sig(:,:,c) = (A3(:,:,c) + alpha*sigStar) / (A1(c)+alpha+F+1);
      end;
      
      % Calculate the log-posterior
      % ---------------------------
      z = zeros(1,N);
      for c = 1:C,
	u = (x - repmat(mu(:,c),[1 N]))';
	z = z + p(c) * exp((-0.5)*dot(u*inv(sig(:,:,c)),u,2))' ...
	               / sqrt(det(2*pi*sig(:,:,c)));
      end;
      l = sum(log(z));
	  
      % Compute the prior on mu.
      Tau = diag(tau);
      z1  = inv(Tau);
      for c = 1:C,
	u = mu(:,c) - muStar;
	l = l - 0.5*u'*z1*u;
      end;
      l = l - 0.5*C*log(det(2*pi*Tau));
      
      % Compute the prior on sigma.
      for c = 1:C,
	l = l - 0.5*(alpha+F+1)*log(det(sig(:,:,c))) + ...
	      - 0.5*trace(alpha*sigStar*inv(sig(:,:,c)));
      end;
      l = l + zIW;
      
      % Compute the prior on tau.
      l = l + zIG - (a+1)*sum(log(tau)) - b*sum(tau.^(-1));
      
      % Plot the posterior graph.
      posteriors = [posteriors l];
      fprintf('log posterior = %f \n', l);
      plot(1:length(posteriors), posteriors);
      title(sprintf('Log-posterior on trial %i', trial));
      xlabel('EM Iteration');
      ylabel('Joint log-posterior');
      drawnow;
      
      % Check if we should stop based on the tolerance.
      if iter > 1,
	if (l - posteriors(iter-1)) < EMtol,
	  break;
	end;
      end;
      
    end; %end EM iterations
    
    % Check whether this model is better than the previous ones, based on
    % our computation of the log posterior.
    curPosterior = posteriors(length(posteriors));
    if curPosterior > model.posterior | trial == 1,
      bestTrial       = trial;
      model.posterior = curPosterior;
      model.mu        = mu;
      model.sig       = sig;
      model.p         = p;
      model.tau       = tau;
    end;    
    
    fprintf('\n');
    
  end; % end trials
  
  fprintf('Out of %i trials, the best model is from trial %i \n', ...
          numTrials, bestTrial);
  fprintf('with a log posterior of %f \n', model.posterior);
