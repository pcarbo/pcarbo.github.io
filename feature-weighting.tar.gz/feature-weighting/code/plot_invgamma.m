% PLOT_INVGAMMA - Plot the inverse gamma distribution.
%   PLOT_INVGAMMA(ALPHA,BETA,UB) plots the inverse gamma distribution
%   with parameters ALPHA and BETA and an upper bound on the x axis
%   specified by UB. 
%
%   Copyright (c) 2003 University of British Columbia. All Rights
%   Reserved. Created by Peter Carbonetto, Department of Computer
%   Science.

function plot_invgamma (alpha, beta, ub)
  
  a = 0.01;
  b = ub;
  c = 0.01;
  
  % Calculate the normalization constant for the inverse gamma.
  z = beta^alpha / gamma(alpha);
  
  % Find the distribution.
  x = a:c:b;
  y = z * invgamma(alpha, beta, x);
  disp(z);
  
  plot(x,y,'r');
