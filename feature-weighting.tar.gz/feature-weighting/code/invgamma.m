% INVGAMMA - Inverse gamma.
%   Y = INVGAMMA(ALPHA,BETA,THETA) finds the probability of THETA with
%   parameters ALPHA and BETA. AlPHA = -1 and BETA = 0 induces a flat
%   distribution. 
%
%   Copyright (c) 2003 University of British Columbia. All Rights
%   Reserved. Created by Peter Carbonetto, Department of Computer
%   Science.

function y = invgamma (alpha, beta, theta)
  y = theta.^(-alpha-1) .* exp(-beta ./ theta);