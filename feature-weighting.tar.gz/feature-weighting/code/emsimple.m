% EMSIMPLE - Run EM for the mixture of Gaussians.
%   EM(DATA,EMITER,EMTOL,NUMTRIALS,C) returns a struct MODEL
%   with the model parameters P, MU and SIGMA. DATA is the struct
%   returned by the function CREATE_DATA. EMITER and EMTOL are the
%   maximum number of iterations and the tolerance for the EM
%   algorithm. NUMTRIALS is the number of times to repeat the EM
%   algorithm, selecting the result with the highest log likelihood. C is 
%   the number of mixture components.
%
%   Copyright (c) 2003 University of British Columbia. All Rights
%   Reserved. Created by Peter Carbonetto, Department of Computer
%   Science.

function model = emsimple (data, EMiter, EMtol, numTrials, C)
  
  % Function constants.
  worstLikelihood = -1e99;
   
  % Find some parameters:
  %   - the number of features, F.
  %   - the number of data points in the training set, N.
  x = data.train.x;
  F = size(data.mu, 1);
  N = size(x,2);

  % Get the sample mean and variance.
  muStar  = mean(x')';
  sigStar = cov(x')';
  
  % Reserve storage space for some latent variables.
  indicator = zeros(C,N);
  A1        = zeros(1,C);
  A2        = zeros(F,C);
  A3        = zeros(F,F,C);
    
  % Repeat for each trial.
  model.likelihood = worstLikelihood;
  for trial = 1:numTrials,
    
    fprintf('ML training, trial %i \n', trial);

    % Initialize the parameters by randomly sampling from their prior
    % distributions. Note that we assume the data is normalised. 
    %   - tau is a F x 1 matrix.
    %   - mu is a F x C matrix.
    %   - sig is a F x F x C matrix.
    %   - p is a 1 x C matrix where sum(p) = 1;
    % We do not sample randomly for the TAU parameter since we can
    % often get some pretty strange values.
    
    % Initialize p uniformly.
    p = ones(1,C) / C;
    
    % Initialize mu.
    % We take random samples.
    mu = mvnormrnd(repmat(muStar',[C 1]), sigStar, C)';

    % Initialize sigma.
    % We take random ramples from the inverse Wishart distribution.
    sig = repmat(sigStar, [1 1 C]);

    % Run EM.
    likelihoods = [];
    for iter = 1:EMiter,
    
      fprintf('EM iteration %i - ', iter);
      
      % E step
      % ------
      for c = 1:C,
	u = (x - repmat(mu(:,c),[1 N]))';
	indicator(c,:) = ...
	    exp((-0.5)*dot(u*inv(sig(:,:,c)),u,2))' ...
	    / sqrt(det(sig(:,:,c)));
      end;
      
      % Normalize the indicator values by summing over the clusters.
      indicator = indicator ./ repmat(sum(indicator), [C 1]);
      
      % M step
      % ------
      % Calculate the sums over the indicators.
      A1 = sum(indicator,2)';
      A2 = reshape(sum(repmat(reshape(indicator',[1 N C]),[F 1 1]) ...
		       .* repmat(x, [1 1 C]),2),[F C]);
      for c = 1:C,
	u = x - repmat(mu(:,c),[1 N]);
	A3(:,:,c) = (repmat(indicator(c,:),[F 1]).*u)*u';
      end;
      
      % Update p. We don't have to normalize because the lambdas
      % already sum to 1. 
      p = A1 / N;
      
      % Update mu and sigma. Note that the order is important!
      for c = 1:C,
	mu(:,c)    = A2(:,c) / A1(c);	
	sig(:,:,c) = A3(:,:,c) / A1(c);
      end;
      
      % Calculate the log-likelihood
      % ----------------------------
      z = zeros(1,N);
      for c = 1:C,
	u = (x - repmat(mu(:,c),[1 N]))';
	z = z + p(c) * exp((-0.5)*dot(u*inv(sig(:,:,c)),u,2))' ...
	               / sqrt(det(2*pi*sig(:,:,c)));
      end;
      l = sum(log(z));
	  
      % Plot the likelihood graph.
      likelihoods = [likelihoods l];
      fprintf('log likelihood = %f \n', l);
      plot(1:length(likelihoods), likelihoods);
      title(sprintf('Log-likelihood on trial %i', trial));
      xlabel('EM Iteration');
      ylabel('Joint log-likelihood');
      drawnow;
      
      % Check if we should stop based on the tolerance.
      if iter > 1,
	if (l - likelihoods(iter-1)) < EMtol,
	  break;
	end;
      end;
      
    end; %end EM iterations
    
    % Check whether this model is better than the previous ones, based on
    % our computation of the log likelihood.
    curLikelihood = likelihoods(length(likelihoods));
    if curLikelihood > model.likelihood,
      bestTrial        = trial;
      model.likelihood = curLikelihood;
      model.mu         = mu;
      model.sig        = sig;
      model.p          = p;
    end;    
    
    fprintf('\n');
    
  end; % end trials
  
  fprintf('Out of %i trials, the best model is from trial %i \n', ...
          numTrials, bestTrial);
  fprintf('with a log likelihood of %f \n', model.likelihood);
