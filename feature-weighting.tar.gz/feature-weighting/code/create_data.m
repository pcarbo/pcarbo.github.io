% CREATE_DATA - Create data points from a distribution of an arbitrary 
%               mixture of Gaussians.
%   CREATE_DATA(P,MU,SIG,N) returns a struct containing the data. P is a
%   1 x C matrix of cluster probabilities where C is the number of 
%   clusters. MU is a F x C matrix of cluster means where F is the number
%   of features. SIG is a F x F x C matrix of cluster covariances. N is a
%   1 x 2 matrix of the number of data points to generate for both the
%   training and test sets, respectively. The return value is a struct
%   with the following entries:
%     x    F x N matrix containing the data elements
%     y    1 x N indexes to which each cluster belongs.
%     mu   F x C matrix of normalized means.
%     sig  F x F x C matrix of normalized covariances.
%     p    1 x C matrix of normalized cluster probabilities.
%
%   Copyright (c) 2003 University of British Columbia. All Rights
%   Reserved. Created by Peter Carbonetto, Department of Computer
%   Science.

function data = create_data (p, mu, sig, N)
  
  % Get function variables.
  C      = length(p);
  F      = size(mu,1);
  Ntrain = N(1);
  N      = sum(N);
  
  % Normalize the cluster probabilities. 
  p = p / sum(p);
    
  % Generate the cluster Y for each data point.
  y = randint(repmat(p,[N 1]));

  % Generate the data points.
  x = zeros(F,N);
  for i = 1:N,
    x(:,i) = mvnormrnd(mu(:,y(i)), sig(:,:,y(i)), 1)';
  end;
  
  % Normalize the data.
  xMean = mean(x')';
  xStd  = std(x')';
  x     = (x - repmat(xMean, [1 N])) ./ repmat(xStd, [1 N]);
  
  data.p   = p;
  data.mu  = (mu - repmat(xMean, [1 C])) ./ repmat(xStd, [1 C]);
  data.sig = sig ./ repmat(xStd * xStd', [1 1 C]);
  
  data.train = splitdata(1,Ntrain,x,y);
  data.test  = splitdata(Ntrain+1,N,x,y);
  
% -------------------------------------------------------------------
function data = splitdata(N0, N1, x, y)

  data.x = x(:,N0+1:N1);
  data.y = y(N0+1:N1);



