% SCRIPT - Sample script.

% DATA PARAMETERS.
createdata = 1;
C = 3;          % The number of clusters.
F = 2;          % The number of feature.
p = [1 2 1];    % The probability of each cluster.
N = [200 100];  % Number of data points in trianing and test sets.
means = [ 1  1.8;   
	  5  2.2; 
	  8  2.0 ]';
covariances = repmat([1 0; 0 1],[1 1 C]);

% EM PARAMETERS.
a         = 0.1;
b         = 0.5;
upsilon   = 1;
alpha     = 3;
numTrials = 5;
EMiter    = 24;
EMtol     = 0.05;

% SCRIPT.
  
% Initialize the randomizer.
rand('state', sum(100*clock));  
randn('state', sum(100*clock));

% Create the data.
if createdata,
  data = create_data(p,means,covariances,N);
end;

clf;
subplot(3,3,1);
view_data(data);
subplot(3,3,4);
plot_mixture(data, 'Original', 0);

% Run EM with feature weighting.
subplot(3,3,8);
model1 = em(data,EMiter,EMtol,numTrials,C,a,b,alpha,upsilon);

% Plot the results.
subplot(3,3,5);
plot_mixture(model1, 'MAP', 0);
datat = find_classes(model1, data);
subplot(3,3,2);
view_data(datat);
clear datat

% Run EM without feature weighting.
subplot(3,3,9);
model2 = emsimple(data,EMiter,EMtol,numTrials,C);

% Plot the results.
subplot(3,3,6);
plot_mixture(model2, 'ML', 0);
datat = find_classes(model2, data);
subplot(3,3,3);
view_data(datat);
clear datat