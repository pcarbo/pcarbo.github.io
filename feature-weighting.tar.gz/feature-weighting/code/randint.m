% RANDINT - Produce a random integer given a set of probabilities.
%   Return an N x 1 matrix of random integers, where the probability of
%   generating the i for the n-th random variable is given by P(n,i). P is
%   a N x M matrix, where the set of integers is defined by [1,M]. We
%   assume that each row of the matrix P contains at least one positive
%   number. 

function x = randint (p)
  
  % Get some function parameters.
  N = size(p,1);
  M = size(p,2);
  
  % Normalize the probabilities.
  sp = sum(p,2);
  p  = p ./ repmat(sp, [1 M]);
  
  % Set the lower and upper bounds.
  lb = zeros(N,M);
  for m = 2:M,
    lb(:,m) = lb(:,m-1) + p(:,m-1);
  end;
  ub = [lb(:,2:M) ones(N,1)];
  
  % Get the uniform random integers.
  U = rand(N,1);
  U = repmat(U .* (U < 1), [1 M]);
  
  % Figure out which class we're in.
  x = sum((lb <= U & U < ub) .* repmat(1:M, [N 1]), 2);
  