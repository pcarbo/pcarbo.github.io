% FIND_CLASSES  Predict mixture components using model.

function data = find_classes (model, data)
  
  data.p   = model.p;
  data.mu  = model.mu;
  data.sig = model.sig;

  % Predict mixtures.
  x = data.train.x;
  N = size(x, 2);
  C = length(model.p);
  y = zeros(N,C);

  for c = 1:C,
    u = (x - repmat(model.mu(:,c),[1 N]))';
    y(:,c) = model.p(c) * exp((-0.5)*dot(u*inv(model.sig(:,:,c)),u,2)) ...
	     / sqrt(2*pi*det(model.sig(:,:,c)));
  end;
  
  [ans data.train.y] = max(y');
