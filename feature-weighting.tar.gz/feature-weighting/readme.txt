Type "help code" in the Matlab console to get you started.

Peter Carbonetto
University of British Columbia
pcarbo@cs.ubc.ca
June 12, 2003

