% RANDOMIZEFACES   Reorder the images randomly.
%    RANDOMIZEFACES(SOURCEFILE, DESTFILE, IMGSIZE, SEED) creates a new
%    database DESTFILE with the same images in SOURCEFILE, but reordered
%    randomly using the random SEED. The standard value for IMGSIZE is
%    24. 
%
%    Date: August 26, 2002
%    Authors:
%    - Peter Carbonetto, University of British Columbia Computer Science
%      Deptartment, pcarbo@cs.ubc.ca

function randomizefaces (sourceFile, destFile, imgSize, seed)

  % Get the file handle.
  fid = fopen(sourceFile, 'r');

  % Start from position 0 and find out how many images are in the
  % file.
  fseek(fid, 0, 'eof');
  numImages = ftell(fid) / (imgSize * imgSize);
  fseek(fid, 0, 'bof');

  % Create the random array.
  rand('state', seed);
  seq = 1:numImages;

  % Generate the random numbers.
  rn = zeros(1, numImages);
  for i = 1:numImages,
    rn(i) = round(1 + rand*(numImages - i));
  end;

  r = zeros(1, numImages);
  for i = 1:numImages,
    x    = rn(i);
    r(i) = seq(x);
    seq  = [seq(1:x-1) seq(x+1:numImages-i+1)];
  end;
 
  % Make the 3D array.
  faces = zeros(imgSize, imgSize, numImages);
  for i = 1:numImages,
    [A count] = fread(fid, [imgSize imgSize], 'uint8');
    faces(:,:,i) = A;
  end
  fclose(fid);

  fid2 = fopen(destFile, 'w+');
  for i = 1:numImages,
    fwrite(fid2, faces(:,:,r(i)), 'uint8');
  end
