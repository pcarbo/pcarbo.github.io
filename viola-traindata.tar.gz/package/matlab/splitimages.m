% SPLITIMAGES   Takes a set of JPEG images and creates a database
%               of smaller images.
%    SPLITIMAGES(SPLITSIZE, IMGDIR, DIFFTHRESHOLD, DESTFILE) loads all
%    the JPEG images located in directory IMGDIR and creates a new image
%    database in the file DESTFILE. All the images in the database will
%    have height and width of size SPLITSIZE. The standard SPLITSIZE is
%    24. 
% 
%    This function will automatically prune images that have a sum
%    squared difference less than a threshold defined by DIFFTHRESHOLD. I
%    found that a threshold of 100000 worked for me. 
%
%    For the final step of the algorithm, the user can manually prune any
%    images as he or she sees fit. The new "sliced" images are displayed
%    in a grid and the user can prune an image by typing in the number
%    corresponding to the position on the grid. To calculate this, take
%    the number to the left of the corresponding row and add it to the
%    corresponding column number.
%
%    Note that the JPEG files can be in either black and white or
%    colour. If they are the latter, they will be converted into B&W.
%
%    Date: August 27, 2002
%    Authors:
%    - Peter Carbonetto, University of British Columbia Computer Science
%      Deptartment, pcarbo@cs.ubc.ca


function splitimages (splitSize, imgDir, diffThreshold, destFile)

  % Parameters you can change.
  % -------------------------
  numImgsShowAtOnceHeight = 8;
  numImgsShowAtOnceWidth  = 8;
  
  splitHeight = splitSize;
  splitWidth  = splitSize;
  
  % LOAD IMAGES
  % -----------
  % Get the list of images.
  oldPwd = pwd;
  cd(imgDir);
  x = dir;
  listOfImages = [];
  for i = 1:length(x),
    if x(i).isdir == 0,
      listOfImages = [listOfImages; x(i)];
    end;
  end;

  disp('Loading the following images:');

  % First find out how much memory we will need.
  numSplitImages = 0;
  for i = 1:length(listOfImages),
    fileName = listOfImages(i).name;
    disp(sprintf('   %s', fileName));
    img = imread(fileName);
    [height width x] = size(img);
    sHeight = fix(height / splitHeight);
    sWidth  = fix(width / splitWidth);
    numSplitImages = numSplitImages + sHeight * sWidth;
  end;

  % Create the array to store all the images.
  IMAGES = uint8(zeros(splitHeight, splitWidth, numSplitImages));

  disp(sprintf(['This procedure is going to create a maximum of %d %dx' ...
                '%d images.'], numSplitImages, splitHeight, splitWidth)); 

  % Repeat for each image.
  numTotalImgs = 0;
  for i = 1:length(listOfImages),
    
    % Read in the image.
    img = double(imread(listOfImages(i).name));
    [height width x] = size(img);
    
    % Average out the colours.
    if x > 1,
        bwImg = uint8((img(:,:,1) + img(:,:,2) + img(:,:,3)) / 3);
    else,
        bwImg = uint8(img);
    end;
    
    % Segment the image into splitHeight x splitWidth images.
    for y = 1:splitHeight:height-splitHeight,
      for x = 1:splitWidth:width-splitWidth,
        sImg = bwImg(y:y+splitHeight-1,x:x+splitWidth-1);
        numTotalImgs = numTotalImgs + 1;
        IMAGES(:,:,numTotalImgs) = sImg;
      end;
    end;
  end;

  disp('processing...');
  
  % PRUNE SIMILAR IMAGES
  % --------------------
  % Now that we've segmented all the images, we need to find out
  % which ones to keep and which ones to remove. First we're going to
  % remove the duplicates. Second, we're going to remove the ones that
  % the user says are bad.
  numKeptImgs = 0;
  onesToKeep = ones(numTotalImgs,1);

  disp('removing duplicates...');

  % Let's remove all the duplicates first.
  numImagesRemoved = 0;
  for i = 1:numTotalImgs - 1,
    
    % If we're keeping that image, then let's check to see if it has any
    % duplicates.
    if onesToKeep(i),
      for j = i+1:numTotalImgs,
        if onesToKeep(j),
          if sum(sum((double(IMAGES(:,:,i)) - double(IMAGES(:,:,j))).^2)) ...
		< diffThreshold,
            onesToKeep(j) = 0;
            numImagesRemoved = numImagesRemoved + 1;
          end;
        end;
      end;
    end;
  end;

  disp(sprintf('We have removed a total of %d duplicates from the list.', ...
	       numImagesRemoved));

  % Remove all the duplicates from IMAGES.
  x = 1;
  for i = 1:numTotalImgs,
    if onesToKeep(i),
      IMAGES(:,:,x) = IMAGES(:,:,i);
      x = x + 1;
    end;
  end;
  numTotalImgs = x;
  
  % MANUAL PRUNING
  % --------------
  onesToKeep = ones(numTotalImgs, 1);
  numImgsShowAtOnce = numImgsShowAtOnceHeight * numImgsShowAtOnceWidth;
  for i = 1:numImgsShowAtOnce:numTotalImgs,
    
    % Display the images on the screen.    
    disp('displaying images...');
    figure(1);
    clf;
    
    for j = i:min(i+numImgsShowAtOnce-1, numTotalImgs),
      subplot(numImgsShowAtOnceHeight, numImgsShowAtOnceWidth, j-i+1);
      imshow(IMAGES(:,:,j));
      x = rem((j - i), numImgsShowAtOnceWidth);
      if fix((j - i) / numImgsShowAtOnceWidth) == 0,
        title(sprintf('%d',x), 'fontsize',9);
      end;
      if rem((j - i), numImgsShowAtOnceWidth) == 0,
        ylabel(sprintf('%d',j-x-i), 'fontsize',9);
      end;
    end;
    
    % Ask the user if there are any to remove.
    r = 1;
    while length(r),
      disp('');
      disp('Is there an image you want to remove?');
      r = input('If so, type in the number -> ');
      if length(r),
            
        % Remove image.
        onesToKeep(i+r) = 0;
            
        disp('The image shown in figure 2 was removed.');
        figure(2);
        imshow(IMAGES(:,:,i+r));
        title(sprintf('%d',r), 'fontsize',9);
      end;
    end;
  end;
  
  % WRITE IMAGE DATABASE TO DISK
  % ----------------------------
  % Now that we've removed the bad images, let's write them all
  % to disk.
  cd(oldPwd);
  fid = fopen(destFile, 'w+');
  x = 0;
  for i = 1:numTotalImgs,
    if onesToKeep(i),
      fwrite(fid, IMAGES(:,:,i)', 'uint8');
      x = x + 1;
    end;
  end;

  disp(sprintf('%d images written to file %s', x, destFile));
