% ROTATEIMAGES   Transpose the images in the image database.
%    ROTATEIMAGES(SOURCEFILE, DESTFILE, IMGSIZE) creates a new image
%    database in DESTFILE using transposed versions of the images in
%    SOURCEFILE. IMGSIZE specifies the size of the dimensions of the
%    images. The standard image height and width is 24.
%
%    Date: August 26, 2002
%    Authors:
%    - Peter Carbonetto, University of British Columbia Computer Science
%      Deptartment, pcarbo@cs.ubc.ca

function rotateimages(sourceFile, destFile, imgSize)

  fid = fopen(sourceFile);

  % Start from position 0 and find out how many images are in the
  % file.
  fseek(fid, 0, 'eof');
  numImages = ftell(fid) / (imgSize * imgSize);
  fseek(fid, 0, 'bof');
  
  faces = zeros(imgSize, imgSize, numImages);
  for i = 1:numImages,
    [A count] = fread(fid, [imgSize imgSize], 'uint8');
    faces(:,:,i) = A';
  end
  fclose(fid);

  fid2 = fopen(destFile, 'w+');
  for i = 1:numImages,
    fwrite(fid2, faces(:,:,i), 'uint8');
  end
  fclose(fid2);
