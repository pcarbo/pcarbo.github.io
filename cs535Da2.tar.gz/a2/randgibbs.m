% Perturb X according to the random single-site Gibbs sampler.
% M is the number of times to run Gibbs sampler.
function X = randgibbs (Y, X, a, b, m)
  
  % Get the number of mixture components.
  K = length(a);
  
  % Get the number of observations / hidden states.
  T = length(X);
  
  n = zeros(1,K);
  N = zeros(K,K);
  z = zeros(1,K);
  C = zeros(1,K);
  
  % Collect the sufficient statistics:
  %   * n(i) is the number of observations assigned to mixture component i.
  %   * N(i,j) is the number of consecutive observations assigned to
  %     mixture components (i,j).
  %   * z(i) is the sum of observations assigned to mixture component i.
  for i = 1:K
    ts     = find(X == i);
    n(i)   = length(ts);
    z(i)   = sum(Y(ts));
    ts     = find(X(1:T-1) == i);
    N(i,:) = hist(X(ts+1),1:K);
  end
  
  % Repeat for each iteration of the Gibbs sampler.
  for mi = 1:m
    t = randint(1,T);
  
    % Remove xt from the sufficient statistics.
    n(X(t)) = n(X(t)) - 1;
    if t > 1
      N(X(t-1),X(t)) = N(X(t-1),X(t)) - 1;
    end
    if t < T
      N(X(t),X(t+1)) = N(X(t),X(t+1)) - 1;
    end
    z(X(t)) = z(X(t)) - Y(t);
  
    % Compute the full conditional for xt. Repeat over all possible
    % assignments to xt. nT is the number of observations assigned to
    % mixture component i, with the exception of the last observation at
    % time step T.
    nT       = n;
    nT(X(T)) = n(X(T)) - 1;
    for i = 1:K
      
      % Set the new proposed sufficient statistics.
      n(i) = n(i) + 1;
      z(i) = z(i) + Y(t);
      if t > 1
        N(X(t-1),i) = N(X(t-1),i) + 1;
      end
      if t < T
        N(i,X(t+1)) = N(i,X(t+1)) + 1;
        nT(i)       = nT(i)       + 1;
      end
      C(i) = sum(gammaln(z+a)) - sum((z+a).*log(n+b)) + ...
             sum(sum(gammaln(N+1))) - sum(gammaln(K+nT));
      
      % Revert the sufficient statistics.
      n(i) = n(i) - 1;
      z(i) = z(i) - Y(t);
      if t > 1
        N(X(t-1),i) = N(X(t-1),i) - 1;
      end
      if t < T
        N(i,X(t+1)) = N(i,X(t+1)) - 1;
        nT(i)       = nT(i)       - 1;
      end
    end
    
    C    = exp(C-max(C));
    X(t) = sample(C);
    
    % Update the sufficient statistics according to sample xt.
    n(X(t)) = n(X(t)) + 1;
    if t > 1
      N(X(t-1),X(t)) = N(X(t-1),X(t)) + 1;
    end
    if t < T
      N(X(t),X(t+1)) = N(X(t),X(t+1)) + 1;
    end
    z(X(t)) = z(X(t)) + Y(t);
  end
