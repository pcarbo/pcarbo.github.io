% Note that the observations are contained in the matrix Y.

K       = 2;        % The number of mixture components.
a       = [1 1];    % Prior on Poisson rates.
b       = [1 1];
s       = 10000;    % Number of samples to generate.
sampler = 2;        % 1 = single-site Gibbs sampler.
                    % 2 = blocked Gibbs sampler [Chib, 1996].

% Get the number of observations.
T = length(Y);

% Initialize the model parameters from the priors. p is a K x K matrix
% such that entry p(i,j) = Pr(Xt=j | X(t-1)=i).
p0 = dirrnd(ones(1,K))';
p  = zeros(K,K);
for i = 1:K
  p(i,:) = dirrnd(ones(1,K));
end

% Draw the Poisson rates according to their prior. We require that the
% Poisson rates are always in increasing order; L(1) < L(2), etc. 
L = zeros(1,K);
for i = 1:K
  L(i) = gengamma(a(i),b(i));
end
L = sort(L);

% Storage for the hidden states.
X = randint(1,K,1,T);

% We will store the conditional probability tables in a T x K matrix "F". 
F = zeros(T,K);

% Keep track of the expectations of the model parameters.
EX  = zeros(K,T);
EL  = zeros(1,K);
Ep0 = zeros(1,K);
Ep  = zeros(K,K);

% Keep track of the evolution of the Poisson rates over time.
Ls = zeros(s,K);

% Repeat for each sample.
for si = 1:s
  fprintf('%i ', si);

  if sampler == 1
    for t = randperm(T)
      if t == 1
        
        % Sample x1 | x2.
        X(1) = sample(L.^Y(1).*exp(-L).*p(:,X(2))');        
      elseif t == T
        
        % Sample xT | x(T-1).
        X(T) = sample(L.^Y(T).*exp(-L).*p(X(T-1),:));
      else
        
        % Sample xt | x(t-1), x(t+1).
        X(t) = sample(L.^Y(t).*exp(-L).*p(X(t-1),:).*p(:,X(t+1))');
      end
    end
  else
  
    % Compute the probabilities p(xt|y1:t) starting with t=1 and ending
    % with t=T. Note that computing p(x1|y1) is trivial.
    f      = L.^Y(1).*exp(-L).*p0;
    F(1,:) = f / sum(f);

    % Repeat for every time step except the first one.
    for t = 2:T
      f      = L.^Y(t).*exp(-L).*(F(t-1,:)*p);
      F(t,:) = f / sum(f);
    end
    
    % We now have the unnormalised expressions of p(xt|y1:t) for all t. For
    % sampling, however, what we actually want is the expression
    % p(xt|x(t+1),y1:t) for every node except the last. 
    
    % Draw from p(xT|y1:T).
    X(T) = sample(F(T,:));
    
    % Repeat for every node, drawing from p(xt|x(t+1),y1:t).
    for t = T-1:-1:1
      X(t) = sample(p(:,X(t+1))' .* F(t,:));
    end
  end
  
  % Sample lambda.
  for i = 1:K
    ts   = find(X == i);
    n    = length(ts);
    L(i) = gengamma(sum(Y(ts))+a(i),n+b(i));
  end
  
  % Enforce the constraint on lambda that L(1) < L(2).
  [L I] = sort(L);
  if I(1) ~= 1
    fprintf('!');
    X     = I(X);
    p0    = p0(I);
    p     = p(I,I);
    EX    = EX(I,:);
  end
  
  % Sample p0.
  n  = (X(1) == 1:K);
  p0 = dirrnd(n+1)';
  
  % Sample p.
  for i = 1:K
    ts     = find(X(1:T-1) == i);
    n      = hist(X(ts+1),1:K);
    p(i,:) = dirrnd(n+1)';
  end
  
  % Update the sufficient statistics.
  EX  = EX  + (repmat(X,K,1) == repmat([1:K]',1,T));
  EL  = EL  + L;
  Ep0 = Ep0 + p0;
  Ep  = Ep  + p;
  
  Ls(si,:) = L;
end
fprintf('\n');

% Normalize the sufficient statistics.
EX  = EX  / s;
EL  = EL  / s;
Ep0 = Ep0 / s;
Ep  = Ep  / s;

figure(1);
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','');
set(gcf,'Color','white');
clf

% Plot data.
subplot(3,1,1);
colormap winter
bar(1:T,Y,1,'EdgeColor','red','FaceColor','red');
xlabel('t');
ylabel('# of movements');
set(gca,'Box','off');

% Plot Pr(X).
subplot(3,1,2);
colormap default
bar(EX',1,'stacked','EdgeColor','none');
xlabel('t');
ylabel('Pr(X=i)');
set(gca,'Box','off');

% Plot evolution of Poisson rates over time.
subplot(3,1,3);
cla
colormap default
hold on
for i = 1:K
  plot(1:s,Ls);
end
hold off
xlabel('s');
ylabel('\lambda');
set(gca,'Box','off');

fprintf('Poisson rates:\n');
disp(EL');

fprintf('Transition matrix:\n');
disp(Ep');

% Plot the Poisson rate distribution.
figure(2);
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','');
set(gcf,'Color','white');
clf
subplot(1,2,1);
[N C] = hist(Ls(:,1),20);
plot(C,N,'b-');
xlabel('\lambda_1');
ylabel('p(\lambda_1)');

subplot(1,2,2);
[N C] = hist(Ls(:,2),20);
plot(C,N,'b-');
xlabel('\lambda_2');
ylabel('p(\lambda_2)');
