% Note:
%   * the observations are contained in the matrix Y.
%   * This version only works for K = 2.

K    = 2;        % The number of mixture components.
a    = [1 1];    % Prior on Poisson rates.
b    = [1 1];
s    = 10000;    % Number of samples to generate.
xi   = 0.25;
zeta = 10;

% Get the number of observations.
T = length(Y);

% Initialize the model parameters from the priors. p is a K x K matrix
% such that entry p(i,j) = Pr(Xt=j | X(t-1)=i).
p0 = dirrnd(ones(1,K))';
p  = zeros(K,K);
for i = 1:K
  p(i,:) = dirrnd(ones(1,K));
end

% Draw the Poisson rates according to their prior. We require that the
% Poisson rates are always in increasing order; L(1) < L(2), etc. 
L = zeros(1,K);
for i = 1:K
  L(i) = gengamma(a(i),b(i));
end
L = sort(L);

% Keep track of the expectations of the model parameters.
EL  = zeros(1,K);
Ep0 = zeros(1,K);
Ep  = zeros(K,K);

% Keep track of the evolution of the Poisson rates over time.
Ls = zeros(s,K);

% Keep track of the Metropolis-Hastings acceptance rates.
ar.lambda = 0;
ar.p0     = 0;
ar.p      = 0;

% Repeat for each sample.
for si = 1:s
  fprintf('%i ', si);

  % Sample lambda.
  for i = 1:K
    
    % Propose a new candidate.
    y     = L(i)*exp(sqrt(xi)*randn-xi/2);
    Ln    = L;
    Ln(i) = y;

    % Compute the acceptance probability.
    g   = varelim(Y,L,p,p0);
    gn  = varelim(Y,Ln,p,p0);
    acc = gn/g*(y/L(i))^(a(i)+1)*exp(b(i)*(L(i)-y));
    
    if rand < acc
      L         = Ln;
      ar.lambda = ar.lambda + 1;
    end
  end
  
  % Enforce the constraint on lambda that L(1) < L(2).
  [L I] = sort(L);
  if I(1) ~= 1
    fprintf('!');
    p0 = p0(I);
    p  = p(I,I);
  end
  
  % Sample p0.
  y = zeros(1,K);
  
  % Transform the weight onto the logit scale and conduct the
  % proposed move. y is the proposed move.
  e    = log(p0(1)/(1-p0(1))) + sqrt(zeta)*randn;
  y(1) = exp(e)/(1+exp(e));
  y(2) = 1-y(1);
  
  % Compute the acceptance probability.
  g   = varelim(Y,L,p,p0);
  gn  = varelim(Y,L,p,y);
  acc = gn/g*y(1)*y(2)/(p0(1)*p0(2));
      
  if rand < acc
    p0    = y;
    ar.p0 = ar.p0 + 1;
  end

  % Sample p.
  for i = 1:K
         
    % Transform the weight onto the logit scale and conduct the
    % proposed move. y is the proposed move.
    ei = log(p(i,1)/(1-p(i,1))) + sqrt(zeta)*randn;
    y  = exp(ei)/(1+exp(ei));
        
    % Compute the acceptance probability.
    pn      = p;
    pn(i,:) = [y 1-y];
    g       = varelim(Y,L,p,p0);
    gn      = varelim(Y,L,pn,p0);
    acc     = gn/g*y*(1-y)/(p(i,1)*p(i,2));
        
    if rand < acc
      p    = pn;
      ar.p = ar.p + 1;
    end
  end

  % Update the sufficient statistics.
  EL  = EL  + L;
  Ep0 = Ep0 + p0;
  Ep  = Ep  + p;
  
  Ls(si,:) = L;
end
fprintf('\n');

% Normalize the sufficient statistics.
EL  = EL  / s;
Ep0 = Ep0 / s;
Ep  = Ep  / s;

% Display the Metropolis-Hastings acceptance rates.
fprintf('Metropolis-Hastings acceptance rates: \n');
fprintf('  lambda: %0.3f \n', ar.lambda/(s*K));
fprintf('  p0:     %0.3f \n', ar.p0/(s));
fprintf('  p:      %0.3f \n', ar.p/(s*K));

figure(1);
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','');
set(gcf,'Color','white');
clf

% Plot evolution of Poisson rates over time.
clf
colormap default
hold on
for i = 1:K
  plot(1:s,Ls);
end
hold off
xlabel('s');
ylabel('\lambda');
set(gca,'Box','off');

fprintf('Poisson rates:\n');
disp(EL');

fprintf('Transition matrix:\n');
disp(Ep);

% Plot the Poisson rate distribution.
figure(2);
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','');
set(gcf,'Color','white');
clf
subplot(1,2,1);
hist(Ls(:,1),20);
xlabel('\lambda_1');
ylabel('p(\lambda_1)');

subplot(1,2,2);
hist(Ls(:,2),20);
xlabel('\lambda_2');
ylabel('p(\lambda_2)');
