% Run variable elimination on the hidden states.
function g = varelim (Y, L, p, p0)  
  
  % Get the number of observations.
  T = length(Y);
  
  % Get the number of mixture components.
  K = length(L);
  
  % Run variable elimination.
  g = ones(1,K);
  for t = T:-1:2
    
    % Sum out Xt.
    g = (L.^Y(t).*exp(-L).*g)*p';
  end
  
  % We now have a factor on X1, so the last thing to do is to sum out X1.
  g = sum(L.^Y(1).*exp(-L).*p0.*g);

  