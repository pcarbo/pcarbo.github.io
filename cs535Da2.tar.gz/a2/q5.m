rand('state',676);

% Note:
%   * The observations are contained in the matrix Y.
%   * We do not need to enforce an ordering on the mixture components
%     except in the final step.

K    = 2;        % The number of mixture components.
a    = [1 1];    % Prior on Poisson rates.
b    = [1 1];
s    = 1000;     % Number of particles in population.
esst = 0.1;      % Lower bound on effective sample size.

% Get the number of observations.
T = length(Y);

% Sample from p(x1|y1). X is a S x T matrix, where S is the number of
% particles and T is the number of observations.
fprintf('1 ');
X = randint(1,K,s,T);

% Initialize the importance weights.
W = ones(s,1)/s;

% Keep track of the effective sample size over time.
ESS    = zeros(t,1);
ESS(1) = s;

% Repeat for each observation except the first.
for t = 2:T
  fprintf('%i ', t);
  
  % Run the random single-site Gibbs sampler for each particle.
  for si = 1:s
    X(si,1:t) = randgibbs(Y(1:t),X(si,1:t),a,b,1);
  end
  
  % Compute the new importance weights.
  % Repeat for each particle.
  for si = 1:s
    w = 0;
    
    % Get the hidden states for the current particle.
    x = X(si,1:t);
    
    % Storage for the sufficient statistics.
    n  = zeros(1,K);
    N  = zeros(K,K);
    z  = zeros(1,K);
    Rn = zeros(1,K);
    Rd = zeros(1,K);
    
    % Collect the sufficient statistics.
    for i = 1:K
      ts     = find(x == i);
      n(i)   = length(ts);
      z(i)   = sum(Y(ts));
      ts     = find(x(1:t-1) == i);
      N(i,:) = hist(x(ts+1),1:K);
    end
    
    % The transition kernel is a mixture of Gibbs kernels. Repeat for
    % each Gibbs kernel (except the last one).
    for r = 1:t
      
      % Remove xr from the sufficient statistics.
      n(x(r)) = n(x(r)) - 1;
      z(x(r)) = z(x(r)) - Y(r);
      if r > 1
        N(x(r-1),x(r)) = N(x(r-1),x(r)) - 1;
      end
      if r < t
        N(x(r),x(r+1)) = N(x(r),x(r+1)) - 1;
      end
            
      % Compute the numerator and the denominator for the rth ratio
      % appearing in the expression for the importance weights.
      % Repeat for each assignment to xr.
      for i = 1:K
        x(r) = i;
        
        % Set the new proposed sufficient statistics.
        n(x(r)) = n(x(r)) + 1;
        z(x(r)) = z(x(r)) + Y(r);
        if r > 1
          N(x(r-1),x(r)) = N(x(r-1),x(r)) + 1;
        end
        if r < t
          N(x(r),x(r+1)) = N(x(r),x(r+1)) + 1;
        end
        
        % "nt" is the same as the sufficient statistics "n" except that
        % we discount the effect of xt.
        nt       = n;
        nt(x(t)) = nt(x(t)) - 1;        
        Rd(i)    = sum(gammaln(z+a)) - sum((z+a).*gammaln(n+b)) + ...
                   sum(sum(gammaln(N+1))) - sum(gammaln(K+nt));
        
        % Remove the effect of xt so that we can compute the density from
        % the previous time step.
        n(x(t))        = n(x(t))        - 1;
        z(x(t))        = z(x(t))        - Y(t);
        N(x(t-1),x(t)) = N(x(t-1),x(t)) - 1;
        
        nt         = n;
        nt(x(t-1)) = nt(x(t-1)) - 1;                
        Rn(i)      = sum(gammaln(z+a)) - sum((z+a).*gammaln(n+b)) + ...
                     sum(sum(gammaln(N+1))) - sum(gammaln(K+nt));
        
        % Reinsert the effect of xt.
        n(x(t))        = n(x(t))        + 1;
        z(x(t))        = z(x(t))        + Y(t);
        N(x(t-1),x(t)) = N(x(t-1),x(t)) + 1;        
        
        % Revert the sufficient statistics.
        n(x(r))        = n(x(r)) - 1;
        z(x(r))        = z(x(r)) - Y(r);
        if r > 1
          N(x(r-1),x(r)) = N(x(r-1),x(r)) - 1;
        end
        if r < t
          N(x(r),x(r+1)) = N(x(r),x(r+1)) - 1;
        end
      end

      % We now can add the rth term in the expression for the
      % importance weight, since we have the log p(x|y) terms.
      c = max(max(Rd),max(Rn));
      w = w + sum(exp(Rn-c))/sum(exp(Rd-c));
      
      if isnan(w)
        error('Stop!');
      end
      
      % Put xr back into the sufficient statistics.
      x       = X(si,1:t);
      n(x(r)) = n(x(r)) + 1;
      z(x(r)) = z(x(r)) + Y(r);
      if r > 1
        N(x(r-1),x(r)) = N(x(r-1),x(r)) + 1;
      end
      if r < t
        N(x(r),x(r+1)) = N(x(r),x(r+1)) + 1;
      end
    end
    W(si) = W(si)./w;
    
    if isnan(W(si))
      error('');
    end
  end
  
  % Normalize the importance weights.
  if isnan(sum(W))
    error('Stop!');
  end
  W = W / sum(W);
  
  % Measure the effective sample size.
  ess    = 1/sum(W.^2);
  ESS(t) = ess;
  if isnan(ess)
    error('Stop!');
  end
  fprintf('<%0.3f> ', ess/s);

  % Resample if necessary.
  if ess/s < esst
    fprintf('*R* ');
    X = X(resampstr(W),:);
    W = ones(s,1)/s;
  end
  
  % Run the Gibbs sampler a few more times.
  for si = 1:s
    X(si,1:t) = randgibbs(Y(1:t),X(si,1:t),a,b,t);
  end 
end
fprintf('\n');

% We should have a weighted sample that approximates the true
% distribution. To make things simpler, we resample the at the final step
% so that the weights remain uniform.
if ess < s
  X = X(resampstr(W),:);
  W = ones(s,1)/s;
end

% Compute the expectations of the hidden states and the model
% parameters. 
EX  = zeros(K,T);
EL  = zeros(1,K);
Ep0 = zeros(1,K);
Ep  = zeros(K,K);

% Store the Poisson rates.
Ls = zeros(s,K);

% Repeat for each particle.
for si = 1:s
  x = X(si,:);
  
  % Collect the sufficient statistics.
  for i = 1:K
    ts     = find(x == i);
    n(i)   = length(ts);
    z(i)   = sum(Y(ts));
    ts     = find(x(1:T-1) == i);
    N(i,:) = hist(x(ts+1),1:K);
  end
  
  % Enforce the ordering on the Poisson rates. 
  [ans I] = sort((z+a)./(n+b));
  X       = I(X);
  n       = n(I);
  z       = z(I);
  N       = N(I,I);

  EX  = EX  + (repmat(x,K,1) == repmat([1:K]',1,T));
  EL  = EL  + (z+a)./(n+b);
  Ep0 = Ep0 + ((x(1)==1:K)+1)/(K+1);
  Ep  = Ep  + (N+1)./repmat((K+n-(x(T)==1:K))',1,K);  
  
  % Get a sample for lambda.
  for i = 1:K
    Ls(si,i) = gengamma(z(i)+a(i),n(i)+b(i));
  end
end

% Normalize the sufficient statistics.
EX  = EX  / s;
EL  = EL  / s;
Ep0 = Ep0 / s;
Ep  = Ep  / s;

fprintf('Poisson rates:\n');
disp(EL');

fprintf('Transition matrix:\n');
disp(Ep');

figure(1);
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','');
set(gcf,'Color','white');
clf

% Plot data.
subplot(3,1,1);
colormap winter
bar(1:T,Y,1,'EdgeColor','red','FaceColor','red');
xlabel('t');
ylabel('# of movements');
set(gca,'Box','off');

% Plot Pr(X).
subplot(3,1,2);
colormap default
bar(EX(2,:),1,'g','EdgeColor','none');
xlabel('t');
ylabel('Pr(X=i)');
set(gca,'Box','off');

% Plot evolution of effective sample size over time.
subplot(3,1,3);
cla
colormap default
plot(1:t,ESS);
xlabel('s');
ylabel('Effective sample size');
set(gca,'Box','off');

% Plot the Poisson rate distribution.
figure(2);
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','');
set(gcf,'Color','white');
clf
subplot(1,2,1);
hist(Ls(:,1),20);
xlabel('\lambda_1');
ylabel('p(\lambda_1)');

subplot(1,2,2);
hist(Ls(:,2),20);
xlabel('\lambda_2');
ylabel('p(\lambda_2)');
