% Note that the observations are contained in the matrix Y.

K = 2;        % The number of mixture components.
a = [1 1];    % Prior on Poisson rates.
b = [1 1];
s = 1000;     % Number of samples to generate.

% Get the number of observations.
T = length(Y);

% Initialize the hidden states.
X = randint(1,K,1,T);
n = zeros(1,K);
N = zeros(K,K);
z = zeros(1,K);

% Keep track of the expectations of the model parameters.
EX  = zeros(K,T);
EL  = zeros(1,K);
Ep0 = zeros(1,K);
Ep  = zeros(K,K);

% Keep track of the evolution of the Poisson rates over time.
Ls = zeros(s,K);

% Repeat for each sample.
for si = 1:s
  fprintf('%i ', si);

  % Collect the sufficient statistics:
  %   * n(i) is the number of observations assigned to mixture component i.
  %   * N(i,j) is the number of consecutive observations assigned to
  %     mixture components (i,j).
  %   * z(i) is the sum of observations assigned to mixture component i.
  for i = 1:K
    ts     = find(X == i);
    n(i)   = length(ts);
    z(i)   = sum(Y(ts));
    ts     = find(X(1:T-1) == i);
    N(i,:) = hist(X(ts+1),1:K);
  end

  % Enforce the ordering on the Poisson rates. 
  [ans I] = sort((z+a)./(n+b));
  X       = I(X);
  n       = n(I);
  z       = z(I);
  N       = N(I,I);
  EX      = EX(I,:);
  
  % Update the expectations.
  EX  = EX  + (repmat(X,K,1) == repmat([1:K]',1,T));
  EL  = EL  + (z+a)./(n+b);
  Ep0 = Ep0 + ((X(1)==1:K)+1)/(K+1);
  Ep  = Ep  + (N+1)./repmat((K+n-(X(T)==1:K))',1,K);
  
  % Get a sample for lambda.
  for i = 1:K
    Ls(si,i) = gengamma(z(i)+a(i),n(i)+b(i));
  end

  % Perturb a single site xt.
  for t = randperm(T)
  
    % Remove xt from the sufficient statistics.
    n(X(t)) = n(X(t)) - 1;
    if t > 1
      N(X(t-1),X(t)) = N(X(t-1),X(t)) - 1;
    end
    if t < T
      N(X(t),X(t+1)) = N(X(t),X(t+1)) - 1;
    end
    z(X(t)) = z(X(t)) - Y(t);
  
    % Compute the full conditional for xt. Repeat over all possible
    % assignments to xt. nT is the number of observations assigned to
    % mixture component i, with the exception of the last observation at
    % time step T.
    nT       = n;
    nT(X(T)) = n(X(T)) - 1;
    for i = 1:K
      
      % Set the new proposed sufficient statistics.
      n(i) = n(i) + 1;
      z(i) = z(i) + Y(t);
      if t > 1
        N(X(t-1),i) = N(X(t-1),i) + 1;
      end
      if t < T
        N(i,X(t+1)) = N(i,X(t+1)) + 1;
        nT(i)       = nT(i)       + 1;
      end
      C(i) = sum(gammaln(z+a)) - sum((z+a).*log(n+b)) + ...
             sum(sum(gammaln(N+1))) - sum(gammaln(K+nT));
      
      % Revert the sufficient statistics.
      n(i) = n(i) - 1;
      z(i) = z(i) - Y(t);
      if t > 1
        N(X(t-1),i) = N(X(t-1),i) - 1;
      end
      if t < T
        N(i,X(t+1)) = N(i,X(t+1)) - 1;
        nT(i)       = nT(i)       - 1;
      end
    end
    
    C    = exp(C-max(C));
    X(t) = sample(C);
    
    % Update the sufficient statistics according to sample xt.
    n(X(t)) = n(X(t)) + 1;
    if t > 1
      N(X(t-1),X(t)) = N(X(t-1),X(t)) + 1;
    end
    if t < T
      N(X(t),X(t+1)) = N(X(t),X(t+1)) + 1;
    end
    z(X(t)) = z(X(t)) + Y(t);
  end
end
fprintf('\n');

% Normalize the sufficient statistics.
EX  = EX  / s;
EL  = EL  / s;
Ep0 = Ep0 / s;
Ep  = Ep  / s;

figure(1);
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','');
set(gcf,'Color','white');
clf

% Plot data.
subplot(3,1,1);
colormap winter
bar(1:T,Y,1,'EdgeColor','red','FaceColor','red');
xlabel('t');
ylabel('# of movements');
set(gca,'Box','off');

% Plot Pr(X).
subplot(3,1,2);
colormap default
bar(EX(2,:),1,'g','EdgeColor','none');
xlabel('t');
ylabel('Pr(X=i)');
set(gca,'Box','off');

% Plot evolution of Poisson rates over time.
subplot(3,1,3);
cla
colormap default
hold on
for i = 1:K
  plot(1:s,Ls);
end
hold off
xlabel('s');
ylabel('\lambda');
set(gca,'Box','off');

fprintf('Poisson rates:\n');
disp(EL');

fprintf('Transition matrix:\n');
disp(Ep');

% Plot the Poisson rate distribution.
figure(2);
set(gcf,'MenuBar','none');
set(gcf,'NumberTitle','off');
set(gcf,'Name','');
set(gcf,'Color','white');
clf
subplot(1,2,1);
hist(Ls(:,1),20);
xlabel('\lambda_1');
ylabel('p(\lambda_1)');

subplot(1,2,2);
hist(Ls(:,2),20);
xlabel('\lambda_2');
ylabel('p(\lambda_2)');
