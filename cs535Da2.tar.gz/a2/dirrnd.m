% DIRRND(A) generates deviates from the Dirichlet distribution parameterized
% by A, such that A >= 0.

function x = dirrnd (a)

  % Get the number of variables.
  n = length(a);
  x = zeros(n,1);
  
  for i = 1:n
    x(i) = gengamma(a(i),1);
  end

  % Normalize so the probabilities sum to 1.
  x = x / sum(x);
  